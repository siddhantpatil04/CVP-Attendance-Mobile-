/**
 * Phone builds only (see metro.config.js): every `import ... from 'react-native'` inside src/ resolves to this file.
 * It re-exports all of React Native, but Text and TextInput get the app font as their DEFAULT font
 * (text that sets its own fontFamily, like the icons, keeps it).
 * On the web the same is done in globalFont.ts.
 */
import React from 'react';
import * as RN from 'react-native';
import { APP_FONT } from './fontFamily';

export * from 'react-native';

const withFont = (style: any) => {
  const own = RN.StyleSheet.flatten(style);
  return own && own.fontFamily ? style : [{ fontFamily: APP_FONT }, style];
};

export function Text(props: React.ComponentProps<typeof RN.Text>) {
  return <RN.Text {...props} style={withFont(props.style)} />;
}

export function TextInput(props: React.ComponentProps<typeof RN.TextInput>) {
  return <RN.TextInput {...props} style={withFont(props.style)} />;
}
