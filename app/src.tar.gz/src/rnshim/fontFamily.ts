import { Platform } from 'react-native';

/**
 * The app font: Arial Black.
 *  - Windows desktop app / browser: Arial Black (installed with Windows and macOS).
 *  - Android: the heaviest system font ("sans-serif-black", Roboto Black).
 *  - iPhone: Arial Bold (iOS has no Arial Black).
 * Arial Black is a licensed font, so it is not bundled into the phone app.
 */
export const APP_FONT: string | undefined = Platform.select({
  web: "'Arial Black', 'Arial Bold', Arial, sans-serif",
  android: 'sans-serif-black',
  ios: 'Arial-BoldMT',
  default: undefined,
});
