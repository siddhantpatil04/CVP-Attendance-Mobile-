﻿import { Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { C } from '../theme';

/**
 * A section whose content opens and closes from its heading (a drop-down).
 * The content stays mounted while closed, so anything typed in it is not lost.
 */
export function Collapsible({ title, note, summary, defaultOpen = false, children }: {
  title: string; note?: string; summary?: string; defaultOpen?: boolean; children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <View style={{ marginTop: 6 }}>
      <Pressable style={st.head} onPress={() => setOpen(!open)}>
        <View style={{ flex: 1 }}>
          <Text style={st.title}>{title}</Text>
          
        </View>
        {summary ? <Text style={st.summary}>{summary}</Text> : null}
        <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={18} color={C.muted} />
      </Pressable>
      <View style={open ? undefined : st.hidden}>{children}</View>
    </View>
  );
}

const st = StyleSheet.create({
  head: {
    flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.white, borderRadius: 14,
    borderWidth: 1, borderColor: C.line, paddingVertical: 12, paddingHorizontal: 14, marginBottom: 8,
  },
  title: { fontSize: 15, fontWeight: '800', color: '#102A45' },
  note: { fontSize: 12, color: C.muted, marginTop: 1 },
  summary: { fontSize: 12, fontWeight: '700', color: C.blue },
  hidden: { display: 'none' },
});

