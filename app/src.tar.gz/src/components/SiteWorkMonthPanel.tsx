import React, { useMemo } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { DailyReport } from '../lib/api';
import { fmtISODate } from '../lib/time';
import { C } from '../theme';
import { Card, Empty, Pill } from './ui';

/** The work text of one site visit of a Daily Report */
const workOf = (s: DailyReport['daily_report_sites'][number]) =>
  [s.sub_work, s.work_description].map((x) => (x ?? '').trim()).filter(Boolean).join(' - ');

/** One row per employee per day: which site(s) and which work (taken from the submitted / saved Daily Reports) */
export function siteWorkRows(reports: DailyReport[]) {
  const out: { Date: string; Employee: string; 'Employee ID': string; Site: string; Work: string; Status: string }[] = [];
  const list = [...reports].sort((a, b) => (a.employee?.full_name ?? '').localeCompare(b.employee?.full_name ?? '') || a.report_date.localeCompare(b.report_date));
  for (const r of list) {
    const visits = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
    if (visits.length === 0) {
      out.push({ Date: fmtISODate(r.report_date), Employee: r.employee?.full_name ?? '', 'Employee ID': r.employee?.username ?? '', Site: '-', Work: '-', Status: r.status });
      continue;
    }
    for (const v of visits) {
      out.push({ Date: fmtISODate(r.report_date), Employee: r.employee?.full_name ?? '', 'Employee ID': r.employee?.username ?? '',
        Site: v.site_name || '-', Work: workOf(v) || '-', Status: r.status });
    }
  }
  return out;
}

/** Admin / HR: monthly site report - for every employee, each day's site and work */
export function SiteWorkMonthPanel({ rows }: { rows: DailyReport[] | null }) {
  const groups = useMemo(() => {
    const m = new Map<string, { name: string; code: string; days: DailyReport[] }>();
    for (const r of rows ?? []) {
      const g = m.get(r.user_id) ?? { name: r.employee?.full_name ?? 'Employee', code: r.employee?.username ?? '', days: [] };
      g.days.push(r);
      m.set(r.user_id, g);
    }
    return [...m.values()].sort((a, b) => a.name.localeCompare(b.name)).map((g) => ({ ...g, days: g.days.sort((a, b) => a.report_date.localeCompare(b.report_date)) }));
  }, [rows]);

  if (!rows) return <ActivityIndicator style={{ margin: 20 }} color={C.blue} />;
  if (groups.length === 0) return <Card><Empty icon="location-outline" text="No site work recorded in this month. It is taken from the employees' Daily Reports." /></Card>;
  return (
    <View>
      {groups.map((g) => (
        <Card key={g.code + g.name}>
          <View style={st.head}>
            <Text style={st.name}>{g.name} <Text style={st.id}>({g.code})</Text></Text>
            <Pill text={`${g.days.length} day(s)`} tone="blue" />
          </View>
          {g.days.map((r) => {
            const visits = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
            return (
              <View key={r.id} style={st.day}>
                <Text style={st.date}>{fmtISODate(r.report_date)}</Text>
                <View style={{ flex: 1, minWidth: 0 }}>
                  {visits.length === 0 ? <Text style={st.work}>No site entered</Text> : visits.map((v) => (
                    <View key={v.id} style={{ marginBottom: 3 }}>
                      <Text style={st.site}>{v.site_name || '-'}</Text>
                      <Text style={st.work}>{workOf(v) || 'Work not written'}</Text>
                    </View>
                  ))}
                </View>
              </View>
            );
          })}
        </Card>
      ))}
    </View>
  );
}

const st = StyleSheet.create({
  head: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  name: { fontSize: 15, fontWeight: '800', color: '#102A45', flex: 1 },
  id: { fontSize: 12, fontWeight: '600', color: C.muted },
  day: { flexDirection: 'row', gap: 12, paddingVertical: 7, borderTopWidth: 1, borderTopColor: '#EEF3F8' },
  date: { width: 84, fontSize: 12.5, fontWeight: '800', color: '#3A5068' },
  site: { fontSize: 13.5, fontWeight: '800', color: '#0F5F3A' },
  work: { fontSize: 12.5, color: '#203951', lineHeight: 18 },
});
