import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { navigationRef } from '../navigation';
import { useAuth } from '../lib/auth';
import { askWebNotify, showWebNotify } from '../lib/notifications';
import { configurePush, listenPush, registerPush } from '../lib/push';
import { NotificationContext, useNotifications } from '../lib/notifications';
import { C } from '../theme';

/** Opens the screen named in a notification (MyLeave / Regularization). Employees have Leave as a tab, Admin / HR as a page. */
export function openNotificationLink(link: string | null, isAdmin: boolean) {
  if (!link || !navigationRef.isReady()) return;
  try {
    if (link === 'MyLeave') { if (isAdmin) navigationRef.navigate('MyLeave'); else navigationRef.navigate('Tabs', { screen: 'Leave' }); }
    else if (link === 'Regularization') navigationRef.navigate('Regularization');
    else navigationRef.navigate(link as any);
  } catch { /* unknown screen: ignore */ }
}

/**
 * Lives inside the signed-in app (renders only the small in-app banner):
 *  - phone: asks for permission once, registers this phone, shows a banner when a notification arrives while the app is open,
 *    opens the screen when a notification is tapped (also from a closed app);
 *  - desktop / web: shows a browser pop-up for a new notification while the app is open.
 */
export function NotificationsHost({ children }: { children: React.ReactNode }) {
  const { profile, isAdmin } = useAuth();
  const [banner, setBanner] = React.useState<{ title: string; body: string; link: string | null } | null>(null);
  const timer = React.useRef<any>(null);
  const show = React.useCallback((b: { title: string; body: string; link: string | null }) => {
    setBanner(b); clearTimeout(timer.current); timer.current = setTimeout(() => setBanner(null), 6000);
  }, []);

  // phone: register + listeners
  React.useEffect(() => {
    if (!profile || Platform.OS === 'web') return;
    void configurePush();
    void registerPush();
    const off = listenPush((n) => show(n), (link) => openNotificationLink(link, isAdmin));
    return off;
  }, [profile?.id]);   // eslint-disable-line react-hooks/exhaustive-deps

  // desktop / web: ask once, then a pop-up for each new row
  React.useEffect(() => { if (profile && Platform.OS === 'web') void askWebNotify(); }, [profile?.id]);
  // Realtime inserts feed the bell AND (on the web) the pop-up. On the phone the push itself / the banner above does it.
  const list = useNotifications((n) => { if (Platform.OS === 'web') showWebNotify(n, () => openNotificationLink(n.link, isAdmin)); });

  return (
    <NotificationContext.Provider value={list}>
      {children}
      {banner ? <Banner2 banner={banner} close={() => setBanner(null)} isAdmin={isAdmin} /> : null}
    </NotificationContext.Provider>
  );
}

function Banner2({ banner, close, isAdmin }: { banner: { title: string; body: string; link: string | null }; close: () => void; isAdmin: boolean }) {
  const setBanner = (_: null) => close();
  return (
    <View pointerEvents="box-none" style={st.wrap}>
      <Pressable style={st.card} onPress={() => { const l = banner.link; setBanner(null); openNotificationLink(l, isAdmin); }} accessibilityRole="button">
        <Ionicons name="notifications" size={20} color={C.blue} />
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.title} numberOfLines={1}>{banner.title}</Text>
          <Text style={st.body} numberOfLines={2}>{banner.body}</Text>
        </View>
        <Pressable onPress={() => setBanner(null)} hitSlop={10}><Ionicons name="close" size={18} color={C.muted} /></Pressable>
      </Pressable>
    </View>
  );
}

const st = StyleSheet.create({
  wrap: { position: 'absolute', top: Platform.OS === 'web' ? 12 : 48, left: 12, right: 12, alignItems: 'center', zIndex: 999 },
  card: { width: '100%', maxWidth: 520, flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#fff', borderRadius: 14, padding: 12, borderWidth: 1, borderColor: '#D7E6F7', shadowColor: '#06253F', shadowOpacity: 0.18, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 8 },
  title: { fontWeight: '800', color: '#102A45', fontSize: 14 },
  body: { color: '#3A5068', fontSize: 12.5, marginTop: 2 },
});
