import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import {
  ActivityIndicator, Platform, Pressable, RefreshControl, ScrollView, StyleProp, StyleSheet,
  Text, TextInput, TextInputProps, View, ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C, radius, shadow, statusTone, Tone, toneColors } from '../theme';
import { initials } from '../lib/time';
import { CONTENT_MAX_WIDTH, useIsDesktop } from '../lib/layout';

export type IconName = React.ComponentProps<typeof Ionicons>['name'];

// ---------------------------------------------------------------- layout
export function Screen({
  children, refreshing, onRefresh, scroll = true, padded = true,
}: {
  children: React.ReactNode; refreshing?: boolean; onRefresh?: () => void;
  scroll?: boolean; padded?: boolean;
}) {
  const desktop = useIsDesktop();
  // Desktop: wider padding and content centred with a max width so it doesn't stretch on big monitors
  const pad = desktop ? 24 : 16; // 16 px side gutter on phones
  const inner = desktop ? { width: '100%' as const, maxWidth: CONTENT_MAX_WIDTH, alignSelf: 'center' as const } : null;
  const body = scroll ? (
    <ScrollView
      style={Platform.OS === 'web' ? { flex: 1, minHeight: 0, minWidth: 0 } : undefined}   // web only: the one vertical scroll area of the page
      contentContainerStyle={[padded && { padding: pad, paddingBottom: Platform.OS === 'web' ? 40 : 28 }]}
      keyboardShouldPersistTaps="handled"
      refreshControl={onRefresh ? <RefreshControl refreshing={!!refreshing} onRefresh={onRefresh} tintColor={C.blue} /> : undefined}
    >
      {inner ? <View style={inner}>{children}</View> : children}
    </ScrollView>
  ) : (
    <View style={[{ flex: 1 }, padded && { padding: pad }]}>
      {inner ? <View style={[inner, { flex: 1 }]}>{children}</View> : children}
    </View>
  );
  return <SafeAreaView edges={['left', 'right']} style={{ flex: 1, backgroundColor: C.bg }}>{body}</SafeAreaView>;
}

export function Card({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[s.card, style]}>{children}</View>;
}

export function Row({ children, style, gap = 10 }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; gap?: number }) {
  return <View style={[{ flexDirection: 'row', alignItems: 'center', gap }, style]}>{children}</View>;
}

/** One half of a two-input row: <Row style={{ alignItems: 'flex-start' }}><Col>..</Col><Col>..</Col></Row> */
export function Col({ children }: { children: React.ReactNode }) {
  return <View style={{ flex: 1, minWidth: 0 }}>{children}</View>;
}

export function SectionTitle({ title, note, right }: { title: string; note?: string; right?: React.ReactNode }) {
  return (
    <View style={s.sectionRow}>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.sectionTitle}>{title}</Text>
        
      </View>
      {right}
    </View>
  );
}

// ---------------------------------------------------------------- text
export function H1({ children }: { children: React.ReactNode }) {
  return <Text style={s.h1}>{children}</Text>;
}
export function Muted({ children, style }: { children: React.ReactNode; style?: object }) {
  return <Text style={[s.muted, style]}>{children}</Text>;
}
export function Label({ children }: { children: React.ReactNode }) {
  return <Text style={s.label}>{children}</Text>;
}

// ---------------------------------------------------------------- hero banner
export function Hero({ kicker, title, subtitle, right }: {
  kicker?: string; title: string; subtitle?: string; right?: React.ReactNode;
}) {
  return (
    <View style={s.hero}>
      <View style={s.heroGlow} />
      <View style={{ flex: 1, minWidth: 0 }}>
        {kicker ? <Text style={s.heroKicker}>{kicker}</Text> : null}
        <Text style={s.heroTitle}>{title}</Text>
        {subtitle ? <Text style={s.heroSub}>{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  );
}

// ---------------------------------------------------------------- buttons
export function Button({
  title, onPress, variant = 'primary', icon, loading, disabled, style, small,
}: {
  title: string; onPress?: () => void; variant?: 'primary' | 'secondary' | 'danger' | 'success' | 'ghost';
  icon?: IconName; loading?: boolean; disabled?: boolean; style?: StyleProp<ViewStyle>; small?: boolean;
}) {
  const v = {
    primary: { bg: C.blue, fg: C.white, border: C.blue },
    success: { bg: C.green, fg: C.white, border: C.green },
    danger: { bg: C.white, fg: C.red, border: '#F6C9CD' },
    secondary: { bg: C.white, fg: C.ink, border: '#D8E3EF' },
    ghost: { bg: 'transparent', fg: C.blue, border: 'transparent' },
  }[variant];
  const off = disabled || loading;
  return (
    <Pressable
      onPress={off ? undefined : onPress}
      style={({ pressed }) => [
        s.btn, small && s.btnSmall,
        { backgroundColor: v.bg, borderColor: v.border, opacity: off ? 0.5 : pressed ? 0.85 : 1 },
        style,
      ]}
      accessibilityRole="button"
      accessibilityState={{ disabled: !!off }}
    >
      {loading ? (
        <ActivityIndicator color={v.fg} />
      ) : (
        <>
          {icon ? <Ionicons name={icon} size={small ? 14 : 16} color={v.fg} /> : null}
          <Text style={[s.btnText, small && { fontSize: 12 }, { color: v.fg }]}>{title}</Text>
        </>
      )}
    </Pressable>
  );
}

// ---------------------------------------------------------------- inputs
export function Field({ label, ...props }: TextInputProps & { label?: string }) {
  return (
    <View style={{ marginBottom: 8 }}>
      {label ? <Label>{label}</Label> : null}
      <TextInput placeholderTextColor="#9AA8B8" {...props} style={[s.input, props.multiline && { minHeight: 80, textAlignVertical: 'top' }, props.style]} />
    </View>
  );
}

/** Dropdown list: a real <select> on the web, tappable chips on phones */
export function Dropdown<T extends string>({ label, options, value, onChange, disabled }: {
  label?: string; options: T[]; value: T; onChange: (v: T) => void; disabled?: boolean;
}) {
  return (
    <View style={{ marginBottom: 8 }}>
      {label ? <Label>{label}</Label> : null}
      {Platform.OS === 'web' ? (
        React.createElement(
          'select',
          {
            value, disabled,
            onChange: (e: { target: { value: string } }) => onChange(e.target.value as T),
            style: {
              backgroundColor: '#EAF3FF', border: '1px solid #B9D4F6', borderRadius: 12, padding: '0 12px', boxSizing: 'border-box', fontWeight: 700,
              height: 44, fontSize: 14, color: '#0E3F7A', width: '100%', fontFamily: 'inherit', cursor: 'pointer',
            },
          },
          options.map((o) => React.createElement('option', { key: o, value: o }, o)),
        )
      ) : (
        <Chips<T> options={options} value={value} onChange={disabled ? () => {} : onChange} />
      )}
    </View>
  );
}

export function Segmented<T extends string>({ options, value, onChange }: {
  options: { value: T; label: string }[]; value: T; onChange: (v: T) => void;
}) {
  return (
    <View style={s.seg}>
      {options.map((o) => (
        <Pressable key={o.value} onPress={() => onChange(o.value)} style={[s.segItem, value === o.value && s.segActive]}>
          <Text style={[s.segText, value === o.value && { color: C.blue }]} numberOfLines={1}>{o.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}

export function Toggle({ label, value, onChange, note }: { label: string; value: boolean; onChange: (v: boolean) => void; note?: string }) {
  return (
    <Pressable onPress={() => onChange(!value)} style={s.toggleRow}>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={{ color: C.ink, fontWeight: '700', fontSize: 13.5, lineHeight: 19 }}>{label}</Text>
        {note ? <Muted>{note}</Muted> : null}
      </View>
      <View style={[s.toggle, value && { backgroundColor: C.green }]}>
        <View style={[s.knob, value && { transform: [{ translateX: 18 }] }]} />
      </View>
    </Pressable>
  );
}

export function Chips<T extends string>({ options, value, onChange }: {
  options: T[]; value: T; onChange: (v: T) => void;
}) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
      {options.map((o) => (
        <Pressable key={o} onPress={() => onChange(o)} style={[s.chip, value === o && s.chipActive]}>
          <Text style={[s.chipText, value === o && { color: C.white }]}>{o}</Text>
        </Pressable>
      ))}
    </View>
  );
}

// ---------------------------------------------------------------- display
export function Pill({ text, tone }: { text: string; tone?: Tone }) {
  const t = toneColors[tone ?? statusTone(text)];
  return (
    <View style={[s.pill, { backgroundColor: t.bg }]}>
      <Text style={[s.pillText, { color: t.fg }]} numberOfLines={1}>{text}</Text>
    </View>
  );
}

export function Kpi({ label, value, icon, tone = 'blue', note }: {
  label: string; value: string | number; icon: IconName; tone?: Tone; note?: string;
}) {
  const t = toneColors[tone];
  return (
    <View style={s.kpi}>
      <View style={[s.kpiIcon, { backgroundColor: t.bg }]}>
        <Ionicons name={icon} size={17} color={t.fg} />
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.kpiLabel} numberOfLines={1}>{label}</Text>
        <Text style={s.kpiValue} numberOfLines={1}>{value}</Text>
        {note ? <Text style={s.kpiNote} numberOfLines={1}>{note}</Text> : null}
      </View>
    </View>
  );
}

export function KpiGrid({ children }: { children: React.ReactNode }) {
  const desktop = useIsDesktop();
  // Phone: 2 per row. Desktop: all in one row (up to 4), 6 to 3 + 3, others to 4 per row
  const n = React.Children.toArray(children).filter(Boolean).length;
  const cols = !desktop ? 2 : n <= 4 ? Math.max(n, 1) : n % 3 === 0 ? 3 : 4;
  const cell = { width: `${100 / cols}%` as const };
  return <View style={s.kpiGrid}>{React.Children.map(children, (c) => (c ? <View style={[s.kpiCell, cell]}>{c}</View> : null))}</View>;
}

export function Avatar({ name, size = 42 }: { name?: string | null; size?: number }) {
  return (
    <View style={[s.avatar, { width: size, height: size, borderRadius: size / 2 }]}>
      <Text style={{ color: '#07536C', fontWeight: '800', fontSize: size * 0.36 }}>{initials(name)}</Text>
    </View>
  );
}

export function InfoTile({ label, value, style }: { label: string; value?: string | null; style?: any }) {
  return (
    <View style={[s.info, style]}>
      <Text style={s.infoLabel}>{label}</Text>
      <Text style={s.infoValue} numberOfLines={1}>{value || '-'}</Text>
    </View>
  );
}

export function ListItem({
  title, subtitle, right, onPress, left, icon,
}: {
  title: string; subtitle?: string; right?: React.ReactNode; onPress?: () => void;
  left?: React.ReactNode; icon?: IconName;
}) {
  return (
    <Pressable onPress={onPress} disabled={!onPress} style={({ pressed }) => [s.listItem, pressed && onPress && { backgroundColor: '#F1F6FC' }]}>
      {left ?? (icon ? (
        <View style={s.listIcon}><Ionicons name={icon} size={19} color={C.blue} /></View>
      ) : null)}
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.listTitle} numberOfLines={1}>{title}</Text>
        {subtitle ? <Text style={s.listSub} numberOfLines={2}>{subtitle}</Text> : null}
      </View>
      {/* the wrapper keeps a Pill (which aligns itself to the top) centred with the row, and never squeezed */}
      {right ? <View style={{ flexShrink: 0, alignItems: 'flex-end', justifyContent: 'center' }}>{right}</View> : null}
      {onPress ? <Ionicons name="chevron-forward" size={18} color="#A7B4C3" /> : null}
    </Pressable>
  );
}

export function Empty({ text, icon = 'file-tray-outline' }: { text: string; icon?: IconName }) {
  return (
    <View style={s.empty}>
      <Ionicons name={icon} size={30} color="#A7B4C3" />
      <Text style={s.emptyText}>{text}</Text>
    </View>
  );
}

export function Loading() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40, backgroundColor: C.bg }}>
      <ActivityIndicator size="large" color={C.blue} />
    </View>
  );
}

export function Banner({ text, tone = 'blue', icon = 'information-circle' }: { text: string; tone?: Tone; icon?: IconName }) {
  const t = toneColors[tone];
  return (
    <View style={[s.banner, { backgroundColor: t.bg }]}>
      <Ionicons name={icon} size={18} color={t.fg} style={{ marginTop: 1 }} />
      <Text style={[s.bannerText, { color: t.fg }]}>{text}</Text>
    </View>
  );
}

export function LiveDot({ live }: { live: boolean }) {
  return (
    <View style={[s.livePill, { backgroundColor: live ? C.greenSoft : '#EEF2F7' }]}>
      <View style={[s.liveDot, { backgroundColor: live ? C.green : '#A7B4C3' }]} />
      <Text style={{ fontSize: 11, fontWeight: '800', color: live ? C.green : C.muted }}>{live ? 'LIVE' : 'CONNECTING'}</Text>
    </View>
  );
}

export const s = StyleSheet.create({
  // Spacing scale used everywhere: 4 / 8 / 12 / 16 / 24. Text sizes are tuned for the wide, heavy Arial Black.
  card: { backgroundColor: C.card, borderRadius: radius.lg, borderWidth: 1, borderColor: C.line, padding: 14, marginBottom: 12, ...shadow },
  sectionRow: { flexDirection: 'row', alignItems: 'flex-end', marginTop: 12, marginBottom: 8, paddingHorizontal: 2 },
  sectionTitle: { fontSize: 14.5, lineHeight: 20, fontWeight: '800', color: '#102944' },
  sectionNote: { fontSize: 11.5, lineHeight: 16, color: C.muted, marginTop: 2 },
  h1: { fontSize: 20, lineHeight: 26, fontWeight: '800', color: C.ink, letterSpacing: -0.3 },
  muted: { fontSize: 12, color: C.muted, lineHeight: 17 },
  label: { fontSize: 11.5, lineHeight: 16, fontWeight: '700', color: '#3A5068', marginBottom: 6 },
  hero: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.navy, borderRadius: radius.lg, padding: 16, marginBottom: 16, overflow: 'hidden', ...shadow },
  heroGlow: { position: 'absolute', right: -60, top: -60, width: 200, height: 200, borderRadius: 100, backgroundColor: 'rgba(11,124,255,0.25)' },
  heroKicker: { color: '#A8DAF5', fontSize: 10.5, lineHeight: 15, fontWeight: '800', letterSpacing: 1.2 },
  heroTitle: { color: C.white, fontSize: 20, lineHeight: 26, fontWeight: '800', marginTop: 4, letterSpacing: -0.3 },
  heroSub: { color: '#D6E8F3', fontSize: 12, lineHeight: 17, marginTop: 6 },
  btn: { minHeight: 44, borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  btnSmall: { minHeight: 34, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10 },
  btnText: { fontSize: 13, lineHeight: 17, fontWeight: '800', textAlign: 'center', flexShrink: 1 },
  input: { backgroundColor: '#FBFDFF', borderWidth: 1, borderColor: '#B9D4F6', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 11, minHeight: 44, fontSize: 14, color: C.ink },
  seg: { flexDirection: 'row', backgroundColor: '#EAF0F7', borderRadius: 12, padding: 3, marginBottom: 12 },
  segItem: { flex: 1, minWidth: 0, minHeight: 38, paddingVertical: 8, paddingHorizontal: 6, alignItems: 'center', justifyContent: 'center', borderRadius: 10 },
  segActive: { backgroundColor: C.white, ...shadow, elevation: 1 },
  segText: { fontWeight: '800', color: '#62738A', fontSize: 12.5, lineHeight: 17, textAlign: 'center' },
  toggleRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12 },
  toggle: { width: 44, height: 26, borderRadius: 13, backgroundColor: '#CBD6E2', padding: 3 },
  knob: { width: 20, height: 20, borderRadius: 10, backgroundColor: C.white },
  chip: { minHeight: 36, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: '#D8E3EF', backgroundColor: C.white, alignItems: 'center', justifyContent: 'center' },
  chipActive: { backgroundColor: C.blue, borderColor: C.blue },
  chipText: { fontWeight: '700', color: '#3A5068', fontSize: 12.5, lineHeight: 17 },
  pill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, alignSelf: 'flex-start', flexShrink: 0 },
  pillText: { fontSize: 11, lineHeight: 15, fontWeight: '800' },
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -6, marginBottom: 8 },
  kpiCell: { width: '50%', padding: 6 },
  kpi: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 68, ...shadow, elevation: 2 },
  kpiIcon: { width: 36, height: 36, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  kpiLabel: { fontSize: 11, lineHeight: 15, color: '#77889D', fontWeight: '700' },
  kpiValue: { fontSize: 15, lineHeight: 21, color: '#0E2742', fontWeight: '800', marginTop: 1 },
  kpiNote: { fontSize: 10, lineHeight: 14, color: '#7E8DA0', marginTop: 1 },
  avatar: { backgroundColor: '#D4F4F2', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#F4F9FD' },
  info: { flex: 1, minWidth: '45%', backgroundColor: '#F8FBFF', borderWidth: 1, borderColor: '#EDF2F7', borderRadius: 12, padding: 10 },
  infoLabel: { fontSize: 9.5, lineHeight: 13, color: '#8493A5', fontWeight: '700', letterSpacing: 0.4, textTransform: 'uppercase' },
  infoValue: { fontSize: 12.5, lineHeight: 17, color: '#17314D', fontWeight: '700', marginTop: 3 },
  listItem: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 56, paddingVertical: 10, paddingHorizontal: 6, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  listIcon: { width: 38, height: 38, borderRadius: 11, backgroundColor: C.blueSoft, alignItems: 'center', justifyContent: 'center' },
  listTitle: { fontSize: 14, lineHeight: 19, fontWeight: '700', color: '#102A45' },
  listSub: { fontSize: 12, lineHeight: 17, color: C.muted, marginTop: 2 },
  empty: { alignItems: 'center', padding: 28, gap: 10 },
  emptyText: { color: C.muted, textAlign: 'center', fontSize: 12.5, lineHeight: 18 },
  banner: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, padding: 12, borderRadius: 12, marginBottom: 12 },
  bannerText: { flex: 1, minWidth: 0, fontWeight: '600', fontSize: 12.5, lineHeight: 18 },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999 },
  liveDot: { width: 8, height: 8, borderRadius: 4 },
});
