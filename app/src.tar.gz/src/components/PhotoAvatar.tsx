import React, { useEffect, useState } from 'react';
import { Image } from 'react-native';
import { api } from '../lib/api';
import { supabase } from '../lib/supabase';
import { Avatar } from './ui';

// signed links last an hour: keep them for 50 minutes so a list of employees does not ask for each photo again and again
const cache = new Map<string, { url: string; at: number }>();
const FRESH_MS = 50 * 60 * 1000;

/** Reads a downloaded file into a data: link (works in the browser and on the phone) */
function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onloadend = () => resolve(String(fr.result));
    fr.onerror = () => reject(fr.error ?? new Error('Could not read the photo'));
    fr.readAsDataURL(blob);
  });
}

export async function photoUrl(path: string): Promise<string> {
  const hit = cache.get(path);
  if (hit && Date.now() - hit.at < FRESH_MS) return hit.url;
  let url: string;
  try {
    url = await api.detailFileUrl(path);
  } catch (first) {
    // The signed link could not be made: download the file itself and show it from memory instead
    const { data, error } = await supabase.storage.from('employee_detail_docs').download(path);
    if (error || !data) throw first;
    url = await blobToDataUrl(data);
  }
  cache.set(path, { url, at: Date.now() });
  return url;
}

/** The employee's profile photo (the photo of the Employee Form). Shows the initials until the photo is there or when there is none. */
export function PhotoAvatar({ name, size = 42, path }: { name?: string | null; size?: number; path?: string | null }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    setUrl(null);
    if (path) photoUrl(path).then((u) => { if (alive) setUrl(u); }).catch((e) => { console.warn('Profile photo could not be loaded:', e?.message ?? e); });
    return () => { alive = false; };
  }, [path]);
  if (!url) return <Avatar name={name} size={size} />;
  // a link that does not open as a picture falls back to the initials
  return <Image source={{ uri: url }} onError={() => setUrl(null)} style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: '#E8F1FF' }} />;
}
