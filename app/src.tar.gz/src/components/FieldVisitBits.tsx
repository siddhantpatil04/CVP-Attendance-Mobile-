import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { ArrivalType, FieldDayRow } from '../lib/api';
import { fmtTime12 } from '../lib/time';
import { C, Tone } from '../theme';
import { Card, Pill } from './ui';

/** 85 -> "1 h 25 m" */
export const hm = (m: number | null | undefined) => (m == null ? '-' : `${Math.floor(m / 60)} h ${String(Math.round(m) % 60).padStart(2, '0')} m`);
export const kmText = (v: number | null | undefined) => (v == null ? '-' : `${Number(v).toFixed(1)} km`);

export const ARRIVAL_TONE: Record<ArrivalType, Tone> = {
  Verified: 'green', 'Foreign - planned stop': 'amber', 'Foreign - mismatch': 'red',
};
/** Plain words for the employee: the database keeps the technical names */
export const arrivalLabel = (t: ArrivalType | null | undefined, dist?: number | null) =>
  t === 'Verified' ? `✓ At the site${dist != null ? ` (${dist} m)` : ''}`
  : t === 'Foreign - planned stop' ? 'Other place'
  : t === 'Foreign - mismatch' ? 'Not at the chosen site' : '';

export function ArrivalPill({ type, dist }: { type: ArrivalType | null | undefined; dist?: number | null }) {
  return type ? <Pill text={arrivalLabel(type, dist)} tone={ARRIVAL_TONE[type]} /> : null;
}

export const DAY_TONE = (s: string | null | undefined): Tone => (s === 'Full day' ? 'green' : s === 'Half day' ? 'amber' : s ? 'red' : 'muted');

/** What the system worked out for the day: shown to the employee after check-out and in the reports */
export function DaySummaryCard({ day }: { day: FieldDayRow }) {
  const done = !!day.check_out_at;
  const rows: [string, string][] = [
    ['Check-in', `${day.checkin_place ?? '-'} - ${day.check_in_at ? fmtTime12(day.check_in_at) : '-'}`],
    ['Check-out', done ? `${day.checkout_place ?? '-'} - ${fmtTime12(day.check_out_at)}${day.auto_closed ? ' (auto 23:59)' : ''}` : 'Not yet'],
    ['Sites visited', day.sites_visited ?? '-'],
    ['Trips', String(day.legs_count)],
    ['Travel time', hm(day.travel_min)],
    ['Total distance', kmText(day.total_km)],
    ['Other places visited', `${day.foreign_stops ?? 0}${day.foreign_min ? ` (${hm(day.foreign_min)})` : ''}`],
    ['Duty time', done ? hm(day.duty_min) : 'Calculated at check-out'],
    ['Late / Overtime', done ? `${day.late_min ?? 0} min / ${day.ot_min ?? 0} min` : '-'],
  ];
  return (
    <Card>
      <View style={st.head}>
        <Text style={st.title}>{done ? 'Your day summary' : 'Today so far'}</Text>
        {done && day.day_status ? <Pill text={day.day_status} tone={DAY_TONE(day.day_status)} /> : null}
      </View>
      {rows.map(([k, v]) => (
        <View key={k} style={st.row}><Text style={st.k}>{k}</Text><Text style={st.v}>{v}</Text></View>
      ))}
      <Text style={st.note}>{done ? 'Calculated automatically and sent to the attendance and field visit reports. No approval is needed.' : '(F) = other place, (M) = not at the chosen site.'}</Text>
    </Card>
  );
}

const st = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 },
  title: { fontSize: 16, fontWeight: '800', color: C.ink },
  row: { flexDirection: 'row', justifyContent: 'space-between', gap: 12, paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  k: { color: C.muted, fontSize: 13 },
  v: { color: '#102A45', fontWeight: '700', fontSize: 13, flexShrink: 1, textAlign: 'right' },
  note: { color: C.muted, fontSize: 11.5, marginTop: 8 },
});
