/// <reference types="google.maps" />
import { MarkerClusterer } from '@googlemaps/markerclusterer';
import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import type { MapDot, MapLine, MapSite } from '../lib/api';
import LocationMap from './LocationMap';

/**
 * Live Map - real Google Maps (satellite + labels) for web and the Electron desktop app.
 * Same props as LocationMap, so the Live Map screen keeps its layout.
 * The key is read from EXPO_PUBLIC_GOOGLE_MAPS_WEB_KEY (never committed). With no key the old map is shown.
 */
const KEY = process.env.EXPO_PUBLIC_GOOGLE_MAPS_WEB_KEY || '';

let loader: Promise<void> | null = null;
function loadGoogle(): Promise<void> {
  const w = window as any;
  if (w.google?.maps?.Map) return Promise.resolve();
  if (loader) return loader;
  loader = new Promise<void>((resolve, reject) => {
    const s = document.createElement('script');
    s.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(KEY)}&language=en&region=IN&v=weekly&loading=async&callback=__cvpGmapsReady`;
    s.async = true;
    const css = document.createElement('style');
    css.textContent = '.cvp-gm-label{text-shadow:0 0 3px #000,0 0 3px #000,0 1px 2px #000}';
    document.head.appendChild(css);
    w.__cvpGmapsReady = () => resolve();
    s.onerror = () => { loader = null; reject(new Error('Google Maps did not load')); };
    document.head.appendChild(s);
  });
  return loader;
}

const PIN_PATH = 'M12 0C5.4 0 0 5.4 0 12c0 9 12 22 12 22s12-13 12-22C24 5.4 18.6 0 12 0z';
const LABEL = (text: string): google.maps.MarkerLabel => ({ text, color: '#FFFFFF', fontWeight: '800', fontSize: '12px', className: 'cvp-gm-label' });

function GoogleMapView({ sites = [], dots = [], lines = [], height = 460 }: {
  sites?: MapSite[]; dots?: MapDot[]; lines?: MapLine[]; height?: number;
}) {
  const host = useRef<any>(null);
  const map = useRef<google.maps.Map | null>(null);
  const objs = useRef<{ clear: () => void }[]>([]);
  const fitted = useRef('');
  const info = useRef<google.maps.InfoWindow | null>(null);
  const [ready, setReady] = React.useState(false);

  useEffect(() => {
    let dead = false;
    loadGoogle().then(() => {
      const el = host.current as HTMLElement | null;
      if (dead || !el || map.current) return;
      map.current = new google.maps.Map(el, {
        center: { lat: 20.59, lng: 78.96 }, zoom: 5, mapTypeId: 'hybrid', gestureHandling: 'greedy',
        streetViewControl: false, fullscreenControl: true, clickableIcons: false,
        mapTypeControl: true,
        mapTypeControlOptions: { mapTypeIds: ['roadmap', 'hybrid', 'terrain'], style: google.maps.MapTypeControlStyle.DROPDOWN_MENU },
      });
      info.current = new google.maps.InfoWindow();
      setReady(true);
    }).catch(() => {});
    return () => { dead = true; };
  }, []);

  useEffect(() => {
    const m = map.current;
    if (!ready || !m) return;
    objs.current.forEach((o) => o.clear());
    objs.current = [];
    const bounds = new google.maps.LatLngBounds();
    const add = (o: { clear: () => void }) => objs.current.push(o);
    const popup = (mk: google.maps.Marker, html: string) => mk.addListener('click', () => {
      const d = document.createElement('div'); d.style.fontWeight = '700'; d.textContent = html;
      info.current?.setContent(d); info.current?.open({ map: m, anchor: mk });
    });

    for (const s of sites) {
      const col = s.color ?? '#7C3AED';
      const pos = { lat: s.lat, lng: s.lng };
      if (s.circle !== false) {
        const c = new google.maps.Circle({ map: m, center: pos, radius: s.radius_m, strokeColor: col, strokeOpacity: 0.95, strokeWeight: 2, fillColor: col, fillOpacity: 0.15, clickable: false });
        add({ clear: () => c.setMap(null) });
        const cb = c.getBounds(); if (cb) bounds.union(cb);
      }
      const mk = new google.maps.Marker({
        map: m, position: pos, title: s.name, label: LABEL(s.label ?? s.name),
        icon: { path: PIN_PATH, fillColor: col, fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2, scale: 0.9, anchor: new google.maps.Point(12, 34), labelOrigin: new google.maps.Point(12, -8) },
      });
      popup(mk, `${s.name} - allowed radius ${s.radius_m >= 1000 ? (s.radius_m / 1000).toFixed(1) + ' km' : s.radius_m + ' m'}`);
      add({ clear: () => mk.setMap(null) });
      bounds.extend(pos);
    }

    for (const ln of lines) {
      if (ln.points.length < 2) continue;
      const path = ln.points.map(([lat, lng]) => ({ lat, lng }));
      const pl = new google.maps.Polyline({
        map: m, path, strokeColor: ln.color, strokeOpacity: ln.dashed ? 0 : 0.9, strokeWeight: 4,
        ...(ln.dashed ? { icons: [{ icon: { path: 'M 0,-1 0,1', strokeOpacity: 1, strokeColor: ln.color, scale: 3 }, offset: '0', repeat: '14px' }] } : {}),
      });
      add({ clear: () => pl.setMap(null) });
      path.forEach((p) => bounds.extend(p));
    }

    // Employee dots: labelled ones are plain markers; the unlabelled ones group into numbered clusters
    const cluster: google.maps.Marker[] = [];
    for (const d of dots) {
      const pos = { lat: d.lat, lng: d.lng };
      const mk = new google.maps.Marker({
        position: pos, title: d.label,
        ...(d.permanent ? { label: LABEL(d.label) } : {}),
        icon: { path: google.maps.SymbolPath.CIRCLE, fillColor: d.color, fillOpacity: 1, strokeColor: '#fff', strokeWeight: 3, scale: 9, labelOrigin: new google.maps.Point(0, -2.4) },
      });
      popup(mk, d.label);
      bounds.extend(pos);
      if (d.permanent) { mk.setMap(m); add({ clear: () => mk.setMap(null) }); } else cluster.push(mk);
    }
    if (cluster.length) {
      const mc = new MarkerClusterer({ map: m, markers: cluster });
      add({ clear: () => mc.clearMarkers() });
    }

    const sig = `${sites.map((s) => s.id).join(',')}|${dots.map((d) => d.key).join(',')}|${lines.map((l) => l.key).join(',')}`;
    if (!bounds.isEmpty() && fitted.current !== sig) {
      fitted.current = sig;
      m.fitBounds(bounds, 48);
      google.maps.event.addListenerOnce(m, 'idle', () => { if ((m.getZoom() ?? 0) > 17) m.setZoom(17); });
    }
  }, [ready, sites, dots, lines]);

  return <View ref={host} style={{ height, borderRadius: 14, overflow: 'hidden', backgroundColor: '#E8EEF5' }} />;
}

export default function GoogleLiveMap(props: React.ComponentProps<typeof LocationMap>) {
  if (!KEY) return <LocationMap {...props} />;
  return <GoogleMapView {...props} />;
}
