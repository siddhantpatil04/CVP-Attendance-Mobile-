import React, { useMemo } from 'react';
import { View } from 'react-native';
import { WebView } from 'react-native-webview';
import type { MapDot, MapLine, MapPoint, MapSite } from '../lib/api';
import { fmtTime12 } from '../lib/time';

/**
 * Phone map (Leaflet + OpenStreetMap inside a WebView).
 *  points : check-in (green) / check-out (blue) pins
 *  sites  : work sites, drawn as a named marker with its allowed-radius circle
 *  me     : the viewer's own live position (blue dot)
 */
export default function LocationMap({ points = [], sites = [], dots = [], lines = [], me = null, height = 460 }: {
  points?: MapPoint[]; sites?: MapSite[]; dots?: MapDot[]; lines?: MapLine[]; me?: { lat: number; lng: number } | null; height?: number;
}) {
  // Callers pass fresh arrays on every render; key on content so the WebView isn't reloaded (the main source of lag).
  const sig = JSON.stringify([points, sites, dots, lines, me]);
  const html = useMemo(() => {
    const pts = points.map((p) => ({
      lat: p.lat, lng: p.lng, kind: p.kind,
      label: `${p.name} - ${p.kind === 'IN' ? 'Check In' : 'Check Out'} ${fmtTime12(p.at)}${p.siteName ? ` - ${p.siteName}` : ''}`,
    }));
    const sts = sites.map((s) => ({
      lat: s.lat, lng: s.lng, r: s.radius_m, name: s.label ?? s.name, color: s.color ?? '#7C3AED', circle: s.circle !== false,
      label: `${s.name} - radius ${s.radius_m >= 1000 ? (s.radius_m / 1000).toFixed(1) + ' km' : s.radius_m + ' m'}`,
    }));
    const dts = dots.map((d) => ({ lat: d.lat, lng: d.lng, color: d.color, label: d.label, perm: !!d.permanent }));
    const lns = lines.filter((l) => l.points.length >= 2).map((l) => ({ pts: l.points, color: l.color, label: l.label, dash: !!l.dashed }));
    const json = (v: unknown) => JSON.stringify(v).replace(/</g, '\\u003c');
    return `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>html,body,#m{height:100%;margin:0;overflow:hidden;touch-action:none;-webkit-user-select:none;user-select:none}.p{width:22px;height:22px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:2px solid #fff;box-shadow:0 1px 5px rgba(0,0,0,.45)}</style></head>
<body><div id="m"></div><script>
var pts=${json(pts)},sts=${json(sts)},dts=${json(dts)},lns=${json(lns)},me=${json(me)};
var m=L.map('m',{zoomControl:true,dragging:true,touchZoom:true,scrollWheelZoom:true,doubleClickZoom:true,tap:false,bounceAtZoomLimits:false,preferCanvas:true,fadeAnimation:false,markerZoomAnimation:false,zoomSnap:0.5,wheelDebounceTime:20}).setView([20.59,78.96],5);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap',updateWhenZooming:false,updateWhenIdle:true,keepBuffer:3}).addTo(m);
function icon(c){return L.divIcon({className:'',html:'<div class="p" style="background:'+c+'"></div>',iconSize:[22,22],iconAnchor:[11,22],popupAnchor:[0,-22]});}
var b=[];
sts.forEach(function(s){
 if(s.circle){var c=L.circle([s.lat,s.lng],{radius:s.r,color:s.color,weight:2,dashArray:'6 6',fillColor:s.color,fillOpacity:0.1}).addTo(m);
 var cb=c.getBounds();b.push([cb.getSouth(),cb.getWest()]);b.push([cb.getNorth(),cb.getEast()]);}
 var mk=L.marker([s.lat,s.lng],{icon:icon(s.color)}).addTo(m);
 mk.bindTooltip(document.createTextNode(s.name).textContent,{permanent:true,direction:'top',offset:[0,-22]});
 mk.bindPopup(document.createTextNode(s.label).textContent);b.push([s.lat,s.lng]);});
pts.forEach(function(p){
 L.marker([p.lat,p.lng],{icon:icon(p.kind==='IN'?'#16A34A':'#2563EB')}).addTo(m).bindPopup(document.createTextNode(p.label).textContent);b.push([p.lat,p.lng]);});
lns.forEach(function(l){L.polyline(l.pts,{color:l.color,weight:4,opacity:0.85,dashArray:l.dash?'8 8':null}).addTo(m).bindTooltip(document.createTextNode(l.label).textContent);l.pts.forEach(function(q){b.push(q);});});
dts.forEach(function(d){var t=document.createTextNode(d.label).textContent;L.circleMarker([d.lat,d.lng],{radius:9,color:'#fff',weight:3,fillColor:d.color,fillOpacity:1}).addTo(m).bindTooltip(t,{permanent:d.perm,direction:'top'}).bindPopup(t);b.push([d.lat,d.lng]);});
if(me){L.circleMarker([me.lat,me.lng],{radius:9,color:'#fff',weight:3,fillColor:'#2563EB',fillOpacity:1}).addTo(m).bindTooltip('You are here');b.push([me.lat,me.lng]);}
function fit(){m.invalidateSize();if(b.length)m.fitBounds(b,{padding:[30,30],maxZoom:17});}
fit();
</script></body></html>`;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig]);

  return (
    <View style={{ height, borderRadius: 14, overflow: 'hidden', backgroundColor: '#E8EEF5' }}>
      <WebView originWhitelist={['*']} source={{ html, baseUrl: 'https://localhost' }} javaScriptEnabled domStorageEnabled
        scrollEnabled={false} bounces={false} overScrollMode="never" nestedScrollEnabled
        androidLayerType="hardware" cacheEnabled mixedContentMode="always" setSupportMultipleWindows={false}
        showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}
        style={{ flex: 1, backgroundColor: '#E8EEF5' }} />
    </View>
  );
}
