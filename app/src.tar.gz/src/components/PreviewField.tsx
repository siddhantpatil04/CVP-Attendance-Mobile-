﻿import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { api } from '../lib/api';
import { isNetworkMessage } from '../lib/journeyPlanQueue';
import { errorText } from '../lib/supabase';
import { C } from '../theme';
import { Field } from './ui';

const DEVANAGARI = /[ऀ-ॿ]/;

/**
 * A Daily Report text box. When the text is Marathi / Hindi, a small "ENGLISH (AUTO)" preview appears about 1 second after the
 * employee stops typing. It is for information only. The real English is made on the server when the report is submitted.
 */
export function PreviewField(props: React.ComponentProps<typeof Field> & { fieldKey: string; value: string }) {
  const { fieldKey, ...fieldProps } = props;
  const [en, setEn] = useState('');
  const [state, setState] = useState<'idle' | 'busy' | 'offline'>('idle');
  const text = props.value ?? '';

  useEffect(() => {
    if (!text.trim() || !DEVANAGARI.test(text)) { setEn(''); setState('idle'); return; }
    let alive = true;
    setState('busy');
    const timer = setTimeout(async () => {
      try {
        const out = await api.translatePreview({ [fieldKey]: text });
        if (alive) { setEn(out[fieldKey] ?? ''); setState('idle'); }
      } catch (e) {
        if (alive) { setEn(''); setState(isNetworkMessage(errorText(e)) ? 'offline' : 'idle'); }
      }
    }, 1000);
    return () => { alive = false; clearTimeout(timer); };
  }, [text, fieldKey]);

  return (
    <View>
      <Field {...(fieldProps as any)} />
      {en || state !== 'idle' ? (
        <View style={st.box}>
          <Text style={st.tag}>{"ENGLISH (AUTO)"}</Text>
          <Text style={st.txt}>{state === 'busy' && !en ? "Translating..." : state === 'offline' ? "Waiting for internet - English will be added when the report is sent." : en}</Text>
        </View>
      ) : null}
    </View>
  );
}

const st = StyleSheet.create({
  box: { backgroundColor: '#F4F7FB', borderRadius: 10, borderWidth: 1, borderColor: '#E1E9F3', paddingVertical: 6, paddingHorizontal: 10, marginTop: -4, marginBottom: 8 },
  tag: { fontSize: 10, fontWeight: '800', letterSpacing: 0.5, color: '#8594A6' },
  txt: { fontSize: 13, color: '#203951', marginTop: 2, lineHeight: 18 },
});
void C;
