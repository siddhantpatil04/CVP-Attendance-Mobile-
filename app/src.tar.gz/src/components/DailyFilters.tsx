import React, { useEffect } from 'react';
import { DailyReport } from '../lib/api';
import { cityCmp, cityOfSite, natCmp } from '../lib/siteCity';
import { DailyStatusFilter, filterDaily } from './DailyReportsPanel';
import { DownloadKind, monthPeriod, ReportFilterBar } from './ReportFilterBar';

/** The filters of the Daily Reports tab (Year and Month live in the screen because the other tabs share them) */
export interface DailyFilterState {
  /** all = Whole month | day = Particular date */
  dateMode: 'all' | 'day';
  dateFrom: string;   // YYYY-MM-DD (day: from = to)
  dateTo: string;
  city: string; site: string; empId: string; status: DailyStatusFilter;
}
export const DAILY_FILTERS_DEFAULT: DailyFilterState = { dateMode: 'day', dateFrom: '', dateTo: '', city: '', site: '', empId: '', status: 'All' };
export type { DownloadKind };

/** The date window (from, to) of the filters inside the month, or null = the whole month */
export const dateWindow = (f: DailyFilterState): { from: string; to: string } | null =>
  f.dateMode === 'all' || !f.dateFrom ? null : { from: f.dateFrom, to: f.dateTo || f.dateFrom };

/** The reports of the filters: Date, City, Site, Employee and Status */
export const applyDailyFilters = (rows: DailyReport[], f: DailyFilterState) =>
  filterDaily(rows, f.site, f.status, f.city, { ...(dateWindow(f) ?? {}), emp: f.empId });

export function DailyFilters({ year, month, onYearMonth, rows, f, set, onReset, shown, busy, busyText, onDownload, company, companyChip }: {
  company?: React.ReactNode; companyChip?: React.ReactNode;
  year: number; month: number; onYearMonth: (y: number, m: number) => void;
  rows: DailyReport[] | null; f: DailyFilterState; set: (patch: Partial<DailyFilterState>) => void; onReset: () => void;
  shown: DailyReport[]; busy: DownloadKind | null; busyText?: string; onDownload: (k: DownloadKind) => void;
}) {
  const all = rows ?? [];
  const P = monthPeriod(year, month);
  const goDay = (iso: string) => set({ dateMode: 'day', dateFrom: iso, dateTo: iso });
  const onDateMode = (m: 'all' | 'day') => { if (m === 'day') goDay(P.days.includes(P.todayISO) ? P.todayISO : P.maxDay); else set({ dateMode: 'all', dateFrom: '', dateTo: '' }); };

  // ---- lists: only options that exist for the choices before them (they come from the reports of the chosen period)
  const win = dateWindow(f);
  const inWin = all.filter((r) => !win || (r.report_date >= win.from && r.report_date <= win.to));
  const siteNames = [...new Set(inWin.flatMap((r) => r.daily_report_sites.map((s) => s.site_name.trim()).filter(Boolean)))].sort(natCmp);
  const cityList = [...new Set(siteNames.map(cityOfSite))].sort(cityCmp);
  const siteOpts: { value: number; label: string }[] = [{ value: 0, label: 'All sites' }];
  cityList.filter((c) => !f.city || c === f.city).forEach((c, k) => {
    if (!f.city) siteOpts.push({ value: -(k + 1), label: `-- ${c} --` });
    siteNames.filter((n) => cityOfSite(n) === c).forEach((n) => siteOpts.push({ value: siteNames.indexOf(n) + 1, label: f.city ? n : `   ${n}` }));
  });
  const siteIdx = f.site ? siteNames.findIndex((n) => n.toLowerCase() === f.site.toLowerCase()) + 1 : 0;
  const empMap = new Map<string, string>();
  for (const r of applyDailyFilters(all, { ...f, empId: '', status: 'All' })) empMap.set(r.user_id, r.employee?.full_name ?? 'Employee');
  const empList = [...empMap.entries()].sort((a, b) => natCmp(a[1], b[1]));
  const empIdx = f.empId ? empList.findIndex(([id]) => id === f.empId) + 1 : 0;

  // a choice that is no longer valid goes back to "All"
  useEffect(() => {
    if (!rows) return;
    if (f.city && !cityList.includes(f.city)) set({ city: '', site: '' });
    else if (f.site && siteIdx === 0) set({ site: '' });
    else if (f.empId && empIdx === 0) set({ empId: '' });
  }, [rows, f.city, f.site, f.empId, cityList.join('|'), siteNames.join('|'), empList.map((e) => e[0]).join('|')]);   // eslint-disable-line react-hooks/exhaustive-deps

  // default = Particular date, the current date (the screen shows ONE day); the date box is filled here
  useEffect(() => { if (f.dateMode === 'day' && !f.dateFrom && rows) goDay(P.days.includes(P.todayISO) ? P.todayISO : P.maxDay); }, [f.dateMode, f.dateFrom, year, month, !!rows]);   // eslint-disable-line react-hooks/exhaustive-deps
  const dirty = !!(f.dateMode !== 'day' || (f.dateFrom && f.dateFrom !== P.todayISO) || f.city || f.site || f.empId);
  return (
    <ReportFilterBar title="Daily Report" company={company} companyChip={companyChip} year={year} month={month} onYearMonth={onYearMonth}
      dateMode={f.dateMode} day={f.dateFrom || P.maxDay} onDateMode={onDateMode} onDay={goDay} particularFirst
      city={{ value: f.city ? cityList.indexOf(f.city) + 1 : 0, onChange: (i) => set({ city: i > 0 ? cityList[i - 1] : '', site: '' }),
        options: [{ value: 0, label: 'All cities' }, ...cityList.map((c, i) => ({ value: i + 1, label: c }))] }}
      site={{ value: siteIdx, onChange: (i) => { if (i < 0) return; set({ site: i > 0 ? siteNames[i - 1] : '' }); }, options: siteOpts }}
      emp={{ value: empIdx, onChange: (i) => set({ empId: i > 0 ? empList[i - 1][0] : '' }),
        options: [{ value: 0, label: 'All employees' }, ...empList.map(([, name], i) => ({ value: i + 1, label: name }))] }}
      countText={`${shown.length} report${shown.length === 1 ? '' : 's'} · ${f.city || 'All cities'} · ${f.site || 'All sites'} · ${f.empId ? empMap.get(f.empId) ?? 'Employee' : 'All employees'}`}
      dirty={dirty} onReset={onReset} busy={busy} busyText={busyText} onDownload={onDownload} />
  );
}
