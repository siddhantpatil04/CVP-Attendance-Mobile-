import * as Location from 'expo-location';
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';

const EVERY_MS = 45000;

/**
 * Sends this device's position to HR / Admin, but ONLY while the employee is on a field visit or
 * between two travel stops (the database refuses and deletes positions at any other time).
 * It runs while the app is open. A small bar tells the employee that the position is being shared.
 */
export default function LiveTracker() {
  const { session, profile } = useAuth();
  const [kind, setKind] = useState<'visit' | 'travel' | 'journey' | null>(null);
  const signedIn = !!session && !!profile;

  useEffect(() => {
    if (!signedIn) { setKind(null); return; }
    let alive = true;
    let busy = false;

    const tick = async () => {
      if (busy) return;
      busy = true;
      try {
        const k = (await api.liveTrackingActive()) as 'visit' | 'travel' | 'journey' | null;
        if (!alive) return;
        setKind(k);
        if (!k) return;                                   // nothing to share right now
        const perm = await Location.requestForegroundPermissionsAsync();
        if (perm.status !== 'granted') return;
        const pos = await Promise.race([
          Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
          new Promise<null>((r) => setTimeout(() => r(null), 15000)),
        ]);
        if (pos && alive) await api.reportLocation(pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy);
      } catch {
        /* offline / GPS off: try again at the next tick */
      } finally {
        busy = false;
      }
    };

    tick();
    const id = setInterval(tick, EVERY_MS);
    return () => { alive = false; clearInterval(id); };
  }, [signedIn]);

  // The "live location shared" note is no longer a bar over every screen: it is shown in Field Site (see LiveShareNote below).
  void kind;
  return null;
}

/** Small note for the Field Site screen (under Start Visit): shown while the position is being shared with HR / Admin */
export function LiveShareNote() {
  const { session, profile } = useAuth();
  const [kind, setKind] = useState<'visit' | 'travel' | 'journey' | null>(null);
  const signedIn = !!session && !!profile;
  useEffect(() => {
    if (!signedIn) { setKind(null); return; }
    let alive = true;
    const read = () => { api.liveTrackingActive().then((k) => { if (alive) setKind(k as 'visit' | 'travel' | 'journey' | null); }).catch(() => undefined); };
    read();
    const id = setInterval(read, 30000);
    return () => { alive = false; clearInterval(id); };
  }, [signedIn]);
  if (!kind) return null;
  return (
    <View style={st.bar}>
      <View style={st.dot} />
      <Text style={st.text}>
        {kind === 'visit' ? 'On a field visit' : kind === 'journey' ? 'Journey in progress' : 'Travelling between sites'} - live location shared with HR / Admin
      </Text>
    </View>
  );
}

const st = StyleSheet.create({
  bar: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FFF4E5', borderRadius: 12, paddingVertical: 10, paddingHorizontal: 12, marginTop: 12 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#EA580C' },
  text: { flex: 1, fontSize: 12.5, fontWeight: '700', color: '#9A4B00' },
});