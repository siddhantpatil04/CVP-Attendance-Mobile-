import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { hm } from '../lib/hours';
import { C } from '../theme';
import { Button, Field } from './ui';

/**
 * Shown when the employee taps Submit Check-Out before the required hours.
 * "Less than 8 hours - You worked 6h 37m, 1h 23m short. Today will be marked Short hours." + a required reason.
 */
export default function ShortHoursSheet({ visible, worked, requiredMin, blocked, busy, onStay, onConfirm }: {
  visible: boolean; worked: number; requiredMin: number;
  /** Admin rule "block": checking out before the required hours is not allowed at all */
  blocked?: boolean; busy?: boolean; onStay: () => void; onConfirm: (reason: string) => void;
}) {
  const [reason, setReason] = useState('');
  useEffect(() => { if (visible) setReason(''); }, [visible]);
  const short = Math.max(0, requiredMin - worked);
  const needHours = `${Math.floor(requiredMin / 60)} hours`;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onStay}>
      <View style={st.backdrop}>
        <View style={st.sheet}>
          <View style={st.warn}><Ionicons name="warning-outline" size={26} color="#C98400" /></View>
          <Text style={st.title}>Less than {needHours}</Text>
          <Text style={st.body}>
            You worked <Text style={st.b}>{hm(worked)}</Text>. You are <Text style={[st.b, { color: '#C98400' }]}>{hm(short)} short</Text> of {needHours}.
            {blocked ? ' Your company does not allow checking out before that.' : ' Today will be marked Short hours.'}
          </Text>
          {blocked ? null : (
            <>
              <Field label="Reason *" placeholder="Example: Site work stopped - no power supply" value={reason} onChangeText={setReason} multiline />
              <View style={st.btns}>
                <Pressable style={st.stay} onPress={onStay}><Text style={st.stayText}>Stay</Text></Pressable>
                <Button title="Check out anyway" variant="primary" loading={busy} disabled={reason.trim().length === 0}
                  onPress={() => onConfirm(reason.trim())} style={st.go} />
              </View>
            </>
          )}
          {blocked ? <Button title="Stay" variant="secondary" onPress={onStay} /> : null}
        </View>
      </View>
    </Modal>
  );
}

const st = StyleSheet.create({
  backdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(6,37,63,0.45)' },
  sheet: { backgroundColor: C.white, borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 18, paddingBottom: 30 },
  warn: { width: 48, height: 48, borderRadius: 24, backgroundColor: C.amberSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  title: { fontSize: 20, fontWeight: '800', color: C.ink },
  body: { fontSize: 14, color: C.muted, lineHeight: 21, marginTop: 6, marginBottom: 12 },
  b: { fontWeight: '800', color: C.ink },
  btns: { flexDirection: 'row', gap: 10, marginTop: 4 },
  stay: { flex: 1, borderWidth: 1, borderColor: '#D8E3EF', borderRadius: 14, alignItems: 'center', justifyContent: 'center', paddingVertical: 13 },
  stayText: { fontWeight: '800', color: C.ink, fontSize: 15 },
  go: { flex: 1.4, backgroundColor: '#C98400', borderColor: '#C98400' },
});
