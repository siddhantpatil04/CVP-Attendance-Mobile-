import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Card, Empty, Field, Row, Segmented } from './ui';
import { api, LeaveLedgerRow, LeaveSummary } from '../lib/api';
import { errorText } from '../lib/supabase';
import { fmtISODate } from '../lib/time';
import { C } from '../theme';

const n1 = (x: number | null | undefined) => String(Math.round(Number(x ?? 0) * 10) / 10);
const KIND: Record<string, string> = { credit: 'Credit', used: 'Used', lapse: 'Lapsed', encash: 'Encashed', adjust: 'Adjusted', opening: 'Opening' };
const TYPES = [{ value: 'Earned Leave', label: 'Earned (EL)' }, { value: 'Casual Leave', label: 'Casual (CL)' }, { value: 'Sick Leave', label: 'Sick (SL)' }];

/** Employee Management -> Paid leave: eligibility date, "Start paid leaves now", ledger, Adjust balance, EL encashment (Admin / HR) */
export default function PaidLeavePanel({ userId, canManage }: { userId: string; canManage: boolean }) {
  const [sum, setSum] = useState<LeaveSummary | null>(null);
  const [ledger, setLedger] = useState<LeaveLedgerRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [early, setEarly] = useState('');
  const [adjType, setAdjType] = useState('Earned Leave');
  const [adjDays, setAdjDays] = useState('');
  const [adjReason, setAdjReason] = useState('');
  const [encDays, setEncDays] = useState('');
  const [encReason, setEncReason] = useState('');

  const load = useCallback(async () => {
    try {
      setSum(await api.leaveSummary(userId));
      api.leaveLedger(userId).then(setLedger).catch(() => {});
    } catch { setSum(null); /* leave_policy_24.sql not run yet */ }
  }, [userId]);
  useEffect(() => { load(); }, [load]);

  if (!sum) return <Card><Text style={st.sub}>The 24-day leave policy is not installed yet (run leave_policy_24.sql).</Text></Card>;

  const run = async (fn: () => Promise<unknown>, done: string) => {
    setBusy(true);
    try { await fn(); Alert.alert('Done', done); await load(); } catch (e) { Alert.alert('Could not save', errorText(e)); } finally { setBusy(false); }
  };
  const canEncash = Math.max(0, sum.el.balance - sum.policy.el_keep_min);

  return (
    <Card>
      <Row style={{ justifyContent: 'space-between' }}>
        <Text style={st.title}>Paid leave</Text>
        <Text style={st.sub}>{sum.eligible ? 'Eligible' : 'Not eligible yet'}</Text>
      </Row>
      <Text style={st.sub}>
        {sum.joining_date ? `Joined ${fmtISODate(sum.joining_date)} - ` : 'No joining date - '}
        {sum.eligible_from ? `paid leaves ${sum.eligible ? 'started' : 'start'} ${fmtISODate(sum.eligible_from)}${sum.early_start ? ' (early start ON)' : ''}` : 'paid leaves cannot start'}
        {!sum.eligible && sum.months_done != null ? ` - ${sum.months_done} of ${sum.months_total} months done` : ''}
      </Text>
      <View style={st.bals}>
        <View style={st.bal}><Text style={st.balK}>EL</Text><Text style={st.balV}>{n1(sum.el.balance)}</Text></View>
        <View style={st.bal}><Text style={st.balK}>CL</Text><Text style={st.balV}>{n1(sum.cl.balance)}</Text></View>
        <View style={st.bal}><Text style={st.balK}>SL</Text><Text style={st.balV}>{n1(sum.sl.balance)}</Text></View>
        <View style={st.bal}><Text style={st.balK}>Unpaid (yr)</Text><Text style={st.balV}>{n1(sum.lop_year)}</Text></View>
      </View>

      {canManage ? (
        <>
          <Text style={st.head}>Start paid leaves now</Text>
          {sum.early_start ? (
            <>
              <Banner tone="green" icon="checkmark-circle-outline" text={`Early start is ON${sum.early_reason ? `: ${sum.early_reason}` : ''}.`} />
              <Button title="Switch early start OFF" variant="secondary" small loading={busy} onPress={() => run(() => api.setPaidLeaveEarlyStart(userId, false), 'Early start switched off.')} />
            </>
          ) : sum.eligible ? <Text style={st.sub}>Not needed - the employee is already eligible.</Text> : (
            <>
              <Field label="Reason (required)" value={early} onChangeText={setEarly} placeholder="e.g. Confirmed early by management" />
              <Button title="Start EL / CL / SL credits from this month" icon="play-outline" variant="secondary" small loading={busy}
                onPress={() => run(() => api.setPaidLeaveEarlyStart(userId, true, early.trim()), 'Paid leaves started. This month was credited.')} />
            </>
          )}

          <Text style={st.head}>Adjust balance</Text>
          <Segmented value={adjType} onChange={setAdjType} options={TYPES} />
          <Row style={{ marginTop: 8 }}>
            <View style={{ width: 120 }}><Field label="Days (+ or -)" value={adjDays} onChangeText={setAdjDays} keyboardType="numbers-and-punctuation" placeholder="e.g. 2 or -0.5" /></View>
            <View style={{ flex: 1 }}><Field label="Reason (required)" value={adjReason} onChangeText={setAdjReason} placeholder="e.g. Opening balance from old Annual Leave" /></View>
          </Row>
          <Button title="Adjust balance" icon="swap-vertical-outline" variant="secondary" small loading={busy}
            onPress={() => run(() => api.adjustLeaveBalance(userId, adjType, Number(adjDays), adjReason.trim()), 'Balance adjusted.').then(() => { setAdjDays(''); setAdjReason(''); })} />

          <Text style={st.head}>Encash Earned Leave</Text>
          <Text style={st.sub}>Only EL above {n1(sum.policy.el_keep_min)} days can be encashed (now {n1(canEncash)} available). Amount = per-day salary x days.</Text>
          <Row>
            <View style={{ width: 120 }}><Field label="EL days" value={encDays} onChangeText={setEncDays} keyboardType="decimal-pad" /></View>
            <View style={{ flex: 1 }}><Field label="Note (optional)" value={encReason} onChangeText={setEncReason} /></View>
          </Row>
          <Button title="Encash EL" icon="cash-outline" variant="secondary" small loading={busy} disabled={canEncash <= 0}
            onPress={() => run(() => api.encashLeave(userId, Number(encDays), encReason.trim() || undefined), 'EL encashed and recorded.').then(() => setEncDays(''))} />
        </>
      ) : null}

      <Text style={st.head}>Ledger</Text>
      {ledger.length === 0 ? <Empty text="No entries yet." /> : ledger.slice(0, 40).map((l, i) => {
        const d = Number(l.credited) + Number(l.adjusted) - Number(l.used) - Number(l.lapsed) - Number(l.encashed);
        return (
          <View key={`${l.created_at}-${i}`} style={st.lrow}>
            <View style={{ flex: 1 }}>
              <Text style={st.lt}>{l.leave_type.replace(' Leave', '')} - {KIND[l.kind] ?? l.kind} - {l.month.slice(0, 7)}</Text>
              {l.reason || l.amount != null ? <Text style={st.sub}>{l.reason ?? ''}{l.amount != null ? ` - Rs ${Number(l.amount).toLocaleString('en-IN')}` : ''}</Text> : null}
            </View>
            <Text style={[st.lv, { color: d >= 0 ? '#157A4B' : '#B42330' }]}>{d >= 0 ? '+' : ''}{n1(d)}</Text>
            <Text style={st.lb}>{n1(l.balance_after)}</Text>
          </View>
        );
      })}
    </Card>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 16, fontWeight: '800', color: C.ink },
  sub: { fontSize: 12.5, color: C.muted, marginTop: 2, marginBottom: 6, lineHeight: 18 },
  head: { fontSize: 13, fontWeight: '800', color: '#3A5068', marginTop: 14, marginBottom: 6 },
  bals: { flexDirection: 'row', gap: 8, marginTop: 6 },
  bal: { flex: 1, backgroundColor: '#F3F7FB', borderRadius: 10, paddingVertical: 8, paddingHorizontal: 10 },
  balK: { fontSize: 10.5, fontWeight: '800', color: '#77889D' },
  balV: { fontSize: 18, fontWeight: '800', color: '#102A45', marginTop: 2 },
  lrow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  lt: { fontSize: 13, fontWeight: '700', color: '#17314D' },
  lv: { width: 54, textAlign: 'right', fontWeight: '800' },
  lb: { width: 54, textAlign: 'right', fontWeight: '800', color: '#17314D' },
});
