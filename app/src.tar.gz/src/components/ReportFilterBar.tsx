import React from 'react';
import { Ionicons } from '@expo/vector-icons';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useIsDesktop } from '../lib/layout';
import { istDateISO, MONTHS } from '../lib/time';
import { C } from '../theme';
import { CTRL_H, CTRL_R, Dropdown } from './Pickers';
import { Card } from './ui';

/**
 * The ONE filter card of the Daily Report and the Site Attendance screens:
 *   (1) Year  (2) Month  (3) Date: Whole month | Particular date  (4) City  (5) Site  (6) Employee  +  Download PDF / Download Excel
 * The screens give it the lists; the period rules (running month = 1st .. today, completed month = 1st .. last day, one date) live here.
 */
export type DownloadKind = 'pdf' | 'xlsx';
export interface DD { value: number; options: { value: number; label: string; disabled?: boolean }[]; onChange: (v: number) => void }

const pad = (n: number) => String(n).padStart(2, '0');
export const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;
const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const wdOf = (iso: string) => WD[new Date(`${iso}T12:00:00Z`).getUTCDay()];

/** Period facts of a month: days, last day, whether it is still running and the last day of the report (today when running) */
export function monthPeriod(year: number, month: number, todayISO = istDateISO()) {
  const lastDay = new Date(year, month, 0).getDate();
  const days = Array.from({ length: lastDay }, (_, i) => `${year}-${pad(month)}-${pad(i + 1)}`);
  const lastISO = days[lastDay - 1];
  const running = todayISO >= days[0] && todayISO < lastISO;
  return { days, lastDay, first: days[0], lastISO, running, toISO: running ? todayISO : lastISO, maxDay: days.filter((d) => d <= todayISO).pop() ?? days[0], todayISO };
}
/** The orange info chip */
export function periodChip(year: number, month: number, dateMode: 'all' | 'day', day: string) {
  const p = monthPeriod(year, month);
  if (dateMode === 'day' && day) return `${dmy(day)} (${new Date(`${day}T12:00:00Z`).toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' })})`;
  return p.running ? `Month in progress · report covers ${dmy(p.first)} to ${dmy(p.toISO)} (today)` : `Completed month · ${dmy(p.first)} to ${dmy(p.lastISO)}`;
}

const Fld = ({ n, label, children, style }: { n: number; label: string; children: React.ReactNode; style?: any }) => (
  <View style={[{ minWidth: 0 }, style]}>
    <View style={st.lblRow}><View style={st.badge}><Text style={st.badgeTx}>{n}</Text></View><Text style={st.lbl}>{label}</Text></View>
    {children}
  </View>
);

/** The date pill with a calendar icon; on the web a click opens the browser calendar (limited to min..max) */
function DateBox({ text, value, min, max, onPick, native }: { text: string; value: string; min: string; max: string; onPick: (iso: string) => void; native?: React.ReactNode }) {
  const ref = React.useRef<any>(null);
  if (native) return <View style={{ minWidth: 0 }}>{native}</View>;
  return (
    <Pressable style={st.dateBox}
      onPress={() => { try { ref.current?.showPicker?.(); } catch { /* older browser */ } ref.current?.focus?.(); }}>
      <Text style={st.dateTx} numberOfLines={1}>{text}</Text>
      <Ionicons name="calendar-outline" size={18} color="#3A5068" />
      {Platform.OS === 'web' ? React.createElement('input', {
        ref, type: 'date', value, min, max, tabIndex: -1,
        onChange: (e: any) => e.target.value && e.target.value >= min && e.target.value <= max && onPick(e.target.value),
        style: { position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', opacity: 0, pointerEvents: 'none', border: 0 },
      }) : null}
    </Pressable>
  );
}

export function ReportFilterBar({ title, year, month, onYearMonth, dateMode, day, onDateMode, onDay, city, site, emp, extra, countText, dirty, onReset, busy, busyText, onDownload, hideDownload, particularFirst, top, siteLabel, preview, company, companyChip }: {
  title: string; year: number; month: number; onYearMonth: (y: number, m: number) => void;
  dateMode: 'all' | 'day'; day: string; onDateMode: (m: 'all' | 'day') => void; onDay: (iso: string) => void;
  city: DD; site: DD; emp: DD;
  /** the line under the dropdowns (the Selfie screen puts its RECORDS chips here) */
  extra?: React.ReactNode;
  countText: string; dirty: boolean; onReset: () => void;
  busy: DownloadKind | null; busyText?: string; onDownload: (k: DownloadKind) => void; hideDownload?: boolean;
  /** Site Attendance: "Particular date" is the first / default option, with a dd-mm-yyyy box and < > arrows */
  particularFirst?: boolean;
  /** a field above the dropdowns (Site Attendance: the ATTENDANCE dropdown) */ top?: React.ReactNode;
  /** label of field 5 (default SITE; Office Attendance: OFFICE) */ siteLabel?: string;
  /** field (0) Company, the first filter */ company?: React.ReactNode;
  /** chip under the filters: Company: <name> · <n> employees */ companyChip?: React.ReactNode;
  /** grey line under the buttons: what Download PDF / Excel will make */ preview?: string;
}) {
  const desktop = useIsDesktop();
  const p = monthPeriod(year, month);
  const thisYear = Number(p.todayISO.slice(0, 4)); const thisMonth = Number(p.todayISO.slice(5, 7));
  const years = Array.from({ length: Math.max(thisYear, year) - 2024 + 1 }, (_, i) => ({ value: 2024 + i, label: String(2024 + i) }));
  const monthOpts = MONTHS.map((n, i) => ({ value: i + 1, label: n, disabled: year > thisYear || (year === thisYear && i + 1 > thisMonth) }));
  const dayNoOf = (iso: string) => Math.min(p.lastDay, Math.max(1, Number(iso.slice(8, 10)) || 1));
  const dayOpts = p.days.map((d, i) => ({ value: i + 1, label: `${dmy(d)} ${wdOf(d)}`, disabled: d > p.maxDay }));

  const step = (d: number) => { const i = p.days.indexOf(day) + d; if (i >= 0 && p.days[i] && p.days[i] <= p.maxDay) onDay(p.days[i]); };
  const arrow = (dir: -1 | 1, off: boolean) => (
    <Pressable disabled={off} onPress={() => step(dir)} accessibilityRole="button" accessibilityLabel={dir < 0 ? 'Previous day' : 'Next day'}
      style={[{ width: CTRL_H, height: CTRL_H, borderRadius: CTRL_R, alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff', borderWidth: 1, borderColor: '#B9D4F6' }, off && { opacity: 0.4 }]}>
      <Ionicons name={dir < 0 ? 'chevron-back' : 'chevron-forward'} size={20} color={C.blue} />
    </Pressable>
  );
  const year$ = <Fld n={1} label="YEAR" style={{ flex: 1 }}><Dropdown width="100%" value={year} options={years} onChange={(y) => onYearMonth(y, y === thisYear && month > thisMonth ? thisMonth : month)} /></Fld>;
  const month$ = <Fld n={2} label="MONTH" style={{ flex: 1.2 }}><Dropdown width="100%" value={month} options={monthOpts} onChange={(m) => onYearMonth(year, m)} /></Fld>;
  const date$ = (
    <Fld n={3} label="DATE" style={desktop ? { flex: particularFirst && dateMode === 'day' ? 3.4 : 1.6 } : undefined}>
      {/* Particular date: the date box sits in the SAME field, next to the dropdown (under it on a phone) */}
      <View style={{ flexDirection: desktop && particularFirst ? 'row' : 'column', alignItems: desktop && particularFirst ? 'center' : 'stretch', gap: 8 }}>
        <View style={{ flex: desktop && particularFirst && dateMode === 'day' ? 1 : undefined, minWidth: 0 }}>
          <Dropdown width="100%" value={dateMode === 'day' ? 2 : 1} onChange={(v) => onDateMode(v === 2 ? 'day' : 'all')}
            options={particularFirst ? [{ value: 2, label: 'Particular date' }, { value: 1, label: 'Whole month' }]
              : [{ value: 1, label: 'Whole month' }, { value: 2, label: 'Particular date 📅' }]} />
        </View>
        {dateMode === 'day' ? (
          <View style={{ flex: desktop && particularFirst ? 1.5 : undefined, minWidth: 0, flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            {particularFirst ? arrow(-1, day <= p.first) : null}
            <View style={{ flex: 1, minWidth: 0 }}>
              <DateBox text={dmy(day)} value={day} min={p.first} max={p.maxDay} onPick={onDay}
                native={Platform.OS === 'web' ? undefined : <Dropdown width="100%" value={dayNoOf(day)} options={dayOpts} onChange={(v) => onDay(p.days[v - 1])} />} />
            </View>
            {particularFirst ? arrow(1, day >= p.maxDay) : null}
          </View>
        ) : null}
      </View>
    </Fld>
  );
  // Attendance screens: just ONE date bar (calendar opens on click, limited to the month, no future days).
  // "Whole month" is a small switch under it; the bar then reads "Whole month".
  const dateOne = (
    <Fld n={3} label="DATE" style={desktop ? { flex: 1.6 } : undefined}>
      {dateMode === 'day' ? (
        <DateBox text={dmy(day)} value={day} min={p.first} max={p.maxDay} onPick={onDay}
          native={Platform.OS === 'web' ? undefined : <Dropdown width="100%" value={dayNoOf(day)} options={dayOpts} onChange={(v) => onDay(p.days[v - 1])} />} />
      ) : (
        <View style={st.dateBox}><Text style={st.dateTx}>Whole month</Text></View>
      )}
      <Pressable onPress={() => onDateMode(dateMode === 'day' ? 'all' : 'day')} accessibilityRole="button" hitSlop={6} style={{ marginTop: 4 }}>
        <Text style={{ fontSize: 11.5, fontWeight: '800', color: C.blue }}>{dateMode === 'day' ? 'Switch to Whole month' : 'Pick a date'}</Text>
      </Pressable>
    </Fld>
  );
  const city$ = <Fld n={4} label="CITY" style={{ flex: 1 }}><Dropdown width="100%" {...city} /></Fld>;
  const site$ = <Fld n={5} label={siteLabel ?? 'SITE'} style={desktop ? { flex: 1.4 } : { flex: 1 }}><Dropdown width="100%" {...site} /></Fld>;
  const emp$ = <Fld n={6} label="EMPLOYEE" style={desktop ? { flex: 1.3 } : undefined}><Dropdown width="100%" {...emp} /></Fld>;

  // ONE Download PDF and ONE Download Excel: the file follows exactly the choices above
  const btn = (kind: DownloadKind, label: string, green: boolean, grow: boolean) => (
    <Pressable disabled={!!busy} onPress={() => onDownload(kind)} accessibilityRole="button"
      style={[st.dl, grow && { flex: 1 }, green ? { borderColor: '#1E7B45', backgroundColor: '#fff' } : { borderColor: C.blue, backgroundColor: C.blue }, !!busy && { opacity: 0.6 }]}>
      <Text style={[st.dlTx, { color: green ? '#1E7B45' : '#fff' }]} numberOfLines={1}>{busy === kind ? (busyText || 'Preparing...') : `⬇ ${label}`}</Text>
    </Pressable>
  );

  return (
    <View>
      <Text style={st.title}>{title}</Text>
      <Card>
        {top ? <View style={{ marginBottom: 12 }}>{top}</View> : null}
        {desktop ? (
          <View style={st.rowD}>
            {year$}{month$}{particularFirst ? dateOne : date$}{city$}{site$}{emp$}
            {/* desktop: Download PDF / Excel sit at the end of the dropdown line, level with the dropdown boxes */}
            {hideDownload ? null : <View style={{ flexDirection: 'row', gap: 8, marginTop: 24 }}>{btn('pdf', 'PDF', false, false)}{btn('xlsx', 'Excel', true, false)}</View>}
          </View>
        ) : (
          <View style={{ gap: 10 }}>
            <View style={st.rowM}>{year$}{month$}</View>
            {particularFirst ? dateOne : date$}
            <View style={st.rowM}>{city$}{site$}</View>
            {emp$}
          </View>
        )}
        {extra ? <View style={{ marginTop: 12 }}>{extra}</View> : null}
        {dirty ? <Text style={[st.reset, { marginTop: 10, fontSize: 12.5 }]} onPress={onReset}>Reset filters</Text> : null}
        <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
          {hideDownload ? null : <View style={{ gap: 10, width: desktop ? undefined : '100%' }}>
            {company ? <View style={{ minWidth: 240 }}>{company}</View> : null}
            {desktop ? null : <View style={{ flexDirection: 'row', gap: 10 }}>{btn('pdf', 'Download PDF', false, true)}{btn('xlsx', 'Download Excel', true, true)}</View>}
          </View>}
        </View>
        {preview ? <Text style={[st.showLbl, { marginTop: 10 }]}>{preview}</Text> : null}
      </Card>
    </View>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 14, fontWeight: '800', color: '#102A45', marginBottom: 8, marginTop: 4 },
  rowD: { flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  rowM: { flexDirection: 'row', gap: 10 },
  lblRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  badge: { width: 18, height: 18, borderRadius: 9, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center' },
  badgeTx: { color: '#fff', fontSize: 10.5, fontWeight: '800' },
  lbl: { fontSize: 11.5, fontWeight: '800', color: '#5A6F86', letterSpacing: 0.4 },
  sep: { borderTopWidth: 1, borderTopColor: '#E6EDF5', borderStyle: 'dashed', marginVertical: 12 },
  dl: { paddingHorizontal: 18, height: 44, borderRadius: 10, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  dlTx: { fontSize: 14, fontWeight: '800' },
  showLbl: { fontSize: 12.5, fontWeight: '600', color: C.muted },
  infoChip: { backgroundColor: '#FFF1DC', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6, alignSelf: 'flex-start' },
  infoTx: { fontSize: 12.5, fontWeight: '700', color: '#9A5B00' },
  dateBox: { height: CTRL_H, borderRadius: CTRL_R, backgroundColor: '#EAF3FF', borderWidth: 1, borderColor: '#B9D4F6', paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dateTx: { fontSize: 15, fontWeight: '800', color: '#0E3F7A', flexShrink: 1 },
  reset: { color: C.blue, fontWeight: '800' },
});
