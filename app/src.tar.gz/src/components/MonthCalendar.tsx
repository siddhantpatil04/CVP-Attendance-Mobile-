import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { MonthDay } from '../lib/api';
import { DAYS, istDateISO, MONTHS } from '../lib/time';
import { C } from '../theme';

const DOT: Record<string, string> = {
  Present: C.green,
  'Checked In': C.purple,
  Absent: C.red,
  Leave: C.amber,
  Holiday: C.blue,
};

/** Month grid with a coloured dot per day (same legend as the web app) */
export function MonthCalendar({ year, month, days }: { year: number; month: number; days: MonthDay[] }) {
  const byDay = new Map(days.map((d) => [Number(d.day.slice(8, 10)), d.status]));
  const first = new Date(Date.UTC(year, month - 1, 1)).getUTCDay();
  const total = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const today = istDateISO();
  const cells: (number | null)[] = [...Array(first).fill(null), ...Array.from({ length: total }, (_, i) => i + 1)];
  while (cells.length % 7) cells.push(null);

  return (
    <View>
      <Text style={st.title}>{MONTHS[month - 1]} {year}</Text>
      <View style={st.grid}>
        {DAYS.map((d) => <Text key={d} style={st.dow}>{d.slice(0, 2)}</Text>)}
        {cells.map((n, i) => {
          const iso = n ? `${year}-${String(month).padStart(2, '0')}-${String(n).padStart(2, '0')}` : '';
          const isToday = iso === today;
          const status = n ? byDay.get(n) : undefined;
          return (
            <View key={i} style={st.cell}>
              {n ? (
                <View style={[st.day, isToday && st.today]}>
                  <Text style={[st.dayText, isToday && { color: C.white, fontWeight: '800' }]}>{n}</Text>
                  {status && DOT[status] ? <View style={[st.dot, { backgroundColor: isToday ? C.white : DOT[status] }]} /> : null}
                </View>
              ) : null}
            </View>
          );
        })}
      </View>
      <View style={st.legend}>
        {['Present', 'Checked In', 'Absent', 'Leave', 'Holiday'].map((k) => (
          <View key={k} style={st.legendItem}>
            <View style={[st.legendDot, { backgroundColor: DOT[k] }]} />
            <Text style={st.legendText}>{k}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  title: { fontWeight: '800', color: '#102A45', fontSize: 15, marginBottom: 8 },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  dow: { width: `${100 / 7}%`, textAlign: 'center', fontSize: 11, color: '#8594A6', fontWeight: '800', paddingVertical: 4 },
  cell: { width: `${100 / 7}%`, alignItems: 'center', paddingVertical: 2 },
  day: { width: 34, height: 34, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  today: { backgroundColor: C.blue },
  dayText: { fontSize: 13, color: '#203951' },
  dot: { width: 5, height: 5, borderRadius: 3, position: 'absolute', bottom: 3 },
  legend: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 8 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  legendDot: { width: 7, height: 7, borderRadius: 4 },
  legendText: { fontSize: 11, color: '#74869A' },
});
