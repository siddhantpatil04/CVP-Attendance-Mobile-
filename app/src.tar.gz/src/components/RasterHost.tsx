import React, { useEffect, useRef } from 'react';
import { Platform, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { RASTER_HTML, RasterJob, RasterResult, setRasterRunner } from '../lib/marathiRaster';

/**
 * Phone only: an invisible WebView that draws Marathi / Hindi text as pictures for the Daily Report PDF
 * (the phone's WebView joins the Devanagari letters correctly; the PDF library cannot).
 */
export default function RasterHost() {
  const ref = useRef<WebView>(null);
  const ready = useRef<Promise<void> | null>(null);
  const markReady = useRef<() => void>(() => {});
  const pending = useRef(new Map<string, (r: RasterResult | null) => void>());

  if (ready.current == null) ready.current = new Promise<void>((res) => { markReady.current = res; });

  useEffect(() => {
    if (Platform.OS === 'web') return;
    setRasterRunner(async (jobs: RasterJob[]) => {
      // wait (at most 8 s) until the page has loaded
      await Promise.race([ready.current, new Promise<void>((r) => setTimeout(r, 8000))]);
      const out: Record<string, RasterResult | null> = {};
      const runPart = async (part: RasterJob[]) => {
        await Promise.all([
          ...part.map((j) => new Promise<void>((resolve) => {
            const t = setTimeout(() => { pending.current.delete(j.id); out[j.id] = null; resolve(); }, 20000 + part.length * 200);
            pending.current.set(j.id, (r) => { clearTimeout(t); out[j.id] = r; resolve(); });
          })),
          Promise.resolve().then(() => ref.current?.injectJavaScript(`window.renderJobs(${JSON.stringify(part)}); true;`)),
        ]);
      };
      for (let i = 0; i < jobs.length; i += 15) await runPart(jobs.slice(i, i + 15));
      // two different texts must never give the same picture: if they do, draw those cells again one by one
      const byImg = new Map<string, string[]>();
      for (const [id, r] of Object.entries(out)) if (r) byImg.set(r.img, [...(byImg.get(r.img) ?? []), id]);
      for (const ids of byImg.values()) {
        if (ids.length < 2) continue;
        for (const id of ids) {
          const job = jobs.find((j) => j.id === id);
          if (!job) continue;
          await new Promise<void>((r) => setTimeout(r, 120));
          await runPart([job]);
        }
      }
      return out;
    });
    return () => setRasterRunner(null);
  }, []);

  if (Platform.OS === 'web') return null;
  // The WebView sits inside a 1 x 1 invisible box that is taken out of the layout (a bare WebView takes half the screen on Android)
  return (
    <View pointerEvents="none" collapsable={false} style={{ position: 'absolute', left: 0, top: 0, width: 1, height: 1, opacity: 0, overflow: 'hidden' }}>
      <WebView
        ref={ref} originWhitelist={['*']} source={{ html: RASTER_HTML, baseUrl: 'https://localhost' }} javaScriptEnabled
        style={{ width: 1, height: 1, flex: 0 }}
        onMessage={(e) => {
          try {
            const m = JSON.parse(e.nativeEvent.data);
            if (m.ready) { markReady.current(); return; }
            const done = pending.current.get(m.id);
            if (done) { pending.current.delete(m.id); done(m.img ? { img: m.img, hMm: m.hMm } : null); }
          } catch { /* ignore */ }
        }}
      />
    </View>
  );
}
