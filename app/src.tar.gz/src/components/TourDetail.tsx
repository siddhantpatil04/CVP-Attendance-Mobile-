﻿import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Linking, StyleSheet, Text, View } from 'react-native';
import { api, Tour, TOUR_CATEGORIES, TourDocument, TourExpense, TourTask } from '../lib/api';
import { useAuth } from '../lib/auth';
import { useRealtime } from '../lib/realtime';
import { errorText } from '../lib/supabase';
import { fmtISODate, istDateISO } from '../lib/time';
import { C } from '../theme';
import { Dropdown, PickerField } from './Pickers';
import { Banner, Button, Card, Col, Empty, Field, Pill, Row, SectionTitle, Segmented } from './ui';

type Part = 'tasks' | 'expenses' | 'documents';
type Shot = { uri: string; base64: string };

const money = (n: number) => `Rs ${Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

/** Picks (or photographs) an image and shrinks it to a ~1280px JPEG */
async function pickShot(camera: boolean): Promise<Shot | null> {
  if (camera) {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) { Alert.alert('Camera permission needed', 'Allow camera access in Settings to photograph the receipt.'); return null; }
  }
  const opts: ImagePicker.ImagePickerOptions = { mediaTypes: ['images'], quality: 0.8, allowsEditing: false };
  const res = camera ? await ImagePicker.launchCameraAsync(opts) : await ImagePicker.launchImageLibraryAsync(opts);
  if (res.canceled || !res.assets?.[0]) return null;
  const ref = await ImageManipulator.manipulate(res.assets[0].uri).resize({ width: 1280 }).renderAsync();
  const out = await ref.saveAsync({ compress: 0.7, format: SaveFormat.JPEG, base64: true });
  if (!out.base64) { Alert.alert('Could not process the photo'); return null; }
  return { uri: out.uri, base64: out.base64 };
}

const addDays = (iso: string, n: number) => {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};

/**
 * One tour's report: tasks completed (with remark), expenses (with receipt) and documents.
 * editable = the employee adds / deletes entries (only while the approved tour is open); otherwise read-only (Admin / HR).
 */
export default function TourDetail({ tour, editable }: { tour: Tour; editable: boolean }) {
  const { profile } = useAuth();
  const [part, setPart] = useState<Part>('tasks');
  const [tasks, setTasks] = useState<TourTask[] | null>(null);
  const [expenses, setExpenses] = useState<TourExpense[]>([]);
  const [docs, setDocs] = useState<TourDocument[]>([]);
  const [busy, setBusy] = useState(false);

  const today = istDateISO();
  const open = editable && tour.status === 'Approved' && today >= tour.from_day && today <= addDays(tour.to_day, 7);
  const clamp = (d: string) => (d < tour.from_day ? tour.from_day : d > tour.to_day ? tour.to_day : d);

  // task form
  const [tDate, setTDate] = useState(clamp(today));
  const [task, setTask] = useState('');
  const [remark, setRemark] = useState('');
  // expense form
  const [eDate, setEDate] = useState(clamp(today));
  const [cat, setCat] = useState(0);
  const [amount, setAmount] = useState('');
  const [eNote, setENote] = useState('');
  const [receipt, setReceipt] = useState<Shot | null>(null);
  // document form
  const [dTitle, setDTitle] = useState('');
  const [dShot, setDShot] = useState<Shot | null>(null);

  const load = useCallback(async () => {
    try {
      const [t, e, d] = await Promise.all([api.tourTasks(tour.id), api.tourExpenses(tour.id), api.tourDocuments(tour.id)]);
      setTasks(t); setExpenses(e); setDocs(d);
    } catch (err) {
      Alert.alert('Could not load', errorText(err));
    }
  }, [tour.id]);
  useEffect(() => { setTasks(null); load(); }, [load]);
  useRealtime(`tour-${tour.id}`, [
    { table: 'tour_expenses', filter: `tour_id=eq.${tour.id}` },
    { table: 'tour_tasks', filter: `tour_id=eq.${tour.id}` },
    { table: 'tour_documents', filter: `tour_id=eq.${tour.id}` },
  ], () => load());

  const total = expenses.reduce((s, x) => s + Number(x.amount), 0);

  const run = async (fn: () => Promise<void>, title: string) => {
    setBusy(true);
    try { await fn(); await load(); } catch (e) { Alert.alert(title, errorText(e)); } finally { setBusy(false); }
  };

  const addTask = () => {
    if (!task.trim()) return Alert.alert('Enter the task / meeting you completed.');
    run(async () => { await api.addTourTask(tour.id, tDate, task.trim(), remark.trim() || undefined); setTask(''); setRemark(''); }, 'Could not save');
  };
  const addExpense = () => {
    const amt = Number(amount.replace(/,/g, ''));
    if (!amt || amt <= 0) return Alert.alert('Enter the amount.');
    run(async () => {
      let path: string | undefined;
      if (receipt && profile) path = await api.uploadTourFile(profile.id, tour.id, receipt.base64);
      try {
        await api.addTourExpense(tour.id, eDate, TOUR_CATEGORIES[cat], amt, eNote.trim() || undefined, path);
      } catch (e) {
        if (path) await supabase_remove(path);
        throw e;
      }
      setAmount(''); setENote(''); setReceipt(null);
    }, 'Could not save');
  };
  const addDoc = () => {
    if (!dTitle.trim()) return Alert.alert('Enter the document name.');
    if (!dShot || !profile) return Alert.alert('Attach a photo or scan of the document.');
    run(async () => {
      const path = await api.uploadTourFile(profile.id, tour.id, dShot.base64);
      try { await api.addTourDocument(tour.id, dTitle.trim(), path); } catch (e) { await supabase_remove(path); throw e; }
      setDTitle(''); setDShot(null);
    }, 'Could not save');
  };

  const remove = (kind: 'expense' | 'task' | 'document', id: number) =>
    Alert.alert('Delete this entry?', '', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => run(() => api.deleteTourItem(kind, id), 'Could not delete') },
    ]);

  const view = async (path: string) => {
    try { Linking.openURL(await api.tourFileUrl(path)); } catch (e) { Alert.alert('File unavailable', errorText(e)); }
  };

  const attach = (shot: Shot | null, set: (s: Shot | null) => void, label: string) => (
    <View style={{ marginBottom: 8 }}>
      <Row style={{ flexWrap: 'wrap' }}>
        <Button title={shot ? `Change ${label}` : `Take photo of ${label}`} icon="camera-outline" variant="secondary" small
          onPress={async () => { const s = await pickShot(true); if (s) set(s); }} />
        <Button title="From gallery" icon="image-outline" variant="secondary" small
          onPress={async () => { const s = await pickShot(false); if (s) set(s); }} />
        {shot ? <Button title="Remove" icon="close-outline" variant="ghost" small onPress={() => set(null)} /> : null}
      </Row>
      {shot ? <Text style={st.ok}>Photo attached</Text> : null}
    </View>
  );

  return (
    <View>
      <Card>
        <Row style={{ justifyContent: 'space-between' }}>
          <Text style={st.city}>{tour.city}</Text>
          <Pill text={tour.status} />
        </Row>
        <Text style={st.sub}>{fmtISODate(tour.from_day)} to {fmtISODate(tour.to_day)}</Text>
        <Text style={st.sub}>{tour.reason}</Text>
        <Text style={st.total}>Total expenses: {money(total)}</Text>
      </Card>

      {editable && !open ? (
        <Banner tone="amber" icon="lock-closed-outline"
          text={tour.status !== 'Approved' ? 'Entries can be added only to an approved tour.'
            : today < tour.from_day ? `You can add entries from ${fmtISODate(tour.from_day)}.`
            : 'This tour is closed. Entries are allowed up to 7 days after the last day.'} />
      ) : null}

      <Segmented value={part} onChange={setPart} options={[
        { value: 'tasks', label: `Tasks (${tasks?.length ?? 0})` },
        { value: 'expenses', label: `Expenses (${expenses.length})` },
        { value: 'documents', label: `Documents (${docs.length})` },
      ]} />

      {tasks === null ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : null}

      {tasks !== null && part === 'tasks' ? (
        <>
          {open ? (
            <Card>
              <PickerField label="Date" mode="date" value={tDate} minimumDate={new Date(`${tour.from_day}T00:00:00`)} onChange={setTDate} />
              <Field label="Task / meeting completed" value={task} onChangeText={setTask} multiline placeholder="e.g. Met the client, finalised the site measurement" />
              <Field label="Remark (optional)" value={remark} onChangeText={setRemark} multiline placeholder="Result, next steps, who you met" />
              <Button title="Add Task" icon="add-circle-outline" loading={busy} onPress={addTask} />
            </Card>
          ) : null}
          <SectionTitle title="Tasks completed" />
          <Card>
            {tasks.length === 0 ? <Empty icon="checkmark-done-outline" text="No tasks added yet." /> : tasks.map((x) => (
              <View key={x.id} style={st.item}>
                <Text style={st.itemTitle}>{x.task}</Text>
                <Text style={st.sub}>{fmtISODate(x.task_date)}</Text>
                {x.remark ? <Text style={st.remark}>Remark: {x.remark}</Text> : null}
                {open ? <Button title="Delete" variant="danger" small style={st.del} onPress={() => remove('task', x.id)} /> : null}
              </View>
            ))}
          </Card>
        </>
      ) : null}

      {tasks !== null && part === 'expenses' ? (
        <>
          {open ? (
            <Card>
              <Row style={{ alignItems: 'flex-start' }}>
                <Col><PickerField label="Expense date" mode="date" value={eDate} minimumDate={new Date(`${tour.from_day}T00:00:00`)}
                  maximumDate={new Date(`${tour.to_day}T00:00:00`)} onChange={setEDate} /></Col>
                <Col>
                  <Text style={st.lbl}>Category</Text>
                  <Dropdown width="100%" value={cat} onChange={setCat} options={TOUR_CATEGORIES.map((c, i) => ({ value: i, label: c }))} />
                </Col>
              </Row>
              <Row style={{ alignItems: 'flex-start', marginTop: 8 }}>
                <Col><Field label="Amount (Rs)" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="0.00" /></Col>
                <Col><Field label="Note (optional)" value={eNote} onChangeText={setENote} placeholder="e.g. Bus ticket" /></Col>
              </Row>
              {attach(receipt, setReceipt, 'receipt')}
              <Button title="Add Expense" icon="add-circle-outline" loading={busy} onPress={addExpense} />
            </Card>
          ) : null}
          <SectionTitle title="Expenses" note={`Total ${money(total)}`} />
          <Card>
            {expenses.length === 0 ? <Empty icon="receipt-outline" text="No expenses added yet." /> : expenses.map((x) => (
              <View key={x.id} style={st.item}>
                <Row style={{ justifyContent: 'space-between' }}>
                  <Text style={st.itemTitle}>{x.category}</Text>
                  <Text style={st.amount}>{money(x.amount)}</Text>
                </Row>
                <Text style={st.sub}>{fmtISODate(x.expense_date)}{x.note ? ` - ${x.note}` : ''}</Text>
                <Row style={{ marginTop: 6, flexWrap: 'wrap' }}>
                  {x.receipt_path ? <Button title="View receipt" icon="image-outline" variant="secondary" small onPress={() => view(x.receipt_path!)} /> : null}
                  {open ? <Button title="Delete" variant="danger" small onPress={() => remove('expense', x.id)} /> : null}
                </Row>
              </View>
            ))}
          </Card>
        </>
      ) : null}

      {tasks !== null && part === 'documents' ? (
        <>
          {open ? (
            <Card>
              <Field label="Document name" value={dTitle} onChangeText={setDTitle} placeholder="e.g. Signed work order, site report" />
              {attach(dShot, setDShot, 'document')}
              <Button title="Add Document" icon="add-circle-outline" loading={busy} onPress={addDoc} />
            </Card>
          ) : null}
          <SectionTitle title="Documents" />
          <Card>
            {docs.length === 0 ? <Empty icon="document-outline" text="No documents added yet." /> : docs.map((x) => (
              <View key={x.id} style={st.item}>
                <Text style={st.itemTitle}>{x.title}</Text>
                <Text style={st.sub}>{fmtISODate(x.created_at.slice(0, 10))}</Text>
                <Row style={{ marginTop: 6, flexWrap: 'wrap' }}>
                  <Button title="View" icon="image-outline" variant="secondary" small onPress={() => view(x.file_path)} />
                  {open ? <Button title="Delete" variant="danger" small onPress={() => remove('document', x.id)} /> : null}
                </Row>
              </View>
            ))}
          </Card>
        </>
      ) : null}
    </View>
  );
}

// best-effort cleanup of an uploaded file when saving its entry fails
async function supabase_remove(path: string) {
  try { await api.removeTourFile(path); } catch { /* ignore */ }
}

const st = StyleSheet.create({
  city: { fontSize: 17, fontWeight: '800', color: C.ink },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 3, lineHeight: 18 },
  total: { marginTop: 10, fontWeight: '800', color: C.ink, fontSize: 15 },
  item: { paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  itemTitle: { fontWeight: '800', color: '#102A45', fontSize: 14, flexShrink: 1 },
  remark: { color: '#203951', marginTop: 4, lineHeight: 19 },
  amount: { fontWeight: '800', color: C.ink },
  lbl: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  ok: { color: C.green, fontSize: 12, marginTop: 4, fontWeight: '700' },
  del: { marginTop: 6, alignSelf: 'flex-start' },
});

