﻿import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Text } from 'react-native';
import { api, Site } from '../lib/api';
import { errorText } from '../lib/supabase';
import { C } from '../theme';
import { Button, Card, Empty, Row, Toggle } from './ui';

/**
 * Admin / HR: choose which work sites one employee may check in and out at.
 * Only the ticked sites are allocated (none ticked = no site: the employee cannot check in until a site is allocated).
 * The "Save Site Access" button is shown by the parent page, at the end of Access Control, once something has changed.
 */
export type SiteAccessState = { changed: boolean; busy: boolean; save: () => Promise<void> };

export function SiteAccessCard({ userId, canManage, onState }: { userId: string; canManage: boolean; onState?: (s: SiteAccessState) => void }) {
  const [sites, setSites] = useState<Site[] | null>(null);
  const [picked, setPicked] = useState<number[]>([]);
  const [saved, setSaved] = useState<number[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [s, mine] = await Promise.all([api.sites(true), api.employeeSites(userId)]);
      setSites(s.filter((x) => !x.is_office));   // the office location is for office employees, not a site
      setPicked(mine);
      setSaved(mine);
    } catch (e) {
      Alert.alert('Could not load sites', errorText(e));
    }
  }, [userId]);
  useEffect(() => { load(); }, [load]);

  const toggle = (id: number, on: boolean) => setPicked((p) => (on ? [...p, id] : p.filter((x) => x !== id)));
  const changed = picked.length !== saved.length || picked.some((x) => !saved.includes(x));

  const save = async () => {
    setBusy(true);
    try {
      await api.setEmployeeSites(userId, picked);
      setSaved(picked);
      Alert.alert('Site access saved', picked.length === 0 ? 'No site is allocated now: this employee can use every active site again.' :`This employee can use ${picked.length} site(s).`);
    } catch (e) {
      Alert.alert('Could not save', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => { onState?.({ changed, busy, save }); }, [changed, busy, picked, saved]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Card>
      {sites && sites.length > 0 ? (
        <Row style={{ marginBottom: 8 }}>
          <Button title={`Select all (${sites.length})`} icon="checkbox-outline" variant="secondary" small style={{ flex: 1 }} disabled={!canManage}
            onPress={() => setPicked(sites.map((x) => x.id))} />
          <Button title="Clear all" icon="close-circle-outline" variant="secondary" small style={{ flex: 1 }} disabled={!canManage}
            onPress={() => setPicked([])} />
        </Row>
      ) : null}
      {sites === null ? null : sites.length === 0 ? (
        <Empty icon="location-outline" text="No active work sites yet. The Admin adds sites under Work Sites." />
      ) : sites.map((s) => (
        <Toggle key={s.id} label={s.name} note={`${s.lat.toFixed(4)}, ${s.lng.toFixed(4)}`}
          value={picked.includes(s.id)} onChange={(v) => canManage && toggle(s.id, v)} />
      ))}
      {sites && sites.length > 0 ? (
        <Text style={{ color: C.muted, fontSize: 12, marginBottom: 4 }}>
          {picked.length === 0 ? 'Currently: no site allocated - all active sites are allowed.' : `Currently: ${picked.length} site(s) allocated - only these sites are allowed.`}
        </Text>
      ) : null}
    </Card>
  );
}


