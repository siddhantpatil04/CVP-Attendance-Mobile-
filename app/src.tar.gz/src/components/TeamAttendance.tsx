import { useNavigation } from '@react-navigation/native';
import React, { useMemo, useState } from 'react';
import { Text, View } from 'react-native';
import { C } from '../theme';
import type { BoardRow } from '../lib/api';
import { useTicker } from '../lib/realtime';
import { fmtMinutes, hhmmTo12 } from '../lib/time';
import { Dropdown } from './Pickers';
import { Avatar, Card, Empty, ListItem, Pill } from './ui';

type Filter = 'All' | 'Checked In' | 'Present' | 'Not In' | 'Leave' | 'Site' | 'Office';

const isOffice = (r: BoardRow) => !r.site_employee && (r.role === 'Employee' || r.role === 'HR');

/** "Today's team attendance": a drop-down of views (with counts); the list opens when one is chosen. */
export function TeamAttendance({ board: allRows }: { board: BoardRow[] }) {
  const board = useMemo(() => allRows.filter((r) => r.role !== 'Admin'), [allRows]);   // the Admin is the owner: no attendance
  const nav = useNavigation<any>();
  const now = useTicker(30000); // refresh "working for" timers every 30 s
  const [view, setView] = useState(-1); // -1 = list hidden, otherwise the chosen view

  const FILTERS: { key: Filter; label: string; count: number }[] = [
    { key: 'All', label: 'All employees', count: board.length },
    { key: 'Checked In', label: 'Working', count: board.filter((r) => r.status === 'Checked In').length },
    { key: 'Present', label: 'Checked out', count: board.filter((r) => r.status === 'Present').length },
    { key: 'Not In', label: 'Not checked in', count: board.filter((r) => r.status === 'Not Checked In' || r.status === 'Absent').length },
    { key: 'Leave', label: 'On leave', count: board.filter((r) => r.status === 'Leave').length },
    { key: 'Office', label: 'Office', count: board.filter(isOffice).length },
    { key: 'Site', label: 'Site', count: board.filter((r) => r.site_employee).length },
  ];
  const filter = view >= 0 ? FILTERS[view].key : 'All';

  const rows = useMemo(() => {
    switch (filter) {
      case 'Checked In': return board.filter((r) => r.status === 'Checked In');
      case 'Present': return board.filter((r) => r.status === 'Present');
      case 'Not In': return board.filter((r) => r.status === 'Not Checked In' || r.status === 'Absent');
      case 'Leave': return board.filter((r) => r.status === 'Leave');
      case 'Office': return board.filter(isOffice);
      case 'Site': return board.filter((r) => r.site_employee);
      default: return board;
    }
  }, [board, filter]);

  // Every employee sits in the section of his department (new employees land there automatically)
  const groups = useMemo(() => {
    const m = new Map<string, BoardRow[]>();
    for (const r of rows) { const d = (r.department || '').trim() || 'General'; m.set(d, [...(m.get(d) ?? []), r]); }
    return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [rows]);

  const workingFor = (r: BoardRow) => {
    if (!r.check_in_at) return null;
    if (r.check_out_at) return r.work_minutes;
    return Math.max(0, Math.floor((now - new Date(r.check_in_at).getTime()) / 60000));
  };

  return (
    <>
      <View style={{ marginBottom: 10 }}>
        <Dropdown width="100%" value={view} onChange={setView}
          options={[{ value: -1, label: 'Select view' }, ...FILTERS.map((f, i) => ({ value: i, label: `${f.label} (${f.count})` }))]} />
      </View>
      <Card style={{ paddingVertical: 4, display: view < 0 ? 'none' : 'flex' }}>
        {rows.length === 0 ? <Empty text="No employees in this view." icon="people-outline" /> : groups.map(([dept, list]) => (
          <View key={dept}>
            <Text style={{ fontWeight: '800', color: C.blue, fontSize: 13, paddingTop: 10, paddingHorizontal: 4 }}>{dept} ({list.length})</Text>
            {list.map((r) => {
          const wf = workingFor(r);
          return (
            <ListItem
              key={r.user_id}
              left={<Avatar name={r.full_name} size={40} />}
              title={r.full_name}
              subtitle={[
                r.in_time ? `In ${hhmmTo12(r.in_time)}` : null,
                r.out_time ? `Out ${hhmmTo12(r.out_time)}` : null,
                wf != null ? fmtMinutes(wf) : null,
                r.site_name ? `${r.site_name}` : null,
                r.leave_type,
                !r.in_time && !r.leave_type ? (r.department || 'General') : null,
              ].filter(Boolean).join(' - ')}
              right={
                <View style={{ alignItems: 'flex-end', gap: 4 }}>
                  <Pill text={r.status === 'Present' ? 'Checked Out' : r.status} tone={r.status === 'Present' ? 'green' : undefined} />
                </View>
              }
              onPress={() => nav.navigate('EmployeeDetail', { userId: r.user_id })}
            />
          );
            })}
          </View>
        ))}
      </Card>
    </>
  );
}
