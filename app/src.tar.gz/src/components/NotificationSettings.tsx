import React from 'react';
import { Alert, Platform, StyleSheet, Text, View } from 'react-native';
import { Button, Card, Pill } from './ui';
import { askWebNotify, notificationsApi, webNotifyPermission } from '../lib/notifications';
import { openPhoneSettings, pushPermission, PushPermission, registeredToken, registerPush } from '../lib/push';
import { errorText } from '../lib/supabase';
import { C } from '../theme';

/** My Profile > Notifications: Phone notifications On / Off, this phone registered, Allow notifications, Send test notification */
export default function NotificationSettings() {
  const web = Platform.OS === 'web';
  const [perm, setPerm] = React.useState<PushPermission>('undetermined');
  const [reg, setReg] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [webPerm, setWebPerm] = React.useState(webNotifyPermission());
  const refresh = React.useCallback(async () => { setPerm(await pushPermission()); setReg(!!(await registeredToken())); setWebPerm(webNotifyPermission()); }, []);
  React.useEffect(() => { void refresh(); }, [refresh]);

  const allow = async () => {
    if (web) { await askWebNotify(); await refresh(); return; }
    if (perm === 'denied') { openPhoneSettings(); return; }   // the phone will not ask again: open its settings
    setBusy(true);
    const r = await registerPush({ ask: true });
    setBusy(false); await refresh();
    if (!r.ok && r.permission === 'unavailable') Alert.alert('Not available', 'This app version cannot receive phone notifications. Install the latest app (version 1.1.0 or newer).');
  };
  const test = async () => {
    setBusy(true);
    try { await notificationsApi.sendTest(); Alert.alert('Sent', web ? 'A test notification was added to your list.' : 'A test notification was sent to this phone. It also appears in the bell list.'); }
    catch (e) { Alert.alert('Could not send', errorText(e)); } finally { setBusy(false); }
  };

  const on = web ? webPerm === 'granted' : perm === 'granted';
  const unavailable = !web && perm === 'unavailable';
  return (
    <Card>
      <View style={st.row}>
        <Text style={st.lbl}>{web ? 'Desktop / browser pop-ups' : 'Phone notifications'}</Text>
        <Pill text={unavailable ? 'Not available' : on ? 'On' : 'Off'} tone={on ? 'green' : 'muted'} />
      </View>
      {!web ? (
        <View style={st.row}>
          <Text style={st.lbl}>This phone registered</Text>
          <Text style={[st.val, { color: reg ? '#12A05C' : C.muted }]}>{reg ? '✓ Yes' : 'No'}</Text>
        </View>
      ) : null}
      {unavailable ? <Text style={st.note}>Phone notifications need the app version 1.1.0 or newer on a real phone.</Text> : null}
      {perm === 'denied' && !web ? <Text style={st.note}>Notifications were refused. Open the phone settings to allow them.</Text> : null}
      {!unavailable ? <Button title={perm === 'denied' && !web ? 'Open phone settings' : 'Allow notifications'} icon="notifications-outline" variant="secondary" loading={busy} disabled={on && (web || reg)} onPress={allow} style={{ marginTop: 10 }} /> : null}
      <Button title="Send test notification" icon="paper-plane-outline" variant="secondary" loading={busy} onPress={test} style={{ marginTop: 8 }} />
    </Card>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 6 },
  lbl: { fontWeight: '700', color: '#17314D', fontSize: 14 },
  val: { fontWeight: '800', fontSize: 14 },
  note: { color: C.muted, fontSize: 12.5, marginTop: 4 },
});
