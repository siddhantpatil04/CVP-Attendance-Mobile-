import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import React, { useEffect, useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { api, FieldSiteJourney, PlanChangeInput, PlanChangeType, Site } from '../lib/api';
import { isNetworkMessage, queuePlanChange } from '../lib/journeyPlanQueue';
import { errorText } from '../lib/supabase';
import { C } from '../theme';
import { Dropdown } from './Pickers';
import { Button } from './ui';

type Pos = { lat: number; lng: number; acc: number | null };

/**
 * "Change plan" while a journey is on the way: go back to the start site, go to another site, or cancel the visit.
 * No approval and no limit. The change point (GPS + time) is saved in the background; with no GPS the change is still allowed.
 * With no internet the change waits on the phone and is sent later with its original time and GPS.
 */
export default function ChangePlanSheet({ visible, onClose, journey, startSite, currentSite, sites, livePos, onDone }: {
  visible: boolean; onClose: () => void; journey: FieldSiteJourney;
  startSite?: Site; currentSite?: Site; sites: Site[]; livePos: { lat: number; lng: number } | null;
  onDone: (message: string, o: { queued: boolean; type: PlanChangeType; newSite: number | null }) => void;
}) {
  const [kind, setKind] = useState<PlanChangeType | null>(null);
  const [otherId, setOtherId] = useState(0);
  const [busy, setBusy] = useState(false);
  const [reason, setReason] = useState('');   // required only when the visit is cancelled
  const [pos, setPos] = useState<Pos | null>(null);

  // a fresh sheet every time; the position is taken when it opens (the "change point")
  useEffect(() => {
    if (!visible) return;
    setKind(null); setOtherId(0); setBusy(false); setReason('');
    let off = false;
    (async () => {
      try {
        const perm = await Location.requestForegroundPermissionsAsync();
        if (perm.status !== 'granted') throw new Error('denied');
        const p = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        if (!off) setPos({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy ?? null });
      } catch { if (!off) setPos(livePos ? { lat: livePos.lat, lng: livePos.lng, acc: null } : null); }
    })();
    return () => { off = true; };
  }, [visible]);   // eslint-disable-line react-hooks/exhaustive-deps

  // the current destination is not offered for "another site"
  const options = sites.filter((s) => s.id !== journey.to_site_id);
  const newSite: Site | undefined = kind === 'back_to_start' ? startSite : kind === 'other_site' ? sites.find((s) => s.id === otherId) : undefined;

  const problem = (): string | null => {
    if (!kind) return 'Choose what you want to do.';
    if (kind === 'other_site' && !otherId) return 'Select the new site.';
    if (kind === 'cancel' && !reason.trim()) return 'Write the reason for cancelling this visit.';
    if (kind === 'back_to_start' && (!startSite || startSite.id === journey.to_site_id)) return 'You are already going to the start site.';
    return null;
  };

  const confirm = async () => {
    const p = problem();
    if (p) return Alert.alert('Change plan', p);
    if (busy || !kind) return;
    setBusy(true);
    // the change point: a fresh position if there is one, otherwise the one from opening the sheet; with none the change is still saved
    let point: Pos | null = pos;
    try {
      const perm = await Location.getForegroundPermissionsAsync();
      if (perm.status === 'granted') {
        const q = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
        point = { lat: q.coords.latitude, lng: q.coords.longitude, acc: q.coords.accuracy ?? null };
      }
    } catch { /* keep the earlier position */ }
    const input: PlanChangeInput = {
      journeyId: journey.id, type: kind, newSite: kind === 'other_site' ? otherId : null, reason: kind === 'cancel' ? reason.trim() : '',
      lat: point?.lat ?? null, lng: point?.lng ?? null, accuracy: point?.acc ?? null,
      changedAt: new Date().toISOString(),
      key: `${journey.id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    };
    const name = newSite?.name ?? 'the new site';
    const newId = input.newSite ?? (kind === 'back_to_start' ? startSite?.id ?? null : null);
    try {
      await api.changeJourneyPlan(input);
      onDone(kind === 'cancel' ? 'Visit cancelled. The distance travelled so far is saved. You can start a new visit.' : `Plan changed. Now going to ${name}.`,
        { queued: false, type: kind, newSite: newId });
    } catch (e) {
      const msg = errorText(e);
      if (isNetworkMessage(msg)) {
        await queuePlanChange(input);
        onDone(kind === 'cancel' ? 'No internet: the cancellation is saved on your phone and is sent when the internet is back.'
          : `No internet: the change is saved on your phone and is sent when the internet is back. You are now going to ${name}.`,
          { queued: true, type: kind, newSite: newId });
      } else {
        Alert.alert('Could not change the plan', msg);
      }
    } finally { setBusy(false); }
  };

  const Option = ({ k, title, sub, icon }: { k: PlanChangeType; title: string; sub: string; icon: keyof typeof Ionicons.glyphMap }) => (
    <Pressable onPress={() => setKind(k)} accessibilityRole="button"
      style={[st.opt, kind === k && st.optOn, k === 'cancel' && kind === k && { borderColor: C.red, backgroundColor: '#FFF3F3' }]}>
      <Ionicons name={icon} size={22} color={k === 'cancel' ? C.red : C.blue} />
      <View style={{ flex: 1 }}>
        <Text style={st.optTitle}>{title}</Text>
        <Text style={st.optSub}>{sub}</Text>
      </View>
      <Ionicons name={kind === k ? 'radio-button-on' : 'radio-button-off'} size={20} color={kind === k ? C.blue : C.muted} />
    </Pressable>
  );

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={st.backdrop} onPress={onClose}>
        <Pressable style={st.sheet} onPress={() => {}}>
          <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            <Text style={st.title}>Change plan</Text>
            <Text style={st.sub}>Current plan: {journey.from_site_name} to {currentSite?.name ?? journey.to_site_name}</Text>

            <Option k="back_to_start" icon="return-up-back-outline" title="Go back to start site" sub={startSite?.name ?? journey.from_site_name ?? '-'} />
            <Option k="other_site" icon="swap-horizontal-outline" title="Go to another site" sub="Choose a different site instead" />
            {kind === 'other_site' ? (
              <View style={{ marginTop: 6 }}>
                <Dropdown width="100%" value={otherId || -1} onChange={(v) => setOtherId(v > 0 ? v : 0)}
                  options={[{ value: -1, label: 'Select the new site' }, ...options.map((s) => ({ value: s.id, label: s.name }))]} />
              </View>
            ) : null}
            <Option k="cancel" icon="close-circle-outline" title="Cancel this visit" sub="Stop the journey at your current location" />
            {kind === 'cancel' ? (
              <View style={{ marginTop: 8 }}>
                <Text style={st.reasonLabel}>Reason for cancelling the visit (required)</Text>
                <TextInput value={reason} onChangeText={setReason} multiline placeholder="e.g. Site work postponed / vehicle breakdown"
                  placeholderTextColor="#8594A6" style={st.reasonInput} />
              </View>
            ) : null}

            <Button title={kind === 'cancel' ? 'Cancel visit' : 'Confirm change'} icon="checkmark-circle-outline" loading={busy}
              disabled={!kind || (kind === 'cancel' && !reason.trim())} onPress={confirm}
              variant={kind === 'cancel' ? 'danger' : 'primary'} style={{ marginTop: 14 }} />
            <Button title="Close" variant="secondary" style={{ marginTop: 8 }} onPress={onClose} />
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const st = StyleSheet.create({
  reasonLabel: { fontSize: 12.5, fontWeight: '800', color: '#4A5A6E', marginBottom: 6 },
  reasonInput: { minHeight: 70, borderWidth: 1, borderColor: '#F0B4B4', borderRadius: 12, padding: 10, fontSize: 14, color: '#102A45', backgroundColor: '#FFF8F8', textAlignVertical: 'top' },
  backdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(6,37,63,0.4)' },
  sheet: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 18, paddingBottom: 26, maxHeight: '92%', width: '100%', maxWidth: 640, alignSelf: 'center' },
  title: { fontSize: 19, fontWeight: '800', color: C.ink },
  sub: { fontSize: 12.5, color: C.muted, marginTop: 2, marginBottom: 12 },
  opt: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: '#DCE7F3', borderRadius: 14, padding: 12, marginTop: 8, backgroundColor: '#FBFDFF' },
  optOn: { borderColor: C.blue, backgroundColor: '#EEF6FF' },
  optTitle: { fontSize: 14.5, fontWeight: '800', color: C.ink },
  optSub: { fontSize: 12.5, color: C.muted, marginTop: 1 },
});
