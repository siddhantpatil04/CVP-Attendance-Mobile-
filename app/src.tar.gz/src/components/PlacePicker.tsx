import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { NearPlace } from '../lib/api';
import { fmtDistance } from '../lib/geo';
import { C } from '../theme';
import { Banner, Button, Pill } from './ui';

/**
 * "Select your place *": ONLY the places within the allowed range right now. Nothing is selected for the employee;
 * he taps the place he is at ("Selected by you"). Used for check-in and again for check-out.
 */
export default function PlacePicker({ title = 'Select your place', hint, places, selectedId, onSelect, rangeM, loading, error, onRefresh, hideRefresh }: {
  title?: string; hint?: string; places: NearPlace[] | null; selectedId: number | null; onSelect: (p: NearPlace) => void;
  rangeM: number; loading: boolean; error: string | null; onRefresh: () => void; hideRefresh?: boolean;
}) {
  return (
    <View style={{ marginTop: 6 }}>
      <Text style={st.title}>{title} *</Text>
      <Text style={st.hint}>{hint ?? `Your places within ${fmtDistance(rangeM)} - choose where you are working.`}</Text>

      {error ? <Banner tone="amber" icon="location-outline" text={error} /> : null}

      {places && places.length > 0 ? places.map((p) => {
        const on = p.site_id === selectedId;
        return (
          <Pressable key={p.site_id} onPress={() => onSelect(p)} accessibilityRole="radio" accessibilityState={{ selected: on }}
            style={[st.row, on && st.rowOn]}>
            <View style={[st.icon, p.is_office && { backgroundColor: C.purpleSoft }, on && !p.is_office && { backgroundColor: C.green }]}>
              <Ionicons name={p.is_office ? 'business-outline' : 'location-outline'} size={18} color={on && !p.is_office ? C.white : p.is_office ? C.purple : C.blue} />
            </View>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={st.name} numberOfLines={2}>{p.name}</Text>
              <Text style={st.sub}>{on ? 'Selected by you' : p.is_office ? 'Office location' : 'Allocated site'}</Text>
            </View>
            <View style={{ alignItems: 'flex-end', gap: 4 }}>
              <Text style={st.dist}>{p.distance_m} m</Text>
              <Pill text={p.is_office ? 'Office' : `Within ${rangeM} m`} tone={p.is_office ? 'purple' : 'blue'} />
            </View>
            <View style={[st.radio, on && st.radioOn]}>{on ? <View style={st.dot} /> : null}</View>
          </Pressable>
        );
      }) : !error && places ? (
        <Banner tone="amber" icon="walk-outline" text={`No site or office within ${fmtDistance(rangeM)}. Move closer to your place.`} />
      ) : null}

      {hideRefresh ? null : <Button title="Refresh my location" icon="locate-outline" variant="ghost" small loading={loading} onPress={onRefresh} style={{ marginTop: 4 }} />}
    </View>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 15, fontWeight: '800', color: C.ink },
  hint: { fontSize: 12.5, color: C.muted, marginTop: 2, marginBottom: 10, lineHeight: 18 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 12, marginBottom: 8, backgroundColor: C.white },
  rowOn: { borderColor: C.green, backgroundColor: '#F2FCF7' },
  icon: { width: 36, height: 36, borderRadius: 10, backgroundColor: C.blueSoft, alignItems: 'center', justifyContent: 'center' },
  name: { fontSize: 14.5, fontWeight: '800', color: C.ink },
  sub: { fontSize: 12, color: C.muted, marginTop: 2 },
  dist: { fontSize: 14, fontWeight: '800', color: C.ink },
  radio: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: '#B8C4D2', alignItems: 'center', justifyContent: 'center' },
  radioOn: { borderColor: C.green },
  dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: C.green },
});
