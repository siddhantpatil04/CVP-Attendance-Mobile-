import Constants from 'expo-constants';
import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import MapView, { Circle, Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import type { MapDot, MapLine, MapSite } from '../lib/api';
import LocationMap from './LocationMap';

/**
 * Live Map - real Google Maps (satellite + labels) on Android, via react-native-maps.
 * Same props as LocationMap, so the Live Map screen keeps its layout.
 * The Android key comes from GOOGLE_MAPS_ANDROID_KEY at build time (app.config.js). With no key the old map is shown.
 */
const HAS_KEY = !!(Constants.expoConfig as any)?.android?.config?.googleMaps?.apiKey;

function GoogleMapView({ sites = [], dots = [], lines = [], height = 460 }: { sites?: MapSite[]; dots?: MapDot[]; lines?: MapLine[]; height?: number }) {
  const ref = useRef<MapView>(null);
  const fitted = useRef('');

  useEffect(() => {
    const sig = `${sites.map((s) => s.id).join(',')}|${dots.map((d) => d.key).join(',')}|${lines.map((l) => l.key).join(',')}`;
    if (fitted.current === sig) return;
    const pts = [
      ...sites.map((s) => ({ latitude: s.lat, longitude: s.lng })),
      ...dots.map((d) => ({ latitude: d.lat, longitude: d.lng })),
      ...lines.flatMap((l) => l.points.map(([latitude, longitude]) => ({ latitude, longitude }))),
    ];
    if (!pts.length) return;
    fitted.current = sig;
    const t = setTimeout(() => ref.current?.fitToCoordinates(pts, { edgePadding: { top: 50, right: 50, bottom: 50, left: 50 }, animated: false }), 300);
    return () => clearTimeout(t);
  }, [sites, dots, lines]);

  const dot = (c: string) => <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: c, borderWidth: 3, borderColor: '#fff' }} />;

  return (
    <View style={{ height, borderRadius: 14, overflow: 'hidden', backgroundColor: '#E8EEF5' }}>
      <MapView ref={ref} style={{ flex: 1 }} provider={PROVIDER_GOOGLE} mapType="hybrid" toolbarEnabled={false}
        initialRegion={{ latitude: 20.59, longitude: 78.96, latitudeDelta: 25, longitudeDelta: 25 }}>
        {sites.map((s) => (
          <React.Fragment key={`s-${s.id}`}>
            {s.circle !== false ? (
              <Circle center={{ latitude: s.lat, longitude: s.lng }} radius={s.radius_m} strokeColor={s.color ?? '#7C3AED'} strokeWidth={2} fillColor={`${s.color ?? '#7C3AED'}33`} />
            ) : null}
            <Marker coordinate={{ latitude: s.lat, longitude: s.lng }} pinColor={s.color ?? '#7C3AED'} title={s.label ?? s.name}
              description={`Allowed radius ${s.radius_m >= 1000 ? (s.radius_m / 1000).toFixed(1) + ' km' : s.radius_m + ' m'}`} />
          </React.Fragment>
        ))}
        {lines.filter((l) => l.points.length >= 2).map((l) => (
          <Polyline key={`l-${l.key}`} coordinates={l.points.map(([latitude, longitude]) => ({ latitude, longitude }))}
            strokeColor={l.color} strokeWidth={4} lineDashPattern={l.dashed ? [14, 10] : undefined} />
        ))}
        {dots.map((d) => (
          <Marker key={`d-${d.key}`} coordinate={{ latitude: d.lat, longitude: d.lng }} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false} title={d.label}>
            {dot(d.color)}
          </Marker>
        ))}
      </MapView>
    </View>
  );
}

export default function GoogleLiveMap(props: React.ComponentProps<typeof LocationMap>) {
  if (!HAS_KEY) return <LocationMap {...props} />;
  return <GoogleMapView {...props} />;
}
