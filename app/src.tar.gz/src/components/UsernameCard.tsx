import React, { useState } from 'react';
import { Alert } from 'react-native';
import { api, Profile } from '../lib/api';
import { errorText } from '../lib/supabase';
import { Banner, Button, Card, Field, Muted } from './ui';

/** Change the username used to sign in (Admin / HR only - enforced by admin_change_username()). */
export function UsernameCard({ user, onChanged }: { user: Profile; onChanged?: () => void | Promise<void> }) {
  const [name, setName] = useState(user.username);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  const clean = name.trim().toLowerCase();
  const changed = clean !== user.username;
  const valid = /^[a-z0-9._-]{2,40}$/.test(clean);

  const save = async () => {
    setMsg('');
    if (!valid) {
      Alert.alert('Invalid username', 'Use letters, numbers, dot, dash and underscore (2-40 characters).');
      return;
    }
    setBusy(true);
    try {
      const p = await api.changeUsername(user.id, clean);
      setName(p.username);
      setMsg(`Username changed to "${p.username}". Use it at the next sign in.`);
      await onChanged?.();
    } catch (e) {
      Alert.alert('Could not change username', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <Field
        label="Username"
        value={name}
        onChangeText={setName}
        autoCapitalize="none"
        autoCorrect={false}
        placeholder="e.g. emp014"
      />
      <Muted style={{ marginBottom: 10 }}>Lower-case letters, numbers, dot, dash and underscore. The password does not change.</Muted>
      {msg ? <Banner tone="green" icon="checkmark-circle" text={msg} /> : null}
      <Button title="Save Username" icon="at-outline" loading={busy} disabled={!changed} onPress={save} />
    </Card>
  );
}
