import { useNavigation } from '@react-navigation/native';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Card, Field, Row } from './ui';
import { api, LeavePolicy2, Profile } from '../lib/api';
import { useAuth } from '../lib/auth';
import { errorText } from '../lib/supabase';
import { C } from '../theme';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * Admin / HR: the 24-day leave policy (Earned 12 + Casual 6 + Sick 6) and its settings (only the Admin can change them),
 * the monthly credit / year-end job, and the employees who have no joining date.
 * Layout: summary chips, General card, one card per leave type (EL / CL / SL), Year-end card, Half day & Unpaid card.
 */
export default function LeavePolicyCard() {
  const { isFullAdmin } = useAuth();
  const nav = useNavigation<any>();
  const [policy, setPolicy] = useState<LeavePolicy2 | null>(null);
  const [v, setV] = useState<Record<string, string>>({});
  const [people, setPeople] = useState<Profile[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const p = await api.leavePolicy2();
      setPolicy(p);
      setV({
        eligibility_months: String(p.eligibility_months), el_notice_days: String(p.el_notice_days), el_cap: String(p.el_cap), el_keep_min: String(p.el_keep_min),
        cl_max_request: String(p.cl_max_request), sl_cert_after: String(p.sl_cert_after), sl_apply_within: String(p.sl_apply_within),
        lapse_day: String(p.lapse_day), lapse_month: String(p.lapse_month), personal_max_month: p.personal_max_month == null ? '' : String(p.personal_max_month),
      });
    } catch { /* leave_policy_24.sql not run yet: the card stays hidden */ }
    api.allProfiles().then((l) => setPeople(l.filter((x) => x.active))).catch(() => {});
  }, []);
  useEffect(() => { load(); }, [load]);

  if (!policy) return null;
  const missing = people.filter((p) => !p.joining_date);
  const num = (s: string) => Number(s);

  const save = async () => {
    setBusy(true);
    try {
      await api.setLeavePolicy2({
        eligibility_months: num(v.eligibility_months), el_notice_days: num(v.el_notice_days), el_cap: num(v.el_cap), el_keep_min: num(v.el_keep_min),
        cl_max_request: num(v.cl_max_request), sl_cert_after: num(v.sl_cert_after), sl_apply_within: num(v.sl_apply_within),
        lapse_day: num(v.lapse_day), lapse_month: num(v.lapse_month), personal_max_month: v.personal_max_month.trim() === '' ? null : num(v.personal_max_month),
      });
      Alert.alert('Saved', 'Leave policy updated. New requests follow it from now on.');
      await load();
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };

  const runJobs = () =>
    Alert.alert('Run the monthly leave credit now?', 'Credits this month (EL +1, CL +0.5, SL +0.5) to every eligible employee who has not been credited yet, and lapses CL / SL if the year-end has just passed. A month is never credited twice.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Run now', onPress: async () => {
        setBusy(true);
        try { const r = await api.runLeaveJobs(); Alert.alert('Done', `Credit rows this month: ${r.credited_rows_this_month}. Lapsed now: ${r.lapsed_now}.`); }
        catch (e) { Alert.alert('Could not run', errorText(e)); }
        finally { setBusy(false); }
      } },
    ]);

  const input = (key: string) => (
    <View style={{ width: 64 }}>
      <Field value={v[key] ?? ''} onChangeText={(x) => setV((o) => ({ ...o, [key]: x }))} keyboardType="decimal-pad" style={{ textAlign: 'center', fontWeight: '800' }} />
    </View>
  );
  // one setting line: label (+ small hint) on the left, a box + unit (Admin) or the plain value (HR) on the right
  const line = (label: string, key: string, unit: string, hint?: string, last?: boolean) => (
    <View key={key} style={[st.row, last && { borderBottomWidth: 0 }]}>
      <View style={{ flex: 1 }}>
        <Text style={st.label}>{label}</Text>
        {hint ? <Text style={st.hint}>{hint}</Text> : null}
      </View>
      {isFullAdmin ? (
        <Row style={{ gap: 6, alignItems: 'center' }}>{input(key)}{unit ? <Text style={st.unit}>{unit}</Text> : null}</Row>
      ) : <Text style={st.val}>{v[key] === '' ? 'no limit' : `${v[key]} ${unit}`}</Text>}
    </View>
  );
  const fixed = (label: string, value: string, last?: boolean) => (
    <View key={label} style={[st.row, last && { borderBottomWidth: 0 }]}><Text style={st.label}>{label}</Text><Text style={st.val}>{value}</Text></View>
  );
  const chip = (big: string, small: string) => (
    <View key={small} style={st.chip}><Text style={st.chipBig}>{big}</Text><Text style={st.chipSmall}>{small}</Text></View>
  );
  const typeCard = (color: string, title: string, sub: string, body: React.ReactNode) => (
    <View style={[st.card, { borderTopWidth: 4, borderTopColor: color, flexGrow: 1, flexBasis: 260, minWidth: 260 }]}>
      <Text style={st.cardTitle}>{title}</Text>
      <Text style={st.cardSub}>{sub}</Text>
      <View style={{ marginTop: 6 }}>{body}</View>
    </View>
  );
  const monthName = MONTHS[Math.min(Math.max(num(v.lapse_month || '12') || 12, 1), 12) - 1];

  return (
    <>
      <View>
        <Text style={st.title}>Leave policy</Text>
        <Text style={st.sub}>Same for all employees - change a box, then Save. {isFullAdmin ? '' : 'Only the Admin can change the settings (view only for HR).'}</Text>

        <Row style={st.chips}>
          {chip('24', 'paid leaves a year')}
          {chip('12', 'Earned (EL)')}
          {chip('6', 'Casual (CL)')}
          {chip('6', 'Sick (SL)')}
          {chip(`${policy.eligibility_months} months`, 'before paid leave starts')}
          {chip('Admin / HR', 'approves every request')}
        </Row>

        <View style={st.card}>
          <Text style={st.cardTitle}>General</Text>
          {line('Paid leaves start after', 'eligibility_months', 'months', 'Before this: only Unpaid leave', true)}
        </View>

        <Row style={st.grid}>
          {typeCard('#1D6FEB', 'Earned Leave (EL) - 12 a year', '1 a month - planned vacations', <>
            {line('Notice before start date', 'el_notice_days', 'days', 'Allowed 7 to 15')}
            {line('Maximum saved balance', 'el_cap', 'days')}
            {line('Keep at least (for encashment)', 'el_keep_min', 'days', 'Only EL above this can be encashed', true)}
          </>)}
          {typeCard('#16A34A', 'Casual Leave (CL) - 6 a year', '0.5 a month - short personal work', <>
            {line('Maximum days in one request', 'cl_max_request', 'days', 'Allowed 2 to 3')}
            {fixed('Lapses at year-end', 'Yes - see Year-end', true)}
          </>)}
          {typeCard('#EF4444', 'Sick Leave (SL) - 6 a year', '0.5 a month - illness', <>
            {line('Medical certificate needed after', 'sl_cert_after', 'days')}
            {line('Can be applied after the leave, within', 'sl_apply_within', 'days')}
            {fixed('Lapses at year-end', 'Yes - see Year-end', true)}
          </>)}
        </Row>

        <Row style={st.grid}>
          <View style={[st.card, { flexGrow: 1, flexBasis: 280, minWidth: 260 }]}>
            <Text style={st.cardTitle}>Year-end</Text>
            <Text style={st.cardSub}>Unused CL and SL are removed on this date</Text>
            <View style={[st.row, { borderBottomWidth: 0, marginTop: 6 }]}>
              <Text style={st.label}>CL / SL lapse on (day, month 1-12)</Text>
              {isFullAdmin
                ? <Row style={{ gap: 6, alignItems: 'center' }}>{input('lapse_day')}{input('lapse_month')}<Text style={st.unit}>{monthName}</Text></Row>
                : <Text style={st.val}>{v.lapse_day} {monthName}</Text>}
            </View>
          </View>
          <View style={[st.card, { flexGrow: 1, flexBasis: 280, minWidth: 260 }]}>
            <Text style={st.cardTitle}>Half day & Unpaid</Text>
            <Text style={st.cardSub}>How half days and unpaid days work</Text>
            <View style={{ marginTop: 6 }}>
              {line('Personal half days a month', 'personal_max_month', 'a month', 'Empty = no limit')}
              {fixed('Half day (personal work) uses', policy.personal_order === 'EL,CL' ? 'EL > CL > Unpaid' : 'CL > EL > Unpaid')}
              {fixed('Unpaid Leave (LOP)', 'Salary is deducted', true)}
            </View>
          </View>
        </Row>

        {isFullAdmin ? (
          <Row style={{ marginTop: 6, justifyContent: 'flex-end', flexWrap: 'wrap', gap: 8 }}>
            <Button title="Reset" variant="secondary" disabled={busy} onPress={load} />
            <Button title="Run monthly credit now" icon="refresh-outline" variant="secondary" disabled={busy} onPress={runJobs} />
            <Button title="Save leave policy" icon="save-outline" loading={busy} onPress={save} />
          </Row>
        ) : null}
      </View>

      {missing.length > 0 ? (
        <Card>
          <Text style={st.cardTitle}>Employees without a joining date</Text>
          <Banner tone="amber" icon="warning-outline"
            text={`${missing.length} employee(s) have no joining date, so their paid leaves cannot start (any leave they take is unpaid). Enter the date in Employee Management.`} />
          {missing.slice(0, 30).map((p) => (
            <Row key={p.id} style={{ justifyContent: 'space-between', paddingVertical: 4 }}>
              <Text style={st.label}>{p.full_name}</Text>
              <Button title="Add joining date" variant="secondary" small onPress={() => nav.navigate('EmployeeDetail', { userId: p.id })} />
            </Row>
          ))}
        </Card>
      ) : null}
    </>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 22, fontWeight: '800', color: C.ink },
  sub: { fontSize: 12, color: C.muted, marginTop: 2, marginBottom: 10, lineHeight: 18 },
  chips: { flexWrap: 'wrap', gap: 8, marginBottom: 10 },
  chip: { backgroundColor: '#FFFFFF', borderRadius: 12, paddingVertical: 8, paddingHorizontal: 14, shadowColor: '#0B2A4A', shadowOpacity: 0.06, shadowRadius: 6, shadowOffset: { width: 0, height: 2 }, elevation: 1 },
  chipBig: { fontSize: 18, fontWeight: '800', color: C.ink },
  chipSmall: { fontSize: 11, color: C.muted },
  card: { backgroundColor: '#FFFFFF', borderRadius: 14, padding: 14, marginBottom: 10, shadowColor: '#0B2A4A', shadowOpacity: 0.06, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 1 },
  grid: { flexWrap: 'wrap', gap: 10, alignItems: 'stretch' },
  cardTitle: { fontSize: 15, fontWeight: '800', color: C.ink },
  cardSub: { fontSize: 11, color: C.muted, marginTop: 2 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  label: { fontSize: 13, fontWeight: '600', color: '#17314D' },
  hint: { fontSize: 11, color: C.muted, marginTop: 1 },
  unit: { fontSize: 12, color: C.muted },
  val: { fontSize: 13, fontWeight: '800', color: C.ink },
});
