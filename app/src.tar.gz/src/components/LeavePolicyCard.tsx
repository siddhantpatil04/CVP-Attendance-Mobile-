import { useNavigation } from '@react-navigation/native';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Card, Field, Row } from './ui';
import { api, LeavePolicy2, Profile } from '../lib/api';
import { useAuth } from '../lib/auth';
import { errorText } from '../lib/supabase';
import { C } from '../theme';

/**
 * Admin / HR: the 24-day leave policy (Earned 12 + Casual 6 + Sick 6) and its settings (only the Admin can change them),
 * the monthly credit / year-end job, and the employees who have no joining date.
 */
export default function LeavePolicyCard() {
  const { isFullAdmin } = useAuth();
  const nav = useNavigation<any>();
  const [policy, setPolicy] = useState<LeavePolicy2 | null>(null);
  const [v, setV] = useState<Record<string, string>>({});
  const [people, setPeople] = useState<Profile[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const p = await api.leavePolicy2();
      setPolicy(p);
      setV({
        eligibility_months: String(p.eligibility_months), el_notice_days: String(p.el_notice_days), el_cap: String(p.el_cap), el_keep_min: String(p.el_keep_min),
        cl_max_request: String(p.cl_max_request), sl_cert_after: String(p.sl_cert_after), sl_apply_within: String(p.sl_apply_within),
        lapse_day: String(p.lapse_day), lapse_month: String(p.lapse_month), personal_max_month: p.personal_max_month == null ? '' : String(p.personal_max_month),
      });
    } catch { /* leave_policy_24.sql not run yet: the card stays hidden */ }
    api.allProfiles().then((l) => setPeople(l.filter((x) => x.active))).catch(() => {});
  }, []);
  useEffect(() => { load(); }, [load]);

  if (!policy) return null;
  const missing = people.filter((p) => !p.joining_date);
  const num = (s: string) => Number(s);

  const save = async () => {
    setBusy(true);
    try {
      await api.setLeavePolicy2({
        eligibility_months: num(v.eligibility_months), el_notice_days: num(v.el_notice_days), el_cap: num(v.el_cap), el_keep_min: num(v.el_keep_min),
        cl_max_request: num(v.cl_max_request), sl_cert_after: num(v.sl_cert_after), sl_apply_within: num(v.sl_apply_within),
        lapse_day: num(v.lapse_day), lapse_month: num(v.lapse_month), personal_max_month: v.personal_max_month.trim() === '' ? null : num(v.personal_max_month),
      });
      Alert.alert('Saved', 'Leave policy updated. New requests follow it from now on.');
      await load();
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };

  const runJobs = () =>
    Alert.alert('Run the monthly leave credit now?', 'Credits this month (EL +1, CL +0.5, SL +0.5) to every eligible employee who has not been credited yet, and lapses CL / SL if the year-end has just passed. A month is never credited twice.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Run now', onPress: async () => {
        setBusy(true);
        try { const r = await api.runLeaveJobs(); Alert.alert('Done', `Credit rows this month: ${r.credited_rows_this_month}. Lapsed now: ${r.lapsed_now}.`); }
        catch (e) { Alert.alert('Could not run', errorText(e)); }
        finally { setBusy(false); }
      } },
    ]);

  const rows: [string, string, string][] = [
    ['Paid leaves start after (months of service)', 'months', 'eligibility_months'],
    ['Earned Leave (EL): notice before the start date (7-15)', 'days', 'el_notice_days'],
    ['Earned Leave (EL): maximum saved balance', 'days', 'el_cap'],
    ['Earned Leave (EL): keep at least this much (only EL above it can be encashed)', 'days', 'el_keep_min'],
    ['Casual Leave (CL): maximum days in one request (2-3)', 'days', 'cl_max_request'],
    ['Sick Leave (SL): medical certificate needed after', 'days', 'sl_cert_after'],
    ['Sick Leave (SL): can be applied after the leave, within', 'days', 'sl_apply_within'],
    ['Year-end: CL / SL lapse on (day)', '', 'lapse_day'],
    ['Year-end: CL / SL lapse on (month 1-12)', '', 'lapse_month'],
    ['Personal half days a month (empty = no limit)', 'days', 'personal_max_month'],
  ];

  return (
    <>
      <Card>
        <Text style={st.title}>Leave policy - 24 paid leaves a year</Text>
        <Text style={st.sub}>Earned 12 (credited 1 a month, saved up to {policy.el_cap}) + Casual 6 (0.5 a month, lapses at year-end) + Sick 6 (0.5 a month, lapses at year-end), after {policy.eligibility_months} months of service. Every request needs Admin / HR approval. {isFullAdmin ? '' : 'Only the Admin can change the settings (view only for HR).'}</Text>
        {rows.map(([label, unit, key]) => (
          <View key={key} style={st.row}>
            <Text style={st.label}>{label}</Text>
            {isFullAdmin ? (
              <View style={{ width: 100 }}><Field value={v[key] ?? ''} onChangeText={(x) => setV((o) => ({ ...o, [key]: x }))} keyboardType="decimal-pad" style={{ textAlign: 'right' }} /></View>
            ) : <Text style={st.val}>{v[key] === '' ? 'no limit' : `${v[key]} ${unit}`}</Text>}
          </View>
        ))}
        <View style={st.row}><Text style={st.label}>Half Day - Personal work uses</Text><Text style={st.val}>{policy.personal_order === 'EL,CL' ? 'EL, then CL, then Unpaid' : 'CL, then EL, then Unpaid'}</Text></View>
        <View style={st.row}><Text style={st.label}>Unpaid Leave (LOP)</Text><Text style={st.val}>Salary is deducted</Text></View>
        {isFullAdmin ? (
          <Row style={{ marginTop: 10 }}>
            <Button title="Save leave policy" icon="save-outline" loading={busy} onPress={save} />
            <Button title="Run monthly credit now" icon="refresh-outline" variant="secondary" disabled={busy} onPress={runJobs} />
          </Row>
        ) : null}
      </Card>

      {missing.length > 0 ? (
        <Card>
          <Text style={st.title}>Employees without a joining date</Text>
          <Banner tone="amber" icon="warning-outline"
            text={`${missing.length} employee(s) have no joining date, so their paid leaves cannot start (any leave they take is unpaid). Enter the date in Employee Management.`} />
          {missing.slice(0, 30).map((p) => (
            <Row key={p.id} style={{ justifyContent: 'space-between', paddingVertical: 4 }}>
              <Text style={st.label}>{p.full_name}</Text>
              <Button title="Add joining date" variant="secondary" small onPress={() => nav.navigate('EmployeeDetail', { userId: p.id })} />
            </Row>
          ))}
        </Card>
      ) : null}
    </>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 16, fontWeight: '800', color: C.ink },
  sub: { fontSize: 12, color: C.muted, marginTop: 2, marginBottom: 8, lineHeight: 18 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  label: { flex: 1, fontSize: 13, fontWeight: '600', color: '#17314D' },
  val: { fontSize: 13, fontWeight: '800', color: C.ink },
});
