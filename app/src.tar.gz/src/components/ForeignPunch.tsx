import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import React, { useState } from 'react';
import { Alert, Image, StyleSheet, Text, View } from 'react-native';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { currentPosition } from '../lib/geo';
import { errorText } from '../lib/supabase';
import { istDateISO } from '../lib/time';
import { C } from '../theme';
import { Button, Field, Row } from './ui';

/**
 * Check in / check out from a FOREIGN LOCATION (any place away from the office).
 * The employee gives the reason and takes a selfie; it is saved at once, nobody has to approve it.
 * Shown only to employees whose "Field Site & Foreign Location Access" switch is on.
 */
export function ForeignPunch({ kind, onDone }: { kind: 'in' | 'out'; onDone: () => void | Promise<void> }) {
  const { profile } = useAuth();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [shot, setShot] = useState<{ uri: string; base64: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const word = kind === 'in' ? 'Check In' : 'Check Out';

  const takeSelfie = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) return Alert.alert('Camera permission needed', 'Allow camera access in Settings to take the selfie.');
    const res = await ImagePicker.launchCameraAsync({ cameraType: ImagePicker.CameraType.front, quality: 0.8, allowsEditing: false, mediaTypes: ['images'] });
    if (res.canceled || !res.assets?.[0]) return;
    const ref = await ImageManipulator.manipulate(res.assets[0].uri).resize({ width: 720 }).renderAsync();
    const out = await ref.saveAsync({ compress: 0.6, format: SaveFormat.JPEG, base64: true });
    if (!out.base64) return Alert.alert('Could not process the photo');
    setShot({ uri: out.uri, base64: out.base64 });
  };

  const submit = async () => {
    if (!profile || busy) return;
    if (!reason.trim()) return Alert.alert('Give the reason first.');
    if (!shot) return Alert.alert('Take your selfie first.');
    setBusy(true);
    let path: string | undefined;
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (perm.status !== 'granted') throw new Error('Allow location access and turn on GPS, then try again.');
      const p = await currentPosition();
      path = await api.uploadSelfie(profile.id, shot.base64, kind === 'in' ? 'IN' : 'OUT', istDateISO());
      const opts = { lat: p.coords.latitude, lng: p.coords.longitude, siteName: 'Foreign location', reason: reason.trim(), photoPath: path };
      const row = kind === 'in' ? await api.checkIn(opts) : await api.checkOut(opts);
      const dm = kind === 'in' ? row.check_in_dist_m : row.check_out_dist_m;
      Alert.alert(`${word} saved`, `Saved from a foreign location${dm != null ? ` (${dm} m from the nearest site)` : ''}. Your reason and selfie are recorded.`);
      setOpen(false); setReason(''); setShot(null);
      await onDone();
    } catch (e) {
      if (path) api.removeSelfie(path).catch(() => {});
      Alert.alert(`${word} failed`, errorText(e));
    } finally { setBusy(false); }
  };

  if (!open) {
    return <Button title={`${word} from a foreign location`} icon="earth-outline" variant="ghost" small onPress={() => setOpen(true)} style={{ marginTop: 6 }} />;
  }
  return (
    <View style={st.box}>
      <Text style={st.title}>Foreign location {kind === 'in' ? 'check-in' : 'check-out'}</Text>
      <Text style={st.meta}>Use this when you are not at the office. Tell us why, and take a selfie.</Text>
      <Field label="1. Why are you here?" value={reason} onChangeText={setReason} multiline placeholder="e.g. Going straight to the client meeting" />
      <Text style={st.label}>2. Take a selfie</Text>
      {shot ? (
        <View style={{ alignItems: 'center', marginVertical: 8 }}>
          <Image source={{ uri: shot.uri }} style={st.preview} />
          <Button title="Take again" icon="refresh" variant="ghost" small onPress={takeSelfie} />
        </View>
      ) : <Button title="Open camera" icon="camera-outline" variant="secondary" onPress={takeSelfie} style={{ marginVertical: 8 }} />}
      <Row>
        <Button title={`Save ${word}`} icon="checkmark" variant="success" loading={busy} onPress={submit} />
        <Button title="Cancel" variant="ghost" onPress={() => { setOpen(false); setShot(null); }} />
      </Row>
    </View>
  );
}

const st = StyleSheet.create({
  box: { marginTop: 10, padding: 12, borderRadius: 14, backgroundColor: '#FFF9EE', borderWidth: 1, borderColor: '#F3C98B' },
  title: { fontWeight: '800', fontSize: 15, color: C.ink },
  meta: { fontSize: 12, color: C.muted, marginTop: 4 },
  label: { fontSize: 12, fontWeight: '800', color: '#6B7C93', marginTop: 8, marginBottom: 4 },
  preview: { width: 180, height: 240, borderRadius: 14, backgroundColor: '#EEF2F7' },
});
