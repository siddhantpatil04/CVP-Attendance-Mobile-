import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { api, CheckoutReportRow, CheckoutRule } from '../lib/api';
import { useAuth } from '../lib/auth';
import { useRealtime } from '../lib/realtime';
import { errorText } from '../lib/supabase';
import { fmtTime12 } from '../lib/time';
import { C } from '../theme';
import { Button, Card, Pill, Row, Toggle } from './ui';

/**
 * Admin, Selfie Attendance: "Daily Report check" for today (who must still submit the report before they can check out),
 * with "Allow once", and the "Check-out rule" settings. Needs checkout_requires_daily_report.sql; shows nothing before it is run.
 */
export default function CheckoutReportPanel({ compact = false }: { compact?: boolean } = {}) {
  const { isFullAdmin } = useAuth();
  const [rows, setRows] = useState<CheckoutReportRow[] | null>(null);
  const [rule, setRule] = useState<CheckoutRule | null>(null);
  const [open, setOpen] = useState(false);
  const [allow, setAllow] = useState<CheckoutReportRow | null>(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [r, s] = await Promise.all([api.checkoutReportToday(), api.checkoutRule()]);
      setRows(r); setRule(s);
    } catch { setRows(null); }   // the database update has not been run
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('checkout-report', [{ table: 'attendance' }, { table: 'daily_reports' }, { table: 'checkout_report_overrides' }], () => load());

  const stateOf = (r: CheckoutReportRow) =>
    r.allowed_by_admin && r.report_status !== 'Submitted' && r.report_status !== 'Reviewed' ? 'allowed'
      : r.report_status === 'Submitted' || r.report_status === 'Reviewed' ? 'submitted'
      : r.report_status === 'Draft' ? 'draft' : 'none';

  const kpi = useMemo(() => {
    const list = rows ?? [];
    return {
      checkedIn: list.length,
      done: list.filter((r) => stateOf(r) === 'submitted' && r.check_out_at).length,
      waiting: list.filter((r) => !r.check_out_at && stateOf(r) !== 'submitted' && stateOf(r) !== 'allowed').length,
      allowed: list.filter((r) => r.allowed_by_admin).length,
    };
  }, [rows]);

  if (rows === null) return null;

  const saveRule = async (required: boolean, draft: boolean) => {
    try { await api.setCheckoutRule(required, draft); await load(); }
    catch (e) { Alert.alert('Could not save', errorText(e)); }
  };

  const confirmAllow = async () => {
    if (!allow) return;
    if (!reason.trim()) return Alert.alert('Enter the reason');
    setBusy(true);
    try {
      await api.allowCheckoutOnce(allow.user_id, reason.trim());
      setAllow(null); setReason('');
      await load();
    } catch (e) { Alert.alert('Could not allow', errorText(e)); }
    finally { setBusy(false); }
  };

  const Kpi = ({ label, value, tone }: { label: string; value: number; tone: string }) => (
    <View style={st.kpi}><Text style={[st.kpiVal, { color: tone }]}>{value}</Text><Text style={st.kpiLabel}>{label}</Text></View>
  );

  return (
    <Card>
      {compact ? (
        // one thin strip: title + the four numbers as pills + View; the details below are closed by default
        <Pressable onPress={() => setOpen((o) => !o)} style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
          <Text style={[st.title, { fontSize: 14 }]}>Daily Report check (today)</Text>
          <Pill text={`${kpi.checkedIn} checked in`} tone="muted" />
          <Pill text={`${kpi.done} report done & out`} tone="green" />
          <Pill text={`${kpi.waiting} waiting`} tone="amber" />
          <Pill text={`${kpi.allowed} allowed by Admin`} tone="blue" />
          <View style={{ flex: 1, minWidth: 8 }} />
          <Text style={{ fontSize: 13, fontWeight: '800', color: C.blue }}>{open ? 'Hide ▴' : 'View ▾'}</Text>
        </Pressable>
      ) : (
        <>
          <Pressable onPress={() => setOpen((o) => !o)} style={st.head}>
            <View style={{ flex: 1 }}>
              <Text style={st.title}>Daily Report check (today)</Text>
              <Text style={st.sub}>Site employees must submit today's Daily Report before they can check out.</Text>
            </View>
            {kpi.waiting > 0 ? <Pill text={`${kpi.waiting} waiting`} tone="amber" /> : null}
            <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={18} color={C.muted} style={{ marginLeft: 8 }} />
          </Pressable>

          <View style={st.kpis}>
            <Kpi label="Site employees checked in" value={kpi.checkedIn} tone={C.ink} />
            <Kpi label="Report done and checked out" value={kpi.done} tone={C.green} />
            <Kpi label="Waiting (report pending)" value={kpi.waiting} tone="#C98400" />
            <Kpi label="Allowed by Admin today" value={kpi.allowed} tone={C.blue} />
          </View>
        </>
      )}

      {open ? (
        <>
          {rows.length === 0 ? <Text style={st.sub}>No site employee has checked in today.</Text> : rows.map((r) => {
            const s = stateOf(r);
            return (
              <View key={r.user_id} style={st.row}>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={st.name} numberOfLines={1}>{r.full_name}</Text>
                  <Text style={st.sub} numberOfLines={1}>{r.site_name || '-'} - In {r.check_in_at ? fmtTime12(r.check_in_at) : '-'}</Text>
                  <Text style={st.sub} numberOfLines={2}>
                    {r.check_out_at ? `Out ${fmtTime12(r.check_out_at)}` : s === 'submitted' || s === 'allowed' ? 'Check-out open' : 'Check-out locked'}
                    {r.allowed_by_admin ? ` - allowed by ${r.override_by ?? 'Admin'}: ${r.override_reason ?? ''}` : ''}
                  </Text>
                </View>
                <View style={{ alignItems: 'flex-end', gap: 6 }}>
                  <Pill tone={s === 'submitted' ? 'green' : s === 'allowed' ? 'blue' : s === 'draft' ? 'amber' : 'red'}
                    text={s === 'submitted' ? `Submitted${r.report_submitted_at ? ' ' + fmtTime12(r.report_submitted_at) : ''}` : s === 'allowed' ? 'Allowed by Admin' : s === 'draft' ? 'Draft saved' : 'Not started'} />
                  {isFullAdmin && !r.check_out_at && s !== 'submitted' && !r.allowed_by_admin
                    ? <Button title="Allow once" small variant="secondary" onPress={() => { setAllow(r); setReason(''); }} /> : null}
                </View>
              </View>
            );
          })}

          {isFullAdmin && rule ? (
            <View style={{ marginTop: 14 }}>
              <Text style={st.title}>Check-out rule</Text>
              <Toggle label="Daily Report required before check-out (site employees)" value={rule.report_required}
                note="Only a SUBMITTED report unlocks check-out. A saved draft does not." onChange={(v) => saveRule(v, false)} />
              <Row style={{ paddingVertical: 8 }}>
                <Text style={[st.name, { flex: 1 }]}>Office employees (no site access)</Text>
                <Text style={st.sub}>No Daily Report, direct check-out</Text>
              </Row>
            </View>
          ) : null}
        </>
      ) : null}

      <Modal visible={!!allow} transparent animationType="fade" onRequestClose={() => setAllow(null)}>
        <Pressable style={st.backdrop} onPress={() => setAllow(null)}>
          <Pressable style={st.box} onPress={() => {}}>
            <Text style={st.title}>Allow check-out without the report</Text>
            <Text style={st.sub}>{allow?.full_name}: valid for today only. The reason, your name and the time are saved in the audit log.</Text>
            <TextInput value={reason} onChangeText={setReason} multiline placeholder="Reason (e.g. no network at the site)"
              placeholderTextColor="#9AA8B8" style={st.input} />
            <Row style={{ marginTop: 12 }}>
              <Button title="Cancel" variant="secondary" style={{ flex: 1 }} onPress={() => setAllow(null)} />
              <Button title="Allow once" style={{ flex: 1 }} loading={busy} onPress={confirmAllow} />
            </Row>
          </Pressable>
        </Pressable>
      </Modal>
    </Card>
  );
}

const st = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center' },
  title: { fontSize: 16, fontWeight: '800', color: '#102A45' },
  sub: { fontSize: 12, color: C.muted, marginTop: 2, lineHeight: 17 },
  name: { fontSize: 14, fontWeight: '800', color: '#102A45' },
  kpis: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  kpi: { flexGrow: 1, flexBasis: 130, minWidth: 0, backgroundColor: '#F8FBFF', borderRadius: 12, borderWidth: 1, borderColor: '#E5EDF6', padding: 10 },
  kpiVal: { fontSize: 22, fontWeight: '800' },
  kpiLabel: { fontSize: 11, fontWeight: '700', color: '#77889D', marginTop: 2 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderTopWidth: 1, borderTopColor: '#EEF3F8', marginTop: 4 },
  backdrop: { flex: 1, justifyContent: 'center', padding: 20, backgroundColor: 'rgba(6,37,63,0.4)' },
  box: { backgroundColor: '#FFFFFF', borderRadius: 16, padding: 18, maxWidth: 480, width: '100%', alignSelf: 'center' },
  input: { borderWidth: 1, borderColor: '#B9D4F6', backgroundColor: '#FBFDFF', borderRadius: 12, padding: 10, minHeight: 70, marginTop: 10, fontSize: 14, color: C.ink, textAlignVertical: 'top' },
});
