﻿import React, { useEffect, useMemo, useState } from 'react';
import { View } from 'react-native';
import { Dropdown } from './Pickers';

const TWO_WORD_AREAS = ['uruli kanchan'];

/** The area / city of a site = the place its name starts with ("Nanded Cidco ESR" -> NANDED) */
export function siteArea(name: string) {
  const n = name.trim().toLowerCase();
  const two = TWO_WORD_AREAS.find((a) => n.startsWith(a));
  return (two ?? n.split(/\s+/)[0] ?? '#').toUpperCase();
}

/** Value of a whole city: -(100 + n) for the n-th city (1-based, A to Z) */
export const cityCode = (n: number) => -(100 + n);
export const isCity = (v: number) => v <= -100;
export function areasOf(sites: { id: number; name: string }[]) {
  const m = new Map<string, { id: number; name: string }[]>();
  for (const s of [...sites].sort((a, b) => a.name.localeCompare(b.name))) m.set(siteArea(s.name), [...(m.get(siteArea(s.name)) ?? []), s]);
  return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]));
}
/** The sites of a chosen whole city (empty when value is not a city) */
export const citySites = <T extends { id: number; name: string }>(sites: T[], v: number): T[] => (isCity(v) ? (areasOf(sites)[-(v + 100) - 1]?.[1] as T[] | undefined) ?? [] : []);

/**
 * Work-site selection in two steps: first the city / area drop-down, then (once a city is chosen) a second drop-down
 * with only the sites of that city.  value: -1 = nothing chosen, 0 = all sites, cityCode(n) = every site of a city, otherwise the site id.
 */
export function SiteDropdown({ sites, value, onChange, allLabel = 'All sites', placeholder = 'Select a site' }: {
  sites: { id: number; name: string }[]; value: number; onChange: (v: number) => void;
  allLabel?: string; placeholder?: string; width?: number | '100%'; triggerStyle?: any; textStyle?: any;
}) {
  const areas = useMemo(() => areasOf(sites), [sites]);

  // the city that is chosen: taken from the selected site, or picked in the first drop-down
  const fromValue = isCity(value) ? -(value + 100) : value > 0 ? areas.findIndex(([, l]) => l.some((s) => s.id === value)) + 1 : 0;
  const [areaIdx, setAreaIdx] = useState(fromValue);   // 0 = no city chosen
  useEffect(() => { if (fromValue > 0) setAreaIdx(fromValue); if (value === 0 || value === -1) { /* keep the city the user picked */ } }, [value]);   // eslint-disable-line react-hooks/exhaustive-deps

  const first = value === 0 && areaIdx === 0 ? -2 : areaIdx > 0 ? areaIdx : -1;   // -1 nothing, -2 all sites, n = n-th city
  const list = areaIdx > 0 ? areas[areaIdx - 1]?.[1] ?? [] : [];

  return (
    <View style={{ gap: 8 }}>
      <Dropdown width="100%" value={first}
        onChange={(v) => {
          if (v === -2) { setAreaIdx(0); onChange(0); }
          else if (v === -1) { setAreaIdx(0); onChange(-1); }
          else { setAreaIdx(v); onChange(cityCode(v)); }   // a city: ALL its sites are shown at once
        }}
        options={[{ value: -1, label: 'Select city / area' }, { value: -2, label: allLabel },
          ...areas.map(([a, l], i) => ({ value: i + 1, label: `${a} (${l.length})` }))]} />
      {areaIdx > 0 ? (
        <Dropdown width="100%" value={isCity(value) ? -2 : list.some((s) => s.id === value) ? value : -2}
          onChange={(v) => onChange(v === -2 ? cityCode(areaIdx) : v)}
          options={[{ value: -2, label: `All ${areas[areaIdx - 1]?.[0] ?? ''} sites (${list.length})` }, ...list.map((s) => ({ value: s.id, label: s.name }))]} />
      ) : null}
    </View>
  );
}
