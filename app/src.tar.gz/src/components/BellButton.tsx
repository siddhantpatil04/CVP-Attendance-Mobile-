import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { navigationRef } from '../navigation';
import { useIsDesktop } from '../lib/layout';
import { useNotificationList } from '../lib/notifications';
import { C } from '../theme';

/** The bell with the unread count. Header of the phone app (the desktop has the bell in the left menu instead). */
export function BellButton({ force, color = C.blue }: { force?: boolean; color?: string }) {
  const desktop = useIsDesktop();
  const { unread } = useNotificationList();
  if (desktop && !force) return null;
  return (
    <Pressable onPress={() => navigationRef.isReady() && navigationRef.navigate('Notifications')} hitSlop={10} style={st.btn} accessibilityRole="button" accessibilityLabel="Notifications">
      <Ionicons name={unread ? 'notifications' : 'notifications-outline'} size={23} color={color} />
      {unread ? <View style={st.badge}><Text style={st.badgeTx}>{unread > 9 ? '9+' : unread}</Text></View> : null}
    </Pressable>
  );
}

const st = StyleSheet.create({
  btn: { paddingHorizontal: 12, paddingVertical: 6 },
  badge: { position: 'absolute', top: 0, right: 4, minWidth: 17, height: 17, borderRadius: 9, backgroundColor: '#E5484D', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3 },
  badgeTx: { color: '#fff', fontSize: 10, fontWeight: '800' },
});
