import React, { useEffect, useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { MIN_PASSWORD, MOBILE_CODES_ENABLED } from '../config';
import { api } from '../lib/api';
import { pickFile } from '../lib/pickFile';
import { errorText, supabase } from '../lib/supabase';
import { C } from '../theme';
import CodeInput from './CodeInput';
import { Banner, Button, Field, Segmented } from './ui';

type Channel = 'email' | 'mobile';
type Flow = 'register' | 'status';
type Step = 'details' | 'code' | 'result' | 'login' | 'done';
type Reg = { status: string; message: string; review_note: string | null } | null;

/**
 * "New employee? Register" and "Check status / Create login".
 * Register: name + e-mail / mobile saved by HR / Admin -> code -> request goes to HR / Admin (Pending Approval).
 * Status: code again -> Pending Approval / Rejected / Approved - Create Login (username + password) / Active.
 */
export default function EmployeeRegistration({ flow, onBack }: { flow: Flow; onBack: () => void }) {
  const [step, setStep] = useState<Step>('details');
  const [contact, setContact] = useState('');
  const [code, setCode] = useState('');
  const [reg, setReg] = useState<Reg>(null);
  const [channel, setChannel] = useState<Channel>('email');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [doneUser, setDoneUser] = useState('');
  const [photo, setPhoto] = useState<{ bytes: ArrayBuffer; name: string; mime: string } | null>(null);
  const [photoNote, setPhotoNote] = useState('');
  const [cooldown, setCooldown] = useState(0);   // seconds until "Resend code" is allowed (60 s after a code is sent)
  useEffect(() => {
    if (cooldown <= 0) return;
    const id = setTimeout(() => setCooldown((s) => s - 1), 1000);
    return () => clearTimeout(id);
  }, [cooldown]);

  const value = contact.trim();
  const target = channel === 'email' ? { email: value.toLowerCase() } : { phone: `+91${value.replace(/\D/g, '').slice(-10)}` };
  const what = channel === 'email' ? 'e-mail' : 'mobile number';

  const run = async (fn: () => Promise<void>) => {
    setError(''); setBusy(true);
    try { await fn(); } catch (e) {
      const msg = errorText(e);
      // Supabase has no SMS provider switched on: mobile codes cannot be sent until Admin sets one up
      setError(/unsupported phone provider/i.test(msg)
        ? 'Mobile codes are not switched on yet. Choose E-mail instead, or ask Admin to set up the SMS service.' : msg);
    } finally { setBusy(false); }
  };

  const sendCode = () => run(async () => {
    if (!value) throw new Error(channel === 'email' ? 'Enter your e-mail ID.' : 'Enter your mobile number.');
    if (flow === 'register') {
      const ok = await supabase.rpc('check_registration_details', { p_channel: channel, p_contact: value, p_name: '' });
      if (ok.error) throw ok.error;
      if (ok.data !== true) throw new Error(`These details do not match an employee record waiting for a login. Check the ${what}, or ask HR / Admin.`);
    }
    const { error: e } = await supabase.auth.signInWithOtp({ ...target, options: { shouldCreateUser: true } });
    if (e) throw e;
    setCode(''); setCooldown(60); setStep('code');
  });

  // a new 6-digit code (the e-mail template must show the code, see the note in the screen text)
  const resend = () => run(async () => {
    const { error: e } = await supabase.auth.signInWithOtp({ ...target, options: { shouldCreateUser: true } });
    if (e) throw e;
    setCode(''); setCooldown(60);
  });

  const verify = () => run(async () => {
    if (code.trim().length < 6) throw new Error('Enter the 6-digit code you received.');
    const { error: e } = await supabase.auth.verifyOtp(
      channel === 'email' ? { email: target.email!, token: code.trim(), type: 'email' } : { phone: target.phone!, token: code.trim(), type: 'sms' });
    if (e) {
      if (/expired|invalid|token|otp|code/i.test(e.message ?? '')) throw new Error('Code is wrong or expired. Tap Resend code.');
      throw e;
    }
    if (flow === 'register') {
      const r = await supabase.rpc('start_registration', { p_channel: channel, p_contact: value, p_name: '' });
      if (r.error) throw r.error;
      setReg({ status: 'Pending Approval', message: 'Your request was sent to HR / Admin. It is waiting for approval. Check again later with "Check status / Create login".', review_note: null });
      await supabase.auth.signOut().catch(() => {});
      setStep('result');
      return;
    }
    const c = await supabase.rpc('claim_registration_status', { p_channel: channel, p_contact: value });
    if (c.error) throw c.error;
    const m = await supabase.rpc('my_registration');
    if (m.error) throw m.error;
    const row = (m.data as Reg[] | null)?.[0] ?? null;
    if (!row) throw new Error('No registration was found. Register first.');
    setReg(row);
    if (row.status === 'Approved') setStep('login');
    else { await supabase.auth.signOut().catch(() => {}); setStep('result'); }
  });

  const finish = () => run(async () => {
    if (!username.trim()) throw new Error('Choose a username.');
    if (password.length < MIN_PASSWORD) throw new Error(`Password must be at least ${MIN_PASSWORD} characters.`);
    const { data, error: e } = await supabase.rpc('complete_registration_login', {
      p_username: username.trim(), p_password: password, p_confirm: confirm,
    });
    if (e) throw e;
    await supabase.auth.signOut().catch(() => {});
    const user = String(data ?? username.trim().toLowerCase());
    setDoneUser(user);
    setPhotoNote('');
    // the helper account is gone now: sign in as the new login only to save the profile photo, then sign out again
    if (photo) {
      try {
        const em = await supabase.rpc('login_email', { p_username: user });
        if (em.error || typeof em.data !== 'string') throw em.error ?? new Error('login');
        const si = await supabase.auth.signInWithPassword({ email: em.data, password });
        if (si.error || !si.data.user) throw si.error ?? new Error('login');
        await api.uploadDetailFile(si.data.user.id, false, 'photo', photo.bytes, photo.name, photo.mime);
        await supabase.auth.signOut().catch(() => {});
      } catch {
        await supabase.auth.signOut().catch(() => {});
        setPhotoNote('Your profile photo could not be saved. You can add it later in My Profile.');
      }
    }
    setStep('done');
  });

  const choosePhoto = async (camera: boolean) => {
    try {
      const f = await pickFile(camera);
      if (!f) return;
      if (!f.mime.startsWith('image/')) { setError('The profile photo must be a picture (JPG, PNG or WEBP).'); return; }
      setError(''); setPhoto(f);
    } catch (e) { setError(errorText(e)); }
  };

  const tone = reg?.status === 'Rejected' ? 'red' : reg?.status === 'Active' ? 'green' : 'blue';

  return (
    <View>
      {step === 'details' && flow === 'register' ? (
        <View style={st.steps}>
          {STEPS.map(([title, note], i) => (
            <View key={title}>
              <View style={st.step}>
                <Text style={st.stepNo}>{i + 1}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={st.stepTitle}>{title}</Text>
                  <Text style={st.stepNote}>{note}</Text>
                </View>
              </View>
              {i < STEPS.length - 1 ? <Text style={st.arrow}>↓</Text> : null}
            </View>
          ))}
          <View style={st.outcomes}>
            <View style={[st.outcome, { borderColor: '#BDE8CF', backgroundColor: '#F1FBF5' }]}>
              <Text style={st.stepTitle}>Approve</Text>
              <Text style={[st.stepNote, { color: '#1E9A58' }]}>Create username and password, account activated</Text>
            </View>
            <View style={[st.outcome, { borderColor: '#F5C6C6', backgroundColor: '#FFF4F4' }]}>
              <Text style={st.stepTitle}>Reject</Text>
              <Text style={[st.stepNote, { color: '#D14343' }]}>Login remains blocked</Text>
            </View>
          </View>
        </View>
      ) : null}

      {step === 'details' ? (<>
        <Text style={st.copy}>
          {flow === 'register'
            ? `Enter the e-mail ID${MOBILE_CODES_ENABLED ? ' or mobile number' : ''} that HR / Admin saved for you. We will send you a code.`
            : `Enter the e-mail ID${MOBILE_CODES_ENABLED ? ' or mobile number' : ''} you registered with. We will send you a code.`}
        </Text>
        {MOBILE_CODES_ENABLED ? (
          <Segmented<Channel> value={channel} onChange={(c) => { setChannel(c); setContact(''); setError(''); }}
            options={[{ value: 'mobile', label: 'Mobile' }, { value: 'email', label: 'E-mail' }]} />
        ) : null}
        <Field label={channel === 'email' ? 'E-mail ID' : 'Mobile number'} value={contact} onChangeText={setContact}
          autoCapitalize="none" autoCorrect={false} keyboardType={channel === 'email' ? 'email-address' : 'phone-pad'}
          placeholder={channel === 'email' ? 'name@example.com' : '10-digit mobile number'} />
      </>) : null}

      {step === 'code' ? (<>
        <Text style={st.status}>Enter verification code</Text>
        <Text style={st.copy}>We sent a 6-digit code to {value}. Type it here or paste it.</Text>
        <CodeInput value={code} onChange={setCode} />
        <Text style={[st.copy, { textAlign: 'center', marginBottom: 6 }]}>Code expires in 10 minutes.</Text>
        <Pressable disabled={cooldown > 0 || busy} onPress={resend} style={{ alignSelf: 'center', marginBottom: 8, opacity: cooldown > 0 ? 0.55 : 1 }}>
          <Text style={st.link}>{cooldown > 0 ? `Resend code in ${cooldown} s` : 'Resend code'}</Text>
        </Pressable>
      </>) : null}

      {step === 'result' && reg ? (<>
        <Text style={st.status}>{reg.status === 'Approved' ? 'Approved - Create Login' : reg.status}</Text>
        <Banner tone={tone} icon={reg.status === 'Rejected' ? 'close-circle' : 'information-circle'} text={reg.message} />
      </>) : null}

      {step === 'login' ? (<>
        <Text style={st.status}>Approved - Create Login</Text>
        <Text style={st.copy}>HR / Admin approved your request. Choose your Username and Password.</Text>
        <Field label="Username" value={username} onChangeText={setUsername} autoCapitalize="none" autoCorrect={false} placeholder="e.g. rahul.patil" />
        <Field label={`Password (min ${MIN_PASSWORD} characters)`} value={password} onChangeText={setPassword} secureTextEntry />
        <Field label="Confirm password" value={confirm} onChangeText={setConfirm} secureTextEntry />
        <Text style={st.copy}>{photo ? `Profile photo: ${photo.name}` : 'Profile picture (optional)'}</Text>
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>
          <Button title={photo ? 'Change photo' : 'Upload photo'} icon="image-outline" variant="secondary" small onPress={() => choosePhoto(false)} />
          {Platform.OS === 'web' ? null : <Button title="Take photo" icon="camera-outline" variant="secondary" small onPress={() => choosePhoto(true)} />}
        </View>
      </>) : null}

      {step === 'done' ? (<>
        <Text style={st.status}>Active</Text>
        <Banner tone="green" icon="checkmark-circle" text={`Your login is ready. Sign in with the username "${doneUser}" and your new password.`} />
        {photoNote ? <Banner tone="amber" icon="alert-circle" text={photoNote} /> : null}
      </>) : null}

      {error ? <Banner tone="red" icon="alert-circle" text={error} /> : null}

      {step === 'details' ? <Button title="Send Code" icon="send-outline" loading={busy} onPress={sendCode} style={{ marginTop: 4 }} /> : null}
      {step === 'code' ? <Button title="Verify" icon="shield-checkmark-outline" loading={busy} onPress={verify} style={{ marginTop: 4 }} /> : null}
      {step === 'login' ? <Button title="Create Login" icon="person-add-outline" loading={busy} onPress={finish} style={{ marginTop: 4 }} /> : null}
      {step === 'result' || step === 'done' ? <Button title="Back to Sign In" icon="arrow-forward" onPress={onBack} style={{ marginTop: 4 }} /> : null}

      {step !== 'result' && step !== 'done' ? (
        <Pressable onPress={() => { if (step !== 'details') void supabase.auth.signOut().catch(() => {}); onBack(); }} style={{ alignSelf: 'center', marginTop: 10 }}>
          <Text style={st.link}>Back</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const STEPS: [string, string][] = [
  ['Employee opens CVP', 'Taps "New employee? Register"'],
  [`Enters the ${MOBILE_CODES_ENABLED ? 'mobile number or e-mail' : 'e-mail'} saved by HR / Admin`, 'It is matched with the employee record'],
  [`Verifies the ${MOBILE_CODES_ENABLED ? 'SMS / e-mail' : 'e-mail'} code`, 'The code must be correct'],
  ['Request sent to HR / Admin', 'Pending Login Approvals'],
];

const st = StyleSheet.create({
  steps: { marginBottom: 14, padding: 12, borderRadius: 14, backgroundColor: '#F7FBFF', borderWidth: 1, borderColor: '#E4EDF6' },
  step: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  stepNo: { width: 24, height: 24, borderRadius: 12, textAlign: 'center', lineHeight: 24, fontSize: 12, fontWeight: '800', color: '#fff', backgroundColor: C.blue, overflow: 'hidden' },
  stepTitle: { fontSize: 13, fontWeight: '800', color: '#102944' },
  stepNote: { fontSize: 11.5, color: '#728299', marginTop: 1 },
  arrow: { marginLeft: 8, color: '#9AA8B8', fontSize: 14, lineHeight: 18 },
  outcomes: { flexDirection: 'row', gap: 8, marginTop: 10 },
  outcome: { flex: 1, borderWidth: 1, borderRadius: 10, padding: 8 },
  copy: { fontSize: 13, color: '#728299', marginBottom: 12 },
  status: { fontSize: 15, fontWeight: '800', color: '#102944', marginBottom: 8 },
  link: { color: C.blue, fontSize: 12, fontWeight: '700' },
});
