import React, { useCallback, useEffect, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { api, PayrollRow } from '../lib/api';
import { loadPf, PfData, pfApi, pfInput, pfMonthStart, ruleOn, settingOn } from '../lib/pf';
import { computeSalary } from '../lib/salaryEngine';
import { formulasForMonth } from '../lib/salaryFormulas';
import { errorText } from '../lib/supabase';
import { fmtISODate, istParts, MONTHS } from '../lib/time';
import { C } from '../theme';
import { Banner, Button, Card, Chips, Field, InfoTile, Row, Toggle } from './ui';

const rs = (n: number) => `Rs ${Number(n).toLocaleString('en-IN')}`;

/** Employee details -> Salary: PF ON / OFF, UAN, from date, Auto / Fixed amount and a preview (Admin / HR) */
export default function EmployeePfCard({ userId, name, canManage }: { userId: string; name: string; canManage: boolean }) {
  const now = istParts();
  const [data, setData] = useState<PfData | null>(null);
  const [on, setOn] = useState(false);
  const [mode, setMode] = useState<'Auto' | 'Fixed'>('Auto');
  const [fixed, setFixed] = useState('');
  const [uan, setUan] = useState('');
  // a change applies from the current month, and the preview shows the current month
  const month = { year: now.year, month: now.month };
  const [preview, setPreview] = useState<{ pay: PayrollRow | undefined; items: Awaited<ReturnType<typeof formulasForMonth>>['items'] } | null>(null);
  const [gender, setGender] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const [d, details] = await Promise.all([loadPf(userId), api.detailsForReports()]);
      const mine = details.find((x) => x.user_id === userId);
      setData(d); setUan(mine?.uan_no ?? ''); setGender(mine?.gender ?? '');
      const latest = d.settings[0];
      setOn(!!latest?.applicable);
      setMode(latest?.amount_mode === 'fixed' ? 'Fixed' : 'Auto');
      setFixed(latest?.fixed_amount ? String(Number(latest.fixed_amount)) : '');
      setError('');
    } catch (e) { setError(errorText(e)); }
  }, [userId]);
  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    let live = true;
    setPreview(null);
    Promise.all([api.payroll(month.year, month.month), formulasForMonth(month.year, month.month)])
      .then(([pay, f]) => { if (live) setPreview({ pay: pay.find((p) => p.user_id === userId), items: f.items }); })
      .catch(() => { if (live) setPreview({ pay: undefined, items: [] }); });
    return () => { live = false; };
  }, [userId, month.year, month.month]);

  if (error) return <Card><Banner tone="red" icon="alert-circle" text={`PF could not be loaded: ${error}`} /></Card>;
  if (!data) return <Card><Text style={st.sub}>Loading PF...</Text></Card>;
  if (!data.installed) return <Card><Banner tone="amber" text="PF ON / OFF needs a one-time database update. Back up, then run supabase/pf_on_off.sql in the Supabase SQL Editor. Until then PF is calculated as before." /></Card>;

  const start = pfMonthStart(month.year, month.month);
  const fixedNum = Number(fixed);
  const rule = ruleOn(data, pfMonthStart(month.year, month.month));
  const row = preview?.pay && rule && preview.items.length
    ? computeSalary(preview.pay, month.month, preview.items, { gender, pf: pfInput(rule, on, mode === 'Fixed' ? 'fixed' : 'auto', fixedNum || 0) })
    : null;

  const doSave = async () => {
    setBusy(true);
    try {
      await pfApi.save(userId, start, on, mode === 'Fixed' ? 'fixed' : 'auto', mode === 'Fixed' ? fixedNum : null, uan);
      await load();
      Alert.alert('Saved', `PF of ${name} updated from ${fmtISODate(start)}.`);
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };
  const save = () => {
    if (on && !/^\d{12}$/.test(uan)) return Alert.alert('Enter the 12-digit UAN number.');
    if (on && mode === 'Fixed' && !(fixedNum > 0)) return Alert.alert('Enter the fixed employee PF amount (more than 0).');
    const before = settingOn(data, userId, start);
    const question = on && before?.applicable
      ? `Change PF amount for ${name} to ${mode === 'Fixed' ? `Fixed ${rs(fixedNum)}` : 'Auto'} from ${fmtISODate(start)}?`
      : `Turn PF ${on ? 'ON' : 'OFF'} for ${name} from ${fmtISODate(start)}?`;
    Alert.alert('Save PF', question, [{ text: 'Cancel', style: 'cancel' }, { text: 'Save', onPress: doSave }]);
  };

  return (
    <Card>
      {!data.switchFrom ? <Banner tone="amber" text="You can set PF here now, but it changes salaries only after the Admin sets the PF start month (Company Reports -> PF rules)." />
        : <Text style={st.sub}>PF buttons are used from {fmtISODate(data.switchFrom)}. Earlier months are calculated as before.</Text>}
      <View style={[st.box, on && st.boxOn]}>
        <Toggle label="PF (Provident Fund) applicable" value={on} onChange={(v) => { if (canManage) setOn(v); }}
          note="ON: salary calculated with PF rules (employee PF deducted). OFF: no PF." />
      </View>
      {on ? (
        <>
          <Field label="UAN no. (PF) *" value={uan} keyboardType="number-pad" maxLength={12} placeholder="12 digits" editable={canManage}
            onChangeText={(v) => setUan(v.replace(/\D/g, ''))} />
          <Text style={st.label}>PF amount</Text>
          <Chips<'Auto' | 'Fixed'> options={['Auto', 'Fixed']} value={mode} onChange={(v) => { if (canManage) setMode(v); }} />
          <Text style={st.sub}>{mode === 'Auto' ? 'Auto: employee PF is the percentage of PF wages in the PF rules.' : 'Fixed: this amount is deducted every month. Employer PF is still calculated on PF wages.'}</Text>
          {mode === 'Fixed' ? (
            <Field label="Fixed employee PF / month (Rs) *" value={fixed} keyboardType="decimal-pad" editable={canManage}
              onChangeText={(v) => setFixed(v.replace(/[^0-9.]/g, ''))} />
          ) : null}
        </>
      ) : null}
      <Text style={st.sub}>Saving applies from {fmtISODate(start)}.</Text>

      <Text style={[st.label, { marginTop: 12 }]}>PF preview - {MONTHS[month.month - 1]} {month.year}</Text>
      {!preview ? <Text style={st.sub}>Loading...</Text> : !row ? <Text style={st.sub}>No salary for this month.</Text> : (
        <>
          <Row style={st.tiles}>
            <InfoTile label="Earned Basic" value={rs(row.basic)} />
            <InfoTile label="PF wages" value={rs(row.pfWages)} />
            <InfoTile label="Employee PF" value={rs(row.pfEmployee)} />
            <InfoTile label="Employer EPS" value={rs(row.employerEps)} />
            <InfoTile label="Employer EPF" value={rs(row.employerEpf)} />
            <InfoTile label="Net wages" value={rs(row.net)} />
          </Row>
          {row.pfCapped ? <Banner tone="amber" icon="warning-outline" text={`The fixed amount is more than the earned Basic, so ${rs(row.basic)} is used.`} /> : null}
        </>
      )}
      <Button title="Save PF" icon="save-outline" loading={busy} disabled={!canManage} onPress={save} style={{ marginTop: 10 }} />
    </Card>
  );
}

const st = StyleSheet.create({
  box: { borderRadius: 12, padding: 4, marginVertical: 8 },
  boxOn: { backgroundColor: '#E6F4EA' },
  label: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6, marginTop: 4 },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 4, marginBottom: 6 },
  tiles: { flexWrap: 'wrap', gap: 8, marginTop: 8 },
});
