import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Company } from '../lib/companies';
import { C } from '../theme';
import { Dropdown } from './Pickers';

/** Short colour of a company: CVPA blue, CVPCE (Pvt. Ltd.) purple */
export const companyTone = (c?: Pick<Company, 'short_code'>) => (c?.short_code === 'CVPCE' ? 'purple' : 'blue') as 'purple' | 'blue';

/** Field (0) "Company": All companies (default) | C.V. Patil & Associates | C.V. Patil Consultancy Engineers Pvt. Ltd. */
export function CompanyFilter({ companies, value, onChange, style, label = 'DOWNLOAD FOR COMPANY' }: { companies: Company[]; value: number; onChange: (v: number) => void; style?: any; label?: string }) {
  return (
    <View style={[{ minWidth: 0 }, style]}>
      <View style={st.lblRow}><Text style={st.lbl}>{label}</Text></View>
      <Dropdown width="100%" value={value} onChange={onChange}
        options={[{ value: 0, label: 'All companies' }, ...companies.map((c) => ({ value: c.id, label: c.legal_name }))]} />
    </View>
  );
}

/** The chip under the filters: "Company: <name> · <n> employees" */
export function CompanyChip({ company, count }: { company?: Company; count: number }) {
  const purple = company?.short_code === 'CVPCE';
  return (
    <View style={[st.chip, purple && { backgroundColor: '#F1E8FF' }]}>
      <Text style={[st.chipTx, purple && { color: '#5B2A9E' }]}>
        Company: {company ? company.legal_name : 'All companies'} · {count} employee{count === 1 ? '' : 's'}
      </Text>
    </View>
  );
}

const st = StyleSheet.create({
  lblRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  badge: { width: 18, height: 18, borderRadius: 9, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center' },
  badgeTx: { color: '#fff', fontSize: 10.5, fontWeight: '800' },
  lbl: { fontSize: 11.5, fontWeight: '800', color: '#5A6F86', letterSpacing: 0.4 },
  chip: { backgroundColor: '#E4F0FF', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6, alignSelf: 'flex-start' },
  chipTx: { fontSize: 12.5, fontWeight: '700', color: '#0E3F7A' },
});
