import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Linking, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { fmtDT, SlipSend, salarySlipsApi } from '../lib/salarySlips';
import { downloadOrOpen } from '../lib/saveDownload';
import { errorText } from '../lib/supabase';
import { useRealtime } from '../lib/realtime';
import { useAuth } from '../lib/auth';
import { MONTHS } from '../lib/time';
import { C } from '../theme';
import { Banner, Button, Card, Pill } from './ui';

const inr = (n: number) => `₹ ${Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
const monthLabel = (iso: string) => `${MONTHS[Number(iso.slice(5, 7)) - 1]} ${iso.slice(0, 4)}`;

/** My Salary > Salary slips: the slips HR sent me (the SAVED PDF), view / download / acknowledge receipt / raise a query */
export default function MySalarySlips() {
  const { profile } = useAuth();
  const [rows, setRows] = useState<SlipSend[] | null>(null);
  const [missing, setMissing] = useState(false);
  const [ticked, setTicked] = useState<Record<number, boolean>>({});
  const [asking, setAsking] = useState<number | null>(null);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    try { setRows((await salarySlipsApi.mine()).filter((r) => r.replaced_by == null)); setMissing(false); }   // a corrected slip replaces the old one on screen
    catch { setRows([]); setMissing(true); }
  }, []);
  useEffect(() => { load(); }, [load]);
  useRealtime(`my-slips-${profile?.id}`, [{ table: 'salary_slip_sends', filter: `user_id=eq.${profile?.id}` }], () => load(), !!profile && !missing);

  const view = async (r: SlipSend) => {
    setBusy(`v${r.id}`);
    try {
      const url = await salarySlipsApi.fileUrl(r.file_path);
      void salarySlipsApi.opened(r.id);
      if (Platform.OS === 'web') window.open(url, '_blank'); else await Linking.openURL(url);
      setTimeout(load, 800);
    } catch (e) { Alert.alert('Could not open the slip', errorText(e)); } finally { setBusy(null); }
  };
  const download = async (r: SlipSend) => {
    setBusy(`d${r.id}`);
    try {
      const name = `salary_slip_${r.month.slice(0, 7)}.pdf`;
      const url = await salarySlipsApi.fileUrl(r.file_path, name);
      void salarySlipsApi.downloaded(r.id);
      await downloadOrOpen(url, name, true);
      setTimeout(load, 800);
    } catch (e) { Alert.alert('Could not download', errorText(e)); } finally { setBusy(null); }
  };
  const ack = async (r: SlipSend) => {
    setBusy(`a${r.id}`);
    try { await salarySlipsApi.acknowledge(r.id); await load(); } catch (e) { Alert.alert('Could not save', errorText(e)); } finally { setBusy(null); }
  };
  const ask = async (r: SlipSend) => {
    if (!text.trim()) return;
    setBusy(`q${r.id}`);
    try { await salarySlipsApi.query(r.id, text); setAsking(null); setText(''); await load(); Alert.alert('Sent', 'HR will answer your query here.'); }
    catch (e) { Alert.alert('Could not send', errorText(e)); } finally { setBusy(null); }
  };

  if (missing || !rows || rows.length === 0) {
    return rows && !missing ? <Card><Text style={st.empty}>No salary slip has been sent to you yet.</Text></Card> : (missing ? null : null);
  }
  return (
    <View style={{ gap: 10 }}>
      {rows.map((r) => {
        const label = monthLabel(r.month); const done = !!r.acknowledged_at;
        return (
          <Card key={r.id}>
            <View style={st.head}>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={st.month}>{label}</Text>
                <Text style={st.sub}>Net pay {inr(r.net_pay)}  ·  Sent {fmtDT(r.sent_at)}</Text>
              </View>
              <Pill text={done ? 'Acknowledged' : 'New'} tone={done ? 'green' : 'blue'} />
            </View>
            <View style={st.row}>
              <Button title="View slip" icon="eye-outline" small loading={busy === `v${r.id}`} onPress={() => view(r)} />
              <Button title="Download PDF" icon="download-outline" variant="secondary" small loading={busy === `d${r.id}`} onPress={() => download(r)} />
            </View>
            {done ? <Text style={st.ok}>✓ You acknowledged receipt on {fmtDT(r.acknowledged_at)}</Text> : (
              <View style={st.ackBox}>
                <Pressable style={st.tickRow} onPress={() => setTicked((t) => ({ ...t, [r.id]: !t[r.id] }))} accessibilityRole="checkbox" accessibilityState={{ checked: !!ticked[r.id] }}>
                  <View style={[st.tick, ticked[r.id] && { backgroundColor: C.blue, borderColor: C.blue }]}>{ticked[r.id] ? <Ionicons name="checkmark" size={14} color="#fff" /> : null}</View>
                  <Text style={st.tickTx}>I have received my salary slip for {label}</Text>
                </Pressable>
                <Button title="Acknowledge receipt" icon="checkmark-done-outline" small disabled={!ticked[r.id]} loading={busy === `a${r.id}`} onPress={() => ack(r)} />
              </View>
            )}
            {r.query_text ? (
              <View style={st.q}>
                <Text style={st.qh}>Your query</Text><Text style={st.qt}>{r.query_text}</Text>
                {r.query_answer ? <><Text style={[st.qh, { marginTop: 6 }]}>Answer from HR</Text><Text style={st.qt}>{r.query_answer}</Text></> : <Text style={st.sub}>Waiting for HR to answer.</Text>}
              </View>
            ) : null}
            {asking === r.id ? (
              <View style={{ marginTop: 8, gap: 8 }}>
                <TextInput value={text} onChangeText={setText} multiline autoFocus placeholder="Type your query about this slip" placeholderTextColor={C.muted} style={st.input} />
                <View style={st.row}>
                  <Button title="Send query" small disabled={!text.trim()} loading={busy === `q${r.id}`} onPress={() => ask(r)} />
                  <Button title="Cancel" variant="secondary" small onPress={() => { setAsking(null); setText(''); }} />
                </View>
              </View>
            ) : <Pressable onPress={() => { setAsking(r.id); setText(''); }} style={{ marginTop: 8 }}><Text style={st.link}>{r.query_text ? 'Raise another query' : 'Raise a query'}</Text></Pressable>}
          </Card>
        );
      })}
    </View>
  );
}

const st = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  month: { fontSize: 16, fontWeight: '800', color: '#102A45' },
  sub: { fontSize: 12.5, color: C.muted, marginTop: 2 },
  row: { flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 10 },
  ackBox: { marginTop: 10, borderTopWidth: 1, borderTopColor: '#EEF3F8', paddingTop: 10, gap: 8 },
  tickRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  tick: { width: 22, height: 22, borderRadius: 6, borderWidth: 1.5, borderColor: '#B9C8DA', alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' },
  tickTx: { flex: 1, fontSize: 13.5, fontWeight: '700', color: '#17314D' },
  ok: { marginTop: 10, color: '#12804A', fontWeight: '700', fontSize: 13 },
  q: { marginTop: 10, backgroundColor: '#F7FAFF', borderRadius: 10, padding: 10 },
  qh: { fontSize: 11.5, fontWeight: '800', color: '#5A6F86', letterSpacing: 0.4 },
  qt: { fontSize: 13.5, color: '#17314D', marginTop: 2 },
  link: { color: C.blue, fontWeight: '800', fontSize: 13 },
  input: { minHeight: 80, borderWidth: 1, borderColor: '#D0DAE6', borderRadius: 10, padding: 10, fontSize: 14, color: C.ink },
  empty: { color: C.muted, fontSize: 13.5, textAlign: 'center', paddingVertical: 6 },
});
