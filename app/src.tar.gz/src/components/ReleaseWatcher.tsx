import { useAuth } from '../lib/auth';
import { useReleaseWatcher } from '../lib/release';

/** Invisible: signs everyone out and loads the new version when the Admin publishes an update */
export default function ReleaseWatcher() {
  const { session, profile, signOut } = useAuth();
  useReleaseWatcher(!!session && !!profile, signOut);
  return null;
}
