import { Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { api } from '../lib/api';
import { sharePdf } from '../lib/pdf';
import { periodLabel, ReportDef, REPORTS } from '../lib/reports';
import { errorText } from '../lib/supabase';
import { istParts } from '../lib/time';
import { shareXlsx } from '../lib/xlsx';
import { C } from '../theme';
import { MonthYearDropdowns } from './Pickers';
import { Button, Card } from './ui';

/** Reports of ONE employee (Admin / HR): the Detailed Day-wise Report and the Leave Register, as Excel or PDF for a chosen month */
export default function EmployeeReportsPanel({ userId, name }: { userId: string; name: string }) {
  const now = istParts();
  const [year, setYear] = useState(now.year);
  const [month, setMonth] = useState(now.month);
  const [busy, setBusy] = useState<string | null>(null);
  const defs = REPORTS.filter((r) => r.perEmployee);

  const download = async (def: ReportDef, kind: 'xlsx' | 'pdf') => {
    setBusy(`${def.id}:${kind}`);
    try {
      const summary = (await api.monthSummary(year, month)).filter((r) => r.user_id === userId);
      if (!summary.length) return Alert.alert('No data', 'There are no records for this employee in this month.');
      const res = await def.build({ year, month, summary, user: userId });
      if (res.rows.length === 0 && !res.aoa?.length && !res.grid?.aoa.length) return Alert.alert('No data', `There are no records for "${def.title}" in this period.`);
      const file = res.file.replace(/(\.xlsx)$/, `_${name.replace(/[^A-Za-z0-9]+/g, '_')}$1`);
      const subtitle = `${name} - ${periodLabel(def, { year, month })}`;
      if (kind === 'pdf') {
        await sharePdf(file.replace(/\.xlsx$/, '.pdf'), { title: def.title, subtitle, rows: res.rows, aoa: res.aoa, merges: res.merges, grid: res.grid });
      } else {
        await shareXlsx(file, [
          { name: def.title, title: def.title, subtitle, rows: res.rows, aoa: res.aoa, merges: res.merges, calc: res.calc },
          ...(res.grid ? [{ name: 'Day-wise Attendance', title: `${def.title} - day-wise attendance`, subtitle, rows: [], aoa: res.grid.aoa, merges: res.grid.merges, calc: res.gridCalc }] : []),
        ]);
      }
    } catch (e) {
      Alert.alert('Download failed', errorText(e));
    } finally {
      setBusy(null);
    }
  };

  return (
    <Card>
      <MonthYearDropdowns year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); }} />
      {defs.map((def, i) => (
        <View key={def.id} style={[st.row, i < defs.length - 1 && st.line]}>
          <Ionicons name={def.icon as any} size={16} color={C.blue} />
          <Text style={st.title} numberOfLines={2}>{def.title}</Text>
          <Button title="Excel" icon="download-outline" small loading={busy === `${def.id}:xlsx`} disabled={!!busy && busy !== `${def.id}:xlsx`} onPress={() => download(def, 'xlsx')} />
          <Button title="PDF" icon="document-text-outline" variant="secondary" small loading={busy === `${def.id}:pdf`} disabled={!!busy && busy !== `${def.id}:pdf`} onPress={() => download(def, 'pdf')} />
        </View>
      ))}
    </Card>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8 },
  line: { borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  title: { flex: 1, fontWeight: '700', color: '#102A45', fontSize: 13.5 },
});
