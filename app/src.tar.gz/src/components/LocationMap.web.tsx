import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import type { MapDot, MapLine, MapPoint, MapSite } from '../lib/api';
import { fmtTime12 } from '../lib/time';

const esc = (t: string) => t.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
const pin = (color: string) => L.divIcon({
  className: '',
  html: `<div style="width:22px;height:22px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:${color};border:2px solid #fff;box-shadow:0 1px 5px rgba(0,0,0,.45)"></div>`,
  iconSize: [22, 22], iconAnchor: [11, 22], popupAnchor: [0, -22],
});

/**
 * Desktop / browser map (Leaflet + OpenStreetMap).
 *  points : check-in (green) / check-out (blue) pins
 *  sites  : work sites, drawn as a named marker with its allowed-radius circle
 *  me     : the viewer's own live position (blue dot)
 */
export default function LocationMap({ points = [], sites = [], dots = [], lines = [], me = null, height = 460 }: {
  points?: MapPoint[]; sites?: MapSite[]; dots?: MapDot[]; lines?: MapLine[]; me?: { lat: number; lng: number } | null; height?: number;
}) {
  const host = useRef<any>(null);
  const map = useRef<L.Map | null>(null);
  const layer = useRef<L.LayerGroup | null>(null);
  const fitted = useRef('');

  useEffect(() => {
    const el = host.current as HTMLElement | null;
    if (!el || map.current) return;
    map.current = L.map(el).setView([20.59, 78.96], 5);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    return () => { map.current?.remove(); map.current = null; };
  }, []);

  useEffect(() => {
    const m = map.current, g = layer.current;
    if (!m || !g) return;
    g.clearLayers();
    const bounds: [number, number][] = [];

    for (const s of sites) {
      const col = s.color ?? '#7C3AED';
      if (s.circle !== false) L.circle([s.lat, s.lng], { radius: s.radius_m, color: col, weight: 2, dashArray: '6 6', fillColor: col, fillOpacity: 0.1 }).addTo(g);
      L.marker([s.lat, s.lng], { icon: pin(col) })
        .bindTooltip(esc(s.label ?? s.name), { permanent: true, direction: 'top', offset: [0, -22] })
        .bindPopup(`<b>${esc(s.name)}</b><br>Allowed radius ${s.radius_m >= 1000 ? (s.radius_m / 1000).toFixed(1) + ' km' : s.radius_m + ' m'}`)
        .addTo(g);
      bounds.push([s.lat, s.lng]);
    }
    for (const p of points) {
      L.marker([p.lat, p.lng], { icon: pin(p.kind === 'IN' ? '#16A34A' : '#2563EB') })
        .bindPopup(`<b>${esc(p.name)}</b><br>${p.kind === 'IN' ? 'Check In' : 'Check Out'} - ${fmtTime12(p.at)}${p.siteName ? `<br>${esc(p.siteName)}` : ''}`)
        .addTo(g);
      bounds.push([p.lat, p.lng]);
    }
    for (const ln of lines) {
      if (ln.points.length < 2) continue;
      L.polyline(ln.points, { color: ln.color, weight: 4, opacity: 0.85, ...(ln.dashed ? { dashArray: '8 8' } : {}) }).bindTooltip(esc(ln.label)).addTo(g);
      for (const pt of ln.points) bounds.push(pt);
    }
    for (const d of dots) {
      L.circleMarker([d.lat, d.lng], { radius: 9, color: '#fff', weight: 3, fillColor: d.color, fillOpacity: 1 })
        .bindTooltip(esc(d.label), { direction: 'top', permanent: !!d.permanent }).bindPopup(esc(d.label)).addTo(g);
      bounds.push([d.lat, d.lng]);
    }
    if (me) {
      L.circleMarker([me.lat, me.lng], { radius: 9, color: '#fff', weight: 3, fillColor: '#2563EB', fillOpacity: 1 })
        .bindTooltip('You are here', { permanent: false }).addTo(g);
      bounds.push([me.lat, me.lng]);
    }
    // Re-fit only when the set of things on the map changes, so a moving "me" dot does not keep resetting the zoom
    const sig = `${sites.map((s) => s.id).join(',')}|${points.length}|${dots.map((d) => d.key).join(",")}|${lines.map((l) => l.key).join(",")}|${me ? 1 : 0}`;
    if (bounds.length && fitted.current !== sig) {
      fitted.current = sig;
      m.fitBounds(L.latLngBounds(bounds), { padding: [40, 40], maxZoom: 16 });
    }
    setTimeout(() => m.invalidateSize(), 50);
  }, [points, sites, dots, lines, me]);

  return <View ref={host} style={{ height, borderRadius: 14, overflow: 'hidden', backgroundColor: '#E8EEF5' }} />;
}
