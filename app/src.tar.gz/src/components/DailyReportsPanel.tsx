import React, { useRef, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { api, DailyReport, DailyReportSite, DailyReportStatus } from '../lib/api';
import { cityCmp, cityOfSite, natCmp } from '../lib/siteCity';
import { dailyReportsPdf } from '../lib/dailyReportPdf';
import { errorText } from '../lib/supabase';
import { fmtISODate, fmtTime12 } from '../lib/time';
import { C } from '../theme';
import { DR_TONE, LANG_NAME, reportLang, reportNo, SiteBlocks, TextView, VisitSequence } from './DailyReportView';
import ReportPhotos from './ReportPhotos';
import { Dropdown } from './Pickers';
import { Avatar, Button, Card, Chips, Empty, Field, Kpi, KpiGrid, Pill, Row, Segmented } from './ui';

export const DAILY_STATUS = ['All', 'Submitted', 'Draft', 'Reviewed', 'Reopened'] as const;
export type DailyStatusFilter = typeof DAILY_STATUS[number];

/** Site names used in a set of reports (for the Site filter) */
export const dailySiteNames = (rows: DailyReport[]) =>
  [...new Set(rows.flatMap((r) => r.daily_report_sites.map((s) => s.site_name.trim()).filter(Boolean)))].sort(natCmp);

/** The reports that match the City, Site and Status filters (the PDF / CSV export uses the same list) */
export const filterDaily = (rows: DailyReport[], site: string, status: DailyStatusFilter, city = '') =>
  rows.filter((r) => (status === 'All' || r.status === status)
    && (!site || r.daily_report_sites.some((s) => s.site_name.trim().toLowerCase() === site.toLowerCase()))
    && (!city || r.daily_report_sites.some((s) => cityOfSite(s.site_name.trim()) === city)));

type Item = { r: DailyReport; s: DailyReportSite | null };
interface EmpGroup { key: string; name: string; id: string; items: Item[] }
interface SiteGroup { site: string; emps: EmpGroup[]; reports: number }
interface CityTree { city: string; sites: SiteGroup[]; employees: number; reports: number }

/** City -> Site -> Employee -> reports (all A-Z, reports oldest -> newest). A report with several sites shows under each of them. */
function buildTree(reports: DailyReport[], site: string, city: string): CityTree[] {
  const map = new Map<string, Map<string, Map<string, EmpGroup>>>();
  const want = site.trim().toLowerCase();
  for (const r of reports) {
    const sites = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
    for (const s of sites) {
      const name = s.site_name.trim() || '(site not entered)';
      if (want && name.toLowerCase() !== want) continue;
      const c = cityOfSite(name);
      if (city && c !== city) continue;
      const cm = map.get(c) ?? new Map<string, Map<string, EmpGroup>>(); map.set(c, cm);
      const sm = cm.get(name) ?? new Map<string, EmpGroup>(); cm.set(name, sm);
      const key = r.employee?.username || r.user_id;
      const g = sm.get(key) ?? { key, name: r.employee?.full_name ?? 'Employee', id: r.employee?.username ?? '', items: [] }; sm.set(key, g);
      g.items.push({ r, s });
    }
  }
  return [...map.entries()].sort((a, b) => cityCmp(a[0], b[0])).map(([cityName, cm]) => {
    const sitesOut: SiteGroup[] = [...cm.entries()].sort((a, b) => natCmp(a[0], b[0])).map(([siteName, sm]) => {
      const emps = [...sm.values()].sort((a, b) => natCmp(a.name, b.name));
      emps.forEach((e) => e.items.sort((a, b) => a.r.report_date.localeCompare(b.r.report_date) || (a.s?.seq ?? 0) - (b.s?.seq ?? 0)));
      return { site: siteName, emps, reports: new Set(emps.flatMap((e) => e.items.map((i) => i.r.id))).size };
    });
    return {
      city: cityName, sites: sitesOut,
      employees: new Set(sitesOut.flatMap((s) => s.emps.map((e) => e.key))).size,
      reports: new Set(sitesOut.flatMap((s) => s.emps.flatMap((e) => e.items.map((i) => i.r.id)))).size,
    };
  });
}
const wd = (iso: string) => new Date(`${iso}T12:00:00Z`).toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' });
const sFor = (n: number, w: string) => `${n} ${w}${n === 1 ? '' : 's'}`;

/** Admin / HR: Daily Reports tab of the Documents Report (City / Site / Status filters, City -> Site -> Employee list, review actions, PDF) */
export function DailyReportsPanel({ rows, shown, city, setCity, site, setSite, status, setStatus, onChanged }: {
  rows: DailyReport[] | null; shown: DailyReport[];
  city: string; setCity: (v: string) => void;
  site: string; setSite: (v: string) => void; status: DailyStatusFilter; setStatus: (v: DailyStatusFilter) => void;
  onChanged: () => void | Promise<void>;
}) {
  const [closed, setClosed] = useState<Set<string>>(new Set());
  const [openRep, setOpenRep] = useState<string | null>(null);
  const anchors = useRef(new Map<string, any>());
  const toggle = (k: string) => setClosed((p) => { const n = new Set(p); if (n.has(k)) n.delete(k); else n.add(k); return n; });

  // the filter lists come from ALL reports of the month, so a choice never removes its own options
  const allNames = dailySiteNames(rows ?? []);
  const cityCounts = new Map<string, number>();
  for (const n of allNames) { const c = cityOfSite(n); cityCounts.set(c, (cityCounts.get(c) ?? 0) + 1); }
  const cityList = [...cityCounts.keys()].sort(cityCmp);
  const cityIdx = city ? cityList.indexOf(city) + 1 : 0;
  // Site list: grouped by city (heading rows have a negative value and cannot be chosen)
  const siteOpts: { value: number; label: string }[] = [{ value: 0, label: 'All sites (all cities)' }];
  cityList.filter((c) => !city || c === city).forEach((c, k) => {
    siteOpts.push({ value: -(k + 1), label: `-- ${c} | ${sFor(cityCounts.get(c) ?? 0, 'site')} --` });
    allNames.filter((n) => cityOfSite(n) === c).forEach((n) => siteOpts.push({ value: allNames.indexOf(n) + 1, label: `   ${n}` }));
  });
  const siteIdx = site ? allNames.findIndex((n) => n.toLowerCase() === site.toLowerCase()) + 1 : 0;

  const tree = buildTree(shown, site, city);
  const nSites = tree.reduce((a, c) => a + c.sites.length, 0);
  const nEmps = new Set(tree.flatMap((c) => c.sites.flatMap((s) => s.emps.map((e) => e.key)))).size;
  const notReviewed = shown.filter((r) => r.status !== 'Reviewed').length;

  const jump = (c: string, s: string) => {
    setClosed((p) => { const n = new Set(p); n.delete(`c:${c}`); n.delete(`s:${c}|${s}`); return n; });
    setTimeout(() => { try { anchors.current.get(`${c}|${s}`)?.scrollIntoView?.({ behavior: 'smooth', block: 'start' }); } catch { /* web only */ } }, 60);
  };

  return (
    <View>
      <Card>
        <Row style={{ flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <View style={st.fcol}>
            <Text style={st.lbl}>City</Text>
            <Dropdown width="100%" value={cityIdx} onChange={(i) => { setCity(i > 0 ? cityList[i - 1] : ''); setSite(''); }}
              options={[{ value: 0, label: 'All cities' }, ...cityList.map((c, i) => ({ value: i + 1, label: `${c} (${cityCounts.get(c)})` }))]} />
          </View>
          <View style={st.fcol}>
            <Text style={st.lbl}>Site</Text>
            <Dropdown width="100%" value={siteIdx} onChange={(i) => { if (i < 0) return; setSite(i > 0 ? allNames[i - 1] : ''); }} options={siteOpts} />
          </View>
        </Row>
        <Text style={st.showing}>
          Showing: {city || 'All cities'} | {site || 'All sites'} | {status}  -  PDF / CSV use these filters
        </Text>
        {(city || site || status !== 'All') ? (
          <Pressable onPress={() => { setCity(''); setSite(''); setStatus('All'); }}><Text style={st.reset}>Reset</Text></Pressable>
        ) : null}
      </Card>
      <Chips<DailyStatusFilter> options={[...DAILY_STATUS]} value={status} onChange={setStatus} />
      <KpiGrid>
        <Kpi label="Cities" value={String(tree.length)} icon="business-outline" />
        <Kpi label="Sites" value={String(nSites)} icon="location-outline" />
        <Kpi label="Employees" value={String(nEmps)} icon="people-outline" />
        <Kpi label="Daily reports" value={String(shown.length)} icon="document-text-outline" />
        <Kpi label="Draft / not reviewed" value={String(notReviewed)} icon="time-outline" tone="amber" />
      </KpiGrid>

      {!rows ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : shown.length === 0 ? (
        <Card><Empty icon="document-text-outline" text="No daily reports here." /></Card>
      ) : tree.map((c, ci) => {
        const cKey = `c:${c.city}`; const cOpen = !closed.has(cKey);
        return (
          <View key={c.city} style={{ marginBottom: 12 }}>
            <Pressable onPress={() => toggle(cKey)} style={st.cityBar}>
              <Text style={st.cityName}>{ci + 1}. {c.city}</Text>
              <Text style={st.cityCount}>{sFor(c.sites.length, 'site')} | {sFor(c.employees, 'employee')} | {sFor(c.reports, 'report')}  {cOpen ? '▴' : '▾'}</Text>
            </Pressable>
            {cOpen ? (
              <View>
                <Card style={{ marginTop: 6, marginBottom: 6 }}>
                  <Text style={st.gridTitle}>Sites in {c.city} ({c.sites.length}) - tap a site to jump</Text>
                  <View style={st.grid}>
                    {c.sites.map((s, si) => (
                      <Pressable key={s.site} style={st.gridCell} onPress={() => jump(c.city, s.site)}>
                        <Text style={st.gridNo}>{ci + 1}.{si + 1}</Text>
                        <View style={{ flex: 1 }}>
                          <Text style={st.gridName} numberOfLines={2}>{s.site}</Text>
                          <Text style={st.gridSub}>{s.emps.length} emp | {s.reports} rep</Text>
                        </View>
                      </Pressable>
                    ))}
                  </View>
                </Card>
                {c.sites.map((s, si) => {
                  const sKey = `s:${c.city}|${s.site}`; const sOpen = !closed.has(sKey);
                  return (
                    <View key={s.site} ref={(el: any) => { if (el) anchors.current.set(`${c.city}|${s.site}`, el); }} style={{ marginBottom: 8 }}>
                      <Pressable onPress={() => toggle(sKey)} style={st.siteBar}>
                        <Text style={st.siteName}>{ci + 1}.{si + 1}  {s.site}</Text>
                        <Text style={st.siteCount}>{sFor(s.emps.length, 'employee')} | {sFor(s.reports, 'report')}  {sOpen ? '▴' : '▾'}</Text>
                      </Pressable>
                      {sOpen ? s.emps.map((e) => (
                        <Card key={e.key} style={{ marginTop: 6 }}>
                          <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                            <Row style={{ flex: 1, alignItems: 'center' }}>
                              <Avatar name={e.name} size={36} />
                              <View style={{ flex: 1 }}>
                                <Text style={st.name}>{e.name}</Text>
                                <Text style={st.id}>{e.id}</Text>
                              </View>
                            </Row>
                            <Pill text={sFor(new Set(e.items.map((i) => i.r.id)).size, 'report')} tone="blue" />
                          </Row>
                          {e.items.map((it, k) => {
                            const rk = `${it.r.id}|${s.site}|${it.s?.id ?? k}`; const open = openRep === rk;
                            const rc = [it.s?.remarks, it.s?.comment_1, it.s?.comment_2, it.s?.comment_3].map((x) => (x ?? '').trim()).filter((x) => x && !/^(na|n\/a|nil|-+)$/i.test(x));
                            return (
                              <View key={rk} style={st.rep}>
                                <Pressable onPress={() => setOpenRep(open ? null : rk)}>
                                  <Row style={{ justifyContent: 'space-between' }}>
                                    <Text style={st.repDate}>{fmtISODate(it.r.report_date)} {wd(it.r.report_date)}  |  {reportNo(it.r.id)}</Text>
                                    <Pill text={it.r.status} tone={DR_TONE[it.r.status as DailyReportStatus]} />
                                  </Row>
                                  {it.s?.sub_work ? <Text style={st.repLine}><Text style={st.repKey}>Sub work: </Text>{it.s.sub_work}</Text> : null}
                                  {(it.s?.work_description || it.s?.work_going_on) ? <Text style={st.repLine}><Text style={st.repKey}>Description: </Text>{it.s?.work_description || it.s?.work_going_on}</Text> : null}
                                  <Text style={st.repLine}><Text style={st.repKey}>Remarks & Comments: </Text>{rc.length ? rc.join('  |  ') : '-'}</Text>
                                </Pressable>
                                {open ? <ReportCard r={it.r} onChanged={onChanged} /> : null}
                              </View>
                            );
                          })}
                        </Card>
                      )) : null}
                    </View>
                  );
                })}
              </View>
            ) : null}
          </View>
        );
      })}
    </View>
  );
}

function ReportCard({ r, onChanged }: { r: DailyReport; onChanged: () => void | Promise<void> }) {
  const [note, setNote] = useState(r.review_note ?? '');
  const [busy, setBusy] = useState<string | null>(null);
  const visits = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq).filter((s) => s.arrived_at);
  const lang = reportLang(r.daily_report_sites);          // 'mr' | 'hi' | null (English)
  const [view, setView] = useState<TextView>('en');       // Admin sees English by default
  const langEnglish: Record<string, string> = { mr: 'Marathi', hi: 'Hindi' };

  const act = async (kind: 'review' | 'reopen') => {
    if (busy) return;
    setBusy(kind);
    try {
      if (kind === 'review') await api.reviewDailyReport(r.id, note.trim() || undefined);
      else await api.reopenDailyReport(r.id, note.trim() || undefined);
      await onChanged();
    } catch (e) { Alert.alert('Could not update', errorText(e)); }
    finally { setBusy(null); }
  };
  const pdf = async () => {
    setBusy('pdf');
    try {
      await dailyReportsPdf(`daily_report_${r.employee?.username ?? 'employee'}_${r.report_date}.pdf`,
        `${r.employee?.full_name ?? ''} - ${fmtISODate(r.report_date)}`, [r]);
    } catch (e) { Alert.alert('Could not create the PDF', errorText(e)); }
    finally { setBusy(null); }
  };

  return (
    <Card>
      <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flex: 1 }}>
          <Text style={st.name}>{r.employee?.full_name ?? 'Employee'} <Text style={st.id}>({r.employee?.username ?? ''})</Text></Text>
          <Text style={st.sub}>
            {fmtISODate(r.report_date)} - {reportNo(r.id)}
            {r.submitted_at ? ` - submitted ${fmtTime12(r.submitted_at)}` : ' - not submitted'}
          </Text>
        </View>
        <Pill text={r.status} tone={DR_TONE[r.status as DailyReportStatus]} />
      </Row>

      <View style={{ marginTop: 8 }}>
        <VisitSequence visits={visits} km={r.gps_km} hasGps={r.has_gps} />
      </View>
      {lang ? (
        <View style={{ marginTop: 8, gap: 6 }}>
          <Pill text={`Written in ${langEnglish[lang] ?? lang} - translated to English`} tone="purple" />
          <Segmented<TextView> value={view} onChange={setView} options={[
            { value: 'en', label: 'English' },
            { value: 'both', label: `English + ${LANG_NAME[lang] ?? lang}` },
            { value: 'orig', label: LANG_NAME[lang] ?? lang },
          ]} />
        </View>
      ) : null}
      <SiteBlocks sites={r.daily_report_sites} view={lang ? view : 'orig'} canEdit={!!lang && r.status !== 'Draft'}
        meta={{ employee: r.employee?.full_name ?? '', reportNo: reportNo(r.id), date: fmtISODate(r.report_date) }} onChanged={onChanged} />
      <ReportPhotos reportId={r.id} />

      <View style={st.box}>
        <Field label="Review note (optional)" value={note} onChangeText={setNote} placeholder="Shown to the employee" />
        <Row style={{ flexWrap: 'wrap' }}>
          <Button title="Mark Reviewed" icon="checkmark" variant="success" small loading={busy === 'review'} disabled={r.status !== 'Submitted'} onPress={() => act('review')} />
          <Button title="Reopen for correction" icon="refresh-outline" variant="secondary" small loading={busy === 'reopen'}
            disabled={r.status !== 'Submitted' && r.status !== 'Reviewed'} onPress={() => act('reopen')} />
          <Button title="Download PDF" icon="download-outline" small loading={busy === 'pdf'} onPress={pdf} />
        </Row>
      </View>
    </Card>
  );
}

const st = StyleSheet.create({
  fcol: { flexGrow: 1, flexBasis: 220, minWidth: 200, marginBottom: 6 },
  showing: { color: C.muted, fontSize: 12, fontWeight: '700', marginTop: 6 },
  reset: { color: C.blue, fontWeight: '800', fontSize: 12.5, marginTop: 4 },
  cityBar: { backgroundColor: '#0B2A4A', borderRadius: 10, paddingVertical: 10, paddingHorizontal: 12, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: 4 },
  cityName: { color: '#fff', fontWeight: '800', fontSize: 15 },
  cityCount: { color: '#CFE0F5', fontWeight: '700', fontSize: 12 },
  gridTitle: { fontWeight: '800', color: '#102A45', fontSize: 12.5, marginBottom: 8 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  gridCell: { flexGrow: 1, flexBasis: '47%', minWidth: 140, flexDirection: 'row', gap: 8, backgroundColor: '#F6F9FD', borderWidth: 1, borderColor: '#E3EBF4', borderRadius: 8, padding: 8 },
  gridNo: { fontWeight: '800', color: C.blue, fontSize: 12 },
  gridName: { fontWeight: '700', color: '#102A45', fontSize: 12.5 },
  gridSub: { color: C.muted, fontSize: 11.5, marginTop: 2 },
  siteBar: { backgroundColor: '#DDEBF7', borderRadius: 10, paddingVertical: 9, paddingHorizontal: 12, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: 4 },
  siteName: { color: '#102A45', fontWeight: '800', fontSize: 14, flexShrink: 1 },
  siteCount: { color: '#3A5068', fontWeight: '700', fontSize: 12 },
  rep: { marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#EEF3F8' },
  repDate: { fontWeight: '800', color: '#102A45', fontSize: 12.5, flexShrink: 1 },
  repLine: { color: '#203951', marginTop: 3, lineHeight: 19, fontSize: 13 },
  repKey: { fontWeight: '800', color: '#3A5068' },
  lbl: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  name: { fontWeight: '800', color: '#102A45', fontSize: 15 },
  id: { fontWeight: '600', color: C.muted, fontSize: 13 },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  box: { marginTop: 10, padding: 10, borderRadius: 12, backgroundColor: '#F6F9FD', borderWidth: 1, borderColor: '#E3EBF4' },
});
