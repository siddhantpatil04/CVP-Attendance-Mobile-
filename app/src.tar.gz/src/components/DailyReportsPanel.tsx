import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { api, DailyReport, DailyReportSite, DailyReportStatus } from '../lib/api';
import { cityCmp, cityOfSite, natCmp } from '../lib/siteCity';
import { dailyReportsPdf } from '../lib/dailyReportPdf';
import { errorText } from '../lib/supabase';
import { fmtISODate, fmtTime12 } from '../lib/time';
import { C } from '../theme';
import { DR_TONE, LANG_NAME, reportLang, reportNo, SiteBlocks, TextView, VisitSequence } from './DailyReportView';
import ReportPhotos from './ReportPhotos';
import { PhotoAvatar } from './PhotoAvatar';
import { Dropdown } from './Pickers';
import { Avatar, Button, Card, Chips, Empty, Field, Kpi, KpiGrid, Pill, Row, Segmented } from './ui';

export const DAILY_STATUS = ['All', 'Submitted', 'Draft', 'Reviewed', 'Reopened'] as const;
export type DailyStatusFilter = typeof DAILY_STATUS[number];

/** Site names used in a set of reports (for the Site filter) */
export const dailySiteNames = (rows: DailyReport[]) =>
  [...new Set(rows.flatMap((r) => r.daily_report_sites.map((s) => s.site_name.trim()).filter(Boolean)))].sort(natCmp);

/** The reports that match the City, Site and Status filters (the PDF / CSV export uses the same list) */
export const filterDaily = (rows: DailyReport[], site: string, status: DailyStatusFilter, city = '', o: { from?: string; to?: string; emp?: string } = {}) =>
  rows.filter((r) => (status === 'All' || r.status === status)
    && (!o.from || r.report_date >= o.from) && (!o.to || r.report_date <= o.to) && (!o.emp || r.user_id === o.emp)
    && (!site || r.daily_report_sites.some((s) => s.site_name.trim().toLowerCase() === site.toLowerCase()))
    && (!city || r.daily_report_sites.some((s) => cityOfSite(s.site_name.trim()) === city)));

type Item = { r: DailyReport; s: DailyReportSite | null };
interface EmpGroup { key: string; name: string; id: string; items: Item[] }
interface SiteGroup { site: string; emps: EmpGroup[]; reports: number }
interface CityTree { city: string; sites: SiteGroup[]; employees: number; reports: number }

/** City -> Site -> Employee -> reports (all A-Z, reports oldest -> newest). A report with several sites shows under each of them. */
function buildTree(reports: DailyReport[], site: string, city: string): CityTree[] {
  const map = new Map<string, Map<string, Map<string, EmpGroup>>>();
  const want = site.trim().toLowerCase();
  for (const r of reports) {
    const sites = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
    for (const s of sites) {
      const name = s.site_name.trim() || '(site not entered)';
      if (want && name.toLowerCase() !== want) continue;
      const c = cityOfSite(name);
      if (city && c !== city) continue;
      const cm = map.get(c) ?? new Map<string, Map<string, EmpGroup>>(); map.set(c, cm);
      const sm = cm.get(name) ?? new Map<string, EmpGroup>(); cm.set(name, sm);
      const key = r.employee?.username || r.user_id;
      const g = sm.get(key) ?? { key, name: r.employee?.full_name ?? 'Employee', id: r.employee?.username ?? '', items: [] }; sm.set(key, g);
      g.items.push({ r, s });
    }
  }
  return [...map.entries()].sort((a, b) => cityCmp(a[0], b[0])).map(([cityName, cm]) => {
    const sitesOut: SiteGroup[] = [...cm.entries()].sort((a, b) => natCmp(a[0], b[0])).map(([siteName, sm]) => {
      const emps = [...sm.values()].sort((a, b) => natCmp(a.name, b.name));
      emps.forEach((e) => e.items.sort((a, b) => a.r.report_date.localeCompare(b.r.report_date) || (a.s?.seq ?? 0) - (b.s?.seq ?? 0)));
      return { site: siteName, emps, reports: new Set(emps.flatMap((e) => e.items.map((i) => i.r.id))).size };
    });
    return {
      city: cityName, sites: sitesOut,
      employees: new Set(sitesOut.flatMap((s) => s.emps.map((e) => e.key))).size,
      reports: new Set(sitesOut.flatMap((s) => s.emps.flatMap((e) => e.items.map((i) => i.r.id)))).size,
    };
  });
}
const wd = (iso: string) => new Date(`${iso}T12:00:00Z`).toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' });
const sFor = (n: number, w: string) => `${n} ${w}${n === 1 ? '' : 's'}`;

/** Admin / HR: Daily Reports tab of the Documents Report (the filters are in DailyFilters; City -> Site -> Employee list, review actions, PDF) */
export function DailyReportsPanel({ rows, shown, city, site, onChanged, day, checkedIn, notSubmitted, photos }: {
  rows: DailyReport[] | null; shown: DailyReport[];
  /** one day on screen (Particular date): flat list; null = Whole month (City -> Site grouping) */ day?: string | null;
  checkedIn?: number; notSubmitted?: { name: string; id: string; site: string }[]; photos?: Map<string, string>;
  city: string; site: string;
  onChanged: () => void | Promise<void>;
}) {
  // City-wise list: every City bar is CLOSED by default and stays closed when a filter (City / Site / Employee / date) is chosen;
  // tap a City to open it, then a Site.
  const [opened, setOpened] = useState<Set<string>>(new Set());
  useEffect(() => { setOpened(new Set()); }, [city, site, shown.length]);
  const [openRep, setOpenRep] = useState<string | null>(null);
  const anchors = useRef(new Map<string, any>());
  const toggle = (k: string) => setOpened((p) => { const n = new Set(p); if (n.has(k)) n.delete(k); else n.add(k); return n; });

  const tree = buildTree(shown, site, city);
  const nSites = tree.reduce((a, c) => a + c.sites.length, 0);
  const nEmps = new Set(tree.flatMap((c) => c.sites.flatMap((s) => s.emps.map((e) => e.key)))).size;
  const notReviewed = shown.filter((r) => r.status !== 'Reviewed').length;

  const jump = (c: string, s: string) => {
    setOpened((p) => { const n = new Set(p); n.add(`c:${c}`); n.add(`s:${c}|${s}`); return n; });
    setTimeout(() => { try { anchors.current.get(`${c}|${s}`)?.scrollIntoView?.({ behavior: 'smooth', block: 'start' }); } catch { /* web only */ } }, 60);
  };

  if (day) {
    // ---- ONE DAY: only that date's reports, A-Z, live; a new day starts empty
    const d = `${day.slice(8, 10)}-${day.slice(5, 7)}-${day.slice(0, 4)}`;
    const list = [...shown].sort((a, b) => (a.employee?.full_name ?? '').localeCompare(b.employee?.full_name ?? '') || a.id - b.id);
    const submitted = shown.filter((r) => r.status === 'Submitted' || r.status === 'Reviewed').length;
    const reviewed = shown.filter((r) => r.status === 'Reviewed').length;
    const ns = notSubmitted ?? [];
    return (
      <View>
        <KpiGrid>
          <Kpi label="Site employees checked in" value={String(checkedIn ?? 0)} icon="people-outline" />
          <Kpi label="Reports submitted" value={String(submitted)} icon="document-text-outline" />
          <Kpi label="Not submitted yet" value={String(ns.length)} icon="time-outline" tone="amber" />
          <Kpi label="Reviewed" value={String(reviewed)} icon="checkmark-done-outline" />
          <Kpi label="Draft / not reviewed" value={String(notReviewed)} icon="create-outline" tone="amber" />
        </KpiGrid>
        <Text style={st.dayTitle}>{d} {'\u00B7'} {sFor(list.length, 'report')} {'\u00B7'} A-Z (new reports appear live)</Text>
        {!rows ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : list.length === 0 ? (
          <Card><Empty icon="document-text-outline" text={`No daily reports yet for ${d}. Reports appear here as soon as employees submit them.`} /></Card>
        ) : list.map((r) => {
          const sites = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
          const open = openRep === `d${r.id}`;
          return (
            <Card key={r.id} style={{ marginBottom: 10 }}>
              <Pressable onPress={() => setOpenRep(open ? null : `d${r.id}`)}>
                <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                  <Row style={{ flex: 1, alignItems: 'center', minWidth: 0 }}>
                    <PhotoAvatar name={r.employee?.full_name} size={38} path={photos?.get(r.user_id)} />
                    <View style={{ flex: 1, minWidth: 0 }}>
                      <Text style={st.name} numberOfLines={1}>{r.employee?.full_name ?? 'Employee'} <Text style={st.id}>{r.employee?.username ?? ''}</Text></Text>
                      <Text style={st.sub} numberOfLines={2}>
                        {'\uD83D\uDCCD'} {[...new Set(sites.map((x) => x.site_name.trim()).filter(Boolean))].join(', ') || '-'} {'\u00B7'} {reportNo(r.id)}
                        {r.submitted_at ? ` \u00B7 submitted ${fmtTime12(r.submitted_at)}` : ' \u00B7 not submitted'}
                      </Text>
                    </View>
                  </Row>
                  <Pill text={r.status} tone={DR_TONE[r.status as DailyReportStatus]} />
                </Row>
                {sites.map((s, k) => {
                  const rc = [s.remarks, s.comment_1, s.comment_2, s.comment_3].map((x) => (x ?? '').trim()).filter((x) => x && !/^(na|n\/a|nil|-+)$/i.test(x));
                  return (
                    <View key={s.id ?? k} style={st.rep}>
                      {s.sub_work ? <Text style={st.repLine}><Text style={st.repKey}>Sub work: </Text>{s.sub_work}</Text> : null}
                      {(s.work_description || s.work_going_on) ? <Text style={st.repLine}><Text style={st.repKey}>Description: </Text>{s.work_description || s.work_going_on}</Text> : null}
                      <Text style={st.repLine}><Text style={st.repKey}>Remarks & Comments: </Text>{rc.length ? rc.join('  |  ') : '-'}</Text>
                    </View>
                  );
                })}
              </Pressable>
              {open ? <ReportCard r={r} onChanged={onChanged} /> : null}
            </Card>
          );
        })}
        {ns.length ? (
          <View style={st.nsBox}>
            <Text style={st.nsTitle}>Not submitted yet (checked in today): {ns.length}</Text>
            <Text style={st.nsList}>{ns.map((x) => `${x.name}${x.id ? ` (${x.id})` : ''}${x.site ? ` - ${x.site}` : ''}`).join('   \u00B7   ')}</Text>
          </View>
        ) : null}
      </View>
    );
  }

  return (
    <View>
      <KpiGrid>
        <Kpi label="Cities" value={String(tree.length)} icon="business-outline" />
        <Kpi label="Sites" value={String(nSites)} icon="location-outline" />
        <Kpi label="Employees" value={String(nEmps)} icon="people-outline" />
        <Kpi label="Daily reports" value={String(shown.length)} icon="document-text-outline" />
        <Kpi label="Draft / not reviewed" value={String(notReviewed)} icon="time-outline" tone="amber" />
      </KpiGrid>

      {!rows ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : shown.length === 0 ? (
        <Card><Empty icon="document-text-outline" text="No daily reports here." /></Card>
      ) : tree.map((c, ci) => {
        const cKey = `c:${c.city}`; const cOpen = opened.has(cKey);
        return (
          <View key={c.city} style={{ marginBottom: 12 }}>
            <Pressable onPress={() => toggle(cKey)} style={st.cityBar}>
              <Text style={st.cityName}>{ci + 1}. {c.city}</Text>
              <Text style={st.cityCount}>{sFor(c.sites.length, 'site')} | {sFor(c.employees, 'employee')} | {sFor(c.reports, 'report')}  {cOpen ? '▴' : '▾'}</Text>
            </Pressable>
            {cOpen ? (
              <View>
                <Card style={{ marginTop: 6, marginBottom: 6 }}>
                  <Text style={st.gridTitle}>Sites in {c.city} ({c.sites.length}) - tap a site to jump</Text>
                  <View style={st.grid}>
                    {c.sites.map((s, si) => (
                      <Pressable key={s.site} style={st.gridCell} onPress={() => jump(c.city, s.site)}>
                        <Text style={st.gridNo}>{ci + 1}.{si + 1}</Text>
                        <View style={{ flex: 1 }}>
                          <Text style={st.gridName} numberOfLines={2}>{s.site}</Text>
                          <Text style={st.gridSub}>{s.emps.length} emp | {s.reports} rep</Text>
                        </View>
                      </Pressable>
                    ))}
                  </View>
                </Card>
                {c.sites.map((s, si) => {
                  const sKey = `s:${c.city}|${s.site}`; const sOpen = opened.has(sKey);
                  return (
                    <View key={s.site} ref={(el: any) => { if (el) anchors.current.set(`${c.city}|${s.site}`, el); }} style={{ marginBottom: 8 }}>
                      <Pressable onPress={() => toggle(sKey)} style={st.siteBar}>
                        <Text style={st.siteName}>{ci + 1}.{si + 1}  {s.site}</Text>
                        <Text style={st.siteCount}>{sFor(s.emps.length, 'employee')} | {sFor(s.reports, 'report')}  {sOpen ? '▴' : '▾'}</Text>
                      </Pressable>
                      {sOpen ? s.emps.map((e) => (
                        <Card key={e.key} style={{ marginTop: 6 }}>
                          <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                            <Row style={{ flex: 1, alignItems: 'center' }}>
                              <Avatar name={e.name} size={36} />
                              <View style={{ flex: 1 }}>
                                <Text style={st.name}>{e.name}</Text>
                                <Text style={st.id}>{e.id}</Text>
                              </View>
                            </Row>
                            <Pill text={sFor(new Set(e.items.map((i) => i.r.id)).size, 'report')} tone="blue" />
                          </Row>
                          {e.items.map((it, k) => {
                            const rk = `${it.r.id}|${s.site}|${it.s?.id ?? k}`; const open = openRep === rk;
                            const rc = [it.s?.remarks, it.s?.comment_1, it.s?.comment_2, it.s?.comment_3].map((x) => (x ?? '').trim()).filter((x) => x && !/^(na|n\/a|nil|-+)$/i.test(x));
                            return (
                              <View key={rk} style={st.rep}>
                                <Pressable onPress={() => setOpenRep(open ? null : rk)}>
                                  <Row style={{ justifyContent: 'space-between' }}>
                                    <Text style={st.repDate}>{fmtISODate(it.r.report_date)} {wd(it.r.report_date)}  |  {reportNo(it.r.id)}</Text>
                                    <Pill text={it.r.status} tone={DR_TONE[it.r.status as DailyReportStatus]} />
                                  </Row>
                                  {it.s?.sub_work ? <Text style={st.repLine}><Text style={st.repKey}>Sub work: </Text>{it.s.sub_work}</Text> : null}
                                  {(it.s?.work_description || it.s?.work_going_on) ? <Text style={st.repLine}><Text style={st.repKey}>Description: </Text>{it.s?.work_description || it.s?.work_going_on}</Text> : null}
                                  <Text style={st.repLine}><Text style={st.repKey}>Remarks & Comments: </Text>{rc.length ? rc.join('  |  ') : '-'}</Text>
                                </Pressable>
                                {open ? <ReportCard r={it.r} onChanged={onChanged} /> : null}
                              </View>
                            );
                          })}
                        </Card>
                      )) : null}
                    </View>
                  );
                })}
              </View>
            ) : null}
          </View>
        );
      })}
    </View>
  );
}

function ReportCard({ r, onChanged }: { r: DailyReport; onChanged: () => void | Promise<void> }) {
  const [note, setNote] = useState(r.review_note ?? '');
  const [busy, setBusy] = useState<string | null>(null);
  const visits = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq).filter((s) => s.arrived_at);
  const lang = reportLang(r.daily_report_sites);          // 'mr' | 'hi' | null (English)
  const [view, setView] = useState<TextView>('en');       // Admin sees English by default
  const langEnglish: Record<string, string> = { mr: 'Marathi', hi: 'Hindi' };

  const act = async (kind: 'review' | 'reopen') => {
    if (busy) return;
    setBusy(kind);
    try {
      if (kind === 'review') await api.reviewDailyReport(r.id, note.trim() || undefined);
      else await api.reopenDailyReport(r.id, note.trim() || undefined);
      await onChanged();
    } catch (e) { Alert.alert('Could not update', errorText(e)); }
    finally { setBusy(null); }
  };
  const pdf = async () => {
    setBusy('pdf');
    try {
      await dailyReportsPdf(`daily_report_${r.employee?.username ?? 'employee'}_${r.report_date}.pdf`,
        `${r.employee?.full_name ?? ''} - ${fmtISODate(r.report_date)}`, [r]);
    } catch (e) { Alert.alert('Could not create the PDF', errorText(e)); }
    finally { setBusy(null); }
  };

  return (
    <Card>
      <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flex: 1 }}>
          <Text style={st.name}>{r.employee?.full_name ?? 'Employee'} <Text style={st.id}>({r.employee?.username ?? ''})</Text></Text>
          <Text style={st.sub}>
            {fmtISODate(r.report_date)} - {reportNo(r.id)}
            {r.submitted_at ? ` - submitted ${fmtTime12(r.submitted_at)}` : ' - not submitted'}
          </Text>
        </View>
        <Pill text={r.status} tone={DR_TONE[r.status as DailyReportStatus]} />
      </Row>

      <View style={{ marginTop: 8 }}>
        <VisitSequence visits={visits} km={r.gps_km} hasGps={r.has_gps} />
      </View>
      {lang ? (
        <View style={{ marginTop: 8, gap: 6 }}>
          <Pill text={`Written in ${langEnglish[lang] ?? lang} - translated to English`} tone="purple" />
          <Segmented<TextView> value={view} onChange={setView} options={[
            { value: 'en', label: 'English' },
            { value: 'both', label: `English + ${LANG_NAME[lang] ?? lang}` },
            { value: 'orig', label: LANG_NAME[lang] ?? lang },
          ]} />
        </View>
      ) : null}
      <SiteBlocks sites={r.daily_report_sites} view={lang ? view : 'orig'} canEdit={!!lang && r.status !== 'Draft'}
        meta={{ employee: r.employee?.full_name ?? '', reportNo: reportNo(r.id), date: fmtISODate(r.report_date) }} onChanged={onChanged} />
      <ReportPhotos reportId={r.id} />

      <View style={st.box}>
        <Field label="Review note (optional)" value={note} onChangeText={setNote} placeholder="Shown to the employee" />
        <Row style={{ flexWrap: 'wrap' }}>
          <Button title="Mark Reviewed" icon="checkmark" variant="success" small loading={busy === 'review'} disabled={r.status !== 'Submitted'} onPress={() => act('review')} />
          <Button title="Reopen for correction" icon="refresh-outline" variant="secondary" small loading={busy === 'reopen'}
            disabled={r.status !== 'Submitted' && r.status !== 'Reviewed'} onPress={() => act('reopen')} />
          <Button title="Download PDF" icon="download-outline" small loading={busy === 'pdf'} onPress={pdf} />
        </Row>
      </View>
    </Card>
  );
}

const st = StyleSheet.create({
  dayTitle: { marginTop: 12, marginBottom: 8, fontSize: 14, fontWeight: '800', color: '#102A45' },
  nsBox: { marginTop: 4, padding: 12, borderRadius: 12, backgroundColor: '#FFF7DB', borderWidth: 1, borderColor: '#F2D98A' },
  nsTitle: { fontWeight: '800', color: '#7A5B00', fontSize: 13.5 },
  nsList: { marginTop: 6, color: '#5B4500', fontSize: 12.5, lineHeight: 19 },
  fcol: { flexGrow: 1, flexBasis: 220, minWidth: 200, marginBottom: 6 },
  showing: { color: C.muted, fontSize: 12, fontWeight: '700', marginTop: 6 },
  reset: { color: C.blue, fontWeight: '800', fontSize: 12.5, marginTop: 4 },
  cityBar: { backgroundColor: '#0B2A4A', borderRadius: 10, paddingVertical: 10, paddingHorizontal: 12, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: 4 },
  cityName: { color: '#fff', fontWeight: '800', fontSize: 15 },
  cityCount: { color: '#CFE0F5', fontWeight: '700', fontSize: 12 },
  gridTitle: { fontWeight: '800', color: '#102A45', fontSize: 12.5, marginBottom: 8 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  gridCell: { flexGrow: 1, flexBasis: '47%', minWidth: 140, flexDirection: 'row', gap: 8, backgroundColor: '#F6F9FD', borderWidth: 1, borderColor: '#E3EBF4', borderRadius: 8, padding: 8 },
  gridNo: { fontWeight: '800', color: C.blue, fontSize: 12 },
  gridName: { fontWeight: '700', color: '#102A45', fontSize: 12.5 },
  gridSub: { color: C.muted, fontSize: 11.5, marginTop: 2 },
  siteBar: { backgroundColor: '#DDEBF7', borderRadius: 10, paddingVertical: 9, paddingHorizontal: 12, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: 4 },
  siteName: { color: '#102A45', fontWeight: '800', fontSize: 14, flexShrink: 1 },
  siteCount: { color: '#3A5068', fontWeight: '700', fontSize: 12 },
  rep: { marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#EEF3F8' },
  repDate: { fontWeight: '800', color: '#102A45', fontSize: 12.5, flexShrink: 1 },
  repLine: { color: '#203951', marginTop: 3, lineHeight: 19, fontSize: 13 },
  repKey: { fontWeight: '800', color: '#3A5068' },
  lbl: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  name: { fontWeight: '800', color: '#102A45', fontSize: 15 },
  id: { fontWeight: '600', color: C.muted, fontSize: 13 },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  box: { marginTop: 10, padding: 10, borderRadius: 12, backgroundColor: '#F6F9FD', borderWidth: 1, borderColor: '#E3EBF4' },
});
