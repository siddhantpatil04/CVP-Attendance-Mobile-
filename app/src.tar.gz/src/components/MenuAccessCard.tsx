import React, { useEffect, useState } from 'react';
import { Alert, Text } from 'react-native';
import { api, Profile } from '../lib/api';
import { MENU_ACCESS_ITEMS } from '../navigation/menu';
import { errorText } from '../lib/supabase';
import { C } from '../theme';
import { Banner, Button, Card, Row, Toggle } from './ui';

/**
 * Admin / HR: choose which admin-menu items a PROJECT MANAGER (designation) gets.
 * At least one item makes him an HR-level user who sees only the ticked items; no item = a normal employee again.
 */
export function MenuAccessCard({ user, onSaved }: { user: Profile; onSaved: () => void | Promise<void> }) {
  const [picked, setPicked] = useState<string[]>(user.menu_access ?? []);
  const [busy, setBusy] = useState(false);
  useEffect(() => { setPicked(user.menu_access ?? []); }, [user.id, user.menu_access]);   // eslint-disable-line react-hooks/exhaustive-deps

  const saved = user.menu_access ?? [];
  const changed = picked.length !== saved.length || picked.some((k) => !saved.includes(k));
  const toggle = (k: string, on: boolean) => setPicked((p) => (on ? [...p, k] : p.filter((x) => x !== k)));

  const save = async () => {
    setBusy(true);
    try {
      await api.setMenuAccess(user.id, picked);
      await onSaved();
      Alert.alert('Saved', picked.length ? `${user.full_name} now sees ${picked.length} admin item(s).` : `${user.full_name} is a normal employee again.`);
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };

  return (
    <Card>
      <Banner tone="blue" icon="information-circle" text="Project Manager: tick the admin-menu items he may use. He then works with HR-level access and sees only these items. Untick all to make him a normal employee again." />
      <Row style={{ marginBottom: 8 }}>
        <Button title={`Select all (${MENU_ACCESS_ITEMS.length})`} icon="checkbox-outline" variant="secondary" small style={{ flex: 1 }}
          onPress={() => setPicked(MENU_ACCESS_ITEMS.map((i) => i.key))} />
        <Button title="Clear all" icon="close-circle-outline" variant="secondary" small style={{ flex: 1 }} onPress={() => setPicked([])} />
      </Row>
      {MENU_ACCESS_ITEMS.map((i) => (
        <Toggle key={i.key} label={i.label} value={picked.includes(i.key)} onChange={(v) => toggle(i.key, v)} />
      ))}
      <Text style={{ color: C.muted, fontSize: 12, marginVertical: 6 }}>{picked.length} item(s) ticked.</Text>
      <Button title="Save access" icon="save-outline" loading={busy} disabled={!changed} onPress={save} />
    </Card>
  );
}
