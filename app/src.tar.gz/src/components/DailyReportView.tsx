import React, { useState } from 'react';
import { Alert, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { api } from '../lib/api';
import type { DailyReportSite, DailyReportStatus } from '../lib/api';
import { DailyField, englishOf, writtenIn } from '../lib/dailyReportPdf';
import { errorText } from '../lib/supabase';
import { fmtTime12 } from '../lib/time';
import { C } from '../theme';
import { Button, Pill, Row } from './ui';

export const DR_TONE: Record<DailyReportStatus, React.ComponentProps<typeof Pill>['tone']> = {
  Draft: 'amber', Submitted: 'blue', Reviewed: 'green', Reopened: 'red',
};
export const reportNo = (id: number) => `DR-${String(id).padStart(6, '0')}`;
export const fmtKm = (km: number | null | undefined) => (km == null ? '' : `${km} km`);

export interface VisitLike { site_name: string; arrived_at: string | null; departed_at: string | null }

/** "9:10 AM - 11:30 AM" (a missing time is shown as a dash, never invented) */
export const visitTimes = (v: { arrived_at: string | null; departed_at: string | null }) =>
  `${v.arrived_at ? fmtTime12(v.arrived_at) : '-'} - ${v.departed_at ? fmtTime12(v.departed_at) : '-'}`;

/** The recorded site sequence with arrival / departure times and the GPS distance, or "GPS not available" */
export function VisitSequence({ visits, km, hasGps }: { visits: VisitLike[]; km: number | null | undefined; hasGps: boolean }) {
  if (!hasGps || visits.length === 0) {
    return <Text style={st.muted}>GPS not available for this day.</Text>;
  }
  return (
    <View>
      <Row gap={6} style={{ flexWrap: 'wrap' }}>
        {visits.map((v, i) => (
          <View key={`${v.site_name}-${i}`} style={st.chip}>
            <Text style={st.chipText}>{i + 1}. {v.site_name}  {visitTimes(v)}</Text>
          </View>
        ))}
      </Row>
      <Text style={st.km}>{km != null ? `GPS distance: ${km} km` : 'GPS distance: not available'}</Text>
    </View>
  );
}

export type TextView = 'en' | 'both' | 'orig';
export const LANG_NAME: Record<string, string> = { mr: 'मराठी', hi: 'हिंदी' };
const FIELD_LABEL: Record<DailyField, string> = {
  sub_work: 'Sub work', work_going_on: 'Work going on', work_description: 'Work description',
  comment_1: 'Comment to contractor 1', comment_2: 'Comment 2', comment_3: 'Comment 3', remarks: 'Remarks',
};
const FIELDS: DailyField[] = ['sub_work', 'work_description', 'comment_1', 'comment_2', 'comment_3', 'remarks'];

/** The first language an entry was written in (for the badge / the view switch), or null when everything is English */
export const reportLang = (sites: DailyReportSite[]): string | null => {
  for (const s of sites) { const l = writtenIn(s); if (l) return l; }
  return null;
};

/**
 * Every site entry of a report, read only.
 * view: 'orig' = as typed (employee), 'en' = English for Admin, 'both' = English with the original under each field.
 * canEdit (Admin / HR): an "Edit translation" link opens the Correct translation pop-up.
 */
export function SiteBlocks({ sites, view = 'orig', canEdit, meta, onChanged }: {
  sites: DailyReportSite[]; view?: TextView; canEdit?: boolean;
  meta?: { employee: string; reportNo: string; date: string }; onChanged?: () => void | Promise<void>;
}) {
  const [edit, setEdit] = useState<{ row: DailyReportSite; field: DailyField } | null>(null);

  const line = (s: DailyReportSite, f: DailyField) => {
    const orig = s[f];
    if (!orig) return null;
    const tr = s.translations?.[f];
    const translated = !!tr && !!tr.en;
    if (view === 'orig' || !translated) {
      return <Text key={f} style={st.line}><Text style={st.lbl}>{FIELD_LABEL[f]}: </Text>{view === 'en' ? englishOf(s, f) : orig}</Text>;
    }
    return (
      <View key={f} style={{ marginTop: 2 }}>
        <Text style={st.line}>
          <Text style={st.lbl}>{FIELD_LABEL[f]}: </Text>{englishOf(s, f)}
          {tr!.corrected_en ? <Text style={st.corrected}>  Corrected</Text> : null}
        </Text>
        {view === 'both' ? <Text style={st.orig}>{LANG_NAME[tr!.lang] ?? tr!.lang}: {orig}</Text> : null}
        {canEdit ? (
          <Pressable onPress={() => setEdit({ row: s, field: f })} accessibilityRole="button" hitSlop={6}>
            <Text style={st.editLink}>Edit translation</Text>
          </Pressable>
        ) : null}
      </View>
    );
  };

  return (
    <View>
      {[...sites].sort((a, b) => a.seq - b.seq).map((s) => (
        <View key={s.seq} style={st.block}>
          <Text style={st.siteName}>{s.seq}. {s.site_name || 'Site'}{s.arrived_at ? `  (${visitTimes(s)})` : ''}</Text>
          {FIELDS.map((f) => line(s, f))}
        </View>
      ))}
      <CorrectTranslation edit={edit} meta={meta} onClose={() => setEdit(null)} onSaved={async () => { setEdit(null); await onChanged?.(); }} />
    </View>
  );
}

/** "Correct translation" pop-up: original (read only), automatic English (read only), corrected English (required) */
function CorrectTranslation({ edit, meta, onClose, onSaved }: {
  edit: { row: DailyReportSite; field: DailyField } | null;
  meta?: { employee: string; reportNo: string; date: string }; onClose: () => void; onSaved: () => void | Promise<void>;
}) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const tr = edit ? edit.row.translations?.[edit.field] : undefined;
  React.useEffect(() => { if (edit) setText(tr?.corrected_en || tr?.en || ''); }, [edit?.row.id, edit?.field]);   // eslint-disable-line react-hooks/exhaustive-deps

  const save = async () => {
    if (!edit) return;
    if (!text.trim()) return Alert.alert('Corrected English is required.');
    setBusy(true);
    try { await api.correctTranslation(edit.row.id, edit.field, text.trim()); await onSaved(); }
    catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };

  return (
    <Modal visible={!!edit} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={st.backdrop} onPress={onClose}>
        <Pressable style={st.dialog} onPress={() => {}}>
          {edit && tr ? (
            <>
              <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                <Text style={st.dTitle}>Correct translation</Text>
                <Pill text={FIELD_LABEL[edit.field]} tone="blue" />
              </Row>
              {meta ? <Text style={st.dMeta}>{meta.employee} - {meta.reportNo} - {meta.date}</Text> : null}

              <Text style={st.dLabel}>{LANG_NAME[tr.lang] ?? tr.lang} original (cannot be edited)</Text>
              <View style={st.readBox}><Text style={st.readText}>{edit.row[edit.field]}</Text></View>

              <Text style={st.dLabel}>English (automatic)</Text>
              <View style={[st.readBox, { backgroundColor: '#EEF1F5' }]}><Text style={[st.readText, { color: '#5B6B7E' }]}>{tr.en}</Text></View>

              <Text style={st.dLabel}>Corrected English *</Text>
              <TextInput value={text} onChangeText={setText} multiline style={st.input} placeholder="Write the correct English" placeholderTextColor="#8594A6" />

              <Text style={st.dNote}>Saved as "Corrected by you" with date and time in the audit log. The original stays unchanged.</Text>
              <Row style={{ marginTop: 10 }}>
                <Button title="Cancel" variant="secondary" style={{ flex: 1 }} onPress={onClose} />
                <Button title="Save correction" icon="checkmark" style={{ flex: 1 }} loading={busy} onPress={save} />
              </Row>
            </>
          ) : null}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const st = StyleSheet.create({
  muted: { color: C.muted, fontSize: 12.5 },
  chip: { backgroundColor: '#EEF6FF', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5, borderWidth: 1, borderColor: '#D5E6FA' },
  chipText: { color: '#17456F', fontSize: 12, fontWeight: '700' },
  km: { color: '#17314D', fontSize: 12.5, fontWeight: '800', marginTop: 6 },
  block: { marginTop: 10, padding: 10, borderRadius: 12, backgroundColor: '#F6F9FD', borderWidth: 1, borderColor: '#E3EBF4' },
  siteName: { fontWeight: '800', color: '#102A45', fontSize: 14, marginBottom: 4 },
  line: { color: '#203951', fontSize: 13, lineHeight: 19, marginTop: 2 },
  lbl: { fontWeight: '800', color: '#3A5068' },
  corrected: { fontSize: 11, fontWeight: '800', color: '#1B6B3A' },
  orig: { fontSize: 12.5, color: '#6F8196', marginLeft: 8, lineHeight: 18 },
  editLink: { fontSize: 12, fontWeight: '800', color: C.blue, marginLeft: 8, marginTop: 1 },
  backdrop: { flex: 1, backgroundColor: 'rgba(6,37,63,0.45)', justifyContent: 'center', alignItems: 'center', padding: 16 },
  dialog: { backgroundColor: '#FFFFFF', borderRadius: 18, padding: 16, width: '100%', maxWidth: 560 },
  dTitle: { fontSize: 18, fontWeight: '800', color: '#102A45' },
  dMeta: { fontSize: 12.5, color: C.muted, marginTop: 4, marginBottom: 6 },
  dLabel: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginTop: 10, marginBottom: 4 },
  readBox: { backgroundColor: '#F8FBFF', borderRadius: 10, borderWidth: 1, borderColor: '#E3ECF6', padding: 10 },
  readText: { fontSize: 13.5, color: '#203951', lineHeight: 19 },
  input: { minHeight: 80, borderWidth: 1, borderColor: C.blue, borderRadius: 10, padding: 10, fontSize: 14, color: '#102A45', textAlignVertical: 'top', backgroundColor: '#FFFFFF' },
  dNote: { fontSize: 11.5, color: '#6F8196', marginTop: 8, lineHeight: 16 },
});
