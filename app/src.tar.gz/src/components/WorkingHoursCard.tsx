import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { completeAtMs, hm, progress } from '../lib/hours';
import { fmtTime12 } from '../lib/time';
import { C } from '../theme';
import { Card } from './ui';

/** "Today's working hours": live progress from check-in towards the required hours, and when they complete. */
export default function WorkingHoursCard({ checkInAt, worked, requiredMin, done }: {
  checkInAt: string; worked: number; requiredMin: number; done?: boolean;
}) {
  const p = progress(worked, requiredMin);
  const complete = worked >= requiredMin;
  return (
    <Card>
      <Text style={st.title}>Today's working hours</Text>
      <View style={st.track}><View style={[st.fill, { width: `${Math.round(p * 100)}%`, backgroundColor: complete ? C.green : C.blue }]} /></View>
      <View style={st.row}>
        <Text style={st.worked}>{hm(worked)} worked</Text>
        <Text style={st.req}>{hm(requiredMin)} required</Text>
      </View>
      <View style={[st.note, { backgroundColor: complete ? C.greenSoft : C.blueSoft }]}>
        <Ionicons name={complete ? 'checkmark-circle-outline' : 'time-outline'} size={18} color={complete ? C.green : C.blue} />
        <Text style={[st.noteText, { color: complete ? '#157A4B' : '#0B5FC4' }]}>
          {complete
            ? done ? `${hm(requiredMin)} completed. Full day.` : `${hm(requiredMin)} complete. You can check out any time.`
            : `${hm(requiredMin)} complete at ${fmtTime12(completeAtMs(checkInAt, requiredMin))}. You can check out any time.`}
        </Text>
      </View>
      <Text style={st.rule}>Only check-in to check-out is counted. There is no check-in or check-out time limit.</Text>
    </Card>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 15, fontWeight: '800', color: C.ink, marginBottom: 10 },
  track: { height: 10, borderRadius: 6, backgroundColor: '#E6EDF6', overflow: 'hidden' },
  fill: { height: 10, borderRadius: 6 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 },
  worked: { fontSize: 13, fontWeight: '800', color: C.ink },
  req: { fontSize: 13, color: C.muted, fontWeight: '600' },
  note: { flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 12, padding: 10, marginTop: 10 },
  noteText: { flex: 1, fontSize: 13, fontWeight: '700', lineHeight: 18 },
  rule: { fontSize: 12, color: C.muted, marginTop: 10, lineHeight: 17 },
});
