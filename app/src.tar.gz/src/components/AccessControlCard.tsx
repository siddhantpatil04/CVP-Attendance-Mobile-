import React, { useState } from 'react';
import { Alert, StyleSheet, Text } from 'react-native';
import { api, Profile } from '../lib/api';
import { errorText } from '../lib/supabase';
import { C } from '../theme';
import { SiteAccessCard, SiteAccessState } from './SiteAccessCard';
import { Collapsible } from './Collapsible';
import { Banner, Button, Card, Toggle } from './ui';

type Draft = { selfie?: boolean; wide?: boolean; field?: boolean; travel?: boolean; tour?: boolean; docs?: boolean };

/**
 * Access Control for one employee (Employee Forms page).
 * The switches only change on screen; nothing is saved until the Admin / HR presses "Save Access".
 */
export function AccessControlCard({ p, canManage, onSaved }: { p: Profile; canManage: boolean; onSaved: () => void | Promise<void> }) {
  const [draft, setDraft] = useState<Draft>({});
  const [busy, setBusy] = useState(false);
  const [siteState, setSiteState] = useState<SiteAccessState | null>(null);

  const fieldNow = !!p.wide_site_access;
  const acc = {
    selfie: draft.selfie ?? !!p.site_employee,
    field: draft.field ?? fieldNow,
    travel: draft.travel ?? !!p.travel_access,
    tour: draft.tour ?? !!p.tour_access,
    docs: draft.docs ?? !!p.documents_access,
  };
  const changed = acc.selfie !== !!p.site_employee || acc.field !== fieldNow
    || acc.travel !== !!p.travel_access || acc.tour !== !!p.tour_access || acc.docs !== !!p.documents_access
    || !!siteState?.changed;
  const setD = (k: keyof Draft, v: boolean) => { if (canManage && !busy) setDraft((d) => ({ ...d, [k]: v })); };

  const save = async () => {
    if (!canManage || busy) return;
    setBusy(true);
    try {
      if (acc.selfie !== !!p.site_employee) await api.updateProfile(p.id, { site_employee: acc.selfie });
      if (acc.field !== fieldNow) {
        await api.setFeatureAccess(p.id, 'wide_site', acc.field);
      }
      if (acc.travel !== !!p.travel_access) await api.setTravelAccess(p.id, acc.travel);
      if (acc.tour !== !!p.tour_access) await api.setFeatureAccess(p.id, 'tour', acc.tour);
      if (acc.docs !== !!p.documents_access) await api.setFeatureAccess(p.id, 'documents', acc.docs);
      if (siteState?.changed) await siteState.save();
      setDraft({});
      await onSaved();
      Alert.alert('Saved', 'Access settings saved.');
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };

  return (
    <Collapsible title="Access Control" note="Switch features ON or OFF, then press Save Access" defaultOpen>
      <Card>
        {!canManage ? <Banner tone="amber" text="Only an Admin can change HR / Admin accounts." /> : null}
        <Toggle label="Selfie Access" note={acc.selfie ? 'ON: a selfie and location are required at the project site (site employee).' : 'OFF: no selfie. Check in / out only at the Office Location (Pune CVPATIL).'}
          value={acc.selfie} onChange={(v) => setD('selfie', v)} />
        {p.site_employee ? (
          <Collapsible title="Site Access" note="Work sites this employee may use">
            <SiteAccessCard userId={p.id} canManage={canManage} onState={setSiteState} />
          </Collapsible>
        ) : null}
        <Text style={st.section}>FIELD WORK</Text>
        <Toggle label="Foreign Location Access" note="Allow this person to check out from a foreign location (any place, with a selfie and a reason)"
          value={acc.field} onChange={(v) => setD('field', v)} />
        <Toggle label="Travel Access" note="Check in / out at many stops a day and the distance in km between them"
          value={acc.travel} onChange={(v) => setD('travel', v)} />
        <Toggle label="Tour Access" note="Allow this person to apply for a tour outside the city and add tour expenses, documents and tasks"
          value={acc.tour} onChange={(v) => setD('tour', v)} />
        <Toggle label="Documents Access" note="Allow this person to upload documents with a remark and to see the documents you send to them"
          value={acc.docs} onChange={(v) => setD('docs', v)} />
        <Button title="Save Access" icon="save-outline" loading={busy} disabled={!canManage || !changed} onPress={save} style={{ marginTop: 8 }} />
        {changed ? <Text style={st.hint}>You have unsaved changes. Press Save Access.</Text> : null}
      </Card>
    </Collapsible>
  );
}

const st = StyleSheet.create({
  section: { fontSize: 11, fontWeight: '800', color: '#8594A6', letterSpacing: 0.6, marginTop: 12, marginBottom: 2 },
  label: { fontWeight: '800', color: '#4A5E75', fontSize: 12, marginBottom: 6, marginTop: 4 },
  hint: { color: C.muted, fontSize: 12, marginTop: 6 },
});
