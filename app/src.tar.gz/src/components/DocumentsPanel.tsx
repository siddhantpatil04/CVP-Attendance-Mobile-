import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Platform, StyleSheet, Text, View } from 'react-native';
import { downloadOrOpen } from '../lib/saveDownload';
import { api, DOC_CATEGORIES, EmployeeDocument } from '../lib/api';
import { DocStatusLine, DocumentReview } from './DocumentReview';
import { PickedFile, pickFile } from '../lib/pickFile';
import { useRealtime } from '../lib/realtime';
import { errorText } from '../lib/supabase';
import { fmtISODate } from '../lib/time';
import { C } from '../theme';
import { Button, Card, Chips, Empty, Field, Pill, Row, SectionTitle } from './ui';

/**
 * Documents of one employee.
 *  admin = false : the employee uploads his own document with a remark, and sees what Admin / HR sent him.
 *  admin = true  : Admin / HR upload a document for that employee (with a remark), see what he uploaded, and can delete.
 */
export default function DocumentsPanel({ userId, admin }: { userId: string; admin: boolean }) {
  const [docs, setDocs] = useState<EmployeeDocument[] | null>(null);
  const [title, setTitle] = useState('');
  const [remark, setRemark] = useState('');
  const [category, setCategory] = useState<string>('Other');
  const [file, setFile] = useState<PickedFile | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try { setDocs(await api.employeeDocuments(userId)); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [userId]);
  useEffect(() => { setDocs(null); load(); }, [load]);
  useRealtime(`docs-${userId}`, [{ table: 'employee_documents', filter: `user_id=eq.${userId}` }], () => load());

  const choose = (camera: boolean) => { pickFile(camera).then((f) => { if (f) setFile(f); }).catch((e) => Alert.alert('Could not pick the file', errorText(e))); };

  const upload = async () => {
    if (!title.trim()) return Alert.alert('Enter the document name.');
    if (!file) return Alert.alert('Choose the document first.');
    setBusy(true);
    let path: string | null = null;
    try {
      path = await api.uploadEmployeeFile(userId, file.bytes, file.name, file.mime);
      await api.addEmployeeDocument(admin ? userId : null, title.trim(), remark.trim() || undefined, path, file.name, category);
      setTitle(''); setRemark(''); setFile(null); setCategory('Other');
      await load();
    } catch (e) {
      if (path) await api.removeEmployeeFile(path).catch(() => {});
      Alert.alert('Could not upload', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  const open = async (d: EmployeeDocument, save = false) => {
    try { await downloadOrOpen(await api.employeeFileUrl(d.file_path, save ? (d.file_name || d.title) : undefined), d.file_name || d.title, save); } catch (e) { Alert.alert('File unavailable', errorText(e)); }
  };
  const remove = (d: EmployeeDocument) =>
    Alert.alert('Delete this document?', d.title, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        try { await api.deleteEmployeeDocument(d.id); await load(); } catch (e) { Alert.alert('Could not delete', errorText(e)); }
      } },
    ]);

  return (
    <View>
      <Card>
        <Text style={st.head}>{admin ? 'Send a document to this employee' : 'Upload a document'}</Text>
        <Field label="Document name" value={title} onChangeText={setTitle}
          placeholder={admin ? 'e.g. Offer letter, Form 16' : 'e.g. Site handover note, Measurement sheet'} />
        <Text style={st.hint}>Type of document</Text>
        <Chips<string> options={[...DOC_CATEGORIES]} value={category} onChange={setCategory} />
        <Field label="Remark (optional)" value={remark} onChangeText={setRemark} multiline
          placeholder={admin ? 'A note for the employee' : 'What this document is for, from which site to which site'} />
        <Row style={{ flexWrap: 'wrap', marginBottom: 6 }}>
          <Button title={file ? 'Change file' : Platform.OS === 'web' ? 'Choose file' : 'From gallery'} icon="attach-outline" variant="secondary" small onPress={() => choose(false)} />
          {Platform.OS !== 'web' ? <Button title="Take photo" icon="camera-outline" variant="secondary" small onPress={() => choose(true)} /> : null}
        </Row>
        {file ? <Text style={st.ok}>{file.name} ({Math.max(1, Math.round(file.bytes.byteLength / 1024))} KB)</Text> : null}
        <Button title="Upload" icon="cloud-upload-outline" loading={busy} onPress={upload} style={{ marginTop: 10 }} />
      </Card>

      <SectionTitle title="Documents" />
      <Card>
        {docs === null ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : docs.length === 0 ? (
          <Empty icon="document-outline" text="No documents yet." />
        ) : docs.map((d) => {
          const fromAdmin = d.direction === 'from_admin';
          return (
            <View key={d.id} style={st.item}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Text style={st.title}>{d.title}</Text>
                <Pill text={fromAdmin ? (admin ? 'Sent by Admin / HR' : 'From Admin / HR') : (admin ? 'Uploaded by employee' : 'You uploaded')} tone={fromAdmin ? 'purple' : 'blue'} />
              </Row>
              <Text style={st.sub}>{fmtISODate(d.created_at.slice(0, 10))}{d.file_name ? ` - ${d.file_name}` : ''}</Text>
              {d.remark ? <Text style={st.remark}>Remark: {d.remark}</Text> : null}
              <DocStatusLine d={d} />
              <Row style={{ marginTop: 6, flexWrap: 'wrap' }}>
                <Button title="View" icon="eye-outline" variant="secondary" small onPress={() => open(d)} />
                <Button title="Download" icon="download-outline" small onPress={() => open(d, true)} />
                {admin ? <Button title="Delete" icon="trash-outline" variant="danger" small onPress={() => remove(d)} /> : null}
              </Row>
              {admin ? <DocumentReview d={d} onChanged={load} /> : null}
            </View>
          );
        })}
      </Card>
    </View>
  );
}

const st = StyleSheet.create({
  head: { fontSize: 15, fontWeight: '800', color: C.ink, marginBottom: 8 },
  item: { paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  title: { fontWeight: '800', color: '#102A45', fontSize: 14, flexShrink: 1 },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  remark: { color: '#203951', marginTop: 4, lineHeight: 19 },
  ok: { color: C.green, fontSize: 12.5, fontWeight: '700' },
  hint: { color: C.muted, fontSize: 12, marginTop: 4 },
});

