import React, { useRef } from 'react';
import { Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { C } from '../theme';

/**
 * One-time code entry: N boxes (6), auto-focus, paste support (digits are taken from whatever is pasted),
 * the phone / browser one-time-code suggestion. One invisible TextInput sits on top of the boxes and holds the value.
 */
export default function CodeInput({ value, onChange, length = 6, autoFocus = true }: { value: string; onChange: (v: string) => void; length?: number; autoFocus?: boolean }) {
  const ref = useRef<TextInput>(null);
  const cur = Math.min(value.length, length - 1);
  return (
    <Pressable onPress={() => ref.current?.focus()} style={st.wrap} accessibilityLabel={`Enter the ${length}-digit code`}>
      <View style={st.row}>
        {Array.from({ length }).map((_, i) => (
          <View key={i} style={[st.box, i === cur && st.boxOn, value[i] ? st.boxFilled : null]}>
            <Text style={st.digit}>{value[i] ?? ''}</Text>
          </View>
        ))}
      </View>
      <TextInput
        ref={ref} value={value} autoFocus={autoFocus}
        onChangeText={(t) => onChange(t.replace(/\D/g, '').slice(0, length))}   // paste "123 456" or "123456": only the digits are kept
        keyboardType="number-pad" inputMode="numeric" maxLength={length * 3}
        textContentType="oneTimeCode" autoComplete="one-time-code" caretHidden selectionColor="transparent"
        style={[st.input, Platform.OS === 'web' ? ({ outlineStyle: 'none', cursor: 'text' } as any) : null]}
      />
    </Pressable>
  );
}

const st = StyleSheet.create({
  wrap: { position: 'relative', alignSelf: 'center', marginBottom: 12 },
  row: { flexDirection: 'row', gap: 8, justifyContent: 'center' },
  box: { width: 44, height: 54, borderRadius: 12, borderWidth: 1.5, borderColor: '#C9DDF3', backgroundColor: '#F4F9FF', alignItems: 'center', justifyContent: 'center' },
  boxOn: { borderColor: C.blue, backgroundColor: '#FFFFFF' },
  boxFilled: { backgroundColor: '#FFFFFF' },
  digit: { fontSize: 24, fontWeight: '800', color: '#102944' },
  input: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, opacity: 0, color: 'transparent', fontSize: 24 },
});
