import React, { useCallback, useEffect, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { useAuth } from '../lib/auth';
import { loadPf, PfData, pfApi, pfMonthStart } from '../lib/pf';
import { wagesOfMonth } from '../lib/reports';
import { errorText } from '../lib/supabase';
import { fmtISODate, istParts, MONTHS } from '../lib/time';
import { WageRow } from '../lib/wages';
import { C } from '../theme';
import { Collapsible } from './Collapsible';
import { MonthPicker } from './Pickers';
import { Banner, Button, Card, Field, InfoTile, Row, Toggle } from './ui';

const rs = (n: number) => Number(n).toLocaleString('en-IN');

/** Company Reports: PF figures of the chosen month (same calculation as the downloads) and, for the Admin, the PF rules */
export default function PfReportsPanel({ year, month, allow, pf: pfOnly }: {
  year: number; month: number; allow?: (userId: string, date: string) => boolean; pf?: 'on' | 'off';
}) {
  const { profile } = useAuth();
  const [wages, setWages] = useState<WageRow[] | null>(null);
  const [data, setData] = useState<PfData | null>(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setError('');
    try {
      const [w, d] = await Promise.all([wagesOfMonth(year, month), loadPf()]);
      setWages(w); setData(d);
    } catch (e) { setError(errorText(e)); setWages(null); }
  }, [year, month]);
  useEffect(() => { setWages(null); load(); }, [load]);

  const end = `${year}-${String(month).padStart(2, '0')}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}`;
  const shown = (wages ?? []).filter((w) => (!allow || allow(w.userId, end)) && (!pfOnly || (w.pfMember === 'Y') === (pfOnly === 'on')));
  const total = (k: 'pfEmployee' | 'pfEmployer' | 'net') => `Rs ${rs(shown.reduce((a, w) => a + w[k], 0))}`;

  return (
    <View style={{ gap: 8, marginBottom: 10 }}>
      {error ? <Banner tone="red" icon="alert-circle" text={`PF figures could not be loaded: ${error}`} /> : null}
      {data && !data.installed ? <Banner tone="amber" text="PF ON / OFF needs a one-time database update: back up, then run supabase/pf_on_off.sql in the Supabase SQL Editor. Reports are calculated as before." /> : null}
      {data?.installed && (!data.switchFrom || pfMonthStart(year, month) < data.switchFrom) ? <Banner tone="amber" text={`${MONTHS[month - 1]} ${year} is calculated as before, so the PF ON / OFF switches are not used for it: ${data.switchFrom ? `they start from ${fmtISODate(data.switchFrom)}.` : 'the PF start month is not set yet (see PF rules below).'}`} /> : null}
      {wages ? (
        <Row style={{ flexWrap: 'wrap' }} gap={8}>
          <InfoTile label="Employees" value={String(shown.length)} />
          <InfoTile label="PF ON" value={String(shown.filter((w) => w.pfMember === 'Y').length)} />
          <InfoTile label="PF OFF" value={String(shown.filter((w) => w.pfMember !== 'Y').length)} />
          <InfoTile label="Employee PF total" value={total('pfEmployee')} />
          <InfoTile label="Employer PF total" value={total('pfEmployer')} />
          <InfoTile label="Net salary total" value={total('net')} />
        </Row>
      ) : error ? null : <Text style={st.meta}>Calculating PF...</Text>}
      {profile?.role === 'Admin' && data?.installed ? (
        <Collapsible title="PF rules" note="PF start month, rates and ceiling">
          <PfSettings data={data} onSaved={load} />
        </Collapsible>
      ) : null}
    </View>
  );
}

/** Admin only: the PF start month and the PF rules (rates and ceiling, from a month) */
function PfSettings({ data, onSaved }: { data: PfData; onSaved: () => void }) {
  const now = istParts();
  const cur = data.rules[0];
  const next = now.month === 12 ? { year: now.year + 1, month: 1 } : { year: now.year, month: now.month + 1 };
  const [startAt, setStartAt] = useState(data.switchFrom ? { year: Number(data.switchFrom.slice(0, 4)), month: Number(data.switchFrom.slice(5, 7)) } : next);
  const [from, setFrom] = useState(next);
  const [emp, setEmp] = useState(String(Number(cur?.employee_rate ?? 12)));
  const [er, setEr] = useState(String(Number(cur?.employer_rate ?? 12)));
  const [eps, setEps] = useState(String(Number(cur?.eps_rate ?? 8.33)));
  const [ceiling, setCeiling] = useState(String(Number(cur?.wage_ceiling ?? 25000)));
  const [apply, setApply] = useState(cur?.apply_ceiling ?? true);
  const [busy, setBusy] = useState(false);

  const act = async (fn: () => Promise<void>) => {
    setBusy(true);
    try { await fn(); onSaved(); Alert.alert('Saved'); }
    catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };
  const saveStart = () => {
    const d = pfMonthStart(startAt.year, startAt.month);
    Alert.alert('PF start month', `From ${fmtISODate(d)} only employees switched ON have PF. Everyone else is OFF. Continue?`,
      [{ text: 'Cancel', style: 'cancel' }, { text: 'Set', onPress: () => act(() => pfApi.setSwitchMonth(d)) }]);
  };
  const num = (set: (v: string) => void) => (v: string) => set(v.replace(/[^0-9.]/g, ''));

  return (
    <Card>
      <Text style={st.title}>PF rules (Admin)</Text>
      <Text style={st.label}>PF start month - {data.switchFrom ? fmtISODate(data.switchFrom) : 'not set'}</Text>
      <MonthPicker year={startAt.year} month={startAt.month} onChange={(year, month) => setStartAt({ year, month })} />
      <Button title="Set PF start month" variant="secondary" small loading={busy} onPress={saveStart} style={{ marginTop: 8, alignSelf: 'flex-start' }} />

      <Text style={[st.label, { marginTop: 14 }]}>Rates and ceiling, effective from</Text>
      <MonthPicker year={from.year} month={from.month} onChange={(year, month) => setFrom({ year, month })} />
      <View style={{ marginTop: 8 }}>
        <Field label="Employee PF rate (%)" value={emp} keyboardType="decimal-pad" onChangeText={num(setEmp)} />
        <Field label="Employer PF rate (%)" value={er} keyboardType="decimal-pad" onChangeText={num(setEr)} />
        <Field label="of which Employer EPS (%)" value={eps} keyboardType="decimal-pad" onChangeText={num(setEps)} />
        <Field label="PF wage ceiling (Rs)" value={ceiling} keyboardType="decimal-pad" onChangeText={num(setCeiling)} />
        <Toggle label="Apply ceiling" value={apply} onChange={setApply} note="OFF: PF on the full PF wages. Amounts are rounded to the nearest rupee." />
      </View>
      <Button title="Save PF rules" icon="save-outline" loading={busy} style={{ marginTop: 8 }}
        onPress={() => act(() => pfApi.saveRules({ effective_from: pfMonthStart(from.year, from.month), employee_rate: Number(emp), employer_rate: Number(er), eps_rate: Number(eps), wage_ceiling: Number(ceiling), apply_ceiling: apply }))} />
      <Text style={[st.label, { marginTop: 14 }]}>History</Text>
      {data.rules.map((r) => (
        <Text key={r.effective_from} style={st.meta}>From {fmtISODate(r.effective_from)}: employee {Number(r.employee_rate)}%, employer {Number(r.employer_rate)}% (EPS {Number(r.eps_rate)}%), ceiling {rs(r.wage_ceiling)}{r.apply_ceiling ? '' : ' not applied'}</Text>
      ))}
    </Card>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 16, fontWeight: '800', color: C.ink, marginBottom: 6 },
  label: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  meta: { fontSize: 11.5, color: C.muted, marginBottom: 2 },
});
