import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Linking, Text, View } from 'react-native';
import { Button, Row } from './ui';
import { api } from '../lib/api';
import { errorText } from '../lib/supabase';

/** The photo(s) attached to a submitted Daily Report: a View button for each (the file is opened through a short private link) */
export default function ReportPhotos({ reportId }: { reportId: number }) {
  const [list, setList] = useState<{ id: number; file_path: string; file_name: string | null }[]>([]);
  const load = useCallback(() => { api.dailyReportPhotos(reportId).then(setList).catch(() => setList([])); }, [reportId]);
  useEffect(() => { load(); }, [load]);
  if (list.length === 0) return null;
  return (
    <View style={{ marginTop: 10 }}>
      <Text style={{ fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 }}>Photo of the report ({list.length})</Text>
      <Row style={{ flexWrap: 'wrap' }}>
        {list.map((p, i) => (
          <Button key={p.id} title={`View photo ${i + 1}`} icon="image-outline" variant="secondary" small
            onPress={() => api.dailyReportPhotoUrl(p.file_path).then((u) => Linking.openURL(u)).catch((e) => Alert.alert('Could not open', errorText(e)))} />
        ))}
      </Row>
    </View>
  );
}