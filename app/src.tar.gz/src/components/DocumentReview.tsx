import React, { useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { api, DocStatus, EmployeeDocument } from '../lib/api';
import { errorText } from '../lib/supabase';
import { fmtISODate } from '../lib/time';
import { C } from '../theme';
import { Button, Field, Pill, Row } from './ui';

export const DOC_TONE: Record<DocStatus, 'blue' | 'amber' | 'green' | 'red' | 'purple'> = {
  Submitted: 'blue', 'Under Review': 'amber', Approved: 'green', Rejected: 'red', Sent: 'purple',
};

/** The status of a document and the reviewer's note (what the employee and Admin / HR both see) */
export function DocStatusLine({ d }: { d: EmployeeDocument }) {
  const status = d.status ?? (d.direction === 'from_admin' ? 'Sent' : 'Submitted');
  return (
    <View>
      <Row gap={6} style={{ flexWrap: 'wrap', marginTop: 4 }}>
        {d.category ? <Pill text={d.category} tone="cyan" /> : null}
        {d.direction === 'from_employee' ? <Pill text={status} tone={DOC_TONE[status]} /> : null}
      </Row>
      {d.direction === 'from_employee' && d.review_note ? (
        <Text style={st.note}>Review note{d.reviewed_at ? ` (${fmtISODate(d.reviewed_at.slice(0, 10))})` : ''}: {d.review_note}</Text>
      ) : null}
    </View>
  );
}

/** Admin / HR: review a document an employee submitted (status + note) */
export function DocumentReview({ d, onChanged }: { d: EmployeeDocument; onChanged: () => void | Promise<void> }) {
  const [note, setNote] = useState(d.review_note ?? '');
  const [busy, setBusy] = useState<string | null>(null);
  if (d.direction !== 'from_employee') return null;

  const set = async (status: 'Approved' | 'Rejected') => {
    if (busy) return;
    setBusy(status);
    try { await api.reviewEmployeeDocument(d.id, status, note.trim() || undefined); await onChanged(); }
    catch (e) { Alert.alert('Could not update', errorText(e)); }
    finally { setBusy(null); }
  };

  return (
    <View style={st.box}>
      <Field label="Review note (optional)" value={note} onChangeText={setNote} placeholder="Shown to the employee" />
      <Row style={{ flexWrap: 'wrap' }}>
        <Button title="Approve" icon="checkmark" variant="success" small loading={busy === 'Approved'} disabled={d.status === 'Approved'} onPress={() => set('Approved')} />
        <Button title="Reject" icon="close" variant="danger" small loading={busy === 'Rejected'} disabled={d.status === 'Rejected'} onPress={() => set('Rejected')} />
      </Row>
    </View>
  );
}

const st = StyleSheet.create({
  note: { color: '#203951', marginTop: 4, lineHeight: 19, fontSize: 13 },
  box: { marginTop: 8, padding: 10, borderRadius: 12, backgroundColor: '#F6F9FD', borderWidth: 1, borderColor: '#E3EBF4' },
});
void C;
