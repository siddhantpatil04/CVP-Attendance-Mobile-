import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { downloadOrOpen } from '../lib/saveDownload';
import { api, DocAudience, DocumentType, Profile, SharedDocument, Site } from '../lib/api';
import { pickFile } from '../lib/pickFile';
import { errorText } from '../lib/supabase';
import { fmtISODate } from '../lib/time';
import { C } from '../theme';
import { Dropdown, PickerField } from './Pickers';
import { Banner, Button, Card, Chips, Empty, Field, Pill, Row, Toggle } from './ui';
import { shownRole } from '../navigation/menu';

const SENDER = 'C V PATIL & ASSOCIATES';
const ALLOWED: Record<string, string> = {
  pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
};
/** The file must really be what its name says (checked by the first bytes, not only the extension) */
function realType(bytes: ArrayBuffer, ext: string): boolean {
  const b = new Uint8Array(bytes.slice(0, 8));
  const is = (...x: number[]) => x.every((v, i) => b[i] === v);
  if (ext === 'pdf') return is(0x25, 0x50, 0x44, 0x46);
  if (ext === 'jpg' || ext === 'jpeg') return is(0xff, 0xd8, 0xff);
  if (ext === 'png') return is(0x89, 0x50, 0x4e, 0x47);
  if (ext === 'docx' || ext === 'xlsx') return is(0x50, 0x4b, 0x03, 0x04);
  return false;
}

// ============================================================ Employee: "From C V Patil"
export function FromCvpList({ myId }: { myId: string }) {
  const [rows, setRows] = useState<SharedDocument[] | null>(null);
  const [q, setQ] = useState('');
  const [typeF, setTypeF] = useState('All types');
  const load = useCallback(async () => {
    try { setRows(await api.sharedDocuments(myId)); } catch (e) { Alert.alert('Could not load', errorText(e)); setRows([]); }
  }, [myId]);
  useEffect(() => { load(); }, [load]);

  const types = ['All types', ...new Set((rows ?? []).map((d) => d.type?.name ?? '').filter(Boolean))];
  const shown = (rows ?? []).filter((d) => (typeF === 'All types' || d.type?.name === typeF)
    && (!q.trim() || `${d.title} ${d.description ?? ''}`.toLowerCase().includes(q.trim().toLowerCase())));

  const open = async (d: SharedDocument, download = false) => {
    try { await downloadOrOpen(await api.openSharedDocument(d.id, download), d.file_name || d.title, download); await load(); }
    catch (e) { Alert.alert('Could not open', errorText(e)); }
  };

  return (
    <View>
      <Card>
        <TextInput value={q} onChangeText={setQ} placeholder="Search documents" placeholderTextColor="#8594A6" style={st.search} />
        <View style={{ marginTop: 8 }}>
          <Dropdown width="100%" value={Math.max(types.indexOf(typeF), 0)} onChange={(i) => setTypeF(types[i] ?? 'All types')}
            options={types.map((t, i) => ({ value: i, label: t }))} />
        </View>
      </Card>
      {!rows ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : shown.length === 0 ? (
        <Card><Empty icon="document-outline" text="No documents from C V Patil yet." /></Card>
      ) : shown.map((d) => {
        const isNew = !(d.views ?? []).length;
        return (
          <Card key={d.id}>
            <Row style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={st.title}>{d.title}</Text>
                <Text style={st.sub}>{d.type?.name ?? ''} - {fmtISODate(d.created_at.slice(0, 10))} - From {d.sender_label || SENDER}</Text>
                {d.description ? <Text style={st.desc}>{d.description}</Text> : null}
              </View>
              <View style={{ gap: 4, alignItems: 'flex-end' }}>
                {isNew ? <Pill text="NEW" tone="green" /> : null}
                {d.audience_kind === 'employee' ? <Pill text="Private" tone="purple" /> : null}
              </View>
            </Row>
            <Row style={{ marginTop: 8, flexWrap: 'wrap' }}>
              <Button title="Open" icon="eye-outline" small onPress={() => open(d)} />
              {d.allow_download ? <Button title="Download" icon="download-outline" variant="secondary" small onPress={() => open(d, true)} /> : <Text style={st.sub}>View only</Text>}
            </Row>
          </Card>
        );
      })}
    </View>
  );
}

// ============================================================ Admin / HR: share a document
type Kind = 'all' | 'site' | 'department' | 'employee';
const KIND_LABEL: Record<Kind, string> = { all: 'All employees', site: 'Project team (sites)', department: 'Department', employee: 'Selected employees' };

/** Search + pick several items; the picked ones are shown as chips with a remove (x) */
function MultiPick({ items, picked, onChange, placeholder }: { items: { id: string; label: string; sub?: string }[]; picked: string[]; onChange: (v: string[]) => void; placeholder: string }) {
  const [q, setQ] = useState('');
  const results = useMemo(() => {
    const k = q.trim().toLowerCase();
    return items.filter((i) => !picked.includes(i.id) && (!k || `${i.label} ${i.sub ?? ''}`.toLowerCase().includes(k))).slice(0, 8);
  }, [items, picked, q]);
  return (
    <View>
      <View style={st.chips}>
        {picked.map((id) => (
          <Pressable key={id} onPress={() => onChange(picked.filter((x) => x !== id))} style={st.chip} accessibilityRole="button">
            <Text style={st.chipText}>{items.find((i) => i.id === id)?.label ?? id}</Text>
            <Ionicons name="close" size={14} color={C.blue} />
          </Pressable>
        ))}
      </View>
      <TextInput value={q} onChangeText={setQ} placeholder={placeholder} placeholderTextColor="#8594A6" style={st.search} />
      {results.map((i) => (
        <Pressable key={i.id} onPress={() => { onChange([...picked, i.id]); setQ(''); }} style={st.pick} accessibilityRole="button">
          <Ionicons name="add-circle-outline" size={18} color={C.blue} />
          <View style={{ flex: 1 }}><Text style={st.pickText}>{i.label}</Text>{i.sub ? <Text style={st.sub}>{i.sub}</Text> : null}</View>
        </Pressable>
      ))}
    </View>
  );
}

export function ShareDocumentPanel({ onShared }: { onShared: () => void }) {
  const [types, setTypes] = useState<DocumentType[]>([]);
  const [typeId, setTypeId] = useState(0);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [file, setFile] = useState<{ bytes: ArrayBuffer; name: string; mime: string } | null>(null);
  const [kind, setKind] = useState<Kind>('all');
  const [vals, setVals] = useState<string[]>([]);
  const [allowDl, setAllowDl] = useState(true);
  const [until, setUntil] = useState('');
  const [team, setTeam] = useState<Profile[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [count, setCount] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.documentTypes('from_cvp').then((t) => { setTypes(t); }).catch(() => {});
    api.team().then((t) => setTeam(t.filter((p) => shownRole(p) === 'Employee' && p.active))).catch(() => {});
    api.sites(true).then((s) => setSites(s.filter((x) => !x.is_office))).catch(() => {});
  }, []);

  const type = types.find((t) => t.id === typeId);
  // the type decides the default; a LOCKED type never offers "All employees"
  const kinds: Kind[] = (type && !type.can_all ? ['site', 'department', 'employee'] : ['all', 'site', 'department', 'employee']);
  const chooseType = (id: number) => {
    setTypeId(id);
    const t = types.find((x) => x.id === id);
    if (t) { const d = (['all', 'site', 'department', 'employee'] as string[]).includes(t.default_visibility) ? (t.default_visibility as Kind) : 'employee'; setKind(d === 'all' && !t.can_all ? 'employee' : d); setVals([]); }
  };

  const departments = useMemo(() => [...new Set(team.map((p) => (p.department ?? '').trim()).filter(Boolean))].sort(), [team]);
  const items = kind === 'site' ? sites.map((s) => ({ id: String(s.id), label: s.name }))
    : kind === 'department' ? departments.map((d) => ({ id: d, label: d }))
    : team.map((p) => ({ id: p.id, label: p.full_name, sub: p.username }));

  // "Will be visible to N employees" (counted by the server)
  useEffect(() => {
    if (kind !== 'all' && vals.length === 0) { setCount(0); return; }
    let alive = true;
    const t = setTimeout(() => { api.previewAudience({ kind, values: vals }).then((n) => { if (alive) setCount(n); }).catch(() => { if (alive) setCount(null); }); }, 400);
    return () => { alive = false; clearTimeout(t); };
  }, [kind, vals]);

  const choose = async () => {
    const f = await pickFile(false);
    if (!f) return;
    const ext = (f.name.split('.').pop() ?? '').toLowerCase();
    if (!ALLOWED[ext]) return Alert.alert('File type not allowed', 'Use PDF, JPG, PNG, DOCX or XLSX.');
    if (f.bytes.byteLength > 10 * 1024 * 1024) return Alert.alert('File too large', 'The file must be 10 MB or smaller.');
    if (!realType(f.bytes, ext)) return Alert.alert('File does not match its type', 'The file content is not a real .' + ext + ' file.');
    setFile({ bytes: f.bytes, name: f.name, mime: ALLOWED[ext] });
  };

  const publish = async () => {
    if (!typeId) return Alert.alert('Choose the document type.');
    if (!title.trim()) return Alert.alert('Enter the document title.');
    if (!file) return Alert.alert('Choose the file.');
    if (kind !== 'all' && vals.length === 0) return Alert.alert('Choose who can see this document.');
    setBusy(true);
    let path: string | null = null;
    try {
      path = await api.uploadSharedFile(file.bytes, file.name, file.mime);
      const r = await api.shareDocument({ typeId, title: title.trim(), description: desc.trim() || undefined, path, fileName: file.name,
        audience: { kind, values: vals }, allowDownload: allowDl, visibleUntil: until || null });
      setTitle(''); setDesc(''); setFile(null); setVals([]); setUntil('');
      Alert.alert('Published', `Visible to ${r.visible_to} employee(s) now.`);
      onShared();
    } catch (e) {
      if (path) api.removeSharedFile(path).catch(() => {});
      Alert.alert('Could not share', errorText(e));
    } finally { setBusy(false); }
  };

  return (
    <Card>
      <Banner tone="blue" icon="business-outline" text={`Sent as ${SENDER}. It is visible at once to the people you choose; there is no approval step.`} />
      <Text style={st.lbl}>Document type *</Text>
      <Dropdown width="100%" value={typeId || -1} onChange={(v) => chooseType(v > 0 ? v : 0)}
        options={[{ value: -1, label: 'Select type' }, ...types.map((t) => ({ value: t.id, label: t.name + (t.can_all ? '' : ' (private)') }))]} />
      <Field label="Title *" value={title} onChangeText={setTitle} />
      <Field label="Description (optional)" value={desc} onChangeText={setDesc} multiline />
      <Button title={file ? `File: ${file.name}` : 'Choose file (PDF, JPG, PNG, DOCX, XLSX - max 10 MB)'} icon="attach-outline" variant="secondary" onPress={choose} style={{ marginVertical: 8 }} />

      <Text style={st.lbl}>Who can see this document?</Text>
      <Chips<string> options={kinds.map((k) => KIND_LABEL[k])} value={KIND_LABEL[kind]}
        onChange={(l) => { const k = kinds.find((x) => KIND_LABEL[x] === l); if (k) { setKind(k); setVals([]); } }} />
      {kind === 'all' ? null : (
        <MultiPick items={items} picked={vals} onChange={setVals}
          placeholder={kind === 'site' ? 'Search project / site' : kind === 'department' ? 'Search department' : 'Search name or employee code'} />
      )}
      <Text style={st.count}>{count == null ? 'Counting...' : `Will be visible to ${count} employee(s)`}</Text>

      <Toggle label="Allow download" note="OFF = view only" value={allowDl} onChange={setAllowDl} />
      {until ? <Button title="Clear date" variant="ghost" small onPress={() => setUntil('')} style={{ alignSelf: 'flex-start' }} /> : null}
      <Button title="Publish" icon="send" loading={busy} onPress={publish} style={{ marginTop: 10 }} />
    </Card>
  );
}

// ============================================================ Admin / HR: shared documents and the view log
export function SharedLogPanel({ refreshKey, myId }: { refreshKey: number; myId: string }) {
  const [rows, setRows] = useState<SharedDocument[] | null>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [stats, setStats] = useState<Record<number, { audience: number; viewed: number; not_viewed: string[] } | null>>({});
  const load = useCallback(async () => {
    try { setRows(await api.sharedDocuments(myId)); } catch (e) { Alert.alert('Could not load', errorText(e)); setRows([]); }
  }, [myId]);
  useEffect(() => { load(); }, [load, refreshKey]);

  const toggle = (d: SharedDocument) => {
    if (open === d.id) { setOpen(null); return; }
    setOpen(d.id);
    api.sharedDocumentStats(d.id).then((s) => setStats((m) => ({ ...m, [d.id]: s }))).catch(() => setStats((m) => ({ ...m, [d.id]: null })));
  };
  const remove = (d: SharedDocument) => Alert.alert('Delete this shared document?', 'It disappears for everyone. The file is deleted.', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Delete', style: 'destructive', onPress: async () => { try { await api.deleteSharedDocument(d.id); await load(); } catch (e) { Alert.alert('Could not delete', errorText(e)); } } },
  ]);

  if (!rows) return <ActivityIndicator style={{ margin: 20 }} color={C.blue} />;
  if (rows.length === 0) return <Card><Empty icon="share-social-outline" text="Nothing has been shared yet." /></Card>;
  return (
    <View>
      {rows.map((d) => {
        const s = stats[d.id];
        return (
          <Card key={d.id}>
            <Pressable onPress={() => toggle(d)}>
              <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={st.title}>{d.title}</Text>
                  <Text style={st.sub}>{d.type?.name} - {fmtISODate(d.created_at.slice(0, 10))} - {KIND_LABEL[d.audience_kind as Kind] ?? d.audience_kind}
                    {d.uploader?.full_name ? ` - by ${d.uploader.full_name}` : ''}{d.visible_until ? ` - until ${fmtISODate(d.visible_until)}` : ''}</Text>
                </View>
                <Ionicons name={open === d.id ? 'chevron-up' : 'chevron-down'} size={18} color={C.muted} />
              </Row>
            </Pressable>
            {open === d.id ? (
              <View style={st.stats}>
                {s === undefined ? <ActivityIndicator color={C.blue} /> : s === null ? <Text style={st.sub}>Could not load the view log.</Text> : (
                  <>
                    <Text style={st.title}>Viewed {s.viewed} / {s.audience}</Text>
                    {s.not_viewed.length ? <Text style={st.sub}>Not opened yet ({s.not_viewed.length}): {s.not_viewed.join(', ')}</Text> : <Text style={st.sub}>Everyone has opened it.</Text>}
                  </>
                )}
                <Row style={{ marginTop: 8 }}>
                  <Button title="Delete" icon="trash-outline" variant="danger" small onPress={() => remove(d)} />
                </Row>
              </View>
            ) : null}
          </Card>
        );
      })}
    </View>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 14.5, fontWeight: '800', color: '#102A45' },
  sub: { fontSize: 12.5, color: C.muted, marginTop: 2, lineHeight: 18 },
  desc: { fontSize: 13, color: '#203951', marginTop: 4, lineHeight: 18 },
  lbl: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginTop: 10, marginBottom: 6 },
  count: { fontSize: 13, fontWeight: '800', color: '#0F5F3A', marginVertical: 8 },
  search: { borderWidth: 1, borderColor: '#DCE7F3', borderRadius: 12, paddingVertical: 10, paddingHorizontal: 12, fontSize: 14, color: '#102A45', backgroundColor: '#F8FBFF' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginVertical: 8 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#E5F0FF', borderRadius: 16, paddingVertical: 5, paddingHorizontal: 10 },
  chipText: { fontSize: 12.5, fontWeight: '700', color: C.blue },
  pick: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  pickText: { fontSize: 14, color: '#102A45', fontWeight: '600' },
  stats: { marginTop: 10, padding: 10, borderRadius: 12, backgroundColor: '#F6F9FD', borderWidth: 1, borderColor: '#E3EBF4' },
});
