import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Image, Linking, Platform, StyleSheet, Text, View } from 'react-native';
import {
  api, DETAIL_FILE_KINDS, DetailFileKind, EducationRow, EmployeeDetailFile, EmployeeDetails, FamilyRow,
} from '../lib/api';
import { downloadEmployeeFormPdf } from '../lib/employeeFormPdf';
import { pickFile } from '../lib/pickFile';
import { downloadOrOpen } from '../lib/saveDownload';
import { useRealtime } from '../lib/realtime';
import { errorText } from '../lib/supabase';
import { fmtISODate } from '../lib/time';
import { C } from '../theme';
import { Banner, Button, Card, Chips, Col, Dropdown, Field, Pill, Row, SectionTitle, Toggle } from './ui';

const DEGREES = ['Post Graduation', 'Graduation', 'HSC / Diploma'];
const GENDERS = ['Male', 'Female', 'Other'];
const MARITAL = ['Single', 'Married', 'Other'];
const FAMILY_ROWS = 4;

// Input filters: each field accepts only the characters that make sense for it
const only = {
  name: (v: string) => v.replace(/[^A-Za-z .'-]/g, '').slice(0, 40),            // letters
  text: (v: string) => v.replace(/[^A-Za-z0-9 &.,/()'-]/g, '').slice(0, 60),    // letters + numbers
  address: (v: string) => v.replace(/[^A-Za-z0-9 ,.\/#()'\n-]/g, '').slice(0, 200),
  mobile: (v: string) => v.replace(/\D/g, '').slice(0, 10),                     // 10 digits
  landline: (v: string) => v.replace(/\D/g, '').slice(0, 12),                   // digits only
  email: (v: string) => v.replace(/[^A-Za-z0-9@._+-]/g, '').toLowerCase().slice(0, 80),
  pan: (v: string) => v.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 10),
  aadhar: (v: string) => v.replace(/\D/g, '').slice(0, 12),                     // 12 digits
  account: (v: string) => v.replace(/\D/g, '').slice(0, 18),
  ifsc: (v: string) => v.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 11),
  vehicleNo: (v: string) => v.replace(/[^A-Za-z0-9 -]/g, '').toUpperCase().slice(0, 13),
  licenseNo: (v: string) => v.replace(/[^A-Za-z0-9 -]/g, '').toUpperCase().slice(0, 20),
  marks: (v: string) => v.replace(/[^A-Za-z0-9.%+ ]/g, '').slice(0, 8),
  year: (v: string) => v.replace(/\D/g, '').slice(0, 4),
};

// An address is typed step by step (house, street, area, city, state, PIN) and saved as one text of 6 lines
const ADDRESS_PARTS = [
  { key: 0, label: 'House / Flat no.', hint: 'e.g. Flat 12, Shree Apartments' },
  { key: 1, label: 'Street / Road', hint: 'e.g. Baner Road' },
  { key: 2, label: 'Area / Locality', hint: 'e.g. Baner' },
  { key: 3, label: 'City', hint: 'e.g. Pune' },
  { key: 4, label: 'State', hint: 'e.g. Maharashtra' },
  { key: 5, label: 'PIN code', hint: '6 digits' },
] as const;
const splitAddress = (v: string): string[] => {
  const p = (v ?? '').split('\n');
  if (p.length === 6) return p;
  const old = (v ?? '').trim();               // an address saved before as free text goes into the first box
  return [old, '', '', '', '', ''];
};

function AddressFields({ title, value, onChange, copyFrom }: { title: string; value: string; onChange: (v: string) => void; copyFrom?: string }) {
  const parts = splitAddress(value);
  const set = (i: number, v: string) => {
    const next = splitAddress(value).map((x, k) => (k === i ? (i === 5 ? v.replace(/\D/g, '').slice(0, 6) : only.address(v).replace(/\n/g, ' ').slice(0, 60)) : x));
    onChange(next.every((x) => !x.trim()) ? '' : next.join('\n'));
  };
  return (
    <View style={{ marginBottom: 6 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
        <Text style={st.label}>{title}</Text>
        {copyFrom !== undefined && copyFrom.trim() ? <Button title="Same as permanent" variant="secondary" small onPress={() => onChange(copyFrom)} /> : null}
      </View>
      <View style={st.line}>
        {ADDRESS_PARTS.map((a) => (
          <View key={a.key} style={st.cell}>
            <Field label={`${a.label}${a.key === 0 || a.key >= 3 ? ' *' : ''}`} value={parts[a.key]} placeholder={a.hint}
              keyboardType={a.key === 5 ? 'number-pad' : 'default'} maxLength={a.key === 5 ? 6 : 60} onChangeText={(v) => set(a.key, v)} />
          </View>
        ))}
      </View>
    </View>
  );
}

const emptyEdu =(): EducationRow[] => DEGREES.map((degree) => ({ degree, specialization: '', year: '', marks: '' }));
const emptyFamily = (): FamilyRow[] => Array.from({ length: FAMILY_ROWS }, () => ({ name: '', relation: '', contact: '' }));

interface Form {
  surname: string; first_name: string; father_name: string; mother_name: string;
  date_of_birth: string; gender: string; marital_status: string;
  permanent_address: string; local_address: string; tel_no: string; cell_no: string; email: string;
  pan_no: string; aadhar_no: string; uan_no: string; software_skills: string;
  vehicle_company: string; vehicle_no: string; license_no: string;
  bank_name: string; bank_address: string; bank_branch: string; bank_account_no: string; ifsc_code: string;
  joining_date: string; resign_date: string; declared: boolean;
  education: EducationRow[]; family: FamilyRow[];
}

const blank = (): Form => ({
  surname: '', first_name: '', father_name: '', mother_name: '', date_of_birth: '', gender: '', marital_status: '',
  permanent_address: '', local_address: '', tel_no: '', cell_no: '', email: '', pan_no: '', aadhar_no: '', uan_no: '', software_skills: '',
  vehicle_company: '', vehicle_no: '', license_no: '',
  bank_name: '', bank_address: '', bank_branch: '', bank_account_no: '', ifsc_code: '',
  joining_date: '', resign_date: '', declared: false, education: emptyEdu(), family: emptyFamily(),
});

const fromRow = (r: EmployeeDetails | null, fallback: { name: string; phone: string; joining: string }): Form => {
  const f = blank();
  if (!r) {
    const parts = fallback.name.trim().split(/\s+/);
    return { ...f, first_name: parts[0] ?? '', surname: parts.length > 1 ? parts[parts.length - 1] : '', cell_no: fallback.phone, joining_date: fallback.joining };
  }
  const s = (v: string | null) => v ?? '';
  const edu = emptyEdu().map((e, i) => ({ ...e, ...(r.education?.[i] ?? {}), degree: e.degree }));
  const fam = emptyFamily().map((e, i) => ({ ...e, ...(r.family?.[i] ?? {}) }));
  return {
    surname: s(r.surname), first_name: s(r.first_name), father_name: s(r.father_name), mother_name: s(r.mother_name),
    date_of_birth: s(r.date_of_birth), gender: s(r.gender), marital_status: s(r.marital_status),
    permanent_address: s(r.permanent_address), local_address: s(r.local_address), tel_no: s(r.tel_no), cell_no: s(r.cell_no),
    email: s(r.email), pan_no: s(r.pan_no), aadhar_no: s(r.aadhar_no), uan_no: s(r.uan_no), software_skills: s(r.software_skills),
    vehicle_company: s(r.vehicle_company), vehicle_no: s(r.vehicle_no), license_no: s(r.license_no),
    bank_name: s(r.bank_name), bank_address: s(r.bank_address), bank_branch: s(r.bank_branch),
    bank_account_no: s(r.bank_account_no), ifsc_code: s(r.ifsc_code), joining_date: s(r.joining_date), resign_date: s(r.resign_date),
    declared: r.declared, education: edu, family: fam,
  };
};

/**
 * The company "Employee Form": personal details, education, family, vehicle, bank, and the documents
 * (photo, Aadhar, PAN, bank passbook, graduation, CV).
 *  admin = false : the employee fills his own form.
 *  admin = true  : Admin / HR fill or correct it for that employee and can view / download the files.
 */
export default function EmployeeDetailsForm({ userId, admin, fallback }: {
  userId: string; admin: boolean; fallback: { name: string; phone: string; joining: string; department?: string; designation?: string; role?: string; siteEmployee?: boolean };
}) {
  const [form, setForm] = useState<Form | null>(null);
  const [saved, setSaved] = useState<EmployeeDetails | null>(null);
  const [files, setFiles] = useState<EmployeeDetailFile[]>([]);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<DetailFileKind | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [siteEmp, setSiteEmp] = useState(!!fallback.siteEmployee);
  useEffect(() => { setSiteEmp(!!fallback.siteEmployee); }, [fallback.siteEmployee]);

  // Admin / HR choose Office or Site employee; it is saved straight away
  const changeOfficeType = async (v: 'Office employee' | 'Site employee') => {
    const site = v === 'Site employee';
    const before = siteEmp;
    setSiteEmp(site);
    try { await api.updateProfile(userId, { site_employee: site }); }
    catch (e) { setSiteEmp(before); Alert.alert('Could not change the office type', errorText(e)); }
  };

  const loadFiles = useCallback(async () => {
    try {
      const list = await api.employeeDetailFiles(userId);
      setFiles(list);
      const photo = list.find((f) => f.kind === 'photo');
      setPhotoUrl(photo ? await api.detailFileUrl(photo.file_path).catch(() => null) : null);
    } catch (e) { Alert.alert('Could not load documents', errorText(e)); }
  }, [userId]);

  const loadForm = useCallback(async () => {
    try {
      const row = await api.employeeDetails(userId);
      setSaved(row);
      setForm(fromRow(row, fallback));
    } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [userId, fallback.name, fallback.phone, fallback.joining]);

  useEffect(() => { setForm(null); loadForm(); loadFiles(); }, [loadForm, loadFiles]);
  useRealtime(`detail-files-${userId}`, [{ table: 'employee_detail_files', filter: `user_id=eq.${userId}` }], () => loadFiles());

  if (!form) return <ActivityIndicator style={{ margin: 20 }} color={C.blue} />;
  const set = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => (f ? { ...f, [k]: v } : f));
  const setEdu = (i: number, k: keyof EducationRow, v: string) =>
    setForm((f) => f && { ...f, education: f.education.map((r, j) => (j === i ? { ...r, [k]: v } : r)) });
  const setFam = (i: number, k: keyof FamilyRow, v: string) =>
    setForm((f) => f && { ...f, family: f.family.map((r, j) => (j === i ? { ...r, [k]: v } : r)) });

  const fileOf = (k: DetailFileKind) => files.find((f) => f.kind === k);
  const missing = DETAIL_FILE_KINDS.filter((d) => d.required && !fileOf(d.kind)).map((d) => d.label);

  const save = async () => {
    setSaving(true);
    try {
      // education rows keep their position (Post Graduation, Graduation, HSC / Diploma)
      const row = await api.saveEmployeeDetails(admin ? userId : null, form);
      setSaved(row);
      Alert.alert('Saved', missing.length ? `Details saved. Still to upload: ${missing.join(', ')}.` : 'Employee details saved.');
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setSaving(false); }
  };

  const choose = async (kind: DetailFileKind, camera: boolean) => {
    try {
      const f = await pickFile(camera);
      if (!f) return;
      setUploading(kind);
      await api.uploadDetailFile(userId, admin, kind, f.bytes, f.name, f.mime);
      await loadFiles();
    } catch (e) { Alert.alert('Could not upload', errorText(e)); }
    finally { setUploading(null); }
  };
  const open = async (d: EmployeeDetailFile, save = false) => {
    try { await downloadOrOpen(await api.detailFileUrl(d.file_path, save ? (d.file_name || d.kind) : undefined), d.file_name || d.kind, save); }
    catch (e) { Alert.alert('File unavailable', errorText(e)); }
  };
  const remove = (kind: DetailFileKind, label: string) =>
    Alert.alert(`Remove ${label}?`, '', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: async () => {
        try { await api.deleteDetailFile(userId, admin, kind); await loadFiles(); } catch (e) { Alert.alert('Could not remove', errorText(e)); }
      } },
    ]);

  const downloadForm = async () => {
    setPdfBusy(true);
    try {
      const who = `${form.first_name} ${form.surname}`.trim() || fallback.name || 'Employee';
      await downloadEmployeeFormPdf(form, {
        photoUrl, uploaded: files.map((x) => x.kind),
        fileName: `${who.replace(/[^A-Za-z0-9]+/g, '_')}_Employee_Form.pdf`,
      });
    } catch (e) { Alert.alert('Could not create the PDF', errorText(e)); }
    finally { setPdfBusy(false); }
  };

  const web = Platform.OS === 'web';
  const ro = { editable: false, style: { backgroundColor: '#F1F4F8', color: C.muted } };
  return (
    <View>
      {saved ? <Banner tone="green" icon="checkmark-circle" text={`Form saved on ${fmtISODate(saved.updated_at.slice(0, 10))}. You can edit it any time.`} />
        : <Banner tone="amber" icon="alert-circle-outline" text="This form is not filled yet. Fields marked * are compulsory." />}

      <SectionTitle title="Personal details" />
      <Card>
        <View style={st.line}>
          <View style={st.cell}><Field label="Surname" value={form.surname} onChangeText={(v) => set('surname', only.name(v))} /></View>
          <View style={st.cell}><Field label="First name" value={form.first_name} onChangeText={(v) => set('first_name', only.name(v))} /></View>
          <View style={st.cell}><Field label="Father name" value={form.father_name} onChangeText={(v) => set('father_name', only.name(v))} /></View>
          <View style={st.cell}><Field label="Mother name" value={form.mother_name} onChangeText={(v) => set('mother_name', only.name(v))} /></View>
        </View>
        <View style={st.line}>
          <View style={st.cell}>
            <Field label="Date of birth (YYYY-MM-DD)" value={form.date_of_birth} placeholder="e.g. 1995-06-15" keyboardType="numbers-and-punctuation"
              onChangeText={(v) => set('date_of_birth', v.replace(/[^0-9-]/g, '').slice(0, 10))} />
          </View>
          <View style={st.cell}>
            <Text style={st.label}>Gender</Text>
            <Chips<string> options={GENDERS} value={form.gender} onChange={(v) => set('gender', v)} />
          </View>
          <View style={st.cell}>
            <Text style={st.label}>Marital status</Text>
            <Chips<string> options={MARITAL} value={form.marital_status} onChange={(v) => set('marital_status', v)} />
          </View>
        </View>
      </Card>

      <SectionTitle title="Address and contact" />
      <Card>
        <AddressFields title="Permanent address *" value={form.permanent_address} onChange={(v) => set('permanent_address', v)} />
        <AddressFields title="Local address *" value={form.local_address} onChange={(v) => set('local_address', v)}
          copyFrom={form.permanent_address} />
        <View style={{ height: 6 }} />
        <View style={st.line}>
          <View style={st.cell}><Field label="Cell no. *" value={form.cell_no} keyboardType="number-pad" maxLength={10} placeholder="10 digits" onChangeText={(v) => set('cell_no', only.mobile(v))} /></View>
          <View style={st.cell}><Field label="Tel. phone no." value={form.tel_no} keyboardType="number-pad" maxLength={12} onChangeText={(v) => set('tel_no', only.landline(v))} /></View>
          <View style={st.cell}><Field label="E-mail address" value={form.email} keyboardType="email-address" autoCapitalize="none" onChangeText={(v) => set('email', only.email(v))} /></View>
        </View>
      </Card>

      <SectionTitle title="Identity" />
      <Card>
        <View style={st.line}>
          <View style={st.cell}>
            <Field label="PAN card no." value={form.pan_no} autoCapitalize="characters" maxLength={10} placeholder="ABCDE1234F"
              onChangeText={(v) => set('pan_no', only.pan(v))} />
          </View>
          <View style={st.cell}>
            <Field label="Aadhar card no." value={form.aadhar_no} keyboardType="number-pad" maxLength={12} placeholder="12 digits"
              onChangeText={(v) => set('aadhar_no', only.aadhar(v))} />
          </View>
        </View>
      </Card>

      <SectionTitle title="Educational qualification" />
      <Card>
        {form.education.map((r, i) => (
          <View key={r.degree} style={st.line}>
            <View style={st.cell}>
              <Text style={st.label}>Degree</Text>
              <Text style={st.degree}>{r.degree}</Text>
            </View>
            <View style={st.cellWide}><Field label="Specialization" value={r.specialization} onChangeText={(v) => setEdu(i, 'specialization', only.text(v))} /></View>
            <View style={st.cell}><Field label="Year of passing" value={r.year} keyboardType="number-pad" maxLength={4} onChangeText={(v) => setEdu(i, 'year', only.year(v))} /></View>
            <View style={st.cell}><Field label="% marks / grade" value={r.marks} maxLength={8} onChangeText={(v) => setEdu(i, 'marks', only.marks(v))} /></View>
          </View>
        ))}
        <Field label="Software skills" value={form.software_skills} multiline onChangeText={(v) => set('software_skills', v)} placeholder="e.g. MS Office, AutoCAD, Tally" />
      </Card>

      <SectionTitle title="Family details" />
      <Card>
        {form.family.map((r, i) => (
          <View key={i} style={st.line}>
            <View style={st.cellWide}><Field label={`Member ${i + 1} - Name`} value={r.name} onChangeText={(v) => setFam(i, 'name', only.name(v))} /></View>
            <View style={st.cell}><Field label="Relation with you" value={r.relation} onChangeText={(v) => setFam(i, 'relation', only.name(v))} /></View>
            <View style={st.cell}><Field label="Contact number" value={r.contact} keyboardType="number-pad" maxLength={10} onChangeText={(v) => setFam(i, 'contact', only.mobile(v))} /></View>
          </View>
        ))}
      </Card>

      <SectionTitle title="Vehicle details" />
      <Card>
        <View style={st.line}>
          <View style={st.cell}><Field label="Vehicle company name" value={form.vehicle_company} onChangeText={(v) => set('vehicle_company', only.text(v))} /></View>
          <View style={st.cell}><Field label="Vehicle no." value={form.vehicle_no} autoCapitalize="characters" onChangeText={(v) => set('vehicle_no', only.vehicleNo(v))} /></View>
          <View style={st.cell}><Field label="License no." value={form.license_no} autoCapitalize="characters" onChangeText={(v) => set('license_no', only.licenseNo(v))} /></View>
        </View>
      </Card>

      <SectionTitle title="Bank details *" />
      <Card>
        <View style={st.line}>
          <View style={[st.cell, { flexBasis: 150, minWidth: 130 }]}><Field label="Bank name *" value={form.bank_name} onChangeText={(v) => set('bank_name', only.text(v))} /></View>
          <View style={[st.cell, { flexBasis: 150, minWidth: 130 }]}><Field label="Branch name *" value={form.bank_branch} onChangeText={(v) => set('bank_branch', only.text(v))} /></View>
          <View style={[st.cellWide, { flexGrow: 2, flexBasis: 220, minWidth: 180 }]}><Field label="Address of bank *" value={form.bank_address} onChangeText={(v) => set('bank_address', only.address(v))} /></View>
          <View style={[st.cell, { flexBasis: 150, minWidth: 130 }]}><Field label="Account no. *" value={form.bank_account_no} keyboardType="number-pad" maxLength={18} onChangeText={(v) => set('bank_account_no', only.account(v))} /></View>
          <View style={[st.cell, { flexBasis: 140, minWidth: 120 }]}>
            <Field label="IFSC code *" value={form.ifsc_code} autoCapitalize="characters" maxLength={11} placeholder="SBIN0001234"
              onChangeText={(v) => set('ifsc_code', only.ifsc(v))} />
          </View>
        </View>
      </Card>

      <SectionTitle title="Joining" />
      <Card>
        <View style={st.line}>
          <View style={st.cell}><Field label="Department" value={fallback.department ?? ''} placeholder="Set by Admin / HR" {...ro} /></View>
          <View style={st.cell}><Field label="Designation" value={fallback.designation ?? ''} placeholder="Set by Admin / HR" {...ro} /></View>
          <View style={st.cell}><Field label="Role" value={fallback.role ?? ''} {...ro} /></View>
          <View style={st.cell}>
            {admin ? (
              <Dropdown<'Office employee' | 'Site employee'> label="Office type" options={['Office employee', 'Site employee']}
                value={siteEmp ? 'Site employee' : 'Office employee'} onChange={changeOfficeType} />
            ) : (
              <Field label="Office type" value={siteEmp ? 'Site employee' : 'Office employee'} {...ro} />
            )}
          </View>
        </View>
        <View style={st.line}>
          <View style={st.cell}>
            <Field label="Joining date * (YYYY-MM-DD)" value={form.joining_date} placeholder="e.g. 2026-04-01" keyboardType="numbers-and-punctuation"
              onChangeText={(v) => set('joining_date', v.replace(/[^0-9-]/g, '').slice(0, 10))} />
          </View>
          <View style={st.cell}>
            <Field label="Resign date (YYYY-MM-DD) - only when leaving" value={form.resign_date} placeholder="e.g. 2027-03-31" keyboardType="numbers-and-punctuation"
              onChangeText={(v) => set('resign_date', v.replace(/[^0-9-]/g, '').slice(0, 10))} />
          </View>
          <View style={st.cell}>
            <Field label="UAN no. (PF)" value={form.uan_no} keyboardType="number-pad" maxLength={12} placeholder="12 digits"
              onChangeText={(v) => set('uan_no', v.replace(/\D/g, ''))} />
          </View>
        </View>
        <Toggle label="Declaration" note="I hereby declare the information furnished by me is correct. I bear the responsibility for all the above information."
          value={form.declared} onChange={(v) => set('declared', v)} />
      </Card>

      <SectionTitle title="Photo and documents" note="PAN, Aadhar, bank passbook and photo are compulsory" />
      <Card>
        <View style={st.grid}>
          {DETAIL_FILE_KINDS.map((d) => {
            const f = fileOf(d.kind);
            return (
              <View key={d.kind} style={st.tile}>
                <Text style={st.docTitle}>{d.label}{d.required ? ' *' : ''}</Text>
                <View style={{ alignSelf: 'flex-start', marginTop: 4 }}>
                  <Pill text={f ? 'Uploaded' : d.required ? 'Required' : 'Optional'} tone={f ? 'green' : d.required ? 'red' : 'muted'} />
                </View>
                <Text style={st.hint} numberOfLines={1}>{f ? (f.file_name || d.hint) : d.hint}</Text>
                {d.kind === 'photo' ? (
                  <View style={st.photoBox}>
                    {photoUrl ? <Image source={{ uri: photoUrl }} style={st.photo} resizeMode="cover" />
                      : <Text style={st.photoHint}>3.5 x 4.5 cm</Text>}
                  </View>
                ) : null}
                <Row style={{ flexWrap: 'wrap', marginTop: 8 }} gap={6}>
                  <Button title={f ? 'Replace' : web ? 'Choose file' : 'Gallery'} icon="cloud-upload-outline" variant="secondary" small
                    loading={uploading === d.kind} onPress={() => choose(d.kind, false)} />
                  {!web ? <Button title="Camera" icon="camera-outline" variant="secondary" small disabled={!!uploading} onPress={() => choose(d.kind, true)} /> : null}
                  {f ? <Button title="View" icon="eye-outline" variant="secondary" small onPress={() => open(f)} /> : null}
                  {f ? <Button title="Download" icon="download-outline" variant="secondary" small onPress={() => open(f, true)} /> : null}
                  {f ? <Button title="Remove" icon="trash-outline" variant="danger" small onPress={() => remove(d.kind, d.label)} /> : null}
                </Row>
              </View>
            );
          })}
        </View>
        <Text style={st.hint}>{web ? 'PDF, image or Word file, up to 10 MB.' : 'Take a photo or choose one from the gallery (up to 10 MB). Name each file clearly.'}</Text>
      </Card>

      <Row style={{ marginTop: 6, marginBottom: 20, flexWrap: 'wrap' }}>
        <Button title="Save Employee Details" icon="save-outline" loading={saving} onPress={save} style={{ flex: 1, minWidth: 200 }} />
        <Button title="Download Form (PDF)" icon="download-outline" variant="secondary" loading={pdfBusy} onPress={downloadForm} style={{ flex: 1, minWidth: 200 }} />
      </Row>
    </View>
  );
}

const st = StyleSheet.create({
  line: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, alignItems: 'flex-start' },
  cell: { flexGrow: 1, flexBasis: 200, minWidth: 150 },
  degree: { fontWeight: '800', color: '#102A45', fontSize: 14, height: 44, textAlignVertical: 'center', lineHeight: 44 },
  cellWide: { flexGrow: 1, flexBasis: 300, minWidth: 220 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 6 },
  tile: {
    flexGrow: 1, flexBasis: 150, minWidth: 140, borderWidth: 1, borderColor: '#E3EBF4', borderRadius: 12,
    padding: 12, backgroundColor: '#FBFDFF',
  },
  photoBox: {
    width: 105, height: 135, borderWidth: 1, borderColor: '#B9C7D8', borderRadius: 6, backgroundColor: '#F4F8FC',
    alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginTop: 8,
  },
  photo: { width: '100%', height: '100%' },
  photoHint: { color: C.muted, fontSize: 11, textAlign: 'center', padding: 6 },
  docRow: { paddingBottom: 10, marginBottom: 10, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  docTitle: { fontWeight: '800', color: '#102A45', fontSize: 14, flexShrink: 1 },
  hint: { color: C.muted, fontSize: 12, marginTop: 3 },
  label: { fontSize: 12, fontWeight: '700', color: '#3A5068', marginBottom: 8 },
  block: { marginBottom: 6 },
});
