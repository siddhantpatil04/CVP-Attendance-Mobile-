import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Image, Linking, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import {
  api, DETAIL_FILE_KINDS, DetailFileKind, EducationRow, EmployeeDetailFile, EmployeeDetails, FamilyRow,
} from '../lib/api';
import { downloadEmployeeFormPdf } from '../lib/employeeFormPdf';
import { pickFile } from '../lib/pickFile';
import { downloadOrOpen } from '../lib/saveDownload';
import { useRealtime } from '../lib/realtime';
import { companiesApi, firstOfMonthISO, useCompanies } from '../lib/companies';
import { errorText, supabase } from '../lib/supabase';
import { fmtISODate } from '../lib/time';
import { C } from '../theme';
import { PickerField } from './Pickers';
import { Banner, Button, Card, Chips, Col, Dropdown, Field, Pill, Row, SectionTitle, Toggle } from './ui';

const DEGREES = ['Post Graduation', 'Graduation', 'HSC / Diploma'];
const GENDERS = ['Male', 'Female', 'Other'];
const MARITAL = ['Single', 'Married', 'Other'];
const FAMILY_ROWS = 4;

// Input filters: each field accepts only the characters that make sense for it
const only = {
  name: (v: string) => v.replace(/[^A-Za-z .'-]/g, '').slice(0, 40),            // letters
  text: (v: string) => v.replace(/[^A-Za-z0-9 &.,/()'-]/g, '').slice(0, 60),    // letters + numbers
  address: (v: string) => v.replace(/[^A-Za-z0-9 ,.\/#()'\n-]/g, '').slice(0, 200),
  mobile: (v: string) => v.replace(/\D/g, '').slice(0, 10),                     // 10 digits
  landline: (v: string) => v.replace(/\D/g, '').slice(0, 12),                   // digits only
  email: (v: string) => v.replace(/[^A-Za-z0-9@._+-]/g, '').toLowerCase().slice(0, 80),
  pan: (v: string) => v.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 10),
  aadhar: (v: string) => v.replace(/\D/g, '').slice(0, 12),                     // 12 digits
  account: (v: string) => v.replace(/\D/g, '').slice(0, 18),
  ifsc: (v: string) => v.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 11),
  vehicleNo: (v: string) => v.replace(/[^A-Za-z0-9 -]/g, '').toUpperCase().slice(0, 13),
  licenseNo: (v: string) => v.replace(/[^A-Za-z0-9 -]/g, '').toUpperCase().slice(0, 20),
  marks: (v: string) => v.replace(/[^A-Za-z0-9.%+ ]/g, '').slice(0, 8),
  year: (v: string) => v.replace(/\D/g, '').slice(0, 4),
};

// An address is typed step by step (house, street, area, city, state, PIN) and saved as one text of 6 lines
const ADDRESS_PARTS = [
  { key: 0, label: 'House / Flat no.', hint: 'e.g. Flat 12, Shree Apt' },
  { key: 1, label: 'Street / Road', hint: 'e.g. Baner Road' },
  { key: 2, label: 'Area / Locality', hint: 'e.g. Baner' },
  { key: 3, label: 'City', hint: 'e.g. Pune' },
  { key: 4, label: 'State', hint: 'e.g. Maharashtra' },
  { key: 5, label: 'PIN code', hint: '6 digits' },
] as const;
const splitAddress = (v: string): string[] => {
  const p = (v ?? '').split('\n');
  if (p.length === 6) return p;
  const old = (v ?? '').trim();               // an address saved before as free text goes into the first box
  return [old, '', '', '', '', ''];
};

type Mode = 'wide' | 'tablet' | 'mobile';
type Cx = { node: React.ReactNode; flex?: number; width?: number };

/** One form line: all fields on ONE row (wide), wrapped into the given groups (tablet), or one field per row (mobile) */
function Cells({ mode, items, tablet }: { mode: Mode; items: Cx[]; tablet?: number[] }) {
  if (mode === 'mobile') return <View>{items.map((c, i) => <View key={i}>{c.node}</View>)}</View>;
  const sizes = mode === 'tablet' && tablet ? tablet : [items.length];
  let k = 0;
  return (
    <View>
      {sizes.map((n, ri) => {
        const part = items.slice(k, k + n); k += n;
        return (
          <View key={ri} style={{ flexDirection: 'row', gap: 12, alignItems: 'flex-end' }}>
            {part.map((c, i) => <View key={i} style={c.width ? { width: c.width } : { flex: c.flex ?? 1, minWidth: 0 }}>{c.node}</View>)}
          </View>
        );
      })}
    </View>
  );
}

/** A small drop-down (Gender, Marital status): same options and saved values as the old chips; empty shows "Select" */
function SelectField({ label, options, value, onChange }: { label: string; options: string[]; value: string; onChange: (v: string) => void }) {
  return (
    <Dropdown<string> label={label} options={['Select', ...options]} value={value && options.includes(value) ? value : 'Select'}
      onChange={(v) => onChange(v === 'Select' ? '' : v)} />
  );
}

/** Light-blue label box at the start of an address / contact line (a small title on a phone) */
function LineLabel({ text, mode }: { text: string; mode: Mode }) {
  if (mode === 'mobile') return <Text style={[st.label, { marginTop: 6, fontSize: 13, color: '#102A45' }]}>{text}</Text>;
  return (
    <View style={{ width: 120, height: 44, marginTop: 22, borderRadius: 12, backgroundColor: '#EAF3FF', justifyContent: 'center', paddingHorizontal: 12 }}>
      <Text style={{ fontWeight: '800', fontSize: 13, color: '#0E3F7A' }}>{text}</Text>
    </View>
  );
}

// An address line: House / Flat no. | Street / Road | Area / Locality | City | State | PIN code  (saved as the same 6-line text as before)
const ADDRESS_FLEX: number[] = [1.3, 1.1, 1, 0.9, 0.9, 0];
function AddressLine({ title, value, onChange, mode, below }: { title: string; value: string; onChange: (v: string) => void; mode: Mode; below?: React.ReactNode }) {
  const parts = splitAddress(value);
  const set = (i: number, v: string) => {
    const next = splitAddress(value).map((x, k) => (k === i ? (i === 5 ? v.replace(/\D/g, '').slice(0, 6) : only.address(v).replace(/\n/g, ' ').slice(0, 60)) : x));
    onChange(next.every((x) => !x.trim()) ? '' : next.join('\n'));
  };
  const items: Cx[] = ADDRESS_PARTS.map((a) => ({
    flex: a.key < 5 ? ADDRESS_FLEX[a.key] : undefined, width: a.key === 5 ? 110 : undefined,
    node: <Field label={`${a.label}${a.key === 0 || a.key >= 3 ? ' *' : ''}`} value={parts[a.key]} placeholder={a.hint}
      keyboardType={a.key === 5 ? 'number-pad' : 'default'} maxLength={a.key === 5 ? 6 : 60} onChangeText={(v) => set(a.key, v)} />,
  }));
  return (
    <View style={{ marginBottom: 2 }}>
      <View style={{ flexDirection: mode === 'mobile' ? 'column' : 'row', gap: 12, alignItems: mode === 'mobile' ? 'stretch' : 'flex-start' }}>
        <LineLabel text={title} mode={mode} />
        <View style={{ flex: 1, minWidth: 0 }}><Cells mode={mode} items={items} tablet={[3, 3]} /></View>
      </View>
      {below ? <View style={{ marginLeft: mode === 'mobile' ? 0 : 132, marginTop: -2, marginBottom: 6 }}>{below}</View> : null}
    </View>
  );
}

const emptyEdu =(): EducationRow[] => DEGREES.map((degree) => ({ degree, specialization: '', year: '', marks: '' }));
const emptyFamily = (): FamilyRow[] => Array.from({ length: FAMILY_ROWS }, () => ({ name: '', relation: '', contact: '' }));

interface Form {
  surname: string; first_name: string; father_name: string; mother_name: string;
  date_of_birth: string; gender: string; marital_status: string;
  permanent_address: string; local_address: string; tel_no: string; cell_no: string; email: string;
  pan_no: string; aadhar_no: string; uan_no: string; esic_no: string; software_skills: string;
  vehicle_company: string; vehicle_no: string; license_no: string;
  bank_name: string; bank_address: string; bank_branch: string; bank_account_no: string; ifsc_code: string;
  joining_date: string; resign_date: string; declared: boolean;
  education: EducationRow[]; family: FamilyRow[];
}

const blank = (): Form => ({
  surname: '', first_name: '', father_name: '', mother_name: '', date_of_birth: '', gender: '', marital_status: '',
  permanent_address: '', local_address: '', tel_no: '', cell_no: '', email: '', pan_no: '', aadhar_no: '', uan_no: '', esic_no: '', software_skills: '',
  vehicle_company: '', vehicle_no: '', license_no: '',
  bank_name: '', bank_address: '', bank_branch: '', bank_account_no: '', ifsc_code: '',
  joining_date: '', resign_date: '', declared: false, education: emptyEdu(), family: emptyFamily(),
});

const fromRow = (r: EmployeeDetails | null, fallback: { name: string; phone: string; joining: string }): Form => {
  const f = blank();
  if (!r) {
    const parts = fallback.name.trim().split(/\s+/);
    return { ...f, first_name: parts[0] ?? '', surname: parts.length > 1 ? parts[parts.length - 1] : '', cell_no: fallback.phone, joining_date: fallback.joining };
  }
  const s = (v: string | null) => v ?? '';
  const edu = emptyEdu().map((e, i) => ({ ...e, ...(r.education?.[i] ?? {}), degree: e.degree }));
  const fam = emptyFamily().map((e, i) => ({ ...e, ...(r.family?.[i] ?? {}) }));
  return {
    surname: s(r.surname), first_name: s(r.first_name), father_name: s(r.father_name), mother_name: s(r.mother_name),
    date_of_birth: s(r.date_of_birth), gender: s(r.gender), marital_status: s(r.marital_status),
    permanent_address: s(r.permanent_address), local_address: s(r.local_address), tel_no: s(r.tel_no), cell_no: s(r.cell_no),
    email: s(r.email), pan_no: s(r.pan_no), aadhar_no: s(r.aadhar_no), uan_no: s(r.uan_no), esic_no: s(r.esic_no ?? null), software_skills: s(r.software_skills),
    vehicle_company: s(r.vehicle_company), vehicle_no: s(r.vehicle_no), license_no: s(r.license_no),
    bank_name: s(r.bank_name), bank_address: s(r.bank_address), bank_branch: s(r.bank_branch),
    bank_account_no: s(r.bank_account_no), ifsc_code: s(r.ifsc_code), joining_date: s(r.joining_date), resign_date: s(r.resign_date),
    declared: r.declared, education: edu, family: fam,
  };
};

/**
 * The company "Employee Form": personal details, education, family, vehicle, bank, and the documents
 * (photo, Aadhar, PAN, bank passbook, graduation, CV).
 *  admin = false : the employee fills his own form.
 *  admin = true  : Admin / HR fill or correct it for that employee and can view / download the files.
 */
export default function EmployeeDetailsForm({ userId, admin, fallback }: {
  userId: string; admin: boolean; fallback: { name: string; phone: string; joining: string; department?: string; designation?: string; role?: string; siteEmployee?: boolean };
}) {
  const [form, setForm] = useState<Form | null>(null);
  const [saved, setSaved] = useState<EmployeeDetails | null>(null);
  const [files, setFiles] = useState<EmployeeDetailFile[]>([]);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<DetailFileKind | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [siteEmp, setSiteEmp] = useState(!!fallback.siteEmployee);
  const [boxW, setBoxW] = useState(1100);          // width of the form: decides one line / two rows / one field per row
  const [sameAddr, setSameAddr] = useState(false);   // "Same as permanent address" tick
  // Company (Admin / HR choose it here; the employee sees it read-only)
  const co = useCompanies();
  const [coNow, setCoNow] = useState<number | null>(null);   // company saved today
  const [coSel, setCoSel] = useState<number | null>(null);   // company picked in the drop-down
  const [coFrom, setCoFrom] = useState(firstOfMonthISO());
  useEffect(() => {
    supabase.from('profiles').select('company_id').eq('id', userId).maybeSingle()
      .then(({ data }) => { const id = (data as any)?.company_id ?? null; setCoNow(id); setCoSel(id); }, () => undefined);
  }, [userId]);
  useEffect(() => { setSiteEmp(!!fallback.siteEmployee); }, [fallback.siteEmployee]);

  // Admin / HR choose Office or Site employee; it is saved straight away
  const changeOfficeType = async (v: 'Office employee' | 'Site employee') => {
    const site = v === 'Site employee';
    const before = siteEmp;
    setSiteEmp(site);
    try { await api.updateProfile(userId, { site_employee: site }); }
    catch (e) { setSiteEmp(before); Alert.alert('Could not change the office type', errorText(e)); }
  };

  const loadFiles = useCallback(async () => {
    try {
      const list = await api.employeeDetailFiles(userId);
      setFiles(list);
      const photo = list.find((f) => f.kind === 'photo');
      setPhotoUrl(photo ? await api.detailFileUrl(photo.file_path).catch(() => null) : null);
    } catch (e) { Alert.alert('Could not load documents', errorText(e)); }
  }, [userId]);

  const loadForm = useCallback(async () => {
    try {
      const row = await api.employeeDetails(userId);
      setSaved(row);
      setForm(fromRow(row, fallback));
    } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [userId, fallback.name, fallback.phone, fallback.joining]);

  useEffect(() => { setForm(null); loadForm(); loadFiles(); }, [loadForm, loadFiles]);
  useRealtime(`detail-files-${userId}`, [{ table: 'employee_detail_files', filter: `user_id=eq.${userId}` }], () => loadFiles());

  if (!form) return <ActivityIndicator style={{ margin: 20 }} color={C.blue} />;
  const set = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => (f ? { ...f, [k]: v } : f));
  const setEdu = (i: number, k: keyof EducationRow, v: string) =>
    setForm((f) => f && { ...f, education: f.education.map((r, j) => (j === i ? { ...r, [k]: v } : r)) });
  const setFam = (i: number, k: keyof FamilyRow, v: string) =>
    setForm((f) => f && { ...f, family: f.family.map((r, j) => (j === i ? { ...r, [k]: v } : r)) });

  const fileOf = (k: DetailFileKind) => files.find((f) => f.kind === k);
  const missing = DETAIL_FILE_KINDS.filter((d) => d.required && !fileOf(d.kind)).map((d) => d.label);

  const save = async () => {
    setSaving(true);
    try {
      // education rows keep their position (Post Graduation, Graduation, HSC / Diploma)
      const row = await api.saveEmployeeDetails(admin ? userId : null, form);
      setSaved(row);
      // ESIC IP no.: only Admin / HR set it (needs esic_ip_no.sql); a problem here never blocks the rest of the form
      if (admin) { const { error: e2 } = await supabase.rpc('admin_set_esic_no', { p_user: userId, p_no: form.esic_no }); if (e2 && !/admin_set_esic_no|schema cache/i.test(e2.message)) throw e2; }
      Alert.alert('Saved', missing.length ? `Details saved. Still to upload: ${missing.join(', ')}.` : 'Employee details saved.');
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setSaving(false); }
  };

  // "Save Employee Details": saves the whole form and, when the company was changed, moves the employee after a confirmation
  const saveJoining = async () => {
    const changed = admin && coSel != null && coSel !== coNow;
    if (!changed) { await save(); return; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(coFrom)) { Alert.alert('Company from date', 'Enter the date as YYYY-MM-DD.'); return; }
    const target = co.byId(coSel!);
    const msg = `Move ${fallback.name} to ${target?.legal_name ?? 'the company'} from ${fmtISODate(coFrom)}?`;
    const run = async () => {
      try { await companiesApi.setEmployeeCompany(userId, coSel!, coFrom); setCoNow(coSel); await co.reload(); await save(); }
      catch (e) { Alert.alert('Could not change the company', errorText(e)); }
    };
    if (Platform.OS === 'web') { if (typeof window !== 'undefined' && window.confirm(msg)) await run(); }
    else Alert.alert('Change company?', msg, [{ text: 'Cancel', style: 'cancel' }, { text: 'Move', onPress: run }]);
  };

  const choose = async (kind: DetailFileKind, camera: boolean) => {
    try {
      const f = await pickFile(camera);
      if (!f) return;
      setUploading(kind);
      await api.uploadDetailFile(userId, admin, kind, f.bytes, f.name, f.mime);
      await loadFiles();
    } catch (e) { Alert.alert('Could not upload', errorText(e)); }
    finally { setUploading(null); }
  };
  const open = async (d: EmployeeDetailFile, save = false) => {
    try { await downloadOrOpen(await api.detailFileUrl(d.file_path, save ? (d.file_name || d.kind) : undefined), d.file_name || d.kind, save); }
    catch (e) { Alert.alert('File unavailable', errorText(e)); }
  };
  const remove = (kind: DetailFileKind, label: string) =>
    Alert.alert(`Remove ${label}?`, '', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: async () => {
        try { await api.deleteDetailFile(userId, admin, kind); await loadFiles(); } catch (e) { Alert.alert('Could not remove', errorText(e)); }
      } },
    ]);

  const downloadForm = async () => {
    setPdfBusy(true);
    try {
      const who = `${form.first_name} ${form.surname}`.trim() || fallback.name || 'Employee';
      await downloadEmployeeFormPdf(form, {
        photoUrl, uploaded: files.map((x) => x.kind),
        fileName: `${who.replace(/[^A-Za-z0-9]+/g, '_')}_Employee_Form.pdf`,
      });
    } catch (e) { Alert.alert('Could not create the PDF', errorText(e)); }
    finally { setPdfBusy(false); }
  };

  const web = Platform.OS === 'web';
  const ro = { editable: false, style: { backgroundColor: '#F1F4F8', color: C.muted } };
  const mode: Mode = boxW >= 1000 ? 'wide' : boxW >= 640 ? 'tablet' : 'mobile';
  return (
    <View onLayout={(e) => setBoxW(Math.round(e.nativeEvent.layout.width))}>
      {saved ? <Banner tone="green" icon="checkmark-circle" text={`Form saved on ${fmtISODate(saved.updated_at.slice(0, 10))}. You can edit it any time.`} />
        : <Banner tone="amber" icon="alert-circle-outline" text="This form is not filled yet. Fields marked * are compulsory." />}

      <SectionTitle title="Personal details" />
      <Card>
        <Cells mode={mode} tablet={[4, 3]} items={[
          { flex: 1, node: <Field label="Surname" value={form.surname} onChangeText={(v) => set('surname', only.name(v))} /> },
          { flex: 1, node: <Field label="First name" value={form.first_name} onChangeText={(v) => set('first_name', only.name(v))} /> },
          { flex: 1.1, node: <Field label="Father name" value={form.father_name} placeholder="e.g. Pandurang" onChangeText={(v) => set('father_name', only.name(v))} /> },
          { flex: 1.1, node: <Field label="Mother name" value={form.mother_name} placeholder="e.g. Sunita" onChangeText={(v) => set('mother_name', only.name(v))} /> },
          { flex: 1, node: <Field label="Date of birth" value={form.date_of_birth} placeholder="YYYY-MM-DD" keyboardType="numbers-and-punctuation"
              onChangeText={(v) => set('date_of_birth', v.replace(/[^0-9-]/g, '').slice(0, 10))} /> },
          { flex: 0.8, node: <SelectField label="Gender" options={GENDERS} value={form.gender} onChange={(v) => set('gender', v)} /> },
          { flex: 0.9, node: <SelectField label="Marital status" options={MARITAL} value={form.marital_status} onChange={(v) => set('marital_status', v)} /> },
        ]} />
      </Card>

      <SectionTitle title="Address and contact" />
      <Card>
        <AddressLine mode={mode} title={mode === 'mobile' ? 'Permanent address *' : 'Permanent *'} value={form.permanent_address} onChange={(v) => { set('permanent_address', v); if (sameAddr) set('local_address', v); }} />
        <AddressLine mode={mode} title={mode === 'mobile' ? 'Local address *' : 'Local *'} value={form.local_address} onChange={(v) => { set('local_address', v); }}
          below={
            <Pressable onPress={() => { const on = !sameAddr; setSameAddr(on); if (on) set('local_address', form.permanent_address); }} accessibilityRole="checkbox" accessibilityState={{ checked: sameAddr }} hitSlop={6}>
              <Text style={{ fontSize: 12.5, fontWeight: '800', color: C.blue }}>{sameAddr ? '\u2611' : '\u2610'} Same as permanent address</Text>
            </Pressable>
          } />
        <View style={{ flexDirection: mode === 'mobile' ? 'column' : 'row', gap: 12, alignItems: mode === 'mobile' ? 'stretch' : 'flex-start' }}>
          <LineLabel text={mode === 'mobile' ? 'Contact' : 'Contact'} mode={mode} />
          <View style={{ flex: 1, minWidth: 0 }}>
            <Cells mode={mode} items={[
              { flex: 1, node: <Field label="Cell no. *" value={form.cell_no} keyboardType="number-pad" maxLength={10} placeholder="10 digits" onChangeText={(v) => set('cell_no', only.mobile(v))} /> },
              { flex: 1, node: <Field label="Tel. phone no." value={form.tel_no} keyboardType="number-pad" maxLength={12} placeholder="optional" onChangeText={(v) => set('tel_no', only.landline(v))} /> },
              { flex: 1.2, node: <Field label="E-mail address" value={form.email} keyboardType="email-address" autoCapitalize="none" placeholder="e.g. name@gmail.com" onChangeText={(v) => set('email', only.email(v))} /> },
            ]} />
          </View>
        </View>
      </Card>

      <SectionTitle title="Identity" />
      <Card>
        <View style={st.line}>
          <View style={st.cell}>
            <Field label="PAN card no." value={form.pan_no} autoCapitalize="characters" maxLength={10} placeholder="ABCDE1234F"
              onChangeText={(v) => set('pan_no', only.pan(v))} />
          </View>
          <View style={st.cell}>
            <Field label="Aadhar card no." value={form.aadhar_no} keyboardType="number-pad" maxLength={12} placeholder="12 digits"
              onChangeText={(v) => set('aadhar_no', only.aadhar(v))} />
          </View>
        </View>
      </Card>

      <SectionTitle title="Educational qualification" />
      <Card>
        {form.education.map((r, i) => (
          <View key={r.degree} style={st.line}>
            <View style={st.cell}>
              <Text style={st.label}>Degree</Text>
              <Text style={st.degree}>{r.degree}</Text>
            </View>
            <View style={st.cellWide}><Field label="Specialization" value={r.specialization} onChangeText={(v) => setEdu(i, 'specialization', only.text(v))} /></View>
            <View style={st.cell}><Field label="Year of passing" value={r.year} keyboardType="number-pad" maxLength={4} onChangeText={(v) => setEdu(i, 'year', only.year(v))} /></View>
            <View style={st.cell}><Field label="% marks / grade" value={r.marks} maxLength={8} onChangeText={(v) => setEdu(i, 'marks', only.marks(v))} /></View>
          </View>
        ))}
        <Field label="Software skills" value={form.software_skills} multiline onChangeText={(v) => set('software_skills', v)} placeholder="e.g. MS Office, AutoCAD, Tally" />
      </Card>

      <SectionTitle title="Family details" />
      <Card>
        {form.family.map((r, i) => (
          <View key={i} style={st.line}>
            <View style={st.cellWide}><Field label={`Member ${i + 1} - Name`} value={r.name} onChangeText={(v) => setFam(i, 'name', only.name(v))} /></View>
            <View style={st.cell}><Field label="Relation with you" value={r.relation} onChangeText={(v) => setFam(i, 'relation', only.name(v))} /></View>
            <View style={st.cell}><Field label="Contact number" value={r.contact} keyboardType="number-pad" maxLength={10} onChangeText={(v) => setFam(i, 'contact', only.mobile(v))} /></View>
          </View>
        ))}
      </Card>

      <SectionTitle title="Vehicle details" />
      <Card>
        <View style={st.line}>
          <View style={st.cell}><Field label="Vehicle company name" value={form.vehicle_company} onChangeText={(v) => set('vehicle_company', only.text(v))} /></View>
          <View style={st.cell}><Field label="Vehicle no." value={form.vehicle_no} autoCapitalize="characters" onChangeText={(v) => set('vehicle_no', only.vehicleNo(v))} /></View>
          <View style={st.cell}><Field label="License no." value={form.license_no} autoCapitalize="characters" onChangeText={(v) => set('license_no', only.licenseNo(v))} /></View>
        </View>
      </Card>

      <SectionTitle title="Bank details *" />
      <Card>
        <View style={st.line}>
          <View style={[st.cell, { flexBasis: 150, minWidth: 130 }]}><Field label="Bank name *" value={form.bank_name} onChangeText={(v) => set('bank_name', only.text(v))} /></View>
          <View style={[st.cell, { flexBasis: 150, minWidth: 130 }]}><Field label="Branch name *" value={form.bank_branch} onChangeText={(v) => set('bank_branch', only.text(v))} /></View>
          <View style={[st.cellWide, { flexGrow: 2, flexBasis: 220, minWidth: 180 }]}><Field label="Address of bank *" value={form.bank_address} onChangeText={(v) => set('bank_address', only.address(v))} /></View>
          <View style={[st.cell, { flexBasis: 150, minWidth: 130 }]}><Field label="Account no. *" value={form.bank_account_no} keyboardType="number-pad" maxLength={18} onChangeText={(v) => set('bank_account_no', only.account(v))} /></View>
          <View style={[st.cell, { flexBasis: 140, minWidth: 120 }]}>
            <Field label="IFSC code *" value={form.ifsc_code} autoCapitalize="characters" maxLength={11} placeholder="SBIN0001234"
              onChangeText={(v) => set('ifsc_code', only.ifsc(v))} />
          </View>
        </View>
      </Card>

      <SectionTitle title="Joining" />
      <Card>
        <Cells mode={mode} tablet={[2]} items={[
          { flex: 2, node: admin ? (
              <View>
                <Text style={st.coLabel}>Company * (Admin / HR only)</Text>
                <View>
                  <Dropdown<string> options={co.companies.map((c) => c.legal_name)} value={co.byId(coSel ?? 0)?.legal_name ?? co.companies[0]?.legal_name ?? ''}
                    onChange={(v) => { const c = co.companies.find((x) => x.legal_name === v); if (c) { setCoSel(c.id); if (c.id !== coNow) setCoFrom(firstOfMonthISO()); } }} />
                </View>
              </View>
            ) : (
              <Field label="Company" value={co.byId(coNow ?? 0)?.legal_name ?? ''} {...ro} />
            ) },
        ]} />
        {admin ? <Text style={st.coHelp}>Reports from the 1st of this month use the new company; older months keep the old company. Saved in Audit Trail.</Text> : null}
        <Cells mode={mode} tablet={[4, 4]} items={[
          { flex: 1, node: <Field label="Department" value={fallback.department ?? ''} placeholder="Set by Admin / HR" {...ro} /> },
          { flex: 1.1, node: <Field label="Designation" value={fallback.designation ?? ''} placeholder="Set by Admin / HR" {...ro} /> },
          { flex: 0.9, node: <Field label="Role" value={fallback.role ?? ''} {...ro} /> },
          { flex: 1.3, node: admin ? (
              <Dropdown<'Office employee' | 'Site employee'> label="Office type" options={['Office employee', 'Site employee']}
                value={siteEmp ? 'Site employee' : 'Office employee'} onChange={changeOfficeType} />
            ) : (
              <Field label="Office type" value={siteEmp ? 'Site employee' : 'Office employee'} {...ro} />
            ) },
          { flex: 1.1, node: <PickerField label="Joining date *" mode="date" value={form.joining_date} onChange={(v) => set('joining_date', v)} /> },
          { flex: 1.2, node: <PickerField label="Resign date (only when leaving)" mode="date" clearable value={form.resign_date} onChange={(v) => set('resign_date', v)} /> },
          { flex: 1, node: <Field label="UAN no. (PF)" value={form.uan_no} keyboardType="number-pad" maxLength={12} placeholder="12 digits"
              onChangeText={(v) => set('uan_no', v.replace(/\D/g, ''))} /> },
          { flex: 1, node: admin ? <Field label="ESIC IP no." value={form.esic_no} keyboardType="number-pad" maxLength={17} placeholder="17 digits" onChangeText={(v) => set('esic_no', v.replace(/\D/g, ''))} />
            : <Field label="ESIC IP no." value={form.esic_no} {...ro} /> },
        ]} />
        <View style={{ borderTopWidth: 1, borderTopColor: '#E6EDF5', borderStyle: 'dashed', marginTop: 6, paddingTop: 6 }}>
          <Toggle label="Declaration" note="I hereby declare the information furnished by me is correct. I bear the responsibility for all the above information."
            value={form.declared} onChange={(v) => set('declared', v)} />
        </View>
      </Card>

      <SectionTitle title="Photo and documents" note="PAN, Aadhar, bank passbook and photo are compulsory" />
      <Card>
        <View style={st.grid}>
          {DETAIL_FILE_KINDS.map((d) => {
            const f = fileOf(d.kind);
            return (
              <View key={d.kind} style={st.tile}>
                <Text style={st.docTitle}>{d.label}{d.required ? ' *' : ''}</Text>
                <View style={{ alignSelf: 'flex-start', marginTop: 4 }}>
                  <Pill text={f ? 'Uploaded' : d.required ? 'Required' : 'Optional'} tone={f ? 'green' : d.required ? 'red' : 'muted'} />
                </View>
                <Text style={st.hint} numberOfLines={1}>{f ? (f.file_name || d.hint) : d.hint}</Text>
                {d.kind === 'photo' ? (
                  <View style={st.photoBox}>
                    {photoUrl ? <Image source={{ uri: photoUrl }} style={st.photo} resizeMode="cover" />
                      : <Text style={st.photoHint}>3.5 x 4.5 cm</Text>}
                  </View>
                ) : null}
                <Row style={{ flexWrap: 'wrap', marginTop: 8 }} gap={6}>
                  <Button title={f ? 'Replace' : web ? 'Choose file' : 'Gallery'} icon="cloud-upload-outline" variant="secondary" small
                    loading={uploading === d.kind} onPress={() => choose(d.kind, false)} />
                  {!web ? <Button title="Camera" icon="camera-outline" variant="secondary" small disabled={!!uploading} onPress={() => choose(d.kind, true)} /> : null}
                  {f ? <Button title="View" icon="eye-outline" variant="secondary" small onPress={() => open(f)} /> : null}
                  {f ? <Button title="Download" icon="download-outline" variant="secondary" small onPress={() => open(f, true)} /> : null}
                  {f ? <Button title="Remove" icon="trash-outline" variant="danger" small onPress={() => remove(d.kind, d.label)} /> : null}
                </Row>
              </View>
            );
          })}
        </View>
        <Text style={st.hint}>{web ? 'PDF, image or Word file, up to 10 MB.' : 'Take a photo or choose one from the gallery (up to 10 MB). Name each file clearly.'}</Text>
      </Card>

      <Row style={{ marginTop: 6, marginBottom: 20, flexWrap: 'wrap' }}>
        <Button title="Save Employee Details" icon="save-outline" loading={saving} onPress={saveJoining} style={{ flex: 1, minWidth: 200 }} />
        <Button title="Download Form (PDF)" icon="download-outline" variant="secondary" loading={pdfBusy} onPress={downloadForm} style={{ flex: 1, minWidth: 200 }} />
      </Row>
    </View>
  );
}

const st = StyleSheet.create({
  coLabel: { fontSize: 12.5, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  coHelp: { fontSize: 12, color: C.muted, marginTop: -2, marginBottom: 10 },
  line: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, alignItems: 'flex-start' },
  cell: { flexGrow: 1, flexBasis: 200, minWidth: 150 },
  degree: { fontWeight: '800', color: '#102A45', fontSize: 14, height: 44, textAlignVertical: 'center', lineHeight: 44 },
  cellWide: { flexGrow: 1, flexBasis: 300, minWidth: 220 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 6 },
  tile: {
    flexGrow: 1, flexBasis: 150, minWidth: 140, borderWidth: 1, borderColor: '#E3EBF4', borderRadius: 12,
    padding: 12, backgroundColor: '#FBFDFF',
  },
  photoBox: {
    width: 105, height: 135, borderWidth: 1, borderColor: '#B9C7D8', borderRadius: 6, backgroundColor: '#F4F8FC',
    alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginTop: 8,
  },
  photo: { width: '100%', height: '100%' },
  photoHint: { color: C.muted, fontSize: 11, textAlign: 'center', padding: 6 },
  docRow: { paddingBottom: 10, marginBottom: 10, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  docTitle: { fontWeight: '800', color: '#102A45', fontSize: 14, flexShrink: 1 },
  hint: { color: C.muted, fontSize: 12, marginTop: 3 },
  label: { fontSize: 12, fontWeight: '700', color: '#3A5068', marginBottom: 8 },
  block: { marginBottom: 6 },
});
