import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useMemo, useState } from 'react';
import { Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useIsDesktop } from '../lib/layout';
import { C } from '../theme';

export interface DDRow { id: string; title: string; sub?: string; initials?: string; tag?: { text: string; color: string }; count?: number }
export interface DDGroup { key: string; title: string; rows: DDRow[] }

/**
 * Live Map filter box. Tap it and a list drops directly under the box (phones: a full-screen list) with a search box,
 * an "All ..." row with its count and collapsible groups. Only one box is open at a time (the parent owns `open`).
 */
export default function MapFilterDropdown({
  label, valueText, open, onToggle, onClose, allLabel, allCount, allSelected, groups, selectedId, onSelectAll, onSelect,
  searchPlaceholder, active,
}: {
  label: string; valueText: string; open: boolean; onToggle: () => void; onClose: () => void;
  allLabel: string; allCount: number; allSelected: boolean; groups: DDGroup[]; selectedId: string | null;
  onSelectAll: () => void; onSelect: (id: string) => void; searchPlaceholder: string; active?: boolean;
}) {
  const desktop = useIsDesktop();
  const [q, setQ] = useState('');
  // every group starts CLOSED each time the list opens; only a tap opens one. While typing, groups with a match show open;
  // clearing the search closes them again. Nothing is remembered between openings.
  const [opened, setOpened] = useState<Record<string, boolean>>({});
  useEffect(() => { if (open) { setQ(''); setOpened({}); } }, [open]);   // eslint-disable-line react-hooks/exhaustive-deps

  const query = q.trim().toLowerCase();
  const shown = useMemo(() => groups
    .map((g) => ({ ...g, rows: query ? g.rows.filter((r) => `${r.title} ${r.sub ?? ''}`.toLowerCase().includes(query)) : g.rows }))
    .filter((g) => !query || g.rows.length > 0), [groups, query]);

  const list = (
    <View style={{ flexShrink: 1 }}>
      <View style={st.searchWrap}>
        <Ionicons name="search-outline" size={16} color="#8594A6" />
        <TextInput value={q} onChangeText={(t) => { setQ(t); setOpened({}); }} placeholder={searchPlaceholder} placeholderTextColor="#8594A6" style={st.search} />
      </View>
      <ScrollView style={{ maxHeight: desktop ? 340 : undefined }} nestedScrollEnabled keyboardShouldPersistTaps="handled">
        {!query || allLabel.toLowerCase().includes(query) ? (
          <Pressable onPress={() => { onSelectAll(); onClose(); }} style={[st.allRow, allSelected && st.rowOn]} accessibilityRole="button">
            <Text style={st.allText}>{allLabel}</Text>
            <Text style={st.allCount}>{allCount}</Text>
          </Pressable>
        ) : null}
        {shown.map((g) => {
          const isClosed = !query && !opened[g.key];
          return (
            <View key={g.key}>
              <Pressable onPress={() => setOpened((c) => ({ ...c, [g.key]: !c[g.key] }))} style={st.groupHead} accessibilityRole="button">
                <Ionicons name={isClosed ? 'chevron-forward' : 'chevron-down'} size={14} color="#3A5068" />
                <Text style={st.groupTitle} numberOfLines={1}>{g.title}</Text>
                <View style={st.groupCount}><Text style={st.groupCountText}>{g.rows.length}</Text></View>
              </Pressable>
              {isClosed ? null : g.rows.map((r) => (
                <Pressable key={r.id} onPress={() => { onSelect(r.id); onClose(); }} style={[st.row, selectedId === r.id && st.rowOn]} accessibilityRole="button">
                  {r.initials ? <View style={st.avatar}><Text style={st.avatarText}>{r.initials}</Text></View> : null}
                  <View style={{ flex: 1, minWidth: 0 }}>
                    <Text style={st.title} numberOfLines={1}>{r.title}</Text>
                    {r.sub ? <Text style={st.sub} numberOfLines={1}>{r.sub}</Text> : null}
                  </View>
                  {r.count != null ? <Text style={st.allCount}>{r.count}</Text> : null}
                  {r.tag ? (
                    <View style={st.tag}><View style={[st.tagDot, { backgroundColor: r.tag.color }]} /><Text style={[st.tagText, { color: r.tag.color }]}>{r.tag.text}</Text></View>
                  ) : null}
                </Pressable>
              ))}
            </View>
          );
        })}
        {shown.length === 0 && query ? <Text style={st.none}>Nothing found.</Text> : null}
      </ScrollView>
    </View>
  );

  return (
    <View style={[st.cell, open && { zIndex: 3000 }]}>
      <Text style={st.label} numberOfLines={1}>{label}</Text>
      <Pressable onPress={onToggle} accessibilityRole="button" style={[st.box, open && st.boxOpen, active && !open && st.boxActive]}>
        <Text style={st.boxText} numberOfLines={1}>{valueText}</Text>
        <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={16} color="#3A5068" />
      </Pressable>
      {open && desktop ? <View style={st.pop}>{list}</View> : null}
      {open && !desktop ? (
        <Modal visible animationType="slide" onRequestClose={onClose}>
          <View style={st.page}>
            <View style={st.pageHead}>
              <Text style={st.pageTitle}>{label}</Text>
              <Pressable onPress={onClose} hitSlop={12}><Text style={{ color: C.blue, fontWeight: '800', fontSize: 15 }}>Close</Text></Pressable>
            </View>
            {list}
          </View>
        </Modal>
      ) : null}
    </View>
  );
}

const st = StyleSheet.create({
  cell: { flexGrow: 1, flexBasis: 150, minWidth: 140, position: 'relative' },
  label: { fontSize: 11.5, lineHeight: 16, fontWeight: '800', letterSpacing: 0.4, color: '#3A5068', marginBottom: 6 },
  box: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8, height: 44, borderRadius: 12, borderWidth: 1, borderColor: '#C9DDF3', backgroundColor: '#EAF2FC', paddingHorizontal: 12 },
  boxOpen: { borderColor: C.blue, borderWidth: 2, backgroundColor: '#FFFFFF' },
  boxActive: { borderColor: '#7DB2F0' },
  boxText: { flex: 1, fontSize: 14, fontWeight: '800', color: '#0F2A47' },
  pop: {
    position: 'absolute', top: 76, left: 0, minWidth: 330, zIndex: 3000, backgroundColor: '#FFFFFF', borderRadius: 16, borderWidth: 1, borderColor: '#D8E6F5', padding: 10,
    ...(Platform.OS === 'web' ? ({ boxShadow: '0 14px 36px rgba(11,43,77,0.22)' } as any) : { elevation: 14 }),
  },
  searchWrap: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderColor: '#DCE7F3', borderRadius: 12, backgroundColor: '#F5F8FC', paddingHorizontal: 12, height: 42, marginBottom: 8 },
  search: { flex: 1, fontSize: 14, color: '#102A45', paddingVertical: 0, ...(Platform.OS === 'web' ? ({ outlineStyle: 'none' } as any) : {}) },
  allRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 11, paddingHorizontal: 10 },
  allText: { fontSize: 14, fontWeight: '800', color: C.blue },
  allCount: { fontSize: 14, fontWeight: '800', color: C.blue },
  groupHead: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EFF4FA', paddingVertical: 8, paddingHorizontal: 10, marginTop: 2 },
  groupTitle: { flex: 1, fontSize: 11.5, fontWeight: '800', letterSpacing: 0.6, color: '#3A5068' },
  groupCount: { minWidth: 26, alignItems: 'center', borderRadius: 10, backgroundColor: '#DCE6F2', paddingHorizontal: 7, paddingVertical: 1 },
  groupCountText: { fontSize: 12, fontWeight: '800', color: '#3A5068' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 9, paddingHorizontal: 10 },
  rowOn: { backgroundColor: '#E8F2FF' },
  avatar: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#DDF5F3', alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 11.5, fontWeight: '800', color: '#0B4F4A' },
  title: { fontSize: 14, fontWeight: '800', color: '#102A45' },
  sub: { fontSize: 12, color: '#77889D', marginTop: 1, fontWeight: '600' },
  tag: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  tagDot: { width: 8, height: 8, borderRadius: 4 },
  tagText: { fontSize: 12.5, fontWeight: '800' },
  none: { padding: 14, fontSize: 13, color: '#77889D' },
  page: { flex: 1, backgroundColor: '#FFFFFF', padding: 16, paddingTop: 44 },
  pageHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  pageTitle: { fontSize: 18, fontWeight: '800', color: '#102A45' },
});
