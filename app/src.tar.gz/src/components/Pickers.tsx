import DateTimePicker, { DateTimePickerEvent } from '@react-native-community/datetimepicker';
import { Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { Modal, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { fmtISODate, hhmmTo12, hhmmToLocalDate, isoToLocalDate, localDateISO, localTimeHHMM, MONTHS } from '../lib/time';
import { C } from '../theme';
import { Button, Label } from './ui';

// One look for every drop-down in the app: small, light blue, blue border and arrow
const DD_BG = '#EAF3FF';
const DD_BORDER = '#B9D4F6';
const DD_TEXT = '#0E3F7A';
// every control (drop-down, date / time field, text box, button) has the same height and corners
export const CTRL_H = Platform.OS === 'web' ? 44 : 48; // 48 dp = comfortable touch target on phones
export const CTRL_R = 12;

/** Compact drop-down: a real <select> on the web, a pick-list sheet on phones */
export function Dropdown({ value, options, onChange, width, compact }: {
  value: number; options: { value: number; label: string; disabled?: boolean }[]; onChange: (v: number) => void; width: number | '100%';
  compact?: boolean;   // the height of a small button (34)
}) {
  const [open, setOpen] = useState(false);
  const label = options.find((o) => o.value === value)?.label ?? '';
  if (Platform.OS === 'web') {
    return React.createElement('select', {
      value,
      onChange: (e: any) => onChange(Number(e.target.value)),
      style: {
        width, height: compact ? 34 : CTRL_H, boxSizing: 'border-box', borderRadius: compact ? 10 : CTRL_R, border: `1px solid ${DD_BORDER}`, background: DD_BG, color: DD_TEXT, fontFamily: 'inherit',
        fontSize: 14, fontWeight: 700, padding: '0 12px', cursor: 'pointer', outline: 'none',
      },
    }, options.map((o) => React.createElement('option', { key: o.value, value: o.value, disabled: o.disabled }, o.label)));
  }
  return (
    <>
      <Pressable onPress={() => setOpen(true)} style={[st.drop, { width }, compact && { height: 34, borderRadius: 10 }]}>
        <Text style={st.dropText} numberOfLines={1}>{label}</Text>
        <Ionicons name="chevron-down" size={14} color={C.blue} />
      </Pressable>
      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable style={st.sheetBackdrop} onPress={() => setOpen(false)}>
          <View style={[st.sheet, { maxHeight: '60%' }]}>
            <ScrollView>
              {options.map((o) => (
                <Pressable key={o.value} disabled={o.disabled} onPress={() => { onChange(o.value); setOpen(false); }} style={[st.opt, o.disabled && { opacity: 0.4 }]}>
                  <Text style={[st.optText, o.value === value && { color: C.blue }]}>{o.label}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </Pressable>
      </Modal>
    </>
  );
}

/** Month / year picker:  <  [ December v ] [ 2026 v ]  >  (arrows still step one month) */
export function MonthPicker({ year, month, onChange }: {
  year: number; month: number; onChange: (y: number, m: number) => void;
}) {
  const step = (d: number) => {
    let m = month + d;
    let y = year;
    if (m < 1) { m = 12; y -= 1; }
    if (m > 12) { m = 1; y += 1; }
    onChange(y, m);
  };
  const thisYear = new Date().getFullYear();
  const first = Math.min(2020, year);
  const last = Math.max(thisYear + 1, year);
  const years = Array.from({ length: last - first + 1 }, (_, i) => ({ value: first + i, label: String(first + i) }));
  const months = MONTHS.map((n, i) => ({ value: i + 1, label: n }));
  return (
    <View style={st.monthRow}>
      <Pressable onPress={() => step(-1)} style={st.arrow} hitSlop={10}>
        <Ionicons name="chevron-back" size={20} color={C.ink} />
      </Pressable>
      <View style={{ flex: 1, flexDirection: 'row', gap: 8, marginHorizontal: 8, minWidth: 0 }}>
        <View style={{ flex: 2, minWidth: 0 }}>
          <Dropdown value={month} options={months} onChange={(m) => onChange(year, m)} width="100%" />
        </View>
        <View style={{ flex: 1.3, minWidth: 0 }}>
          <Dropdown value={year} options={years} onChange={(y) => onChange(y, month)} width="100%" />
        </View>
      </View>
      <Pressable onPress={() => step(1)} style={st.arrow} hitSlop={10}>
        <Ionicons name="chevron-forward" size={20} color={C.ink} />
      </Pressable>
    </View>
  );
}

/** "Day" drop-down for one month: All days, or a single date (1..last day of the month). 0 = all days. */
export function DayPicker({ year, month, value, onChange, allowNone }: {
  year: number; month: number; value: number; onChange: (day: number) => void;
  /** adds a first option "Select a day" (value -1) so the list can stay hidden until a choice is made */
  allowNone?: boolean;
}) {
  const last = new Date(year, month, 0).getDate();
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const options = [...(allowNone ? [{ value: -1, label: 'Select a day' }] : []), { value: 0, label: 'All days' }].concat(
    Array.from({ length: last }, (_, i) => ({ value: i + 1, label: `${i + 1} ${MONTHS[month - 1].slice(0, 3)} (${days[new Date(year, month - 1, i + 1).getDay()]})` })),
  );
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
      <Text style={{ fontSize: 12, fontWeight: '800', color: '#3A5068' }}>Day</Text>
      <Dropdown value={value > last ? 0 : value} options={options} onChange={onChange} width={allowNone ? 200 : 170} />
    </View>
  );
}
/** Same control under the name the Reports page imports */
export const MonthYearDropdowns = MonthPicker;

/** Tap-to-pick date ("YYYY-MM-DD") or time ("HH:MM") field that works on Android and iOS */
export function PickerField({ label, mode, value, onChange, maximumDate, minimumDate, flat, compact, clearable }: {
  label: string; mode: 'date' | 'time'; value: string; onChange: (v: string) => void;
  maximumDate?: Date; minimumDate?: Date;
  flat?: boolean; // no bottom margin / own label: for use inside a filter grid that supplies its own spacing
  compact?: boolean; // the height of a small button (34)
  clearable?: boolean; // web: the date can be cleared (empty value)
}) {
  const [open, setOpen] = useState(false);
  const [temp, setTemp] = useState<Date>(new Date());
  const asDate = mode === 'date' ? isoToLocalDate(value) : hhmmToLocalDate(value);
  const text = mode === 'date' ? fmtISODate(value) : hhmmTo12(value);
  const commit = (d: Date) => onChange(mode === 'date' ? localDateISO(d) : localTimeHHMM(d));

  // Browser: use the built-in date / time input
  if (Platform.OS === 'web') {
    return (
      <View style={{ marginBottom: flat ? 0 : 12, flex: 1 }}>
        <Label>{label}</Label>
        <input
          type={mode}
          value={value}
          max={mode === 'date' && maximumDate ? localDateISO(maximumDate) : undefined}
          min={mode === 'date' && minimumDate ? localDateISO(minimumDate) : undefined}
          onChange={(e) => (e.target.value || clearable) && onChange(e.target.value)}
          style={{
            width: '100%', boxSizing: 'border-box', backgroundColor: DD_BG, border: `1px solid ${DD_BORDER}`,
            borderRadius: compact ? 10 : CTRL_R, height: compact ? 34 : CTRL_H, padding: '0 12px', fontSize: compact ? 13 : 14, fontWeight: 700, color: DD_TEXT, fontFamily: 'inherit',
          }}
        />
      </View>
    );
  }

  const onAndroid = (e: DateTimePickerEvent, d?: Date) => {
    setOpen(false);
    if (e.type === 'set' && d) commit(d);
  };

  return (
    <View style={{ marginBottom: flat ? 0 : 12, flex: 1 }}>
      <Label>{label}</Label>
      <Pressable
        style={[st.field, compact && { height: 34, minHeight: 34, borderRadius: 10 }]}
        onPress={() => { setTemp(asDate); setOpen(true); }}
      >
        <Ionicons name={mode === 'date' ? 'calendar-outline' : 'time-outline'} size={18} color={C.blue} />
        <Text style={st.fieldText}>{text}</Text>
      </Pressable>

      {open && Platform.OS === 'android' ? (
        <DateTimePicker value={asDate} mode={mode} onChange={onAndroid} maximumDate={maximumDate} minimumDate={minimumDate} />
      ) : null}

      {Platform.OS === 'ios' ? (
        <Modal visible={open} transparent animationType="slide" onRequestClose={() => setOpen(false)}>
          <View style={st.sheetBackdrop}>
            <View style={st.sheet}>
              <Text style={st.sheetTitle}>{label}</Text>
              <DateTimePicker
                value={temp}
                mode={mode}
                display={mode === 'date' ? 'inline' : 'spinner'}
                onChange={(_e, d) => d && setTemp(d)}
                maximumDate={maximumDate}
                minimumDate={minimumDate}
              />
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
                <Button title="Cancel" variant="secondary" style={{ flex: 1 }} onPress={() => setOpen(false)} />
                <Button title="Done" style={{ flex: 1 }} onPress={() => { commit(temp); setOpen(false); }} />
              </View>
            </View>
          </View>
        </Modal>
      ) : null}
    </View>
  );
}

const st = StyleSheet.create({
  monthRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: C.white, borderRadius: 14, borderWidth: 1, borderColor: C.line, padding: 6, marginBottom: 12 },
  arrow: { width: CTRL_H, height: CTRL_H, borderRadius: CTRL_R, alignItems: 'center', justifyContent: 'center', backgroundColor: DD_BG },
  drop: { height: CTRL_H, borderRadius: CTRL_R, backgroundColor: DD_BG, borderWidth: 1, borderColor: DD_BORDER, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dropText: { fontSize: 14, fontWeight: '700', color: DD_TEXT, flexShrink: 1, marginRight: 6 },
  opt: { paddingVertical: 13, paddingHorizontal: 8, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  optText: { fontSize: 14, fontWeight: '700', color: C.ink },
  monthText: { fontSize: 16, fontWeight: '800', color: C.ink },
  field: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: DD_BG, borderWidth: 1, borderColor: DD_BORDER, borderRadius: CTRL_R, paddingHorizontal: 12, height: CTRL_H },
  fieldText: { fontSize: 14, color: DD_TEXT, fontWeight: '700' },
  ddRow: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  sheetBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(6,37,63,0.35)' },
  sheet: { backgroundColor: C.white, borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 16, paddingBottom: 34 },
  sheetTitle: { fontSize: 16, fontWeight: '800', color: C.ink, marginBottom: 6 },
});

