import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { api, LeaveRequest } from '../lib/api';
import { useAuth } from '../lib/auth';
import { LeaveRegRow, leaveRegisterPdf, leaveRegisterXlsx } from '../lib/leaveRegisterReport';
import { useRealtime } from '../lib/realtime';
import { errorText } from '../lib/supabase';
import { fmtTime12, istDateISO, MONTHS } from '../lib/time';
import { C } from '../theme';
import { Dropdown } from './Pickers';
import { Card, Empty, Pill } from './ui';
import { CompanyFilter } from './CompanyFilter';
import { headingOf, setReportCompany, useCompanies, useCompanyChoice } from '../lib/companies';

/** "Leaves (monthly)": Leave Approvals - Monthly. Filters + Download PDF / Excel (Leave Register). Only reads leave requests, approvals and balances. */
const STATUS = ['All statuses', 'Approved', 'Rejected', 'Waiting', 'Cancelled'] as const;
type St = (typeof STATUS)[number];
const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;
const statusOf = (l: LeaveRequest): LeaveRegRow['status'] => (l.status === 'Approved' ? 'Approved' : l.status === 'Rejected' ? 'Rejected' : /cancel/i.test(l.status) ? 'Cancelled' : 'Waiting');
const abbr = (t: string) => t.split(/\s+/).map((w) => w[0]?.toUpperCase() ?? '').join('');
const unitsOf = (l: LeaveRequest) => Number(l.units ?? l.days) || 0;
const typeOf = (l: LeaveRequest) => {
  if (l.leave_type === 'Loss of Pay') return l.half_part ? `Half day Unpaid - ${l.half_part === 'first' ? 'Morning' : 'Afternoon'}` : 'Unpaid (LOP)';
  return l.half_part || unitsOf(l) === 0.5 ? `Half day ${abbr(l.leave_type)}${l.half_part ? ` - ${l.half_part === 'first' ? 'Morning' : 'Afternoon'}` : ''}` : l.leave_type;
};
const bucketOf = (t: string): 'EL' | 'CL' | 'SL' | null => (/casual|^cl$/i.test(t) ? 'CL' : /sick|^sl$/i.test(t) ? 'SL' : /earned|privilege|^el$|^pl$/i.test(t) ? 'EL' : null);

export default function LeavesMonthlyPanel() {
  const { profile } = useAuth();
  const today = istDateISO();
  const [year, setYear] = useState(Number(today.slice(0, 4)));
  const [month, setMonth] = useState(Number(today.slice(5, 7)));
  const [status, setStatus] = useState<St>('All statuses');
  const [type, setType] = useState('All types');
  const [empId, setEmpId] = useState('');
  const [types, setTypes] = useState<string[]>([]);
  const [rows, setRows] = useState<LeaveRequest[] | null>(null);
  const [busy, setBusy] = useState<'' | 'pdf' | 'xlsx'>('');
  const [progress, setProgress] = useState('');
  const co = useCompanies();
  const [coSel, setCoSel] = useCompanyChoice();

  const mm = String(month).padStart(2, '0');
  const first = `${year}-${mm}-01`;
  const last = `${year}-${mm}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}`;
  const running = today >= first && today < last;
  const to = running ? today : last;

  useEffect(() => { api.leaveTypes().then((l) => setTypes(l.map((x) => x.name))).catch(() => {}); }, []);
  const load = useCallback(async () => {
    try { setRows(await api.leavesForRegister(first, last)); } catch (e) { setRows([]); Alert.alert('Could not load', errorText(e)); }
  }, [first, last]);
  useEffect(() => { setRows(null); load(); }, [load]);
  useRealtime('leaves-monthly', [{ table: 'leaves' }], () => load());

  const rowsC = rows;   // the screen lists everybody; the Company choice only applies to the downloaded report
  const people = useMemo(() => {
    const m = new Map<string, { id: string; name: string; empId: string }>();
    (rowsC ?? []).forEach((l) => m.set(l.user_id, { id: l.user_id, name: l.employee?.full_name ?? 'Employee', empId: l.employee?.username ?? '' }));
    return [...m.values()].sort((a, b) => a.name.localeCompare(b.name));
  }, [rowsC]);
  useEffect(() => { if (empId && !people.some((p) => p.id === empId)) setEmpId(''); }, [people, empId]);

  const shown = useMemo(() => (rowsC ?? []).filter((l) =>
    (status === 'All statuses' || statusOf(l) === status)
    && (type === 'All types' || (type === 'Half day' ? !!l.half_part || unitsOf(l) === 0.5 : l.leave_type === type))
    && (!empId || l.user_id === empId))
    .sort((a, b) => (a.employee?.full_name ?? '').localeCompare(b.employee?.full_name ?? '') || a.from_day.localeCompare(b.from_day)), [rowsC, status, type, empId]);
  const cnt = (s: LeaveRegRow['status']) => shown.filter((l) => statusOf(l) === s).length;
  const typeOpts = ['All types', ...types, 'Half day'];

  const years = Array.from({ length: Math.max(Number(today.slice(0, 4)), year) - 2024 + 1 }, (_, i) => ({ value: 2024 + i, label: String(2024 + i) }));
  const tY = Number(today.slice(0, 4)); const tM = Number(today.slice(5, 7));
  const monthOpts = MONTHS.map((n, i) => ({ value: i + 1, label: n, disabled: year > tY || (year === tY && i + 1 > tM) }));
  const chip = running ? `Month in progress · ${dmy(first)} to ${dmy(to)}` : `${dmy(first)} to ${dmy(last)}`;

  const download = async (kind: 'pdf' | 'xlsx') => {
    if (busy) return;
    // a leave belongs to the company the employee was in on the leave's first day
    const shownD = coSel ? shown.filter((l) => co.companyAt(l.user_id, l.from_day) === coSel) : shown;
    setReportCompany(headingOf(co.companies, coSel));
    const cntD = (x: LeaveRegRow['status']) => shownD.filter((l) => statusOf(l) === x).length;
    if (shownD.length === 0) return Alert.alert('Nothing to export', 'No leave requests for these filters.');
    setBusy(kind); setProgress('Preparing...');
    try {
      // paid / unpaid split of every request: the same numbers the Approvals screen uses (leave_review_info / leave_preview)
      const split = new Map<number, { pay: string; paid: number; unpaid: number; uses?: { EL: number; CL: number; SL: number; LOP: number } }>();
      let done = 0;
      for (let i = 0; i < shownD.length; i += 6) {
        await Promise.all(shownD.slice(i, i + 6).map(async (l) => {
          try {
            if (l.policy_v2) {
              const u = (await api.leaveReviewInfo(l.id)).uses;
              const parts = (['EL', 'CL', 'SL'] as const).filter((k) => u[k] > 0).map((k) => `${u[k]} ${k}`);
              if (u.LOP > 0) parts.push(`${u.LOP} Unpaid`);
              split.set(l.id, { pay: parts.join(' + '), paid: u.EL + u.CL + u.SL, unpaid: u.LOP, uses: u });
            } else {
              const d = await api.leavePreview(l.leave_type, l.from_day, l.to_day, l.user_id);
              const paid = d.filter((x) => x.status === 'Paid').length; const unpaid = d.filter((x) => x.status === 'Unpaid').length;
              split.set(l.id, { pay: unpaid === 0 ? `${paid} Paid` : paid === 0 ? `${unpaid} Unpaid` : `${paid} Paid + ${unpaid} Unpaid`, paid, unpaid });
            }
          } catch { /* split not available for this request */ }
          done += 1; setProgress(`Preparing... ${done} / ${shownD.length}`);
        }));
      }
      const regRows: LeaveRegRow[] = shownD.map((l) => {
        const s = statusOf(l);
        const who = l.reviewer?.full_name ?? '';
        const when = l.reviewed_at ? ` (${dmy(istDateISO(l.reviewed_at))} ${fmtTime12(l.reviewed_at)})` : '';
        const by = s === 'Waiting' ? '-' : `${who || (s === 'Cancelled' ? 'Cancelled' : '-')}${who ? when : ''}${(s === 'Rejected' || s === 'Cancelled') && l.review_note ? `\n${l.review_note}` : ''}`;
        return {
          name: l.employee?.full_name ?? '', empId: l.employee?.username ?? '', type: typeOf(l), from: dmy(l.from_day), to: dmy(l.to_day), days: unitsOf(l),
          pay: split.get(l.id)?.pay ?? '', reason: (l.reason ?? '').trim() || '-', applied: dmy(istDateISO(l.created_at)), status: s, by,
        };
      });
      // approved: days and paid / unpaid for the summary row
      const ap = shownD.filter((l) => statusOf(l) === 'Approved');
      const apDays = ap.reduce((a, l) => a + unitsOf(l), 0);
      const apPaid = ap.reduce((a, l) => a + (split.get(l.id)?.paid ?? 0), 0); const apUnpaid = ap.reduce((a, l) => a + (split.get(l.id)?.unpaid ?? 0), 0);
      const n = (v: number) => String(Number(v.toFixed(2)));
      const summary = `Requests ${shownD.length} | Approved ${ap.length} (${n(apDays)} days: Paid ${n(apPaid)}, Unpaid ${n(apUnpaid)}) | Rejected ${cntD('Rejected')} | Waiting ${cntD('Waiting')}${cntD('Cancelled') ? ` | Cancelled ${cntD('Cancelled')}` : ''}`;
      const monthName = `${MONTHS[month - 1]} ${year}`;
      const nm = empId ? people.find((p) => p.id === empId)?.name ?? '' : '';
      const info = {
        title: `Leave Register - Monthly (${nm ? nm : 'All Employees'})`, period: `${dmy(first)} to ${dmy(to)}${running ? ' (Month in progress - up to today)' : ''}${status !== 'All statuses' ? ` · ${status}` : ''}${type !== 'All types' ? ` · ${type}` : ''}`,
        month: `${monthName}.`, generated: `${dmy(today)} ${fmtTime12(new Date())}`, by: profile?.full_name, summary, footer: `Leave Register - Monthly · ${monthName}`,
      };
      const file = `cvp_leave_register_${nm ? nm.trim().replace(/[^A-Za-z0-9]+/g, '_') : 'all'}_${year}-${mm}`;
      setProgress(kind === 'pdf' ? 'Creating the PDF...' : 'Creating the Excel file...');
      if (kind === 'pdf') await leaveRegisterPdf(`${file}.pdf`, info, regRows); else await leaveRegisterXlsx(`${file}.xlsx`, info, regRows);
    } catch (e) { Alert.alert('Could not create the report', errorText(e)); }
    finally { setBusy(''); setProgress(''); }
  };

  const Fld = ({ n, label, children }: { n: number; label: string; children: React.ReactNode }) => (
    <View style={{ flexGrow: 1, flexBasis: 150, minWidth: 140 }}>
      <View style={st.lblRow}><View style={st.badge}><Text style={st.badgeTx}>{n}</Text></View><Text style={st.lbl}>{label}</Text></View>
      {children}
    </View>
  );
  const btn = (k: 'pdf' | 'xlsx', label: string, green: boolean) => (
    <Pressable disabled={!!busy} onPress={() => download(k)} accessibilityRole="button"
      style={[st.dl, green ? { borderColor: '#1E7B45', backgroundColor: '#fff' } : { borderColor: C.blue, backgroundColor: C.blue }, !!busy && { opacity: 0.6 }]}>
      <Text style={[st.dlTx, { color: green ? '#1E7B45' : '#fff' }]}>{busy === k ? progress || 'Preparing...' : `⬇ ${label}`}</Text>
    </Pressable>
  );

  return (
    <View>
      <Text style={st.title}>Leave Approvals - Monthly</Text>
      <Card>
                <View style={st.row}>
          <Fld n={1} label="YEAR"><Dropdown width="100%" value={year} options={years} onChange={(y) => { setYear(y); if (y === tY && month > tM) setMonth(tM); }} /></Fld>
          <Fld n={2} label="MONTH"><Dropdown width="100%" value={month} options={monthOpts} onChange={setMonth} /></Fld>
          <Fld n={3} label="STATUS"><Dropdown width="100%" value={STATUS.indexOf(status)} options={STATUS.map((s, i) => ({ value: i, label: s }))} onChange={(i) => setStatus(STATUS[i])} /></Fld>
          <Fld n={4} label="LEAVE TYPE"><Dropdown width="100%" value={typeOpts.indexOf(type)} options={typeOpts.map((s, i) => ({ value: i, label: s }))} onChange={(i) => setType(typeOpts[i])} /></Fld>
          <Fld n={5} label="EMPLOYEE"><Dropdown width="100%" value={empId ? people.findIndex((p) => p.id === empId) + 1 : 0} onChange={(i) => setEmpId(i > 0 ? people[i - 1].id : '')}
            options={[{ value: 0, label: 'All employees' }, ...people.map((p, i) => ({ value: i + 1, label: p.name }))]} /></Fld>
        </View>
        <View style={st.sep} />
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
          <View style={{ flexShrink: 1, gap: 4 }}>
            <View style={st.chip}><Text style={st.chipTx}>{chip}</Text></View>
            <Text style={st.sub}>{shown.length} leave request{shown.length === 1 ? '' : 's'} {'·'} {cnt('Approved')} approved {'·'} {cnt('Rejected')} rejected {'·'} {cnt('Waiting')} waiting</Text>
          </View>
          <View style={{ gap: 10 }}>
            <View style={{ minWidth: 240 }}><CompanyFilter companies={co.companies} value={coSel} onChange={setCoSel} /></View>
            <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>{btn('pdf', 'Download PDF', false)}{btn('xlsx', 'Download Excel', true)}</View>
          </View>
        </View>
      </Card>

      <Card style={{ marginTop: 12, paddingVertical: 4 }}>
        {!rowsC ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : shown.length === 0 ? <Empty icon="calendar-outline" text="No leave requests for these filters." /> : shown.map((l) => {
          const s = statusOf(l);
          return (
            <View key={l.id} style={st.item}>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={st.name} numberOfLines={1}>{l.employee?.full_name ?? 'Employee'} <Text style={st.sub}>{l.employee?.username ?? ''}</Text></Text>
                <Text style={st.sub} numberOfLines={1}>{typeOf(l)} {'·'} {dmy(l.from_day)} to {dmy(l.to_day)} {'·'} {unitsOf(l)} day(s) {'·'} applied {dmy(istDateISO(l.created_at))}</Text>
              </View>
              <Pill text={s} tone={s === 'Approved' ? 'green' : s === 'Rejected' ? 'red' : s === 'Waiting' ? 'amber' : 'muted'} />
            </View>
          );
        })}
      </Card>
    </View>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 14, fontWeight: '800', color: '#102A45', marginBottom: 8, marginTop: 4 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  lblRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  badge: { width: 18, height: 18, borderRadius: 9, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center' },
  badgeTx: { color: '#fff', fontSize: 10.5, fontWeight: '800' },
  lbl: { fontSize: 11.5, fontWeight: '800', color: '#5A6F86', letterSpacing: 0.4 },
  sep: { borderTopWidth: 1, borderTopColor: '#E6EDF5', borderStyle: 'dashed', marginVertical: 12 },
  chip: { backgroundColor: '#FFF1DC', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6, alignSelf: 'flex-start' },
  chipTx: { fontSize: 12.5, fontWeight: '700', color: '#9A5B00' },
  sub: { fontSize: 12.5, fontWeight: '600', color: C.muted },
  dl: { paddingHorizontal: 18, height: 44, borderRadius: 10, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  dlTx: { fontSize: 14, fontWeight: '800' },
  item: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  name: { fontWeight: '800', color: '#102A45', fontSize: 14 },
});
