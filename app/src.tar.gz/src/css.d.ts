﻿declare module '*.css';
