// CVP visual system (from the approved Streamlit design references)
export const C = {
  ink: '#0B1F3A',
  navy: '#06253F',
  navy2: '#0A3658',
  blue: '#0B7CFF',
  blueSoft: '#E6F2FF',
  cyan: '#1BD2D0',
  cyanSoft: '#E5FBFB',
  green: '#12B76A',
  greenSoft: '#E9F9F1',
  red: '#F04452',
  redSoft: '#FFF0F1',
  amber: '#F7A600',
  amberSoft: '#FFF7E5',
  purple: '#7C4DFF',
  purpleSoft: '#F2EDFF',
  bg: '#F5F8FC',
  card: '#FFFFFF',
  muted: '#718097',
  line: '#E5EDF6',
  white: '#FFFFFF',
};

export const radius = { sm: 10, md: 14, lg: 18, xl: 24 };

export const shadow = {
  shadowColor: '#133558',
  shadowOpacity: 0.08,
  shadowRadius: 14,
  shadowOffset: { width: 0, height: 6 },
  elevation: 3,
};

export type Tone = 'blue' | 'green' | 'red' | 'amber' | 'purple' | 'cyan' | 'muted';

export const toneColors: Record<Tone, { fg: string; bg: string }> = {
  blue: { fg: C.blue, bg: C.blueSoft },
  green: { fg: C.green, bg: C.greenSoft },
  red: { fg: C.red, bg: C.redSoft },
  amber: { fg: '#C98400', bg: C.amberSoft },
  purple: { fg: C.purple, bg: C.purpleSoft },
  cyan: { fg: '#0FABB0', bg: C.cyanSoft },
  muted: { fg: C.muted, bg: '#EEF2F7' },
};

/** Colour used for each attendance / request status everywhere in the app */
export function statusTone(status?: string | null): Tone {
  switch (status) {
    case 'Present':
    case 'Approved':
      return 'green';
    case 'Checked In':
      return 'purple';
    case 'Absent':
    case 'Rejected':
      return 'red';
    case 'Leave':
    case 'Pending':
    case 'Late':
      return 'amber';
    case 'Holiday':
      return 'blue';
    case 'Not Checked In':
      return 'red';
    default:
      return 'muted';
  }
}
