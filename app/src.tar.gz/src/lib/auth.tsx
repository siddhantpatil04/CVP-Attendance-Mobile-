
import type { Session } from '@supabase/supabase-js';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';
import type { Profile } from './api';
import { errorText, supabase } from './supabase';
import { shownRole } from '../navigation/menu';

export type Portal = 'employee' | 'hr' | 'admin';

const PORTAL_LABEL: Record<Portal, string> = {
  employee: 'Employee',
  hr: 'HR',
  admin: 'Admin',
};

interface AuthState {
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  isAdmin: boolean;
  isFullAdmin: boolean;
  signIn: (login: string, password: string, portal: Portal) => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const Ctx = createContext<AuthState | null>(null);

async function loadProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (error) throw error;
  return data as Profile | null;
}

function readableLoginError(error: unknown): string {
  const message = errorText(error);

  if (/email logins are disabled/i.test(message)) {
    return (
      'Login is not available right now. Please contact your Admin.'
    );
  }

  if (/invalid login credentials/i.test(message)) {
    return 'Invalid username or password. Please check your login details.';
  }

  return message;
}

export function AuthProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function restoreSession() {
      try {
        const { data, error } = await supabase.auth.getSession();

        if (error) throw error;
        if (!mounted) return;

        setSession(data.session);

        if (data.session) {
          try {
            const p = await loadProfile(data.session.user.id);

            if (!mounted) return;

            if (p?.active) {
              setProfile(p);
            } else {
              await supabase.auth.signOut();
              setProfile(null);
            }
          } catch {
            // Keep the session if profile loading fails temporarily.
          }
        }
      } catch (error) {
        if (mounted) {
          console.warn('Session restore failed:', errorText(error));
        }
      } finally {
        if (mounted) setLoading(false);
      }
    }

    void restoreSession();

    const { data: subscription } = supabase.auth.onAuthStateChange(
      (_event, nextSession) => {
        setSession(nextSession);
        if (!nextSession) setProfile(null);
      },
    );

    return () => {
      mounted = false;
      subscription.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    const userId = session?.user.id;
    if (!userId) return;

    const channel = supabase
      .channel(`profile-${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${userId}`,
        },
        (payload) => {
          const updatedProfile = payload.new as Profile;

          if (!updatedProfile.active) {
            void supabase.auth.signOut();
            setProfile(null);
            return;
          }

          setProfile(updatedProfile);
        },
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [session?.user.id]);

  const signIn = useCallback(
    async (login: string, password: string, portal: Portal) => {
      const username = login.trim();

      if (!username || !password) {
        throw new Error('Enter your username and password.');
      }

      try {
        let email = username;

        // Resolve employee/admin usernames to their Auth email.
        if (!username.includes('@')) {
          const { data, error } = await supabase.rpc('login_email', {
            p_username: username,
          });

          if (error) throw error;

          if (typeof data !== 'string' || !data.trim()) {
            throw new Error(
              `Invalid ${PORTAL_LABEL[portal].toLowerCase()} username or password.`,
            );
          }

          email = data.trim();
        }

        // This still requires email/password authentication to be enabled
        // and the corresponding user to exist in Supabase Auth.
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (error) throw error;

        const currentProfile = await loadProfile(data.user.id);

        if (!currentProfile || !currentProfile.active) {
          await supabase.auth.signOut();
          if (currentProfile?.approval_status === 'Pending') {
            throw new Error('Your registration is waiting for Admin approval. You can sign in after it is approved.');
          }
          if (currentProfile?.approval_status === 'Rejected') {
            throw new Error('Your registration was not approved. Contact your Admin.');
          }
          throw new Error('Your account is inactive. Contact your administrator.');
        }

        // "Employee Sign In" accepts employees only. "I am Admin" accepts Admin AND HR.
        // What the person can do after sign-in always comes from the real role (HR opens the HR panel, Admin the Admin panel).
        const role = shownRole(currentProfile);   // a Project Manager with menu items signs in as an Employee
        const portalMatches = portal === 'employee' ? role === 'Employee' : role === 'Admin' || role === 'HR';

        if (!portalMatches) {
          await supabase.auth.signOut();
          throw new Error(
            role === 'Employee'
              ? 'This is an employee account. Use Employee Sign In.'
              : "This is an HR / Admin account. Tap Back and use 'I am Admin' to sign in.",
          );
        }

        setSession(data.session);
        setProfile(currentProfile);
      } catch (error) {
        throw new Error(readableLoginError(error));
      }
    },
    [],
  );

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setSession(null);
    setProfile(null);
  }, []);

  const refreshProfile = useCallback(async () => {
    if (!session) return;

    const currentProfile = await loadProfile(session.user.id);

    if (currentProfile?.active) {
      setProfile(currentProfile);
    } else {
      await supabase.auth.signOut();
      setSession(null);
      setProfile(null);
    }
  }, [session]);

  const isAdmin =
    profile?.role === 'Admin' || profile?.role === 'HR';
  const isFullAdmin = profile?.role === 'Admin' || profile?.role === 'HR';

  return (
    <Ctx.Provider
      value={{
        session,
        profile,
        loading,
        isAdmin,
        isFullAdmin,
        signIn,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useAuth(): AuthState {
  const value = useContext(Ctx);

  if (!value) {
    throw new Error('useAuth must be used inside AuthProvider');
  }

  return value;
}
