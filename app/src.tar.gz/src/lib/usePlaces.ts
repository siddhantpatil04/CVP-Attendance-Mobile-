import { useFocusEffect } from '@react-navigation/native';
import * as Location from 'expo-location';
import { useCallback, useEffect, useRef, useState } from 'react';
import { api, NearPlace, WorkingRule } from './api';
import { currentPosition } from './geo';
import { DEFAULT_RANGE_M, DEFAULT_REQUIRED_MIN } from './hours';
import { errorText } from './supabase';

/**
 * Places the employee may use RIGHT NOW (allocated sites + office, within the Admin range, nearest first).
 * Re-reads GPS every 30 seconds while the screen is open. Nothing is ever selected automatically.
 */
export function usePlaces(enabled: boolean, siteEmployee: boolean) {
  const [places, setPlaces] = useState<NearPlace[] | null>(null);
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rule, setRule] = useState<WorkingRule>({ kind: siteEmployee ? 'site' : 'office', range_m: DEFAULT_RANGE_M, required_minutes: DEFAULT_REQUIRED_MIN, before_required: 'reason' });
  const busy = useRef(false);

  const refresh = useCallback(async () => {
    if (!enabled || busy.current) return;
    busy.current = true;
    setLoading(true);
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (perm.status !== 'granted') throw new Error('Allow location access and turn on GPS to see the places near you.');
      const p = await currentPosition();
      const here = { lat: p.coords.latitude, lng: p.coords.longitude };
      setPos(here);
      setPlaces(await api.placesNearMe(here.lat, here.lng));
      setError(null);
    } catch (e) {
      setError(errorText(e));
    } finally {
      busy.current = false;
      setLoading(false);
    }
  }, [enabled]);

  // The Admin rules (range, required hours) are read each time the screen opens, so a change is followed on the next open
  useFocusEffect(useCallback(() => {
    api.workingRules().then((all) => {
      const mine = all.find((r) => r.kind === (siteEmployee ? 'site' : 'office'));
      if (mine) setRule(mine);
      // half the hours on the date of an approved half-day leave (leave_policy_24.sql)
      api.myRequiredToday().then((r) => { if (mine && r?.required_minutes) setRule({ ...mine, required_minutes: r.required_minutes }); }).catch(() => undefined);
    }).catch(() => undefined);
    refresh();
  }, [refresh, siteEmployee]));

  useEffect(() => {
    if (!enabled) return;
    const t = setInterval(refresh, 30000);
    return () => clearInterval(t);
  }, [enabled, refresh]);

  return { places, pos, loading, error, refresh, rule };
}
