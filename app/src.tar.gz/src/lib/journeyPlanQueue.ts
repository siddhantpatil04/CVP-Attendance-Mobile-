import AsyncStorage from '@react-native-async-storage/async-storage';
import { api, PlanChangeInput } from './api';
import { errorText } from './supabase';

export const isNetworkMessage = (msg: string) => /No internet|network is too slow|Failed to fetch|Network request failed|timed out|timeout/i.test(msg);

const KEY = 'fsj_pending_plan_changes';

/** Plan changes made with no internet wait here, with their ORIGINAL time and GPS, and are sent when the network is back */
export async function readPendingChanges(): Promise<PlanChangeInput[]> {
  try { const v = await AsyncStorage.getItem(KEY); return v ? (JSON.parse(v) as PlanChangeInput[]) : []; } catch { return []; }
}
async function writePending(list: PlanChangeInput[]) {
  try { await AsyncStorage.setItem(KEY, JSON.stringify(list)); } catch { /* storage full: nothing more can be done */ }
}
export async function queuePlanChange(c: PlanChangeInput) {
  const cur = await readPendingChanges();
  if (!cur.some((x) => x.key === c.key)) await writePending([...cur, c]);
}

/**
 * Sends the waiting changes in the order they were made. A change that failed only because of the network stays;
 * one the server refuses (for example the journey is already finished) is dropped and reported.
 */
export async function flushPlanChanges(): Promise<{ sent: number; left: number; refused: string[] }> {
  const list = await readPendingChanges();
  const keep: PlanChangeInput[] = [];
  const refused: string[] = [];
  let sent = 0;
  let offline = false;
  for (const c of list) {
    if (offline) { keep.push(c); continue; }
    try { await api.changeJourneyPlan(c); sent++; }
    catch (e) {
      const msg = errorText(e);
      if (isNetworkMessage(msg)) { offline = true; keep.push(c); } else refused.push(msg);
    }
  }
  if (sent > 0 || refused.length > 0) await writePending(keep);
  return { sent, left: keep.length, refused };
}
