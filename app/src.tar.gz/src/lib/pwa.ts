import { Platform } from 'react-native';

/**
 * Web only: makes the site installable as a desktop app (Edge / Chrome: Install CVP Attendance) and registers the
 * service worker that always fetches the newest files, so every desktop gets the latest version.
 */
export function setupPwa() {
  if (Platform.OS !== 'web' || typeof document === 'undefined') return;

  if (!document.querySelector('link[rel="manifest"]')) {
    const link = document.createElement('link');
    link.rel = 'manifest';
    link.href = '/manifest.webmanifest';
    document.head.appendChild(link);
  }
  if (!document.querySelector('meta[name="theme-color"]')) {
    const meta = document.createElement('meta');
    meta.name = 'theme-color';
    meta.content = '#06253F';
    document.head.appendChild(meta);
  }

  // iPhone / iPad (Safari "Add to Home Screen"): app icon, full-screen mode and name under the icon
  const addMeta = (name: string, content: string) => {
    if (!document.querySelector(`meta[name="${name}"]`)) {
      const m = document.createElement('meta');
      m.name = name;
      m.content = content;
      document.head.appendChild(m);
    }
  };
  addMeta('apple-mobile-web-app-capable', 'yes');
  addMeta('mobile-web-app-capable', 'yes');
  addMeta('apple-mobile-web-app-title', 'CVP Attendance');
  addMeta('apple-mobile-web-app-status-bar-style', 'default');
  if (!document.querySelector('link[rel="apple-touch-icon"]')) {
    const icon = document.createElement('link');
    icon.rel = 'apple-touch-icon';
    icon.href = '/icon-192.png';
    document.head.appendChild(icon);
  }

  if ('serviceWorker' in navigator) {
    const register = () =>
      navigator.serviceWorker.register('/sw.js').then((reg) => {
        // look for a new version every 5 minutes and whenever the window comes back to the front
        setInterval(() => reg.update().catch(() => {}), 5 * 60 * 1000);
        document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') reg.update().catch(() => {}); });
      }).catch(() => {});
    if (document.readyState === 'complete') register();
    else window.addEventListener('load', register);
  }
}
