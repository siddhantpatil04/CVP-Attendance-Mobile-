﻿import * as XLSX from 'xlsx-js-style';
import { COMPANY_ADDRESS, COMPANY_PAN } from '../config';
import { saveXlsxData } from './xlsx';
import { WAGE_RULES, WageRow } from './wages';

/** Same colours as the PDF reports and the company's wage sheet */
const AMBER = 'FFC000';
const YELLOW = 'FFFF00';
const TOTAL_FILL = 'FFF4CC';
const thin = { style: 'thin', color: { rgb: '3C3C3C' } } as const;
const BORDER = { top: thin, bottom: thin, left: thin, right: thin };
const font = (bold = false, sz = 10) => ({ name: 'Arial', sz, bold });
const centre = { horizontal: 'center', vertical: 'center', wrapText: true } as const;

const dmy = (iso: string) => (iso ? `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}` : '');
const col = (c: number) => XLSX.utils.encode_col(c);
/** Indian digit grouping (10,43,000) like the PDFs */
const NUM = '[>=10000000]##\\,##\\,##\\,##0;[>=100000]##\\,##\\,##0;##,##0';

type Cell = XLSX.CellObject;
const put = (ws: XLSX.WorkSheet, r: number, c: number, cell: Cell) => { ws[XLSX.utils.encode_cell({ r, c })] = cell; };
const txt = (v: string, style: object = {}): Cell => ({ t: 's', v, s: { font: font(), ...style } } as Cell);
const num = (v: number, style: object = {}): Cell => ({ t: 'n', v, z: NUM, s: { font: font(), ...style } } as Cell);
const fx = (f: string, v: number, style: object = {}): Cell => ({ t: 'n', f, v, z: NUM, s: { font: font(), ...style } } as Cell);

function finish(ws: XLSX.WorkSheet, rows: number, cols: number, merges: XLSX.Range[], widths: number[]) {
  ws['!ref'] = XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: rows - 1, c: cols - 1 } });
  ws['!merges'] = merges;
  ws['!cols'] = widths.map((wch) => ({ wch }));
  (ws as any)['!pageSetup'] = { orientation: 'landscape', paperSize: 9, fitToWidth: 1, fitToHeight: 0 };
  (ws as any)['!sheetPr'] = { pageSetUpPr: { fitToPage: true } };
}

/**
 * "Muster Roll cum Wages Register - FORM (II)": the same layout and colours as the PDF and the company's sheet.
 * Gross wages, days, professional tax and advance are typed values; everything else is an Excel formula,
 * so the sheet stays editable and recalculates (change a salary or the days and the wages, PF, ESIC and net follow).
 */
export async function wagesRegisterXlsx(fileName: string, monthLabel: string, rows: WageRow[], month: number) {
  const R = WAGE_RULES;
  const ptTop = month === 2 ? R.professionalTaxFeb : R.professionalTax;     // PT is higher in February
  const ws: XLSX.WorkSheet = {};
  const COLS = 28;
  const merges: XLSX.Range[] = [];
  const span = (r: number) => merges.push({ s: { r, c: 0 }, e: { r, c: COLS - 1 } });

  // ---- title block (rows 1-9 of the company sheet)
  for (let c = 0; c < COLS; c++) put(ws, 0, c, txt('', { fill: { fgColor: { rgb: YELLOW } } }));
  put(ws, 0, 0, txt('!! Shree !!', { fill: { fgColor: { rgb: YELLOW } }, font: font(true, 11), alignment: centre })); span(0);
  put(ws, 1, 0, txt('Muster Roll Cum Wages Register', { font: font(true, 11), alignment: centre })); span(1);
  put(ws, 2, 0, txt('FORM (II)', { font: font(true, 11), alignment: centre })); span(2);
  put(ws, 3, 0, txt('M.W. Rules 1963 Rule 27 (I)', { font: font(true, 10), alignment: centre })); span(3);
  put(ws, 5, 0, txt('Name of the Establishment -', { font: font(true) }));
  put(ws, 5, 3, txt('C.V.Patil & Associates', {}));
  put(ws, 5, 8, txt('Pan NO', { font: font(true) }));
  put(ws, 5, 10, txt(COMPANY_PAN, {}));
  put(ws, 5, 14, txt('For the Month of', { font: font(true, 11) }));
  put(ws, 5, 17, txt(monthLabel, { font: font(true, 12) }));
  put(ws, 7, 0, txt('Address of the Establishment -', { font: font(true) }));
  put(ws, 7, 3, txt(COMPANY_ADDRESS, {}));

  // ---- two header rows (rows 10-11): single cells merged downwards, "Deductions" merged across six columns
  const H = 9;
  const head1 = ['Sr. No.', 'Date of Joining', 'Date of Resignation', 'UAN No.', 'Full Name of the Employees', 'Male/ Female', 'Gross Wages', 'Total Days Present', 'Total Days',
    'Basic @ 50%', 'HRA@ 40%', 'Other Allowances', 'Total Gross Wages', 'Deductions', '', '', '', '', '', 'Total Deduct', 'Net Wages Paid',
    'PF Member (Y/N)', 'EPS Eligible (Y/N)', 'PF Wages (EPF/EDLI wages)', 'EPS Wages', 'Employer EPS 8.33%', 'Employer EPF 3.67% (diff)', 'Employer Cost (Gross + Er PF + Er ESIC)'];
  const head2 = ['PF Employee', 'PT', 'ESIC Employee', 'PF Employer', 'ESIC Employer', 'Advance'];
  const hs = { font: font(true), fill: { fgColor: { rgb: AMBER } }, border: BORDER, alignment: centre };
  for (let c = 0; c < COLS; c++) { put(ws, H, c, txt(head1[c], hs)); put(ws, H + 1, c, txt('', hs)); }
  head2.forEach((h, i) => put(ws, H + 1, 13 + i, txt(h, hs)));
  for (let c = 0; c < COLS; c++) if (c < 13 || c > 18) merges.push({ s: { r: H, c }, e: { r: H + 1, c } });
  merges.push({ s: { r: H, c: 13 }, e: { r: H, c: 18 } });

  // ---- one row per employee; the amounts are formulas that follow the company's rules
  const first = H + 2;
  const cs = { border: BORDER, alignment: { horizontal: 'center', vertical: 'center' } };
  const left = { border: BORDER, alignment: { horizontal: 'left', vertical: 'center' } };
  rows.forEach((w, i) => {
    const r = first + i; const n = r + 1;                       // n = Excel row number
    // same formulas as the Salary Sheet Calculator: Basic = Gross x Present / Total days x 50 %, HRA = 40 % of Basic, Other = 60 % of Basic
    put(ws, r, 0, num(i + 1, cs));
    put(ws, r, 1, txt(dmy(w.joining), cs));
    put(ws, r, 2, txt(dmy(w.resigned), cs));
    put(ws, r, 3, txt(w.uan, cs));
    put(ws, r, 4, txt(w.name, left));
    put(ws, r, 5, txt(w.gender, cs));
    put(ws, r, 6, num(w.gross, cs));
    put(ws, r, 7, num(w.daysPresent, cs));
    put(ws, r, 8, num(w.daysInMonth, cs));
    put(ws, r, 9, fx(`IF(AND(ISNUMBER(H${n}),ISNUMBER(G${n}),I${n}>0),ROUND(G${n}*H${n}/I${n}*${R.basicPct},0),0)`, w.basic, cs));
    put(ws, r, 10, fx(`ROUND(J${n}*${R.hraPct},0)`, w.hra, cs));
    put(ws, r, 11, fx(`ROUND(J${n}*${R.otherPct},0)`, w.other, cs));
    put(ws, r, 12, fx(`J${n}+K${n}+L${n}`, w.totalGross, cs));
    put(ws, r, 13, fx(`ROUND(X${n}*${R.pfPct},0)`, w.pfEmployee, cs));
    // Maharashtra PT slabs, the same formula as the Salary Sheet Calculator (E = M / F)
    put(ws, r, 14, fx(`IF(M${n}<=0,0,IF(UPPER(F${n})="F",IF(M${n}<=${R.ptWomenNil},0,${ptTop}),IF(M${n}<=${R.ptMenNil},0,IF(M${n}<=${R.ptMenMid},${R.ptMidAmount},${ptTop}))))`, w.pt, cs));
    put(ws, r, 15, fx(`IF(AND(ISNUMBER(G${n}),G${n}<=${R.esicSalaryLimit},M${n}>0),ROUNDUP(M${n}*${R.esicEmployeePct},0),0)`, w.esicEmployee, cs));
    put(ws, r, 16, fx(`ROUND(X${n}*${R.pfPct},0)`, w.pfEmployer, cs));
    put(ws, r, 17, fx(`IF(AND(ISNUMBER(G${n}),G${n}<=${R.esicSalaryLimit},M${n}>0),ROUNDUP(M${n}*${R.esicEmployerPct},0),0)`, w.esicEmployer, cs));
    put(ws, r, 18, num(w.advance, cs));
    put(ws, r, 19, fx(`N${n}+O${n}+P${n}+S${n}`, w.totalDeduct, cs));
    put(ws, r, 20, fx(`M${n}-T${n}`, w.net, { ...cs, font: font(true) }));
    // employer-side columns (U-AA): Y / N are typed, the rest are formulas
    put(ws, r, 21, txt(w.pfMember, cs));
    put(ws, r, 22, txt(w.epsEligible, cs));
    put(ws, r, 23, fx(`IF(UPPER(V${n})="Y",MIN(MAX(J${n},ROUND(M${n}/2,0)),${R.pfWageCeiling}),0)`, w.pfWages, cs));
    put(ws, r, 24, fx(`IF(UPPER(W${n})="Y",X${n},0)`, w.epsWages, cs));
    put(ws, r, 25, fx(`ROUND(Y${n}*${R.epsPct},0)`, w.employerEps, cs));
    put(ws, r, 26, fx(`Q${n}-Z${n}`, w.employerEpf, cs));
    put(ws, r, 27, fx(`M${n}+Q${n}+R${n}`, w.employerCost, cs));
  });

  // ---- total row (SUM formulas)
  const t = first + rows.length; const a = first + 1; const b = first + rows.length;
  const ts = { border: BORDER, fill: { fgColor: { rgb: TOTAL_FILL } }, font: font(true), alignment: { horizontal: 'center', vertical: 'center' } };
  for (let c = 0; c < COLS; c++) put(ws, t, c, txt('', ts));
  put(ws, t, 0, txt('TOTAL', { ...ts, alignment: { horizontal: 'right', vertical: 'center' } }));
  merges.push({ s: { r: t, c: 0 }, e: { r: t, c: 5 } });
  const sums: [number, number][] = [[6, 0], [7, 0], [9, 0], [10, 0], [11, 0], [12, 0], [13, 0], [14, 0], [15, 0], [16, 0], [17, 0], [18, 0], [19, 0], [20, 0], [23, 0], [24, 0], [25, 0], [26, 0], [27, 0]];
  const key: (keyof WageRow)[] = ['gross', 'daysPresent', 'basic', 'hra', 'other', 'totalGross', 'pfEmployee', 'pt', 'esicEmployee', 'pfEmployer', 'esicEmployer', 'advance', 'totalDeduct', 'net',
    'pfWages', 'epsWages', 'employerEps', 'employerEpf', 'employerCost'];
  sums.forEach(([c], k) => {
    const v = rows.reduce((s, w) => s + Number(w[key[k]] || 0), 0);
    put(ws, t, c, fx(`SUM(${col(c)}${a}:${col(c)}${b})`, v, ts));
  });

  finish(ws, t + 1, COLS, merges, [6, 12, 12, 15, 32, 8, 11, 9, 9, 11, 11, 12, 12, 11, 8, 10, 11, 10, 9, 11, 13, 10, 10, 14, 11, 12, 14, 16]);
  (ws as any)['!rows'] = [];
  (ws as any)['!rows'][H] = { hpt: 30 }; (ws as any)['!rows'][H + 1] = { hpt: 30 };
  (ws as any)['!freeze'] = { xSplit: 5, ySplit: H + 2 };
  (ws as any)['!views'] = [{ state: 'frozen', xSplit: 5, ySplit: H + 2 }];

  // a zero amount shows as a dash (like the company's sheet); the value itself stays 0 for the formulas
  const DASH = '[=0]"-";[>=100000]##\\,##\\,##0;##,##0';
  for (const k of Object.keys(ws)) { if (k[0] === '!') continue; const cell = ws[k] as XLSX.CellObject; if (cell.t === 'n') cell.z = DASH; }

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Wages Register');
  await saveXlsxData(fileName, XLSX.write(wb, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer);
}

/**
 * A plain report table in the same style (company name, title, amber header, bordered rows, bold total row).
 * Number columns in the total row are SUM formulas, so edited amounts keep adding up.
 */
export async function styledTableXlsx(
  fileName: string, sheetName: string, title: string, subtitle: string,
  head: string[], body: (string | number)[][], opts: { sumFrom?: number; rowSum?: { col: number; from: number; to: number } } = {},
) {
  const ws: XLSX.WorkSheet = {};
  const cols = head.length; const merges: XLSX.Range[] = [];
  const span = (r: number) => merges.push({ s: { r, c: 0 }, e: { r, c: cols - 1 } });
  for (let c = 0; c < cols; c++) put(ws, 0, c, txt('', { fill: { fgColor: { rgb: YELLOW } } }));
  put(ws, 0, 0, txt('!! Shree !!', { fill: { fgColor: { rgb: YELLOW } }, font: font(true, 11), alignment: centre })); span(0);
  put(ws, 1, 0, txt('C. V. PATIL & ASSOCIATES', { font: font(true, 13), alignment: centre })); span(1);
  put(ws, 2, 0, txt(title, { font: font(true, 11), alignment: centre })); span(2);
  put(ws, 3, 0, txt(subtitle, { font: font(true, 10), alignment: centre })); span(3);
  const H = 5;
  const hs = { font: font(true), fill: { fgColor: { rgb: AMBER } }, border: BORDER, alignment: centre };
  head.forEach((h, c) => put(ws, H, c, txt(h, hs)));
  const cs = { border: BORDER, alignment: { horizontal: 'center', vertical: 'center' } };
  const left = { border: BORDER, alignment: { horizontal: 'left', vertical: 'center' } };
  body.forEach((row, i) => row.forEach((v, c) => {
    const isNum = typeof v === 'number';
    const rs = opts.rowSum;
    if (rs && c === rs.col && isNum) {
      // a row total that follows the cells it adds up (e.g. the months of a yearly report)
      const x = H + 2 + i;
      put(ws, H + 1 + i, c, fx(`SUM(${col(rs.from)}${x}:${col(rs.to)}${x})`, v as number, { ...cs, font: font(true) }));
      return;
    }
    put(ws, H + 1 + i, c, isNum ? num(v as number, cs) : txt(String(v ?? ''), c === 1 || c === 0 ? left : cs));
  }));
  let last = H + body.length;
  if (opts.sumFrom !== undefined && body.length) {
    const t = last + 1; const ts = { border: BORDER, fill: { fgColor: { rgb: TOTAL_FILL } }, font: font(true), alignment: { horizontal: 'center', vertical: 'center' } };
    for (let c = 0; c < cols; c++) put(ws, t, c, txt('', ts));
    put(ws, t, 0, txt('TOTAL', { ...ts, alignment: { horizontal: 'left', vertical: 'center' } }));
    for (let c = opts.sumFrom; c < cols; c++) {
      const v = body.reduce((s, row) => s + Number(row[c] || 0), 0);
      put(ws, t, c, fx(`SUM(${col(c)}${H + 2}:${col(c)}${H + 1 + body.length})`, v, ts));
    }
    last = t;
  }
  const widths = head.map((h, c) => Math.min(34, Math.max(h.length + 3, ...body.map((r) => String(r[c] ?? '').length + 3), 9)));
  finish(ws, last + 1, cols, merges, widths);
  (ws as any)['!rows'] = []; (ws as any)['!rows'][H] = { hpt: 30 };
  (ws as any)['!views'] = [{ state: 'frozen', xSplit: 0, ySplit: H + 1 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0, 31));
  await saveXlsxData(fileName, XLSX.write(wb, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer);
}
