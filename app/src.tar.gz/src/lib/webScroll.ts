import { Platform } from 'react-native';

/**
 * WEB / DESKTOP (Electron) ONLY - four-direction scrolling. Nothing here runs on Android / iOS.
 *  - the page itself never scrolls (html, body, #root fill the window); every screen scrolls inside the app shell
 *  - thin CVP-style scrollbars (10 px, light grey, darker on hover) everywhere
 *  - a box that scrolls sideways (wide table) keeps its sideways scroll to itself (no page jump), and a box at its top / bottom
 *    hands the wheel to the page (vertical) - so only ONE vertical scrollbar is in use
 *  - keyboard: PgUp / PgDn / Home / End / arrows scroll the main area when nothing else has focus (arrows scroll a focused table sideways)
 */
if (Platform.OS === 'web' && typeof document !== 'undefined') {
  const css = `
    html, body, #root { height: 100%; width: 100%; }
    body { margin: 0; overflow: hidden; }
    #root { display: flex; flex-direction: column; min-height: 0; min-width: 0; }
    * { scrollbar-width: thin; scrollbar-color: #C5D0DD transparent; }
    *::-webkit-scrollbar { width: 10px; height: 10px; }
    *::-webkit-scrollbar-track { background: transparent; }
    *::-webkit-scrollbar-thumb { background: #C5D0DD; border-radius: 8px; border: 2px solid transparent; background-clip: content-box; }
    *::-webkit-scrollbar-thumb:hover { background: #9FB0C4; background-clip: content-box; }
    *::-webkit-scrollbar-corner { background: transparent; }
    /* wide boxes: sideways scroll stays inside the box */
    div[style*="overflow-x: auto"], div[style*="overflow-x: scroll"] { overscroll-behavior-x: contain; }
    /* dropdown lists scroll inside the list */
    select { max-height: 60vh; }
    html { scroll-behavior: auto; }
  `;
  const style = document.createElement('style');
  style.setAttribute('data-cvp', 'web-scroll');
  style.textContent = css;
  document.head.appendChild(style);

  /** the biggest element on the page that can scroll up / down (the current screen) */
  const mainScroller = (): HTMLElement | null => {
    let best: HTMLElement | null = null; let area = 0;
    document.querySelectorAll<HTMLElement>('#root div').forEach((el) => {
      if (el.scrollHeight <= el.clientHeight + 4) return;
      const oy = getComputedStyle(el).overflowY;
      if (oy !== 'auto' && oy !== 'scroll') return;
      const a = el.clientWidth * el.clientHeight;
      if (a > area) { area = a; best = el; }
    });
    return best;
  };
  document.addEventListener('keydown', (e) => {
    const t = e.target as HTMLElement | null;
    const tag = (t?.tagName ?? '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select' || t?.isContentEditable) return;   // typing keeps its keys
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const el = mainScroller(); if (!el) return;
    const page = el.clientHeight * 0.9;
    const k = e.key;
    if (k === 'PageDown') el.scrollBy({ top: page });
    else if (k === 'PageUp') el.scrollBy({ top: -page });
    else if (k === 'Home') el.scrollTo({ top: 0 });
    else if (k === 'End') el.scrollTo({ top: el.scrollHeight });
    else if (k === 'ArrowDown' && (!t || t === document.body)) el.scrollBy({ top: 48 });
    else if (k === 'ArrowUp' && (!t || t === document.body)) el.scrollBy({ top: -48 });
    else return;
    e.preventDefault();
  });
}
