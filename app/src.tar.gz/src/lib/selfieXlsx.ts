import { COMPANY_ADDRESS } from '../config';
import { saveXlsxData } from './xlsx';
import { hm, selfieEmpBlocks, weekday3 } from './wagesRegisterPdf';
import type { ForeignRow, SelfieReportInfo, SelfieRow } from './wagesRegisterPdf';

const BLACK = { argb: 'FF000000' };
const thin = { style: 'thin' as const, color: BLACK };
const BORDER = { top: thin, bottom: thin, left: thin, right: thin };

/**
 * Selfie Attendance Register as a real Excel file in the Muster Roll style, with the selfies embedded in the cells.
 * ExcelJS (browser build, pure JavaScript) is loaded only when this is called.
 */
export async function selfieReportXlsx(fileName: string, info: SelfieReportInfo, rows: SelfieRow[]) {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Selfie Attendance');
  const one = !!info.employee;

  const cols: { head: string; width: number; key: string }[] = [
    { head: 'Sr. No.', width: 8, key: 'sr' },
    ...(one ? [] : [{ head: 'Full Name of the Employee', width: 30, key: 'name' }, { head: 'Emp ID', width: 11, key: 'emp' }]),
    ...(info.showDate ? [{ head: 'Date', width: 13, key: 'date' }] : []),
    { head: 'Check-in Site', width: 28, key: 'inSite' },
    { head: 'Check-in Selfie', width: 14, key: 'inImg' }, { head: 'Check-in Time', width: 13, key: 'inTime' }, { head: 'Check-in Distance', width: 13, key: 'inDist' },
    { head: 'Check-out Site', width: 28, key: 'outSite' },
    { head: 'Check-out Selfie', width: 14, key: 'outImg' }, { head: 'Check-out Time', width: 13, key: 'outTime' }, { head: 'Check-out Distance', width: 13, key: 'outDist' },
    { head: 'Worked Hours', width: 18, key: 'worked' },
  ];
  const n = cols.length;
  cols.forEach((c, i) => { ws.getColumn(i + 1).width = c.width; });
  const font = (bold = false, size = 11) => ({ name: 'Calibri', size, bold, color: BLACK });
  const center = { horizontal: 'center' as const, vertical: 'middle' as const };

  // rows 1-4: Shree bar and the three title lines, no empty rows between the heading rows
  const line = (r: number, text: string, size: number, fill?: string) => {
    ws.mergeCells(r, 1, r, n);
    const c = ws.getCell(r, 1);
    c.value = text; c.font = font(true, size); c.alignment = center;
    if (fill) c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: fill } };
  };
  line(1, 'Selfie Attendance Register', 12);
  line(2, 'Check-in / Check-out with Selfie and GPS', 11);
  line(3, info.period, 11);

  // row 5: establishment | PAN | month   (label next to its value)
  const seg = (r: number, c1: number, c2: number, v: string, o: { bold?: boolean; size?: number } = {}) => {
    if (c2 > c1) ws.mergeCells(r, c1, r, c2);
    const c = ws.getCell(r, c1);
    c.value = v; c.font = font(!!o.bold, o.size ?? 11); c.alignment = { horizontal: 'left', vertical: 'middle' };
  };
  seg(4, 1, 2, 'Name of the Establishment -', { bold: true }); seg(4, 3, 4, 'C.V.Patil & Associates');
  seg(4, 8, 9, 'For the Month of', { bold: true, size: 13 }); seg(4, 10, n, info.month, { bold: true, size: 13 });
  seg(5, 1, 2, 'Address of the Establishment -', { bold: true }); seg(5, 3, n, COMPANY_ADDRESS);
  let HDR = 6;
  if (one) { seg(6, 1, n, `Name of the Employee - ${info.employee}`, { bold: true }); HDR = 7; }

  // column heading row: orange, bold, centred, wrapped, black borders
  const hr = ws.getRow(HDR);
  hr.height = 34;
  cols.forEach((c, i) => {
    const cell = hr.getCell(i + 1);
    cell.value = c.head; cell.font = font(true);
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFC000' } };
    cell.alignment = { ...center, wrapText: true }; cell.border = BORDER;
  });
  ws.autoFilter = { from: { row: HDR, column: 1 }, to: { row: HDR, column: n } };
  ws.views = [{ state: 'frozen', ySplit: HDR }];

  const IMG = 56;   // px; the row is a little taller
  const idx = (k: string) => cols.findIndex((c) => c.key === k);
  rows.forEach((r, i) => {
    const rowNo = HDR + 1 + i;
    const row = ws.getRow(rowNo);
    row.height = 48;   // points (about 64 px)
    const put = (k: string, v: string, bold = false, argb?: string, h: 'left' | 'center' = 'center') => {
      const c = row.getCell(idx(k) + 1);
      c.value = v; c.font = { ...font(bold), ...(argb ? { color: { argb } } : {}) };
      c.alignment = { horizontal: h, vertical: 'middle', wrapText: true };
    };
    put('sr', String(i + 1));
    if (!one) { put('name', r.name, false, undefined, 'left'); put('emp', r.empId); }
    if (info.showDate) put('date', r.date);
    put('inSite', r.inSite || '-', false, undefined, 'left');
    const diff = !!r.outSite && r.outSite.trim() !== r.inSite.trim();   // check-out at another site: bold blue
    put('outSite', r.outSite || '-', diff, diff ? 'FF1F4E9E' : undefined, 'left');
    // long site names wrap: the row grows with the longest one
    const lines = Math.max(1, ...['inSite', 'outSite'].map((k) => Math.ceil((k === 'inSite' ? r.inSite : r.outSite).length / (cols[idx(k)].width - 3))));
    row.height = Math.max(48, lines * 15 + 8);
    put('inTime', r.inTime || '-'); put('inDist', r.inDist || '-'); put('outTime', r.outTime || '-'); put('outDist', r.outDist || '-');
    const tone = r.workedTone === 'short' ? 'FFC00000' : r.workedTone === 'ok' ? 'FF0E7A4A' : undefined;
    put('worked', r.worked || '-', true, tone);
    cols.forEach((_, c) => { const cell = row.getCell(c + 1); cell.border = BORDER; });
    // selfies: embedded pictures; otherwise a short text in the cell
    const place = (k: 'inImg' | 'outImg', img: string | null, has: boolean) => {
      const col = idx(k);
      if (img) {
        const id = wb.addImage({ base64: img, extension: 'jpeg' });
        ws.addImage(id, { tl: { col: col + 0.22, row: rowNo - 1 + 0.07 }, ext: { width: IMG, height: IMG } });
        return;
      }
      const c = row.getCell(col + 1);
      c.value = has ? 'Photo not available' : (k === 'outImg' && !r.outTime ? 'Not checked out' : 'No selfie');
      c.font = { name: 'Calibri', size: 9, color: { argb: 'FF787878' } }; c.alignment = { ...center, wrapText: true };
    };
    place('inImg', r.inImg, r.inHas); place('outImg', r.outImg, r.outHas);
  });

  const data = await wb.xlsx.writeBuffer();
  const ab = data instanceof ArrayBuffer ? data : (data as any).buffer.slice((data as any).byteOffset, (data as any).byteOffset + (data as any).byteLength);
  await saveXlsxData(fileName, ab);
}

/**
 * ALL EMPLOYEES monthly / daily Excel: A-Z, a light-yellow summary row per employee, no name / ID on every row, 4 heading lines,
 * the same 11 columns and colours as the PDF, selfies embedded, frozen heading row, filters on it.
 */
export async function selfieAllXlsx(fileName: string, info: SelfieReportInfo, rows: SelfieRow[]) {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Selfie Attendance');
  const cols = [
    { head: 'Sr. No.', width: 8 }, { head: 'Date', width: 13 }, { head: 'Check-in Site', width: 30 }, { head: 'Check-in Selfie', width: 14 },
    { head: 'Check-in Time', width: 13 }, { head: 'Check-in Distance', width: 13 }, { head: 'Check-out Site', width: 30 }, { head: 'Check-out Selfie', width: 14 },
    { head: 'Check-out Time', width: 13 }, { head: 'Check-out Distance', width: 13 }, { head: 'Worked Hours', width: 18 },
  ];
  const n = cols.length;
  cols.forEach((c, i) => { ws.getColumn(i + 1).width = c.width; });
  const font = (bold = false, size = 11, argb = 'FF000000') => ({ name: 'Calibri', size, bold, color: { argb } });
  const merge = (r: number, c1: number, c2: number) => { if (c2 > c1) ws.mergeCells(r, c1, r, c2); return ws.getCell(r, c1); };

  // 4 compact heading lines, no Shree / PAN / "with Selfie and GPS"
  let c = merge(1, 1, n); c.value = 'Selfie Attendance Register - All Employees'; c.font = font(true, 13); c.alignment = { horizontal: 'center', vertical: 'middle' };
  c = merge(2, 1, n); c.value = info.period; c.font = font(true, 11); c.alignment = { horizontal: 'center', vertical: 'middle' };
  c = merge(3, 1, 2); c.value = 'Name of the Establishment -'; c.font = font(true); c.alignment = { vertical: 'middle' };
  c = merge(3, 3, 4); c.value = 'C.V.Patil & Associates'; c.font = font(); c.alignment = { vertical: 'middle' };
  c = merge(3, 8, n); c.value = `For the Month of -  ${info.month}`; c.font = font(true, 12); c.alignment = { horizontal: 'right', vertical: 'middle' };
  c = merge(4, 1, 2); c.value = 'Address of the Establishment -'; c.font = font(true); c.alignment = { vertical: 'middle' };
  c = merge(4, 3, n); c.value = COMPANY_ADDRESS; c.font = font(); c.alignment = { vertical: 'middle' };
  const HDR = 5;
  const hr = ws.getRow(HDR); hr.height = 30;
  cols.forEach((col, i) => {
    const cell = hr.getCell(i + 1);
    cell.value = col.head; cell.font = font(true);
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFC000' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true }; cell.border = BORDER;
  });
  ws.autoFilter = { from: { row: HDR, column: 1 }, to: { row: HDR, column: n } };
  ws.views = [{ state: 'frozen', ySplit: HDR }];

  const IMG = 46;
  let rowNo = HDR;
  for (const b of selfieEmpBlocks(rows)) {
    rowNo += 1;
    const g = merge(rowNo, 1, n);
    g.value = `${b.name} (${b.empId})   -   Days checked in ${b.checkedIn}   |   Checked out ${b.checkedOut}   |   No check-out ${b.noOut}   |   Total worked ${hm(b.mins)}`;
    g.font = font(true, 11); g.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF2CC' } }; g.alignment = { horizontal: 'left', vertical: 'middle' };
    for (let k = 1; k <= n; k++) ws.getCell(rowNo, k).border = BORDER;
    ws.getRow(rowNo).height = 22;
    b.rows.forEach((r, i) => {
      rowNo += 1;
      const row = ws.getRow(rowNo); row.height = 38;
      const lines = Math.max(1, Math.ceil(r.inSite.length / 27), Math.ceil(r.outSite.length / 27));
      if (lines > 2) row.height = Math.max(38, lines * 15 + 8);
      const put = (col: number, v: any, o: { bold?: boolean; argb?: string; left?: boolean } = {}) => {
        const cell = row.getCell(col);
        cell.value = v; cell.font = font(!!o.bold, 10, o.argb ?? 'FF000000');
        cell.alignment = { horizontal: o.left ? 'left' : 'center', vertical: 'middle', wrapText: true };
      };
      put(1, i + 1);
      row.getCell(2).value = { richText: [{ text: `${r.date}\n`, font: font(false, 10) }, { text: weekday3(r.date), font: font(false, 8, 'FF787878') }] };
      row.getCell(2).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      put(3, r.inSite || '-', { left: true });
      put(5, r.inTime || '-');
      put(6, r.inDist || '-', (r.inDistM ?? 0) > 200 ? { bold: true, argb: 'FFC00000' } : {});
      const diff = !!r.outSite && r.outSite.trim() !== r.inSite.trim();
      put(7, r.outSite || '-', { left: true, ...(diff ? { bold: true, argb: 'FF1F4E9E' } : {}) });
      put(9, r.outTime || '-');
      put(10, r.outDist || '-', (r.outDistM ?? 0) > 200 ? { bold: true, argb: 'FFC00000' } : {});
      put(11, r.worked || '-', { bold: true, argb: r.workedTone === 'short' ? 'FFC00000' : r.workedTone === 'ok' ? 'FF0E7A4A' : 'FF000000' });
      for (let k = 1; k <= n; k++) row.getCell(k).border = BORDER;
      const place = (col: number, img: string | null, has: boolean, isOut: boolean) => {
        if (img) { const id = wb.addImage({ base64: img, extension: 'jpeg' }); ws.addImage(id, { tl: { col: col - 1 + 0.22, row: rowNo - 1 + 0.08 }, ext: { width: IMG, height: IMG } }); return; }
        const cell = row.getCell(col);
        cell.value = has ? 'Photo not available' : (isOut && !r.outTime ? 'Not checked out' : 'No selfie');
        cell.font = font(false, 9, 'FF787878'); cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      };
      place(4, r.inImg, r.inHas, false); place(8, r.outImg, r.outHas, true);
    });
  }

  const data = await wb.xlsx.writeBuffer();
  const ab = data instanceof ArrayBuffer ? data : (data as any).buffer.slice((data as any).byteOffset, (data as any).byteOffset + (data as any).byteLength);
  await saveXlsxData(fileName, ab);
}

/** Foreign Location register as Excel: same columns as the PDF, selfies embedded, filters + frozen heading, sheet "Foreign Location" */
export async function selfieForeignXlsx(fileName: string, info: SelfieReportInfo, rows: ForeignRow[], grouped: boolean) {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Foreign Location');
  const cols: { head: string; width: number; key: string }[] = [
    { head: 'Sr. No.', width: 8, key: 'sr' },
    ...(grouped ? [] : [{ head: 'Name of the Employee', width: 28, key: 'emp' }]),
    ...(info.showDate ? [{ head: 'Date', width: 13, key: 'date' }] : []),
    { head: 'Foreign Place (entered + GPS address)', width: 36, key: 'place' },
    { head: 'Nearest Allotted Site', width: 28, key: 'near' },
    { head: 'Reason for Foreign Location', width: 40, key: 'reason' },
    { head: 'Check-in Time', width: 13, key: 'inT' }, { head: 'Check-in Selfie', width: 14, key: 'inI' },
    { head: 'Check-out Time', width: 13, key: 'outT' }, { head: 'Check-out Selfie', width: 14, key: 'outI' },
    { head: 'Worked Hours', width: 18, key: 'wk' },
  ];
  const n = cols.length;
  cols.forEach((c, i) => { ws.getColumn(i + 1).width = c.width; });
  const font = (bold = false, size = 11, argb = 'FF000000') => ({ name: 'Calibri', size, bold, color: { argb } });
  const merge = (r: number, c1: number, c2: number) => { if (c2 > c1) ws.mergeCells(r, c1, r, c2); return ws.getCell(r, c1); };
  let c = merge(1, 1, n); c.value = 'Selfie Attendance Register - Foreign Location'; c.font = font(true, 13); c.alignment = { horizontal: 'center', vertical: 'middle' };
  c = merge(2, 1, n); c.value = info.period; c.font = font(true, 11); c.alignment = { horizontal: 'center', vertical: 'middle' };
  c = merge(3, 1, 2); c.value = 'Name of the Establishment -'; c.font = font(true);
  c = merge(3, 3, 4); c.value = 'C.V.Patil & Associates'; c.font = font();
  c = merge(3, Math.max(5, n - 3), n); c.value = `For the Month of -  ${info.month}`; c.font = font(true, 12); c.alignment = { horizontal: 'right', vertical: 'middle' };
  c = merge(4, 1, 2); c.value = 'Address of the Establishment -'; c.font = font(true);
  c = merge(4, 3, n); c.value = COMPANY_ADDRESS; c.font = font();
  const HDR = 5;
  const hr = ws.getRow(HDR); hr.height = 32;
  cols.forEach((col, i) => {
    const cell = hr.getCell(i + 1);
    cell.value = col.head; cell.font = font(true);
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFC000' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true }; cell.border = BORDER;
  });
  ws.autoFilter = { from: { row: HDR, column: 1 }, to: { row: HDR, column: n } };
  ws.views = [{ state: 'frozen', ySplit: HDR }];
  const ix = (k: string) => cols.findIndex((x) => x.key === k) + 1;
  const IMG = 50; let rowNo = HDR; let cur = ''; let sr = 0;
  for (const r of rows) {
    const key = `${r.name}|${r.empId}`;
    if (grouped && key !== cur) {
      cur = key; sr = 0; rowNo += 1;
      const mine = rows.filter((x) => `${x.name}|${x.empId}` === key);
      const g = merge(rowNo, 1, n);
      g.value = `${r.name} (${r.empId})   -   Foreign location punches ${mine.length}   |   Checked out ${mine.filter((x) => x.outTime).length}   |   No check-out ${mine.filter((x) => x.inTime && !x.outTime).length}`;
      g.font = font(true, 11); g.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF2CC' } }; g.alignment = { horizontal: 'left', vertical: 'middle' };
      for (let k = 1; k <= n; k++) ws.getCell(rowNo, k).border = BORDER;
      ws.getRow(rowNo).height = 22;
    }
    sr += 1; rowNo += 1;
    const row = ws.getRow(rowNo);
    row.height = Math.max(42, Math.ceil(Math.max(r.reason.length / 38, r.place.length / 34, 2)) * 15 + 10);
    const put = (col: number, v: any, o: { bold?: boolean; argb?: string; left?: boolean; fill?: string } = {}) => {
      const cell = row.getCell(col);
      cell.value = v; cell.font = font(!!o.bold, 10, o.argb ?? 'FF000000');
      cell.alignment = { horizontal: o.left ? 'left' : 'center', vertical: 'middle', wrapText: true };
      if (o.fill) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: o.fill } };
    };
    put(ix('sr'), grouped ? sr : rows.indexOf(r) + 1);
    if (!grouped) put(ix('emp'), r.empId ? `${r.name}\n${r.empId}` : r.name, { left: true });
    if (info.showDate) put(ix('date'), r.date);
    put(ix('place'), r.gps ? `${r.place || '-'}\n${r.gps}` : (r.place || '-'), { left: true, bold: true, argb: 'FFC25A00' });
    put(ix('near'), r.nearDist ? `${r.nearSite || '-'}\n${r.nearDist}` : (r.nearSite || '-'), { left: true });
    put(ix('reason'), r.reason.trim() || 'No reason given', { left: true, fill: 'FFFFF7ED', argb: r.reason.trim() ? 'FF6E3200' : 'FF828282' });
    put(ix('inT'), r.inTime || '-'); put(ix('outT'), r.outTime || '-');
    put(ix('wk'), r.worked || '-', { bold: true, argb: r.workedTone === 'short' ? 'FFC00000' : r.workedTone === 'ok' ? 'FF0E7A4A' : r.workedTone === 'still' ? 'FFA86400' : 'FF000000' });
    for (let k = 1; k <= n; k++) row.getCell(k).border = BORDER;
    const place = (col: number, img: string | null, has: boolean, isOut: boolean) => {
      if (img) { const id = wb.addImage({ base64: img, extension: 'jpeg' }); ws.addImage(id, { tl: { col: col - 1 + 0.2, row: rowNo - 1 + 0.08 }, ext: { width: IMG, height: IMG } }); return; }
      const cell = row.getCell(col);
      cell.value = has ? 'Photo not available' : (isOut && !r.outTime ? 'Not checked out' : 'No selfie');
      cell.font = font(false, 9, 'FF787878'); cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    };
    place(ix('inI'), r.inImg, r.inHas, false); place(ix('outI'), r.outImg, r.outHas, true);
  }
  const data = await wb.xlsx.writeBuffer();
  const ab = data instanceof ArrayBuffer ? data : (data as any).buffer.slice((data as any).byteOffset, (data as any).byteOffset + (data as any).byteLength);
  await saveXlsxData(fileName, ab);
}
