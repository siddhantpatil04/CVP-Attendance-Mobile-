// Salary formulas that apply FROM a month (table salary_formulas, supabase/salary_formulas.sql). The calculator is in salaryEngine.ts.
// When the table cannot be read, today's formulas (STARTING_ITEMS) are used, so the salary never stops.
import { FormulaItem, STARTING_ITEMS } from './salaryEngine';
import { supabase } from './supabase';

export { computeSalary, STARTING_ITEMS } from './salaryEngine';
export type { FormulaItem } from './salaryEngine';

const START_DATE = '2000-01-01';
export interface MonthFormulas { items: FormulaItem[]; applyFrom: string; fromDatabase: boolean }
const cache = new Map<string, MonthFormulas>();
export const clearFormulaCache = () => cache.clear();

/** The formulas of one salary month: the saved row with the latest apply_from on or before that month */
export async function formulasForMonth(year: number, month: number): Promise<MonthFormulas> {
  const key = `${year}-${month}`;
  const hit = cache.get(key); if (hit) return hit;
  try {
    const { data, error } = await supabase.rpc('formulas_for_month', { p_month: `${year}-${String(month).padStart(2, '0')}-01` });
    if (error || !data?.formulas?.items) throw error ?? new Error('none');
    const r: MonthFormulas = { items: data.formulas.items as FormulaItem[], applyFrom: String(data.apply_from), fromDatabase: true };
    cache.set(key, r); return r;
  } catch { return { items: STARTING_ITEMS, applyFrom: START_DATE, fromDatabase: false }; }
}

/** Small footer of the Wage Register: "Salary formulas applied from 01-12-2026" */
export const footerText = (m: MonthFormulas) => (m.applyFrom <= START_DATE ? 'Salary formulas: starting formulas' : `Salary formulas applied from ${m.applyFrom.slice(8, 10)}-${m.applyFrom.slice(5, 7)}-${m.applyFrom.slice(0, 4)}`);

export const salaryFormulasApi = {
  /** the last finalized month, or null */
  lastFinalized: async (): Promise<{ year: number; month: number } | null> => {
    const { data } = await supabase.from('payroll_months').select('year, month').order('year', { ascending: false }).order('month', { ascending: false }).limit(1);
    return data && data[0] ? { year: data[0].year, month: data[0].month } : null;
  },
  save: async (applyFrom: string, items: FormulaItem[]) => {
    const { error } = await supabase.rpc('save_salary_formulas', { p_apply_from: applyFrom, p_formulas: { items } });
    if (error) throw error;
    clearFormulaCache();
  },
};
