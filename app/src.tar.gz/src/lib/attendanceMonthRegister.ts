import { rh } from './companies';
import { loadPdfLibs, outputPdf } from './pdf';
import { saveXlsxData } from './xlsx';
import { SELFIE_STATUS } from './wagesRegisterPdf';

/**
 * "Attendance Register - Monthly" of an employee (or of every employee of a selection): one row for EVERY date with both kinds of days
 * (decided per day by where the check-in was made - see attendanceKind.ts):
 * Sr. No. | Date | Day | Attendance at (Site / Office) | Site / Office | Check-in | Check-out | Worked Hours | Selfie | Daily Report
 * plus Sunday / holiday / leave / absent rows and a green summary row. Each date appears once.
 */
export interface MixedRow {
  date: string; day: string; at?: 'site' | 'office'; place: string;
  inTime: string; inDist: string; outTime: string; outDist: string; worked: string; tone: 'ok' | 'short' | 'still' | 'none';
  /** the check-out is the automatic one at 11:59 PM (forgotten check-out closed at day end) */ outAuto?: boolean;
  inImg: string | null; outImg: string | null; inHas: boolean; outHas: boolean;
  report: string; reportTone: 'ok' | 'bad' | 'grey' | 'none';
  /** the row matches the Records chip (Checked out / Short day ...): printed on light yellow */ hl?: boolean;
  status?: { kind: 'sun' | 'hol' | 'leave' | 'absent' | 'noreport'; text: string };
}
export interface MixedInfo { title: string; period: string; month: string; employee: string; generated: string; by?: string; summary: string }
export interface RegisterSummary { name: string; empId: string; type: string; officeDays: number; siteDays: number; short: number; noOut: number; absent: number; leave: number; worked: string }
export interface Register { sheet: string; info: MixedInfo; rows: MixedRow[]; sum: RegisterSummary }

const INK: [number, number, number] = [20, 20, 20];
const clean = (s: unknown) => String(s ?? '').replace(/[    ]/g, ' ');
const tone = (t: MixedRow['tone']): [number, number, number] => (t === 'ok' ? [14, 122, 74] : t === 'short' ? [192, 0, 0] : t === 'still' ? [168, 100, 0] : INK);
const rtone = (t: MixedRow['reportTone']): [number, number, number] => (t === 'ok' ? [14, 122, 74] : t === 'bad' ? [192, 0, 0] : t === 'grey' ? [110, 110, 110] : INK);
const HEAD = ['Sr. No.', 'Date', 'Day', 'Attendance at', 'Site / Office', 'Check-in', 'Check-out', 'Worked Hours', 'Selfie', 'Daily Report'];
const CW = [10, 22, 14, 24, 52, 26, 26, 26, 40, 41];
const IMG = 14;
const HL: [number, number, number] = [255, 250, 205];

function drawHeader(doc: any, info: MixedInfo, withEmployee: boolean) {
  const W = doc.internal.pageSize.getWidth();
  doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5);
  doc.text(clean(info.title), W / 2, 10, { align: 'center' });
  doc.setFontSize(9); doc.text('Check-in / Check-out - Site and Office days', W / 2, 15, { align: 'center' });
  doc.text(clean(info.period), W / 2, 20, { align: 'center' });
  doc.setFontSize(8); doc.text('Name of the Establishment -', 8, 26);
  doc.setFont('helvetica', 'normal'); doc.text(rh().name, 52, 26);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text('For the Month of -', 165, 26); doc.text(clean(info.month), 198, 26);
  doc.setFontSize(8); doc.text('Address of the Establishment -', 8, 31);
  doc.setFont('helvetica', 'normal'); doc.text(clean(rh().address), 52, 31);
  if (withEmployee) { doc.setFont('helvetica', 'bold'); doc.text(clean(`Name of the Employee - ${info.employee}`), 8, 36); }
}

/** one employee's register, starting at the top of the current page */
function drawRegister(doc: any, autoTable: any, info: MixedInfo, rows: MixedRow[]) {
  const body: any[][] = rows.map((r, i) => {
    if (r.status) {
      const col = SELFIE_STATUS[r.status.kind];
      return [String(i + 1), r.date, r.day, { content: clean(r.status.text), colSpan: 7, styles: { fillColor: col.fill, textColor: col.text, fontStyle: 'bold', halign: 'center' } }];
    }
    const out = r.outAuto ? { content: `${r.outTime} (auto)${r.outDist ? `\n${r.outDist}` : ''}`, styles: { textColor: [130, 130, 130] } } : `${r.outTime || '-'}${r.outDist ? `\n${r.outDist}` : ''}`;
    return [String(i + 1), r.date, r.day, r.at === 'office' ? 'Office' : 'Site', clean(r.place) || '-',
      `${r.inTime || '-'}${r.inDist ? `\n${r.inDist}` : ''}`, out, `${r.worked || '-'}${r.outAuto ? ' *' : ''}`,
      r.at === 'office' ? '-' : '', clean(r.report)];
  });
  body.push([{ content: clean(info.summary), colSpan: 10, styles: { fillColor: [226, 239, 218], textColor: INK, fontStyle: 'bold', halign: 'left' } }]);
  autoTable(doc, {
    startY: 39, head: [HEAD], body, theme: 'grid', showHead: 'everyPage',
    styles: { font: 'helvetica', fontSize: 7.5, cellPadding: 1.2, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', halign: 'center', overflow: 'linebreak', minCellHeight: 7 },
    headStyles: { fillColor: [255, 192, 0], textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle' },
    columnStyles: Object.fromEntries(CW.map((w, i) => [i, { cellWidth: w, halign: i === 4 ? 'left' : 'center' }])),
    margin: { left: 8, right: 8, top: 39, bottom: 14 }, rowPageBreak: 'avoid',
    didDrawPage: () => drawHeader(doc, info, true),
    willDrawCell: (d: any) => {
      if (d.section !== 'body') return;
      const r = rows[d.row.index]; if (!r || r.status) return;
      if (r.hl) d.cell.styles.fillColor = HL;
      if (d.column.index === 3) { d.cell.styles.fontStyle = 'bold'; d.cell.styles.textColor = r.at === 'office' ? [107, 47, 179] : [31, 78, 158]; }
      if (d.column.index === 7) { d.cell.styles.fontStyle = 'bold'; d.cell.styles.textColor = tone(r.tone); }
      if (d.column.index === 9) d.cell.styles.textColor = rtone(r.reportTone);
    },
    didParseCell: (d: any) => {
      if (d.section !== 'body' || d.column.index !== 8) return;
      const r = rows[d.row.index];
      if (r && !r.status && r.at !== 'office') d.cell.styles.minCellHeight = IMG + 5;   // room for the selfies
    },
    didDrawCell: (d: any) => {
      if (d.section !== 'body' || d.column.index !== 8) return;
      const r = rows[d.row.index]; if (!r || r.status || r.at === 'office') return;
      const onlyIn = !r.outTime;   // not checked out: the check-in selfie only
      const list: [string | null, boolean][] = onlyIn ? [[r.inImg, r.inHas]] : [[r.inImg, r.inHas], [r.outImg, r.outHas]];
      const GAP = 4; const total = list.length * IMG + (list.length - 1) * GAP;
      const x0 = onlyIn ? d.cell.x + 4 : d.cell.x + (d.cell.width - total) / 2;
      const y0 = d.cell.y + (d.cell.height - IMG) / 2;
      list.forEach(([img, has], k) => {
        const x = x0 + k * (IMG + GAP);
        if (img) {
          try {   // the whole selfie, kept in proportion and centred in its square
            const pr = doc.getImageProperties(img); const sc = Math.min(IMG / pr.width, IMG / pr.height);
            const w = pr.width * sc; const h = pr.height * sc;
            doc.addImage(img, 'JPEG', x + (IMG - w) / 2, y0 + (IMG - h) / 2, w, h); return;
          } catch { /* grey box */ }
        }
        doc.setDrawColor(150, 160, 170); doc.setLineDashPattern([1, 1], 0); doc.rect(x, y0, IMG, IMG); doc.setLineDashPattern([], 0);
        doc.setFontSize(5.5); doc.setTextColor(120, 120, 120);
        doc.text(has ? 'Photo not\navailable' : 'No selfie', x + IMG / 2, y0 + IMG / 2 - 1, { align: 'center' });
        doc.setTextColor(...INK); doc.setDrawColor(0, 0, 0);
      });
      if (onlyIn) { doc.setFontSize(6); doc.setFont('helvetica', 'normal'); doc.setTextColor(120, 120, 120); doc.text('Check-in\nselfie only', x0 + IMG + 4, d.cell.y + d.cell.height / 2 - 1); doc.setTextColor(...INK); }
    },
  });
}

function footers(doc: any, info: MixedInfo, anyAuto: boolean) {
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight(); const n = doc.getNumberOfPages();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.text(`A day is counted once: Site or Office, decided by where the check-in was made.${anyAuto ? '   * auto check-out at day end' : ''}`, 8, H - 6);
    doc.text(clean(`Generated ${info.generated}${info.by ? ` by ${info.by}` : ''} - Page ${i} of ${n}`), W - 8, H - 6, { align: 'right' });
  }
}

/** ONE employee */
export async function mixedMonthPdf(fileName: string, info: MixedInfo, rows: MixedRow[]) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  drawRegister(doc, autoTable, info, rows);
  footers(doc, info, rows.some((r) => r.outAuto));
  await outputPdf(fileName, doc);
}

/** ALL employees of the selection: first page = summary list, then each employee's register on a new page (A-Z) */
export async function registersPdf(fileName: string, info: MixedInfo, regs: Register[]) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const SH = ['Sr. No.', 'Employee', 'Office days', 'Site days', 'Short', 'No check-out', 'Absent', 'Leave', 'Total worked'];
  const SC = [12, 90, 24, 24, 20, 28, 20, 20, 43];
  autoTable(doc, {
    startY: 39, head: [SH], theme: 'grid', showHead: 'everyPage',
    body: regs.map((r, i) => [String(i + 1), clean(`${r.sum.name} (${r.sum.empId}) · ${r.sum.type}`), r.sum.officeDays, r.sum.siteDays, r.sum.short, r.sum.noOut, r.sum.absent, r.sum.leave, r.sum.worked]),
    styles: { font: 'helvetica', fontSize: 8, cellPadding: 1.6, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', halign: 'center' },
    headStyles: { fillColor: [255, 192, 0], textColor: INK, fontStyle: 'bold', halign: 'center' },
    columnStyles: Object.fromEntries(SC.map((w, i) => [i, { cellWidth: w, halign: i === 1 ? 'left' : 'center' }])),
    margin: { left: 8, right: 8, top: 39, bottom: 14 }, rowPageBreak: 'avoid',
    didDrawPage: () => { drawHeader(doc, { ...info, title: `${info.title} - All Employees` }, false); doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.text(clean(info.employee), 8, 36); },
  });
  for (const r of regs) { doc.addPage(); drawRegister(doc, autoTable, r.info, r.rows); }
  footers(doc, info, regs.some((r) => r.rows.some((x) => x.outAuto)));
  await outputPdf(fileName, doc);
}

// ---------------------------------------------------------------- Excel
function fillSheet(wb: any, ws: any, info: MixedInfo, rows: MixedRow[]) {
  const widths = [8, 13, 8, 15, 34, 18, 18, 16, 24, 30]; const n = widths.length;
  widths.forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  const BLACK = { argb: 'FF000000' }; const thin = { style: 'thin' as const, color: BLACK };
  const BORDER = { top: thin, bottom: thin, left: thin, right: thin };
  const font = (bold = false, argb = 'FF000000') => ({ name: 'Calibri', size: 11, bold, color: { argb } });
  const fill = (argb: string) => ({ type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb } });
  const center = { horizontal: 'center' as const, vertical: 'middle' as const, wrapText: true };
  let r = 0;
  const borders = () => { for (let k = 1; k <= n; k++) ws.getCell(r, k).border = BORDER; };
  const band = (text: string, bg: string | null, bold = true, align: 'left' | 'center' = 'left', border = true) => {
    r += 1; ws.mergeCells(r, 1, r, n);
    const c = ws.getCell(r, 1); c.value = text; c.font = font(bold); c.alignment = { horizontal: align, vertical: 'middle', wrapText: true };
    if (bg) c.fill = fill(bg);
    if (border) borders();
    ws.getRow(r).height = 20;
  };
  band(info.title, null, true, 'center', false); band('Check-in / Check-out - Site and Office days', null, true, 'center', false); band(info.period, null, true, 'center', false);
  band(`Name of the Establishment - ${rh().name}        For the Month of - ${info.month}`, null, true, 'left', false);
  band(`Name of the Employee - ${info.employee}`, null, true, 'left', false);
  r += 1; ws.getRow(r).height = 30;
  HEAD.forEach((h, i) => { const c = ws.getCell(r, i + 1); c.value = h; c.font = font(true); c.fill = fill('FFFFC000'); c.alignment = center; });
  borders();
  ws.views = [{ state: 'frozen', ySplit: r }];
  ws.pageSetup = { orientation: 'landscape', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: 0.3, right: 0.3, top: 0.5, bottom: 0.55, header: 0.2, footer: 0.25 } };
  const argbTone = (t: MixedRow['tone']) => (t === 'ok' ? 'FF0E7A4A' : t === 'short' ? 'FFC00000' : t === 'still' ? 'FFA86400' : 'FF000000');
  const argbRep = (t: MixedRow['reportTone']) => (t === 'ok' ? 'FF0E7A4A' : t === 'bad' ? 'FFC00000' : t === 'grey' ? 'FF6E6E6E' : 'FF000000');
  const IMGX = 52;
  rows.forEach((x, i) => {
    r += 1; const rn = r;
    const put = (c: number, v: any, o: { bold?: boolean; argb?: string; left?: boolean } = {}) => {
      const cell = ws.getCell(rn, c); cell.value = v; cell.font = font(!!o.bold, o.argb); cell.alignment = { horizontal: o.left ? 'left' : 'center', vertical: 'middle', wrapText: true };
      if (x.hl && !x.status) cell.fill = fill('FFFFFACD');
    };
    put(1, i + 1); put(2, x.date); put(3, x.day);
    if (x.status) {
      const col = SELFIE_STATUS[x.status.kind];
      ws.mergeCells(rn, 4, rn, n);
      const c = ws.getCell(rn, 4); c.value = x.status.text; c.fill = fill(col.argb); c.font = font(true, col.targb); c.alignment = center;
      ws.getRow(rn).height = 18; borders(); return;
    }
    put(4, x.at === 'office' ? 'Office' : 'Site', { bold: true, argb: x.at === 'office' ? 'FF6B2FB3' : 'FF1F4E9E' });
    put(5, x.place || '-', { left: true });
    put(6, `${x.inTime || '-'}${x.inDist ? `\n${x.inDist}` : ''}`);
    put(7, x.outAuto ? `${x.outTime} (auto)${x.outDist ? `\n${x.outDist}` : ''}` : `${x.outTime || '-'}${x.outDist ? `\n${x.outDist}` : ''}`, x.outAuto ? { argb: 'FF828282' } : {});
    put(8, `${x.worked || '-'}${x.outAuto ? ' *' : ''}`, { bold: true, argb: argbTone(x.tone) });
    put(10, x.report, { argb: argbRep(x.reportTone) });
    ws.getRow(rn).height = x.at === 'office' ? 32 : 54;
    if (x.at === 'office') put(9, '-', { argb: 'FF787878' });
    else if (!x.outTime) put(9, 'Check-in selfie only', { argb: 'FF787878' });
    // selfies: centred in the cell, in proportion, the same two pictures as the PDF (check-in only when not checked out)
    if (x.at !== 'office') {
      const imgsX = x.outTime ? [x.inImg, x.outImg] : [x.inImg];
      const colPx = 24 * 7 + 5; const size = 48; const gap = 8;
      const total = imgsX.length * size + (imgsX.length - 1) * gap; const left = x.outTime ? (colPx - total) / 2 : 6;
      imgsX.forEach((img, k) => {
        if (!img) return;
        ws.addImage(wb.addImage({ base64: img, extension: 'jpeg' }), { tl: { col: 8 + (left + k * (size + gap)) / colPx, row: rn - 1 + 0.1 }, ext: { width: size, height: size } });
      });
    }
    borders();
  });
  band(info.summary, 'FFE2EFDA');
  if (rows.some((x) => x.outAuto)) band('* auto check-out at day end', null, false, 'left', false);
}
async function save(wb: any, fileName: string) {
  const data = await wb.xlsx.writeBuffer();
  const ab = data instanceof ArrayBuffer ? data : (data as any).buffer.slice((data as any).byteOffset, (data as any).byteOffset + (data as any).byteLength);
  await saveXlsxData(fileName, ab);
}
async function newBook() {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  return new ExcelJS.Workbook();
}
const sheetName = (s: string, used: Set<string>) => {
  let base = s.replace(/[\\/?*[\]:]/g, ' ').trim().slice(0, 31) || 'Employee'; let n = base; let k = 2;
  while (used.has(n.toLowerCase())) { n = `${base.slice(0, 28)} ${k++}`; }
  used.add(n.toLowerCase()); return n;
};

export async function mixedMonthXlsx(fileName: string, info: MixedInfo, rows: MixedRow[]) {
  const wb = await newBook();
  fillSheet(wb, wb.addWorksheet(sheetName(info.employee.split(' (')[0], new Set())), info, rows);
  await save(wb, fileName);
}

/** ALL employees: first sheet "Summary", then one sheet per employee (sheet name = employee name) */
export async function registersXlsx(fileName: string, info: MixedInfo, regs: Register[]) {
  const wb = await newBook();
  const sm = wb.addWorksheet('Summary');
  const SH = ['Sr. No.', 'Employee', 'Type', 'Office days', 'Site days', 'Short', 'No check-out', 'Absent', 'Leave', 'Total worked'];
  [8, 34, 16, 13, 12, 9, 14, 10, 10, 16].forEach((w, i) => { sm.getColumn(i + 1).width = w; });
  const BLACK = { argb: 'FF000000' }; const thin = { style: 'thin' as const, color: BLACK }; const B = { top: thin, bottom: thin, left: thin, right: thin };
  const t = (r: number, text: string) => { sm.mergeCells(r, 1, r, SH.length); const c = sm.getCell(r, 1); c.value = text; c.font = { name: 'Calibri', size: 11, bold: true }; c.alignment = { horizontal: 'center', vertical: 'middle' }; };
  t(1, `${info.title} - All Employees`); t(2, 'Check-in / Check-out - Site and Office days'); t(3, info.period); t(4, info.employee);
  SH.forEach((h, i) => { const c = sm.getCell(6, i + 1); c.value = h; c.font = { name: 'Calibri', size: 11, bold: true }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFC000' } }; c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true }; c.border = B; });
  regs.forEach((r, i) => {
    const v = [i + 1, `${r.sum.name} (${r.sum.empId})`, r.sum.type, r.sum.officeDays, r.sum.siteDays, r.sum.short, r.sum.noOut, r.sum.absent, r.sum.leave, r.sum.worked];
    v.forEach((x, k) => { const c = sm.getCell(7 + i, k + 1); c.value = x as any; c.font = { name: 'Calibri', size: 11 }; c.alignment = { horizontal: k === 1 ? 'left' : 'center', vertical: 'middle' }; c.border = B; });
  });
  sm.views = [{ state: 'frozen', ySplit: 6 }];
  sm.pageSetup = { orientation: 'landscape', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0 };
  const used = new Set<string>(['summary']);
  for (const r of regs) fillSheet(wb, wb.addWorksheet(sheetName(r.sheet, used)), r.info, r.rows);
  await save(wb, fileName);
}
