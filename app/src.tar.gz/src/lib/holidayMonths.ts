import { MONTHS } from './time';

/** Month groups for a holiday drop-down: [{ key: '2026-10', label: 'October 2026 (2)' }, ...] in date order */
export function holidayMonths(rows: { day: string }[]): { key: string; label: string }[] {
  const m = new Map<string, number>();
  for (const r of rows) m.set(r.day.slice(0, 7), (m.get(r.day.slice(0, 7)) ?? 0) + 1);
  return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([key, n]) => ({
    key, label: `${MONTHS[Number(key.slice(5, 7)) - 1]} ${key.slice(0, 4)} (${n})`,
  }));
}
