import { COMPANY_ADDRESS, COMPANY_PAN } from '../config';
import { siteTextCell } from './dailyReportPdf';
import { loadPdfLibs, outputPdf } from './pdf';
import type { WageRow } from './wages';

const dmy = (iso: string) => (iso ? `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}` : '');
const money = (n: number) => (n ? n.toLocaleString('en-IN') : '0');
/** the wages register shows a zero amount as a dash, like the company's sheet */
const moneyDash = (n: number) => (n ? n.toLocaleString('en-IN') : '-');
const AMBER: [number, number, number] = [255, 192, 0];
const INK: [number, number, number] = [20, 20, 20];

/**
 * "Muster Roll cum Wages Register - FORM (II)" in the layout of the company's Excel sheet:
 * one landscape page set, serial no., joining date, UAN, name, M/F, wages, deductions, net wages.
 */
export async function wagesRegisterPdf(fileName: string, monthLabel: string, rows: WageRow[], total: WageRow) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();

  const header = () => {
    doc.setFillColor(255, 255, 0); doc.rect(8, 6, W - 16, 5, 'F');
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
    doc.text('!! Shree !!', W / 2, 9.8, { align: 'center' });
    doc.setFontSize(9);
    doc.text('Muster Roll Cum Wages Register', W / 2, 15, { align: 'center' });
    doc.text('FORM (II)', W / 2, 19.5, { align: 'center' });
    doc.setFontSize(8);
    doc.text('M.W. Rules 1963 Rule 27 (I)', W / 2, 24, { align: 'center' });
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
    doc.text('Name of the Establishment -', 10, 31); doc.setFont('helvetica', 'normal'); doc.text('C.V.Patil & Associates', 52, 31);
    doc.setFont('helvetica', 'bold'); doc.text('Pan NO', 130, 31); doc.setFont('helvetica', 'normal'); doc.text(COMPANY_PAN, 144, 31);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text(`For the Month of   ${monthLabel}`, W - 10, 31, { align: 'right' });
    doc.setFontSize(8);
    doc.text('Address of the Establishment -', 10, 36); doc.setFont('helvetica', 'normal'); doc.text(COMPANY_ADDRESS, 52, 36);
  };

  const num = (n: number) => ({ content: moneyDash(n), styles: { halign: 'right' as const } });
  const body: any[][] = rows.map((r, i) => [
    String(i + 1), dmy(r.joining), dmy(r.resigned), r.uan, r.name, r.gender,
    num(r.gross), String(r.daysPresent), String(r.daysInMonth), num(r.basic), num(r.hra), num(r.other), num(r.totalGross),
    num(r.pfEmployee), num(r.pt), num(r.esicEmployee), num(r.pfEmployer), num(r.esicEmployer), r.advance ? num(r.advance) : '-',
    num(r.totalDeduct), { content: moneyDash(r.net), styles: { halign: 'right', fontStyle: 'bold' } },
    r.pfMember, r.epsEligible, num(r.pfWages), num(r.epsWages), num(r.employerEps), num(r.employerEpf), num(r.employerCost),
  ]);
  const t = total;
  const bold = { fontStyle: 'bold' as const, fillColor: [255, 244, 204] as [number, number, number] };
  body.push([
    { content: 'TOTAL', colSpan: 6, styles: { ...bold, halign: 'right' } },
    { content: moneyDash(t.gross), styles: { ...bold, halign: 'right' } }, { content: String(t.daysPresent), styles: bold }, { content: '', styles: bold },
    { content: moneyDash(t.basic), styles: { ...bold, halign: 'right' } }, { content: moneyDash(t.hra), styles: { ...bold, halign: 'right' } },
    { content: moneyDash(t.other), styles: { ...bold, halign: 'right' } }, { content: moneyDash(t.totalGross), styles: { ...bold, halign: 'right' } },
    { content: moneyDash(t.pfEmployee), styles: { ...bold, halign: 'right' } }, { content: moneyDash(t.pt), styles: { ...bold, halign: 'right' } },
    { content: moneyDash(t.esicEmployee), styles: { ...bold, halign: 'right' } }, { content: moneyDash(t.pfEmployer), styles: { ...bold, halign: 'right' } },
    { content: moneyDash(t.esicEmployer), styles: { ...bold, halign: 'right' } }, { content: t.advance ? moneyDash(t.advance) : '-', styles: { ...bold, halign: 'right' } },
    { content: moneyDash(t.totalDeduct), styles: { ...bold, halign: 'right' } }, { content: moneyDash(t.net), styles: { ...bold, halign: 'right' } },
    { content: '', styles: bold }, { content: '', styles: bold },
    { content: moneyDash(t.pfWages), styles: { ...bold, halign: 'right' } }, { content: moneyDash(t.epsWages), styles: { ...bold, halign: 'right' } },
    { content: moneyDash(t.employerEps), styles: { ...bold, halign: 'right' } }, { content: moneyDash(t.employerEpf), styles: { ...bold, halign: 'right' } },
    { content: moneyDash(t.employerCost), styles: { ...bold, halign: 'right' } },
  ]);

  const span2 = (c: string) => ({ content: c, rowSpan: 2 });
  autoTable(doc, {
    startY: 40,
    head: [
      [span2('Sr. No.'), span2('Date of Joining'), span2('Date of Resignation'), span2('UAN No.'), span2('Full Name of the Employees'), span2('Male / Female'),
        span2('Gross Wages'), span2('Total Days Present'), span2('Total Days'), span2('Basic @ 50%'), span2('HRA@ 40%'), span2('Other Allowances'), span2('Total Gross Wages'),
        { content: 'Deductions', colSpan: 6, styles: { halign: 'center' } }, span2('Total Deduct'), span2('Net Wages Paid'),
        span2('PF Member (Y/N)'), span2('EPS Eligible (Y/N)'), span2('PF Wages (EPF/EDLI wages)'), span2('EPS Wages'),
        span2('Employer EPS 8.33%'), span2('Employer EPF 3.67% (diff)'), span2('Employer Cost (Gross + Er PF + Er ESIC)')],
      ['PF Employee', 'PT', 'ESIC Employee', 'PF Employer', 'ESIC Employer', 'Advance'],
    ],
    body,
    theme: 'grid',
    // 28 columns on a landscape A4: a slightly smaller type so everything stays on one page width
    styles: { fontSize: 5.2, cellPadding: 0.9, textColor: INK, lineColor: [60, 60, 60], lineWidth: 0.15, valign: 'middle', halign: 'center', overflow: 'linebreak' },
    headStyles: { fillColor: AMBER, textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle', fontSize: 4.8 },
    columnStyles: { 0: { cellWidth: 6 }, 1: { cellWidth: 13 }, 2: { cellWidth: 13 }, 3: { cellWidth: 15 }, 4: { cellWidth: 27, halign: 'left' }, 5: { cellWidth: 8 } },
    margin: { left: 5, right: 5, top: 40, bottom: 12 },
    didDrawPage: () => header(),
  });

  const n = doc.getNumberOfPages(); const H = doc.internal.pageSize.getHeight();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(120, 120, 120);
  for (let i = 1; i <= n; i++) { doc.setPage(i); doc.text(`Page ${i} of ${n}`, W - 10, H - 5, { align: 'right' }); }
  await outputPdf(fileName, doc);
}

/**
 * Any salary / bank list in the same style as the wages register and its Excel:
 * yellow "Shree" bar, company, title, amber header, bordered rows, pale-yellow TOTAL row (numbers right-aligned).
 */
export async function styledTablePdf(
  fileName: string, title: string, subtitle: string,
  head: string[], body: (string | number)[][],
  /** `info`: compact heading lines under the date (establishment / PAN / month, address); `employee`: green row (one employee) */
  opts: { sumFrom?: number; info?: string[]; employee?: string; company?: boolean } = {},
) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: head.length > 9 ? 'landscape' : 'portrait', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const fmt = (v: string | number) => (typeof v === 'number' ? money(v) : String(v ?? ''));
  const cell = (v: string | number) => ({ content: fmt(v), styles: { halign: typeof v === 'number' ? ('right' as const) : ('left' as const) } });

  const rows: any[][] = body.map((r) => r.map(cell));
  if (opts.sumFrom !== undefined && body.length) {
    const bold = { fontStyle: 'bold' as const, fillColor: [255, 244, 204] as [number, number, number] };
    rows.push(head.map((_, c) => {
      if (c === 0) return { content: 'TOTAL', styles: bold };
      if (c < (opts.sumFrom as number)) return { content: '', styles: bold };
      return { content: money(body.reduce((s, r) => s + Number(r[c] || 0), 0)), styles: { ...bold, halign: 'right' as const } };
    }));
  }

  const o = opts.company ? 0 : -7;   // Company Reports keep the Shree bar; every other report starts higher without it
  const header = () => {
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold');
    if (opts.company) {
      doc.setFillColor(255, 255, 0); doc.rect(8, 6, W - 16, 5, 'F');
      doc.setFontSize(9); doc.text('!! Shree !!', W / 2, 9.8, { align: 'center' });
    }
    doc.setFontSize(12); doc.text('C. V. PATIL & ASSOCIATES', W / 2, 17 + o, { align: 'center' });
    doc.setFontSize(10); doc.text(title, W / 2, 23 + o, { align: 'center' });
    doc.setFontSize(9); doc.text(subtitle, W / 2, 28.5 + o, { align: 'center' });
    let y = 34 + o;
    for (const line of opts.info ?? []) { doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.text(line, 8, y); y += 4.6; }
    if (opts.employee) {
      doc.setFillColor(226, 239, 218); doc.rect(8, y - 3.6, W - 16, 5, 'F');
      doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.text(opts.employee, 9, y); y += 4.6;
    }
  };
  const top = 33 + o + (opts.info?.length ?? 0) * 4.6 + (opts.employee ? 4.6 : 0) + ((opts.info?.length || opts.employee) ? 2 : 0);

  autoTable(doc, {
    startY: top,
    head: [head],
    body: rows,
    theme: 'grid',
    styles: { fontSize: head.length > 12 ? 6.5 : 7.8, cellPadding: 1.5, textColor: INK, lineColor: [60, 60, 60], lineWidth: 0.15, valign: 'middle', halign: 'center', overflow: 'linebreak' },
    headStyles: { fillColor: AMBER, textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle' },
    margin: { left: 8, right: 8, top, bottom: 12 },
    didDrawPage: () => header(),
  });

  const n = doc.getNumberOfPages(); const H = doc.internal.pageSize.getHeight();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(120, 120, 120);
  for (let i = 1; i <= n; i++) { doc.setPage(i); doc.text(`Page ${i} of ${n}`, W - 10, H - 5, { align: 'right' }); }
  await outputPdf(fileName, doc);
}

/** One employee on one day of the Selfie Attendance report (shared by the PDF and the Excel) */
export interface SelfieRow {
  name: string; empId: string; date: string;
  inSite: string; inTime: string; inDist: string; inImg: string | null; inHas: boolean;
  outSite: string; outTime: string; outDist: string; outImg: string | null; outHas: boolean;
  worked: string; workedTone: 'ok' | 'short' | 'still' | 'none';
  mins?: number | null; inDistM?: number | null; outDistM?: number | null;
}
export interface SelfieReportInfo {
  period: string; month: string; employee?: string; showDate: boolean; generated: string; by?: string;
}

/**
 * Selfie Attendance Register in the Muster Roll style: yellow "!! Shree !!" bar, centred bold title lines, establishment / PAN / month,
 * address, orange heading row (repeats on every page) and one row per employee and day with the two selfies printed in the table.
 * A4 landscape. A picture that cannot load shows a grey "Photo not available" box instead of failing the PDF.
 */
export async function selfieReportPdf(fileName: string, info: SelfieReportInfo, rows: SelfieRow[]) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  // the PDF font prints plain characters only: odd spaces (e.g. U+202F in browser dates) are turned into normal spaces
  const clean = (s: unknown) => String(s ?? '').replace(/[    ]/g, ' ');
  info = { ...info, period: clean(info.period), month: clean(info.month), generated: clean(info.generated), employee: info.employee ? clean(info.employee) : undefined, by: info.by ? clean(info.by) : undefined };
  rows = rows.map((r) => ({ ...r, name: clean(r.name), empId: clean(r.empId), date: clean(r.date), inSite: clean(r.inSite), outSite: clean(r.outSite), inTime: clean(r.inTime), inDist: clean(r.inDist), outTime: clean(r.outTime), outDist: clean(r.outDist), worked: clean(r.worked) }));
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  // a failing text call reports WHICH text it was (instead of only "Invalid arguments")
  const rawText = doc.text.bind(doc) as (...a: any[]) => any;
  (doc as any).text = (...a: any[]) => {
    try { return rawText(...a); } catch (e) { throw new Error(`${(e as Error).message}: ${JSON.stringify(a).slice(0, 160)}`); }
  };
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
  const one = !!info.employee;
  const header = () => {
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5);
    doc.text('Selfie Attendance Register', W / 2, 10, { align: 'center' });
    doc.setFontSize(9); doc.text('Check-in / Check-out with Selfie and GPS', W / 2, 15, { align: 'center' });
    doc.text(info.period, W / 2, 20, { align: 'center' });
    doc.setFontSize(8); doc.text('Name of the Establishment -', 8, 26);
    doc.setFont('helvetica', 'normal'); doc.text('C.V.Patil & Associates', 52, 26);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text('For the Month of -', 165, 26); doc.text(info.month, 198, 26);
    doc.setFontSize(8); doc.text('Address of the Establishment -', 8, 31);
    doc.setFont('helvetica', 'normal'); doc.text(COMPANY_ADDRESS, 52, 31);
    if (one) { doc.setFont('helvetica', 'bold'); doc.text(`Name of the Employee - ${info.employee}`, 8, 36); }
  };
  const top = one ? 39 : 34;
  const IMG = one ? 22 : 15; const ROW = one ? 26 : 19;   // one employee: larger selfies
  // the site of the check-in and of the check-out are shown separately (an employee can check out at another site)
  const head = ['Sr. No.', ...(one ? [] : ['Full Name of the Employee', 'Emp ID']), ...(info.showDate ? ['Date'] : []),
    'Check-in Site', 'Check-in Selfie', 'Check-in Time', 'Check-in Distance', 'Check-out Site', 'Check-out Selfie', 'Check-out Time', 'Check-out Distance', 'Worked Hours'];
  const inCol = head.indexOf('Check-in Selfie'); const outCol = head.indexOf('Check-out Selfie'); const wCol = head.indexOf('Worked Hours'); const osCol = head.indexOf('Check-out Site');
  const body = rows.map((r, i) => [
    String(i + 1), ...(one ? [] : [r.name, r.empId]), ...(info.showDate ? [r.date] : []),
    r.inSite || '-', '', r.inTime || '-', r.inDist || '-', r.outSite || '-', '', r.outTime || '-', r.outDist || '-', r.worked || '-',
  ]);
  const styles: Record<number, any> = { 0: { cellWidth: 9, halign: 'center' }, [inCol]: { cellWidth: IMG + 5, halign: 'center' }, [outCol]: { cellWidth: IMG + 5, halign: 'center' } };
  [inCol + 1, inCol + 2, outCol + 1, outCol + 2].forEach((c) => { styles[c] = { halign: 'center', cellWidth: 17 }; });
  styles[wCol] = { halign: 'center', fontStyle: 'bold', cellWidth: 22 };
  autoTable(doc, {
    startY: top, head: [head], body, theme: 'grid', showHead: 'everyPage',
    styles: { font: 'helvetica', fontSize: 7, cellPadding: 1.2, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', halign: 'left', overflow: 'linebreak', minCellHeight: ROW },
    headStyles: { fillColor: AMBER, textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle', minCellHeight: 10 },
    columnStyles: styles,
    margin: { left: 8, right: 8, top, bottom: 14 },
    rowPageBreak: 'avoid',
    didDrawPage: () => header(),
    didDrawCell: (d: any) => {
      if (d.section !== 'body' || (d.column.index !== inCol && d.column.index !== outCol)) return;
      const r = rows[d.row.index]; if (!r) return;
      const isIn = d.column.index === inCol;
      const img = isIn ? r.inImg : r.outImg; const has = isIn ? r.inHas : r.outHas;
      const x = d.cell.x + (d.cell.width - IMG) / 2; const y = d.cell.y + (d.cell.height - IMG) / 2;
      if (img) { try { doc.addImage(img, 'JPEG', x, y, IMG, IMG); return; } catch { /* falls to the grey box */ } }
      doc.setFontSize(6); doc.setFont('helvetica', 'normal'); doc.setTextColor(120, 120, 120);
      if (has || img === null && isIn) {            // a selfie exists but could not be loaded
        doc.setFillColor(232, 236, 241); doc.rect(x, y, IMG, IMG, 'F');
        doc.text('Photo not\navailable', x + IMG / 2, y + IMG / 2 - 1, { align: 'center' });
      } else if (!isIn && !r.outTime) {              // not checked out: dashed box
        doc.setDrawColor(150, 160, 170); doc.setLineDashPattern([1, 1], 0); doc.rect(x, y, IMG, IMG); doc.setLineDashPattern([], 0);
        doc.text('Not\nchecked out', x + IMG / 2, y + IMG / 2 - 1, { align: 'center' });
      } else {
        doc.setDrawColor(150, 160, 170); doc.setLineDashPattern([1, 1], 0); doc.rect(x, y, IMG, IMG); doc.setLineDashPattern([], 0);
        doc.text('No selfie', x + IMG / 2, y + IMG / 2 + 1, { align: 'center' });
      }
      doc.setTextColor(...INK); doc.setDrawColor(0, 0, 0);
    },
    willDrawCell: (d: any) => {
      if (d.section !== 'body') return;
      const r = rows[d.row.index];
      if (d.column.index === wCol) {
        // full day = green, short day = red, no check-out = black (all bold)
        d.cell.styles.textColor = r?.workedTone === 'short' ? [192, 0, 0] : r?.workedTone === 'ok' ? [14, 122, 74] : INK;
      }
      // a check-out at a DIFFERENT site than the check-in is shown in bold blue
      if (d.column.index === osCol && r?.outSite && r.outSite.trim() !== r.inSite.trim()) { d.cell.styles.textColor = [31, 78, 158]; d.cell.styles.fontStyle = 'bold'; }
    },  });
  const n = doc.getNumberOfPages();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.text('Selfies taken live in the app with GPS. Distance = from the site point.', 8, H - 6);
    doc.text(`Generated ${info.generated}${info.by ? ` by ${info.by}` : ''} - Page ${i} of ${n}`, W - 8, H - 6, { align: 'right' });
  }
  await outputPdf(fileName, doc);
}

/** Employee blocks of the All-employees report: rows must already be sorted A-Z by name, then by date */
export interface SelfieEmpBlock { name: string; empId: string; rows: SelfieRow[]; checkedIn: number; checkedOut: number; noOut: number; mins: number }
export function selfieEmpBlocks(rows: SelfieRow[]): SelfieEmpBlock[] {
  const out: SelfieEmpBlock[] = [];
  for (const r of rows) {
    let b = out[out.length - 1];
    if (!b || b.name !== r.name || b.empId !== r.empId) { b = { name: r.name, empId: r.empId, rows: [], checkedIn: 0, checkedOut: 0, noOut: 0, mins: 0 }; out.push(b); }
    b.rows.push(r);
    if (r.inTime) b.checkedIn += 1;
    if (r.outTime) b.checkedOut += 1; else if (r.inTime) b.noOut += 1;
    b.mins += r.mins ?? 0;
  }
  return out;
}
export const hm = (mins: number) => `${Math.floor(mins / 60)}h ${String(mins % 60).padStart(2, '0')}m`;
const weekday3 = (dmyText: string) => { const [d, m, y] = dmyText.split('-').map(Number); return new Date(Date.UTC(y, (m || 1) - 1, d || 1)).toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' }); };
export { weekday3 };

/**
 * Selfie Attendance Register - ALL EMPLOYEES: A-Z, one light-yellow summary row per employee, no name / ID on every row,
 * heading block on page 1 only, orange column heading repeated on every page, small rows so about 11 fit on a page.
 */
export async function selfieAllPdf(fileName: string, info: SelfieReportInfo, rowsIn: SelfieRow[]) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const clean = (s: unknown) => String(s ?? '').replace(/[\u00a0\u2007\u2009\u202f]/g, ' ');
  const rows = rowsIn.map((r) => ({ ...r, name: clean(r.name), empId: clean(r.empId), date: clean(r.date), inSite: clean(r.inSite), outSite: clean(r.outSite), inTime: clean(r.inTime), inDist: clean(r.inDist), outTime: clean(r.outTime), outDist: clean(r.outDist), worked: clean(r.worked) }));
  const blocks = selfieEmpBlocks(rows);
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const rawText = doc.text.bind(doc) as (...a: any[]) => any;
  (doc as any).text = (...a: any[]) => { try { return rawText(...a); } catch (e) { throw new Error(`${(e as Error).message}: ${JSON.stringify(a).slice(0, 160)}`); } };
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
  const X0 = 8;
  const CW = [12, 26, 44, 22, 20, 20, 44, 22, 20, 20, 29];   // = 279 mm
  const HEAD = ['Sr. No.', 'Date', 'Check-in Site', 'Check-in Selfie', 'Check-in Time', 'Check-in Distance', 'Check-out Site', 'Check-out Selfie', 'Check-out Time', 'Check-out Distance', 'Worked Hours'];
  const HEADH = 9; const ROW = 14; const IMG = 12; const BOT = 14; const GROUPH = 7;
  const INK: [number, number, number] = [20, 20, 20];

  // heading block: page 1 only
  const drawTitle = (): number => {
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(11);
    doc.text('Selfie Attendance Register - All Employees', W / 2, 9, { align: 'center' });
    doc.setFontSize(9); doc.text(info.period, W / 2, 14.5, { align: 'center' });
    doc.setFontSize(8);
    const l1 = 'Name of the Establishment -';
    doc.text(l1, X0, 20.5);
    doc.setFont('helvetica', 'normal'); doc.text('C.V.Patil & Associates', X0 + doc.getTextWidth(l1) + 2, 20.5);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.text(`For the Month of -  ${info.month}`, W - X0, 20.5, { align: 'right' });
    doc.setFontSize(8);
    const l2 = 'Address of the Establishment -';
    doc.text(l2, X0, 25.5);
    doc.setFont('helvetica', 'normal'); doc.text(COMPANY_ADDRESS, X0 + doc.getTextWidth(l2) + 2, 25.5);
    return 28;
  };
  // orange column heading row, drawn by hand so it can repeat at the top of every page
  const drawHead = (y: number) => {
    let x = X0;
    doc.setLineWidth(0.2); doc.setDrawColor(0, 0, 0); doc.setFillColor(255, 192, 0); doc.setTextColor(...INK);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(6.8);
    HEAD.forEach((h, i) => {
      doc.rect(x, y, CW[i], HEADH, 'FD');
      const lines = doc.splitTextToSize(h, CW[i] - 2) as string[];
      const lh = 3; const top = y + HEADH / 2 - ((lines.length - 1) * lh) / 2 + 1;
      lines.forEach((ln, k) => doc.text(ln, x + CW[i] / 2, top + k * lh, { align: 'center' }));
      x += CW[i];
    });
  };
  const headDone = new Set<number>();
  let y = drawTitle() + 1; drawHead(y); headDone.add(1); y += HEADH;
  const TOP = 10 + HEADH;   // table top on pages 2, 3 ...

  const styles: Record<number, any> = {};
  CW.forEach((w, i) => { styles[i] = { cellWidth: w, halign: [0, 1, 3, 4, 5, 7, 8, 9, 10].includes(i) ? 'center' : 'left' }; });
  styles[10].fontStyle = 'bold';

  for (const b of blocks) {
    if (y + GROUPH + ROW > H - BOT) { doc.addPage(); drawHead(10); headDone.add(doc.getNumberOfPages()); y = TOP; }
    const summary = `${b.name} (${b.empId})   -   Days checked in ${b.checkedIn}   |   Checked out ${b.checkedOut}   |   No check-out ${b.noOut}   |   Total worked ${hm(b.mins)}`;
    const body: any[][] = [
      [{ content: summary, colSpan: 11, styles: { fillColor: [255, 242, 204], fontStyle: 'bold', fontSize: 7.5, halign: 'left', minCellHeight: GROUPH, cellPadding: 1.4 } }],
      ...b.rows.map((r, i) => [String(i + 1), `${r.date}\n `, r.inSite || '-', '', r.inTime || '-', r.inDist || '-', r.outSite || '-', '', r.outTime || '-', r.outDist || '-', r.worked || '-']),
    ];
    autoTable(doc, {
      startY: y, body, theme: 'grid', showHead: 'never',
      styles: { font: 'helvetica', fontSize: 7, cellPadding: 1, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', overflow: 'linebreak', minCellHeight: ROW },
      columnStyles: styles,
      margin: { left: X0, right: X0, top: TOP, bottom: BOT },
      rowPageBreak: 'avoid',
      didDrawPage: () => { const pn = doc.getNumberOfPages(); const cur = (doc as any).getCurrentPageInfo?.().pageNumber ?? pn; if (!headDone.has(cur)) { drawHead(10); headDone.add(cur); } },
      didParseCell: (d: any) => {
        if (d.section !== 'body' || d.row.index === 0) return;
        const r = b.rows[d.row.index - 1]; if (!r) return;
        const c = d.column.index;
        if (c === 10) d.cell.styles.textColor = r.workedTone === 'short' ? [192, 0, 0] : r.workedTone === 'ok' ? [14, 122, 74] : INK;
        if (c === 6 && r.outSite && r.outSite.trim() !== r.inSite.trim()) { d.cell.styles.textColor = [31, 78, 158]; d.cell.styles.fontStyle = 'bold'; }
        if (c === 5 && (r.inDistM ?? 0) > 200) { d.cell.styles.textColor = [192, 0, 0]; d.cell.styles.fontStyle = 'bold'; }
        if (c === 9 && (r.outDistM ?? 0) > 200) { d.cell.styles.textColor = [192, 0, 0]; d.cell.styles.fontStyle = 'bold'; }
      },
      didDrawCell: (d: any) => {
        if (d.section !== 'body' || d.row.index === 0) return;
        const r = b.rows[d.row.index - 1]; if (!r) return;
        const c = d.column.index;
        if (c === 1) {   // the weekday under the date, small and grey
          doc.setFont('helvetica', 'normal'); doc.setFontSize(6.5); doc.setTextColor(120, 120, 120);
          doc.text(weekday3(r.date), d.cell.x + d.cell.width / 2, d.cell.y + d.cell.height / 2 + 3.6, { align: 'center' });
          doc.setTextColor(...INK); return;
        }
        if (c !== 3 && c !== 7) return;
        const isIn = c === 3;
        const img = isIn ? r.inImg : r.outImg; const has = isIn ? r.inHas : r.outHas;
        const x = d.cell.x + (d.cell.width - IMG) / 2; const yy = d.cell.y + (d.cell.height - IMG) / 2;
        if (img) { try { doc.addImage(img, 'JPEG', x, yy, IMG, IMG); return; } catch { /* grey box below */ } }
        doc.setFontSize(5.5); doc.setFont('helvetica', 'normal'); doc.setTextColor(120, 120, 120);
        if (has) { doc.setFillColor(232, 236, 241); doc.rect(x, yy, IMG, IMG, 'F'); doc.text('Photo not\navailable', x + IMG / 2, yy + IMG / 2 - 1, { align: 'center' }); }
        else { doc.setDrawColor(150, 160, 170); doc.setLineDashPattern([1, 1], 0); doc.rect(x, yy, IMG, IMG); doc.setLineDashPattern([], 0);
          doc.text(!isIn && !r.outTime ? 'Not\nchecked out' : 'No selfie', x + IMG / 2, yy + IMG / 2 - (!isIn && !r.outTime ? 1 : -1), { align: 'center' }); }
        doc.setTextColor(...INK); doc.setDrawColor(0, 0, 0);
      },
    });
    y = (doc as any).lastAutoTable.finalY;
  }

  const n = doc.getNumberOfPages();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.text('All employees in alphabetical order (A-Z). Distance = from the selected site point.', X0, H - 6);
    doc.text(`Generated ${clean(info.generated)}${info.by ? ` by ${clean(info.by)}` : ''} - Page ${i} of ${n}`, W - X0, H - 6, { align: 'right' });
  }
  await outputPdf(fileName, doc);
}

// =====================================================================================================================
// Selfie Attendance - FOREIGN LOCATION register (Place = Foreign Location): who, where, why + both selfies
// =====================================================================================================================
export interface ForeignRow {
  name: string; empId: string; date: string;
  place: string; gps: string;                 // the place the employee entered (or the site he picked) + "lat, lng"
  nearSite: string; nearDist: string;         // nearest allotted site and "6.4 km away"
  reason: string;
  inTime: string; inImg: string | null; inHas: boolean;
  outTime: string; outImg: string | null; outHas: boolean;
  worked: string; workedTone: 'ok' | 'short' | 'still' | 'none';
}

/** A / Z order is the caller's job (name, then date). `grouped`: one yellow row per employee and no Employee column (month / one employee). */
export async function selfieForeignPdf(fileName: string, info: SelfieReportInfo, rowsIn: ForeignRow[], grouped: boolean) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const clean = (s: unknown) => String(s ?? '').replace(/[\u00a0\u2007\u2009\u202f]/g, ' ');
  const rows = rowsIn.map((r) => ({ ...r, name: clean(r.name), empId: clean(r.empId), place: clean(r.place), gps: clean(r.gps), nearSite: clean(r.nearSite), nearDist: clean(r.nearDist), reason: clean(r.reason), worked: clean(r.worked) }));
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
  const X0 = 8; const INK: [number, number, number] = [20, 20, 20];
  const showDate = info.showDate;
  // columns
  const cols: { head: string; w: number; key: string }[] = [
    { head: 'Sr. No.', w: 10, key: 'sr' },
    ...(grouped ? [] : [{ head: 'Name of the Employee', w: 34, key: 'emp' }]),
    ...(showDate ? [{ head: 'Date', w: 19, key: 'date' }] : []),
    { head: 'Foreign Place (entered + GPS address)', w: 44, key: 'place' },
    { head: 'Nearest Allotted Site', w: 36, key: 'near' },
    { head: 'Reason for Foreign Location', w: 48, key: 'reason' },
    { head: 'Check-in Time', w: 17, key: 'inT' }, { head: 'Check-in Selfie', w: 20, key: 'inI' },
    { head: 'Check-out Time', w: 17, key: 'outT' }, { head: 'Check-out Selfie', w: 20, key: 'outI' },
    { head: 'Worked Hours', w: 23, key: 'wk' },
  ];
  const total = cols.reduce((a, c) => a + c.w, 0);
  cols.find((c) => c.key === 'reason')!.w += Math.max(0, 266 - total);   // the free width goes to the reason
  const ix = (k: string) => cols.findIndex((c) => c.key === k);
  const IMG = 14; const ROW = 19;

  // heading (page 1 only)
  doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(11);
  doc.text('Selfie Attendance Register - Foreign Location', W / 2, 9, { align: 'center' });
  doc.setFontSize(9); doc.text(info.period, W / 2, 14.5, { align: 'center' });
  doc.setFontSize(8);
  const l1 = 'Name of the Establishment -'; doc.text(l1, X0, 20.5);
  doc.setFont('helvetica', 'normal'); doc.text('C.V.Patil & Associates', X0 + doc.getTextWidth(l1) + 2, 20.5);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.text(`For the Month of -  ${info.month}`, W - X0, 20.5, { align: 'right' });
  doc.setFontSize(8);
  const l2 = 'Address of the Establishment -'; doc.text(l2, X0, 25.5);
  doc.setFont('helvetica', 'normal'); doc.text(COMPANY_ADDRESS, X0 + doc.getTextWidth(l2) + 2, 25.5);

  // body: yellow employee rows when grouped
  type Item = { kind: 'group'; text: string } | { kind: 'row'; r: (typeof rows)[number]; i: number };
  const items: Item[] = [];
  if (grouped) {
    let cur = ''; let n = 0;
    for (const r of rows) {
      const key = `${r.name}|${r.empId}`;
      if (key !== cur) {
        cur = key; n = 0;
        const mine = rows.filter((x) => `${x.name}|${x.empId}` === key);
        items.push({ kind: 'group', text: `${r.name} (${r.empId})   -   Foreign location punches ${mine.length}   |   Checked out ${mine.filter((x) => x.outTime).length}   |   No check-out ${mine.filter((x) => x.inTime && !x.outTime).length}` });
      }
      n += 1; items.push({ kind: 'row', r, i: n });
    }
  } else rows.forEach((r, i) => items.push({ kind: 'row', r, i: i + 1 }));

  const body: any[][] = items.map((it) => {
    if (it.kind === 'group') return [{ content: it.text, colSpan: cols.length, styles: { fillColor: [255, 242, 204], fontStyle: 'bold', fontSize: 7.5, halign: 'left', minCellHeight: 7 } }];
    const r = it.r;
    const reasonCell: any = r.reason.trim() ? siteTextCell(r.reason, cols[ix('reason')].w) : { content: 'No reason given', styles: { fontStyle: 'italic', textColor: [130, 130, 130] } };
    const reasonOut = typeof reasonCell === 'string' ? { content: reasonCell, styles: { fillColor: [255, 247, 237], textColor: [110, 50, 0] } } : reasonCell;
    return cols.map((c) => {
      switch (c.key) {
        case 'sr': return String(it.i);
        case 'emp': return r.empId ? `${r.name}\n${r.empId}` : r.name;
        case 'date': return r.date;
        case 'place': return { content: `${r.place || '-'}\n `, styles: { fontStyle: 'bold', textColor: [194, 90, 0], halign: 'left' } };
        case 'near': return { content: `${r.nearSite || '-'}\n `, styles: { halign: 'left' } };
        case 'reason': return reasonOut;
        case 'inT': return r.inTime || '-';
        case 'outT': return r.outTime || '-';
        case 'wk': return { content: r.worked || '-', styles: { fontStyle: 'bold', textColor: r.workedTone === 'short' ? [192, 0, 0] : r.workedTone === 'ok' ? [14, 122, 74] : r.workedTone === 'still' ? [168, 100, 0] : INK } };
        default: return '';
      }
    });
  });
  const colStyles: Record<number, any> = {};
  cols.forEach((c, i) => { colStyles[i] = { cellWidth: c.w, halign: ['reason', 'place', 'near', 'emp'].includes(c.key) ? 'left' : 'center' }; });
  const rowOf = (index: number) => (items[index] as Item);
  autoTable(doc, {
    startY: 29, theme: 'grid', showHead: 'everyPage',
    head: [cols.map((c) => c.head)], body,
    styles: { font: 'helvetica', fontSize: 7, cellPadding: 1.4, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', overflow: 'linebreak', minCellHeight: ROW },
    headStyles: { fillColor: [255, 192, 0], textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle', fontSize: 7, minCellHeight: 9 },
    columnStyles: colStyles,
    margin: { left: X0, right: X0, top: 10, bottom: 14 },
    rowPageBreak: 'avoid',
    didDrawCell: (d: any) => {
      if (d.section !== 'body') return;
      const it = rowOf(d.row.index); if (!it || it.kind !== 'row') return;
      const r = it.r; const key = cols[d.column.index]?.key; const raw = d.cell?.raw;
      if (raw && raw.img && key === 'reason') { try { doc.addImage(raw.img, 'PNG', d.cell.x + 1.4, d.cell.y + 1.4, raw.iw, raw.ih); } catch { /* skip */ } return; }
      // second line of the place / nearest-site cells, drawn in its own colour
      if (key === 'place' || key === 'near') {
        const text = key === 'place' ? `📍 ${r.gps}`.replace('📍 ', '') : r.nearDist;
        if (!text) return;
        const lines = (doc.splitTextToSize(key === 'place' ? (r.place || '-') : (r.nearSite || '-'), d.cell.width - 3) as string[]).length;
        const lh = 2.9; const top = d.cell.y + (d.cell.height - (lines + 1) * lh) / 2;
        doc.setFont('helvetica', key === 'near' ? 'bold' : 'normal'); doc.setFontSize(6.3);
        if (key === 'near') doc.setTextColor(192, 0, 0); else doc.setTextColor(110, 110, 110);
        doc.text(doc.splitTextToSize(text, d.cell.width - 3)[0], d.cell.x + 1.4, top + lines * lh + lh * 0.8);
        doc.setTextColor(...INK); return;
      }
      if (key !== 'inI' && key !== 'outI') return;
      const isIn = key === 'inI'; const img = isIn ? r.inImg : r.outImg; const has = isIn ? r.inHas : r.outHas;
      const x = d.cell.x + (d.cell.width - IMG) / 2; const y = d.cell.y + (d.cell.height - IMG) / 2;
      if (img) { try { doc.addImage(img, 'JPEG', x, y, IMG, IMG); return; } catch { /* grey box below */ } }
      doc.setFontSize(5.5); doc.setFont('helvetica', 'normal'); doc.setTextColor(120, 120, 120);
      if (has) { doc.setFillColor(232, 236, 241); doc.rect(x, y, IMG, IMG, 'F'); doc.text('Photo not\navailable', x + IMG / 2, y + IMG / 2 - 1, { align: 'center' }); }
      else { doc.setDrawColor(150, 160, 170); doc.setLineDashPattern([1, 1], 0); doc.rect(x, y, IMG, IMG); doc.setLineDashPattern([], 0);
        doc.text(!isIn && !r.outTime ? 'Not\nchecked out' : 'No selfie', x + IMG / 2, y + IMG / 2 - (!isIn && !r.outTime ? 1 : -1), { align: 'center' }); }
      doc.setTextColor(...INK); doc.setDrawColor(0, 0, 0);
    },
  });
  const n = doc.getNumberOfPages();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.text("Foreign Location = check-in outside 500 m of every allotted site, with the employee's reason.", X0, H - 6);
    doc.text(`Generated ${clean(info.generated)}${info.by ? ` by ${clean(info.by)}` : ''} - Page ${i} of ${n}`, W - X0, H - 6, { align: 'right' });
  }
  await outputPdf(fileName, doc);
}
