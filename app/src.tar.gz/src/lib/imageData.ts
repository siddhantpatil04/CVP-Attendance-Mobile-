import { Platform } from 'react-native';

/**
 * Downloads an image and returns it as a small JPEG data URL (for a PDF). On the web the picture is scaled down to `max` pixels
 * so a report with many selfies stays small. Returns null when the picture cannot be loaded (the report shows "Photo unavailable").
 */
export async function imageDataUrl(url: string, max = 220): Promise<string | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const blob = await res.blob();
    if (Platform.OS === 'web') {
      const obj = URL.createObjectURL(blob);
      try {
        const img: HTMLImageElement = await new Promise((ok, no) => { const i = new window.Image(); i.onload = () => ok(i); i.onerror = no; i.src = obj; });
        const k = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
        c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
        return c.toDataURL('image/jpeg', 0.75);
      } finally { URL.revokeObjectURL(obj); }
    }
    return await new Promise<string | null>((ok) => {
      const r = new FileReader();
      r.onloadend = () => ok(typeof r.result === 'string' ? r.result : null);
      r.onerror = () => ok(null);
      r.readAsDataURL(blob);
    });
  } catch { return null; }
}
