import { COMPANY_ADDRESS } from '../config';
import type { EmployeeDetails, PayrollRow } from './api';
import { loadPdfLibs, outputPdf } from './pdf';

const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
const TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

/**
 * Payroll rules used for the salary slip. Change them here (one place) when the company rules change.
 *  - Basic is 50% of the earned salary, HRA is 40% of Basic, Allowances are the rest, Bonus = overtime pay.
 *  - Provident Fund 12% of Basic, at most Rs 1,800, only for an employee who has a UAN / PF number.
 *  - Professional Tax by the Maharashtra slab (men: above Rs 10,000 -> Rs 200, February Rs 300; women: nil up to Rs 25,000).
 */
export const PAYROLL_RULES = {
  basicPct: 50, hraPctOfBasic: 40, pfPct: 12, pfMax: 1800,
  ptMen: [{ upto: 7500, tax: 0 }, { upto: 10000, tax: 175 }, { upto: Infinity, tax: 200 }],
  ptWomenFreeUpto: 25000, ptWomen: 200, ptFebruary: 300,
};

const two = (n: number) => Math.round(n * 100) / 100;
const rs = (n: number) => Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function below1000(n: number): string {
  if (n < 20) return ONES[n];
  if (n < 100) return TENS[Math.floor(n / 10)] + (n % 10 ? ` ${ONES[n % 10]}` : '');
  return `${ONES[Math.floor(n / 100)]} Hundred${n % 100 ? ` ${below1000(n % 100)}` : ''}`;
}
/** 26120 -> "Rupees Twenty Six Thousand One Hundred Twenty Only" (Indian numbering) */
export function rupeesInWords(amount: number): string {
  let rupees = Math.floor(Math.abs(amount));
  const paise = Math.round((Math.abs(amount) - rupees) * 100);
  if (rupees === 0 && paise === 0) return 'Rupees Zero Only';
  const parts: string[] = [];
  for (const [div, name] of [[10000000, 'Crore'], [100000, 'Lakh'], [1000, 'Thousand']] as const) {
    const q = Math.floor(rupees / div);
    if (q) { parts.push(`${below1000(q)} ${name}`); rupees -= q * div; }
  }
  if (rupees) parts.push(below1000(rupees));
  const words = parts.join(' ') || 'Zero';
  return `Rupees ${words}${paise ? ` and ${below1000(paise)} Paise` : ''} Only`;
}

export interface SlipData {
  year: number; month: number; slipNo: string;
  code: string; name: string; department: string; designation: string; joining: string;
  bank: string; account: string; pan: string; uan: string; paidDays: number; monthDays: number;
  basic: number; hra: number; allowances: number; bonus: number; gross: number;
  pf: number; tax: number; other: number; deductions: number; net: number;
  salary: number; unpaidDays: number; unpaidLeave: number; pfApplies: boolean;
}

export type SlipResult = { ok: true; slip: SlipData } | { ok: false; problems: string[] };

/**
 * Builds the slip of one employee for one month from the saved payroll and employee details.
 * Never returns a blank slip: a missing salary, payroll, bank detail or PAN is reported instead.
 */
export function computeSlip(
  pay: PayrollRow | undefined,
  d: Partial<EmployeeDetails> | undefined,
  info: { designation: string; joining: string | null; department: string | null },
  year: number, month: number,
): SlipResult {
  if (!pay) return { ok: false, problems: [`No payroll for ${MONTH_NAMES[month - 1]} ${year}${info.joining ? ` (joined ${info.joining})` : ''}. Run the payroll first.`] };
  const problems: string[] = [];
  if (!(Number(pay.monthly_salary) > 0)) problems.push('Salary is not set. Set the Basic salary first.');
  if (!d?.bank_name?.trim() || !d?.bank_account_no?.trim()) problems.push('Bank details are missing.');
  if (!d?.pan_no?.trim()) problems.push('PAN is missing.');
  if (problems.length) return { ok: false, problems };

  const R = PAYROLL_RULES;
  const earned = two(Number(pay.monthly_salary) - Number(pay.deduction));            // salary for the paid days
  const basic = two(earned * R.basicPct / 100);
  const hra = two(basic * R.hraPctOfBasic / 100);
  const bonus = two(Number(pay.overtime_pay));                                         // overtime is paid as a bonus line
  const allowances = two(Math.max(earned - basic - hra, 0));
  const gross = two(basic + hra + allowances + bonus);
  const pfApplies = !!d?.uan_no?.trim();
  const pf = pfApplies ? two(Math.min(basic * R.pfPct / 100, R.pfMax)) : 0;
  const female = /^f/i.test(d?.gender ?? '');
  let tax = 0;
  if (female) tax = gross > R.ptWomenFreeUpto ? R.ptWomen : 0;
  else tax = R.ptMen.find((s) => gross <= s.upto)!.tax;
  if (tax >= 200 && month === 2) tax = R.ptFebruary;
  const deductions = two(pf + tax);
  const mm = String(month).padStart(2, '0');
  return {
    ok: true,
    slip: {
      year, month, slipNo: `SS-${year}-${mm}-${pay.username}`,
      code: pay.username, name: pay.full_name, department: info.department ?? pay.department ?? '-', designation: info.designation || '-',
      joining: info.joining ?? '-', bank: [d?.bank_name, d?.bank_branch].filter(Boolean).join(', '),
      account: d?.bank_account_no ?? '', pan: d?.pan_no ?? '', uan: d?.uan_no || '-',
      paidDays: Number(pay.payable_days), monthDays: Number(pay.days_in_month),
      basic, hra, allowances, bonus, gross, pf, tax, other: 0, deductions, net: two(gross - deductions),
      salary: Number(pay.monthly_salary), unpaidDays: Number(pay.unpaid_days), unpaidLeave: Number(pay.unpaid_leave), pfApplies,
    },
  };
}

const maskAccount = (a: string) => (a.length > 4 ? `${'X'.repeat(Math.max(a.length - 4, 0))}${a.slice(-4)}`.replace(/(.{4})(?=.)/g, '$1 ') : a);
export const slipFileName = (s: SlipData) => `salary_slip_${s.code}_${s.year}-${String(s.month).padStart(2, '0')}.pdf`;
const fmtDate = (iso: string) => {
  if (!/^\d{4}-\d{2}-\d{2}/.test(iso)) return iso;
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return `${d} ${MONTH_NAMES[m - 1].slice(0, 3)} ${y}`;
};

/** Salary slip PDF in the layout of the reference slip (header, info table, earnings / deductions, net box, stamp, signatures) */
export async function shareSalarySlip(s: SlipData) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const w = doc.internal.pageSize.getWidth();
  const navy: [number, number, number] = [6, 37, 63];
  const ink: [number, number, number] = [20, 30, 45];
  const line: [number, number, number] = [190, 200, 212];
  const label: [number, number, number] = [110, 122, 138];
  const L = 14; const W = w - 28;

  // header: logo box, company name, address, rule
  doc.setDrawColor(...line); doc.setLineWidth(0.4); doc.roundedRect(L, 12, 17, 17, 3, 3);
  doc.setTextColor(11, 124, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text('CVP', L + 8.5, 22.5, { align: 'center' });
  doc.setTextColor(...navy); doc.setFontSize(18); doc.text('C. V. PATIL & ASSOCIATES', L + 22, 20);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(...label);
  doc.text(COMPANY_ADDRESS, L + 22, 25.5, { maxWidth: W - 22 });
  doc.setDrawColor(...navy); doc.setLineWidth(0.7); doc.line(L, 33, L + W, 33);

  // title band
  doc.setFillColor(235, 241, 248); doc.setDrawColor(...line); doc.setLineWidth(0.2); doc.rect(L, 38, W, 9, 'FD');
  doc.setTextColor(...ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(11);
  doc.text(`SALARY SLIP FOR THE MONTH OF ${MONTH_NAMES[s.month - 1].toUpperCase()} ${s.year}`, w / 2, 44, { align: 'center' });

  // employee information
  const lab = (t: string) => ({ content: t, styles: { textColor: label, fontStyle: 'bold' as const, fillColor: [248, 250, 252] as [number, number, number] } });
  const base = { fontSize: 8.5, cellPadding: 2.4, textColor: ink, lineColor: line, lineWidth: 0.2 };
  autoTable(doc, {
    startY: 51, theme: 'grid', margin: { left: L, right: L }, styles: base,
    columnStyles: { 0: { cellWidth: 33 }, 1: { cellWidth: 49, fontStyle: 'bold' }, 2: { cellWidth: 33 }, 3: { fontStyle: 'bold' } },
    body: [
      [lab('Employee Code'), s.code, lab('Employee Name'), s.name],
      [lab('Department'), s.department, lab('Designation'), s.designation],
      [lab('Date of Joining'), fmtDate(s.joining), lab('Bank Name'), s.bank || '-'],
      [lab('Account Number'), maskAccount(s.account), lab('PAN'), s.pan],
      [lab('UAN / PF Number'), s.uan, lab('Paid Days / Month Days'), `${Number(s.paidDays.toFixed(2))} / ${s.monthDays}`],
    ],
  });
  let y = (doc as any).lastAutoTable.finalY + 6;

  // earnings / deductions
  const right = { halign: 'right' as const };
  const total = { fontStyle: 'bold' as const, fillColor: [235, 241, 248] as [number, number, number] };
  autoTable(doc, {
    startY: y, theme: 'grid', margin: { left: L, right: L }, styles: { ...base, fontSize: 9 },
    headStyles: { fillColor: navy, textColor: [255, 255, 255], fontStyle: 'bold' },
    head: [['EARNINGS', { content: 'AMOUNT (Rs)', styles: right }, 'DEDUCTIONS', { content: 'AMOUNT (Rs)', styles: right }]],
    columnStyles: { 0: { cellWidth: 42, fontStyle: 'bold' }, 1: { cellWidth: 36, halign: 'right', fontStyle: 'bold' }, 2: { fontStyle: 'bold' }, 3: { cellWidth: 36, halign: 'right', fontStyle: 'bold' } },
    body: [
      ['Basic', rs(s.basic), `Provident Fund (${PAYROLL_RULES.pfPct}% of Basic)`, rs(s.pf)],
      ['HRA', rs(s.hra), 'Tax (Professional Tax)', rs(s.tax)],
      ['Allowances', rs(s.allowances), 'Other Deductions', rs(s.other)],
      ['Bonus', rs(s.bonus), '', ''],
      [{ content: 'Gross Earnings', styles: total }, { content: rs(s.gross), styles: { ...total, ...right } },
        { content: 'Total Deductions', styles: total }, { content: rs(s.deductions), styles: { ...total, ...right } }],
    ],
  });
  y = (doc as any).lastAutoTable.finalY + 7;

  // net salary box + in words
  doc.setDrawColor(...navy); doc.setLineWidth(0.8); doc.rect(L, y, W, 11);
  doc.setTextColor(...ink); doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5);
  doc.text('NET SALARY PAYABLE', L + 4, y + 7.2);
  doc.setFontSize(12); doc.text(`Rs ${rs(s.net)}`, L + W - 4, y + 7.4, { align: 'right' });
  doc.setFontSize(8); doc.text(`In words: ${rupeesInWords(s.net)}`, L, y + 17);

  // company stamp, signatures
  const sy = y + 58;
  doc.setDrawColor(130, 142, 160); doc.setLineWidth(0.4); (doc as any).setLineDashPattern([1.6, 1.4], 0);
  doc.circle(w / 2, sy - 14, 10); (doc as any).setLineDashPattern([], 0);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(6.5); doc.setTextColor(...label);
  doc.text('COMPANY', w / 2, sy - 15, { align: 'center' }); doc.text('STAMP', w / 2, sy - 12, { align: 'center' });
  doc.setDrawColor(...ink); doc.setLineWidth(0.4);
  doc.line(L, sy, L + 55, sy); doc.line(L + W - 55, sy, L + W, sy);
  doc.setTextColor(...ink); doc.setFontSize(8.5);
  doc.text('Employee Signature', L + 27.5, sy + 5, { align: 'center' }); doc.text('Authorized Signatory', L + W - 27.5, sy + 5, { align: 'center' });

  doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.setTextColor(...label);
  doc.text(`This is a system-generated salary slip from CVP Attendance - Slip No. ${s.slipNo}`, w / 2, sy + 16, { align: 'center' });

  await outputPdf(slipFileName(s), doc);
}
