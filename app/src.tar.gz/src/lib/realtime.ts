import type { RealtimePostgresChangesPayload } from '@supabase/supabase-js';
import { useEffect, useRef, useState } from 'react';
import { AppState, Platform } from 'react-native';
import { supabase } from './supabase';

/** Sent to `onChange` when the screen should simply reload (no specific row changed). */
const RESYNC = { table: '', schema: 'public', eventType: 'UPDATE', new: {}, old: {}, commit_timestamp: '', errors: [] } as unknown as RealtimePostgresChangesPayload<Record<string, unknown>>;

export interface TableWatch {
  table: string;
  filter?: string; // e.g. "user_id=eq.<uuid>"
}

/**
 * Subscribes to database changes on the given tables and calls `onChange`
 * (debounced) whenever a row is inserted / updated / deleted.
 * Row Level Security still applies: each phone only receives rows it may see.
 * Returns true while the live connection is open.
 *
 * It also reloads the screen (so phone + desktop never drift apart) when:
 *  - the live connection comes back after a drop (Wi-Fi change, laptop sleep), and
 *  - the browser tab / phone app comes back to the foreground.
 */
export function useRealtime(
  key: string,
  tables: TableWatch[],
  onChange: (payload: RealtimePostgresChangesPayload<Record<string, unknown>>) => void,
  enabled = true,
): boolean {
  const [live, setLive] = useState(false);
  const cb = useRef(onChange);
  cb.current = onChange;
  const sig = JSON.stringify(tables);

  useEffect(() => {
    if (!enabled) return;
    let timer: ReturnType<typeof setTimeout> | null = null;
    let last: RealtimePostgresChangesPayload<Record<string, unknown>> | null = null;
    let ch = supabase.channel(`${key}-${Math.random().toString(36).slice(2, 8)}`);
    for (const t of JSON.parse(sig) as TableWatch[]) {
      ch = ch.on(
        'postgres_changes',
        { event: '*', schema: 'public', table: t.table, ...(t.filter ? { filter: t.filter } : {}) },
        (payload) => {
          last = payload;
          if (timer) clearTimeout(timer);
          timer = setTimeout(() => last && cb.current(last), 350);
        },
      );
    }
    let wasLive = false;
    ch.subscribe((status) => {
      const ok = status === 'SUBSCRIBED';
      setLive(ok);
      if (ok && wasLive) cb.current(RESYNC); // reconnected: catch up on anything missed
      if (ok) wasLive = true;
    });

    // Back in the foreground -> reload, because events may have been missed while hidden
    let lastSync = Date.now();
    const resync = () => {
      if (Date.now() - lastSync < 2000) return;
      lastSync = Date.now();
      cb.current(RESYNC);
    };
    let removeForeground: () => void;
    if (Platform.OS === 'web' && typeof document !== 'undefined') {
      const onVis = () => { if (document.visibilityState === 'visible') resync(); };
      document.addEventListener('visibilitychange', onVis);
      window.addEventListener('online', resync);
      removeForeground = () => {
        document.removeEventListener('visibilitychange', onVis);
        window.removeEventListener('online', resync);
      };
    } else {
      const sub = AppState.addEventListener('change', (st) => { if (st === 'active') resync(); });
      removeForeground = () => sub.remove();
    }

    return () => {
      if (timer) clearTimeout(timer);
      removeForeground();
      setLive(false);
      supabase.removeChannel(ch);
    };
  }, [key, sig, enabled]);

  return live;
}

/** Re-renders every `ms` milliseconds (for live clocks / "working for" timers) */
export function useTicker(ms: number): number {
  const [n, setN] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setN(Date.now()), ms);
    return () => clearInterval(id);
  }, [ms]);
  return n;
}
