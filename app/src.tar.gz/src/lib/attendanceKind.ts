import { OFFICE_ATTENDANCE_EMPLOYEES } from '../config';
import { isForeignSiteName } from './geo';

/** Is this employee an OFFICE employee for attendance? (the list in config.ts, else: not a Site employee and role Employee / HR) */
export const isOfficeEmployee = (p: { site_employee?: boolean | null; role?: string | null; username?: string | null }) =>
  OFFICE_ATTENDANCE_EMPLOYEES.includes((p.username ?? '').trim().toLowerCase())
  || (!p.site_employee && (p.role === 'Employee' || p.role === 'HR'));

/**
 * THE one rule for "Site Attendance" or "Office Attendance" - decided per record (per day) by WHERE the check-in was made,
 * not by the type of the employee:
 *   office employee (any place)                -> 'office'  (their attendance is always in Office Attendance)
 *   check-in at a work site (selfie flow)      -> 'site'
 *   check-in at an office location             -> 'office'
 *   Foreign Location                           -> the employee's own type (site employee -> 'site', office employee -> 'office')
 *   anything else (e.g. a regularized day)     -> the employee's own type
 * A check-out never decides: if check-in and check-out are at different kinds, the CHECK-IN place is used.
 * Read only - nothing is saved or changed by this.
 */
export type AttendanceKind = 'site' | 'office';

export function getAttendanceKind(
  r: { site_name?: string | null; /** the record came from the site selfie flow */ siteFlow?: boolean; /** attendance.source: 'site' | 'office' | 'regularized' */ source?: string | null; foreign?: boolean },
  officeNames: Set<string>,
  employeeIsOffice: boolean,
): AttendanceKind {
  const own: AttendanceKind = employeeIsOffice ? 'office' : 'site';
  if (employeeIsOffice) return 'office';   // an OFFICE employee always counts in Office Attendance, even when checked in at a work site
  const name = (r.site_name ?? '').trim().toLowerCase();
  if (r.foreign || isForeignSiteName(r.site_name)) return own;
  if (name && officeNames.has(name)) return 'office';
  if (r.siteFlow || r.source === 'site') return 'site';
  if (r.source === 'office') return 'office';
  return own;
}

/** office location names (lower case) from the Work Sites list: the rows ticked "office location" */
export const officeNameSet = (sites: { name: string; is_office?: boolean }[]) =>
  new Set(sites.filter((s) => s.is_office).map((s) => s.name.trim().toLowerCase()));
