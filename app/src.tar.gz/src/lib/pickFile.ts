﻿import { decode } from 'base64-arraybuffer';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import { Alert, Platform } from 'react-native';

export interface PickedFile { bytes: ArrayBuffer; name: string; mime: string }

const MAX_BYTES = 10 * 1024 * 1024;
const WEB_TYPES = '.pdf,.jpg,.jpeg,.png,.webp,.doc,.docx,.xls,.xlsx,image/*';
const MIME: Record<string, string> = {
  pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp',
  doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
};

/**
 * Picks a document. Call it straight from a button press (the browser only opens the file dialog then).
 *  Web / desktop : any PDF, image, Word or Excel file.
 *  Phone         : a photo (camera or gallery), shrunk to a JPEG.
 */
export function pickFile(camera = false, crop = false): Promise<PickedFile | null> {
  if (Platform.OS === 'web') {
    return new Promise((resolve) => {
      const doc = (globalThis as any).document;
      const input = doc.createElement('input');
      input.type = 'file';
      input.accept = WEB_TYPES;
      input.onchange = async () => {
        const file = input.files?.[0];
        if (!file) return resolve(null);
        const ext = String(file.name).split('.').pop()?.toLowerCase() ?? '';
        if (!MIME[ext]) { Alert.alert('File type not allowed', 'Choose a PDF, image, Word or Excel file.'); return resolve(null); }
        if (file.size > MAX_BYTES) { Alert.alert('File too large', 'The file must be 10 MB or smaller.'); return resolve(null); }
        resolve({ bytes: await file.arrayBuffer(), name: file.name, mime: MIME[ext] });
      };
      input.oncancel = () => resolve(null);
      input.click();
    });
  }
  return pickPhoto(camera, crop);
}

async function pickPhoto(camera: boolean, crop = false): Promise<PickedFile | null> {
  if (camera) {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) { Alert.alert('Camera permission needed', 'Allow camera access in Settings to photograph the document.'); return null; }
  }
  const opts: ImagePicker.ImagePickerOptions = { mediaTypes: ['images'], quality: 0.8, allowsEditing: crop, ...(crop ? { aspect: [1, 1] as [number, number] } : {}) };
  const res = camera ? await ImagePicker.launchCameraAsync(opts) : await ImagePicker.launchImageLibraryAsync(opts);
  if (res.canceled || !res.assets?.[0]) return null;
  const ref = await ImageManipulator.manipulate(res.assets[0].uri).resize({ width: crop ? 800 : 1600 }).renderAsync();
  const out = await ref.saveAsync({ compress: 0.7, format: SaveFormat.JPEG, base64: true });
  if (!out.base64) { Alert.alert('Could not process the photo'); return null; }
  return { bytes: decode(out.base64), name: `photo-${Date.now()}.jpg`, mime: 'image/jpeg' };
}
