/**
 * Daily Reports: the city of a work site. Work Sites has no City field (and no SQL is run), so the city is taken from the site name:
 * the FIRST word of the name that is a known city (or one of its spellings) -> that city; no match -> "Other".
 * Example: "Office Location Pune CVPATIL" -> Pune.
 */
const CITIES: Record<string, string[]> = {
  Ahilyanagar: ['ahilyanagar', 'ahmednagar', 'ahmadnagar'],
  Akola: ['akola'], Amravati: ['amravati', 'amaravati'], Aurangabad: ['aurangabad', 'chhatrapati', 'sambhajinagar', 'sambhaji'],
  Baramati: ['baramati'], Beed: ['beed', 'bid'], Bhandara: ['bhandara'], Buldhana: ['buldhana', 'buldana'],
  Chandrapur: ['chandrapur'], Dhule: ['dhule'], Gadchiroli: ['gadchiroli'], Gondia: ['gondia'], Hingoli: ['hingoli'],
  Jalgaon: ['jalgaon'], Jalna: ['jalna'], Kolhapur: ['kolhapur'], Latur: ['latur'], Mumbai: ['mumbai', 'bombay'],
  Nagpur: ['nagpur'], Nanded: ['nanded'], Nandurbar: ['nandurbar'], Nashik: ['nashik', 'nasik'], 'Navi Mumbai': ['navimumbai'],
  Osmanabad: ['osmanabad', 'dharashiv'], Palghar: ['palghar'], Parbhani: ['parbhani'], Pune: ['pune', 'poona', 'pimpri', 'chinchwad'],
  Raigad: ['raigad', 'alibag'], Ratnagiri: ['ratnagiri'], Sangli: ['sangli'], Satara: ['satara'], Sindhudurg: ['sindhudurg'],
  Solapur: ['solapur'], Thane: ['thane'], Wardha: ['wardha'], Washim: ['washim'], Yavatmal: ['yavatmal'],
  Hyderabad: ['hyderabad'], Bengaluru: ['bengaluru', 'bangalore'], Delhi: ['delhi'], Ahmedabad: ['ahmedabad'], Goa: ['goa', 'panaji'],
};
const LOOKUP = new Map<string, string>();
for (const [city, words] of Object.entries(CITIES)) for (const w of words) LOOKUP.set(w, city);
export const OTHER_CITY = 'Other';

/** The city of a work site name ("Other" when no known city is in the name) */
export function cityOfSite(siteName: string): string {
  const words = (siteName ?? '').toLowerCase().split(/[^a-z]+/).filter(Boolean);
  for (const w of words) {
    const c = LOOKUP.get(w);
    if (c) return c;
  }
  return OTHER_CITY;
}

/** Natural A-Z (Sub Division 2 before Sub Division 10) */
export const natCmp = (a: string, b: string) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
/** City order: A-Z with "Other" last */
export const cityCmp = (a: string, b: string) => (a === OTHER_CITY ? 1 : b === OTHER_CITY ? -1 : natCmp(a, b));
