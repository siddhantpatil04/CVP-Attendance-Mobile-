// The notification list (bell): rows come from public.notifications (RLS: only my own), live through Realtime.
import React from 'react';
import { Platform } from 'react-native';
import { useAuth } from './auth';
import { useRealtime } from './realtime';
import { supabase } from './supabase';

export interface AppNotification {
  id: number; user_id: string; kind: 'LEAVE_APPROVED' | 'LEAVE_REJECTED' | 'REG_APPROVED' | 'REG_REJECTED' | 'TEST' | 'SLIP_READY' | 'SLIP_REMINDER' | 'SLIP_QUERY' | 'SLIP_ANSWER';
  title: string; body: string; link: string | null; data: Record<string, unknown>; read_at: string | null; sent_at: string | null; push_error: string | null; created_at: string;
}

export const notificationsApi = {
  list: async (limit = 100): Promise<AppNotification[]> => {
    const { data, error } = await supabase.from('notifications').select('*').order('id', { ascending: false }).limit(limit);
    if (error) throw error;
    return (data ?? []) as AppNotification[];
  },
  markRead: async (ids: number[] | null) => {
    const { error } = await supabase.rpc('mark_notifications_read', { p_ids: ids });
    if (error) throw error;
  },
  sendTest: async () => {
    const { error } = await supabase.rpc('send_test_notification');
    if (error) throw error;
  },
  /** HR / Admin: how many phones with notifications does this employee have */
  deviceCount: async (userId: string): Promise<number> => {
    try { const { data, error } = await supabase.rpc('admin_push_device_count', { p_user: userId }); if (error) throw error; return Number(data ?? 0); }
    catch { return 0; }
  },
};

/** "now", "5 min", "3 h", "2 d" */
export function ago(iso: string): string {
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return 'now';
  if (s < 3600) return `${Math.floor(s / 60)} min`;
  if (s < 86400) return `${Math.floor(s / 3600)} h`;
  return `${Math.floor(s / 86400)} d`;
}

/** The list + unread count of the signed-in user, kept live. `onNew` is called for each row that arrives while the app is open. */
export function useNotifications(onNew?: (n: AppNotification) => void) {
  const { profile } = useAuth();
  const [rows, setRows] = React.useState<AppNotification[] | null>(null);
  const [missing, setMissing] = React.useState(false);   // notifications.sql was not run yet
  const cb = React.useRef(onNew); cb.current = onNew;
  const load = React.useCallback(async () => {
    if (!profile) return;
    try { setRows(await notificationsApi.list()); setMissing(false); } catch { setRows((r) => r ?? []); setMissing(true); }
  }, [profile?.id]);
  React.useEffect(() => { setRows(null); load(); }, [load]);
  useRealtime(`notifications-${profile?.id}`, [{ table: 'notifications', filter: `user_id=eq.${profile?.id}` }], (p) => {
    if (p.eventType === 'INSERT' && p.new) cb.current?.(p.new as unknown as AppNotification);
    load();
  }, !!profile && !missing);
  const unread = (rows ?? []).filter((r) => !r.read_at).length;
  const markRead = React.useCallback(async (ids: number[] | null) => {
    setRows((r) => (r ?? []).map((x) => (ids === null || ids.includes(x.id) ? { ...x, read_at: x.read_at ?? new Date().toISOString() } : x)));
    try { await notificationsApi.markRead(ids); } catch { load(); }
  }, [load]);
  return { rows, unread, missing, reload: load, markRead };
}

/** ONE shared list for the whole app (the provider is in NotificationsHost); screens read it with useNotificationList() */
export type NotificationState = ReturnType<typeof useNotifications>;
export const NotificationContext = React.createContext<NotificationState>({ rows: [], unread: 0, missing: false, reload: async () => undefined, markRead: async () => undefined });
export const useNotificationList = () => React.useContext(NotificationContext);

// ---- desktop / web pop-up (browser Notification API; asks once) --------------------------------------------------------------------
export const webNotifyAvailable = () => Platform.OS === 'web' && typeof window !== 'undefined' && 'Notification' in window;
export const webNotifyPermission = (): 'granted' | 'denied' | 'default' | 'unavailable' => (webNotifyAvailable() ? (Notification.permission as any) : 'unavailable');
export async function askWebNotify(): Promise<void> {
  if (!webNotifyAvailable() || Notification.permission !== 'default') return;
  try { await Notification.requestPermission(); } catch { /* ignore */ }
}
export function showWebNotify(n: { title: string; body: string }, onClick?: () => void) {
  if (!webNotifyAvailable() || Notification.permission !== 'granted') return;
  try {
    const x = new Notification(n.title, { body: n.body, icon: '/favicon.ico' });
    x.onclick = () => { try { window.focus(); } catch { /* ignore */ } onClick?.(); x.close(); };
  } catch { /* some browsers only allow it from a service worker: ignore */ }
}
