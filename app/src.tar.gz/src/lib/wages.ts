﻿import type { PayrollRow } from './api';
import { computeSalary, FormulaItem, STARTING_ITEMS, WageExtra } from './salaryEngine';

/**
 * Wage-register rules (change them here, in one place). They follow the company's Salary Sheet Calculator.
 *  Basic         = monthly salary x present days / days in the month x 50 %.
 *  HRA           = 40 % of Basic.   Other allowances = 60 % of Basic (+ overtime pay).   Total Gross = Basic + HRA + Other.
 *  PF wages      = the larger of Basic and half of Total Gross, up to Rs 25,000.   PF = 12 % of PF wages (employee and employer).
 *  ESIC          = only when the monthly salary is Rs 21,000 or less: employee 0.75 %, employer 3.25 % of total gross, rounded up.
 *  Professional tax = Rs 200 a month (Rs 300 in February).
 *  Advance       = not recorded in the app yet (0).
 */
export const WAGE_RULES = {
  basicPct: 0.5, hraPct: 0.4, otherPct: 0.6,
  pfPct: 0.12,
  esicSalaryLimit: 21000, esicEmployeePct: 0.0075, esicEmployerPct: 0.0325,
  // Maharashtra PT slabs of the Salary Sheet Calculator: women nil up to 25,000; men nil up to 7,500, 175 up to 10,000; above that 200 (300 in February)
  professionalTax: 200, professionalTaxFeb: 300, ptMenNil: 7500, ptMenMid: 10000, ptMidAmount: 175, ptWomenNil: 25000,
  // employer-cost columns (PF wages = the larger of Basic and half of Total Gross, up to the ceiling; EPS part of the employer PF)
  pfWageCeiling: 25000, epsPct: 0.0833,
};

export interface WageRow {
  userId: string; name: string; department: string; joining: string; resigned: string; uan: string; gender: string;
  gross: number; daysPresent: number; daysUnpaid: number;
  /** "Total Days" column: the days of that month (28 / 29 / 30 / 31) */
  daysInMonth: number;
  basic: number; hra: number; other: number; overtime: number; totalGross: number;
  pfEmployee: number; pt: number; esicEmployee: number; pfEmployer: number; esicEmployer: number; advance: number;
  totalDeduct: number; net: number;
  /** PF member / EPS eligible: Y when PF is deducted, else N (empty in the totals row) */
  pfMember: 'Y' | 'N' | ''; epsEligible: 'Y' | 'N' | '';
  pfWages: number; epsWages: number; employerEps: number; employerEpf: number; employerCost: number;
  /** amount of every ADDED salary formula by code (salary rules); empty with Version 1 */
  extras?: Record<string, number>;
}

/** One wage row. The numbers come from the ONE calculator (salaryEngine.computeSalary) with the formulas of the month; the starting formulas give the old numbers. */
export function wageRow(p: PayrollRow, month: number, extra: WageExtra, items: FormulaItem[] = STARTING_ITEMS): WageRow {
  return computeSalary(p, month, items, extra);
}

/** Totals row of a list of wage rows */
export function wageTotals(rows: WageRow[]): WageRow {
  const sum = (k: keyof WageRow) => rows.reduce((a, r) => a + Number(r[k] || 0), 0);
  return {
    userId: '', name: 'TOTAL', department: '', joining: '', resigned: '', uan: '', gender: '',
    gross: sum('gross'), daysPresent: sum('daysPresent'), daysUnpaid: sum('daysUnpaid'), daysInMonth: 0,
    basic: sum('basic'), hra: sum('hra'), other: sum('other'), overtime: sum('overtime'), totalGross: sum('totalGross'),
    pfEmployee: sum('pfEmployee'), pt: sum('pt'), esicEmployee: sum('esicEmployee'), pfEmployer: sum('pfEmployer'),
    esicEmployer: sum('esicEmployer'), advance: sum('advance'), totalDeduct: sum('totalDeduct'), net: sum('net'),
    pfMember: '', epsEligible: '',
    pfWages: sum('pfWages'), epsWages: sum('epsWages'), employerEps: sum('employerEps'), employerEpf: sum('employerEpf'), employerCost: sum('employerCost'),
    extras: rows.reduce((a, r) => { for (const [k, v] of Object.entries(r.extras ?? {})) a[k] = (a[k] ?? 0) + v; return a; }, {} as Record<string, number>),
  };
}
