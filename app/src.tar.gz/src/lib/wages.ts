﻿import type { PayrollRow } from './api';

/**
 * Wage-register rules (change them here, in one place). They follow the company's Salary Sheet Calculator.
 *  Basic         = monthly salary x present days / days in the month x 50 %.
 *  HRA           = 40 % of Basic.   Other allowances = 60 % of Basic (+ overtime pay).   Total Gross = Basic + HRA + Other.
 *  PF wages      = the larger of Basic and half of Total Gross, up to Rs 25,000.   PF = 12 % of PF wages (employee and employer).
 *  ESIC          = only when the monthly salary is Rs 21,000 or less: employee 0.75 %, employer 3.25 % of total gross, rounded up.
 *  Professional tax = Rs 200 a month (Rs 300 in February).
 *  Advance       = not recorded in the app yet (0).
 */
export const WAGE_RULES = {
  basicPct: 0.5, hraPct: 0.4, otherPct: 0.6,
  pfPct: 0.12,
  esicSalaryLimit: 21000, esicEmployeePct: 0.0075, esicEmployerPct: 0.0325,
  // Maharashtra PT slabs of the Salary Sheet Calculator: women nil up to 25,000; men nil up to 7,500, 175 up to 10,000; above that 200 (300 in February)
  professionalTax: 200, professionalTaxFeb: 300, ptMenNil: 7500, ptMenMid: 10000, ptMidAmount: 175, ptWomenNil: 25000,
  // employer-cost columns (PF wages = the larger of Basic and half of Total Gross, up to the ceiling; EPS part of the employer PF)
  pfWageCeiling: 25000, epsPct: 0.0833,
};

export interface WageRow {
  userId: string; name: string; department: string; joining: string; resigned: string; uan: string; gender: string;
  gross: number; daysPresent: number; daysUnpaid: number;
  /** "Total Days" column: the days of that month (28 / 29 / 30 / 31) */
  daysInMonth: number;
  basic: number; hra: number; other: number; overtime: number; totalGross: number;
  pfEmployee: number; pt: number; esicEmployee: number; pfEmployer: number; esicEmployer: number; advance: number;
  totalDeduct: number; net: number;
  /** PF member / EPS eligible: Y when PF is deducted, else N (empty in the totals row) */
  pfMember: 'Y' | 'N' | ''; epsEligible: 'Y' | 'N' | '';
  pfWages: number; epsWages: number; employerEps: number; employerEpf: number; employerCost: number;
}

const r0 = (n: number) => Math.round(n);

export function wageRow(
  p: PayrollRow, month: number,
  extra: { joining?: string | null; resigned?: string | null; uan?: string | null; gender?: string | null; advance?: number },
): WageRow {
  const R = WAGE_RULES;
  const salary = Number(p.monthly_salary);
  // The same formulas as the Salary Sheet Calculator (Days in the month = paid days + unpaid days):
  //   Basic = Gross x Present / Total days x 50 %,  HRA = Basic x 40 %,  Other = Basic x 60 %,  Total Gross = Basic + HRA + Other (+ overtime)
  const days = p.payable_days + p.unpaid_days || 1;
  const basic = r0(((salary * p.payable_days) / days) * R.basicPct);
  const hra = r0(basic * R.hraPct);
  // The Salary Sheet Calculator has no overtime: Other = Basic x 60 % only (overtime stays in the Working Hours / Salary reports)
  const ot = 0;
  const other = r0(basic * R.otherPct);
  const totalGross = basic + hra + other;
  // PF wages = the larger of Basic and half of Total Gross, up to Rs 25,000; PF = 12 % of PF wages (employee and employer)
  const member = salary > 0;
  const pfWages = member ? Math.min(Math.max(basic, r0(totalGross / 2)), R.pfWageCeiling) : 0;
  const pf = r0(pfWages * R.pfPct);
  const fem = (extra.gender ?? '').toLowerCase().startsWith('f');
  const ptTop = month === 2 ? R.professionalTaxFeb : R.professionalTax;
  const pt = totalGross <= 0 ? 0
    : fem ? (totalGross <= R.ptWomenNil ? 0 : ptTop)
    : totalGross <= R.ptMenNil ? 0 : totalGross <= R.ptMenMid ? R.ptMidAmount : ptTop;
  // ESIC only when the monthly rate is Rs 21,000 or less: Total Gross x 0.75 % / 3.25 %, rounded UP
  const esicOn = salary > 0 && salary <= R.esicSalaryLimit && totalGross > 0;
  const up = (n: number) => Math.ceil(Number(n.toFixed(6)));
  const esicEmployee = esicOn ? up(totalGross * R.esicEmployeePct) : 0;
  const esicEmployer = esicOn ? up(totalGross * R.esicEmployerPct) : 0;
  const advance = extra.advance ?? 0;
  const totalDeduct = pf + pt + esicEmployee + advance;
  const g = (extra.gender ?? '').toLowerCase();
  const epsWages = member ? pfWages : 0;
  const employerEps = r0(epsWages * R.epsPct);
  return {
    userId: p.user_id, name: p.full_name.replace(/\s*\(Resigned[^)]*\)\s*$/i, ''), department: p.department ?? '',
    joining: extra.joining ?? '', resigned: extra.resigned ?? '', uan: extra.uan ?? '', gender: g.startsWith('m') ? 'M' : g.startsWith('f') ? 'F' : g ? 'O' : '',
    gross: r0(salary), daysPresent: p.payable_days, daysUnpaid: p.unpaid_days, daysInMonth: p.payable_days + p.unpaid_days,
    basic, hra, other, overtime: ot, totalGross,
    pfEmployee: pf, pt, esicEmployee, pfEmployer: pf, esicEmployer, advance,
    totalDeduct, net: totalGross - totalDeduct,
    pfMember: member ? 'Y' : 'N', epsEligible: member ? 'Y' : 'N',
    pfWages, epsWages, employerEps, employerEpf: pf - employerEps, employerCost: totalGross + pf + esicEmployer,
  };
}

/** Totals row of a list of wage rows */
export function wageTotals(rows: WageRow[]): WageRow {
  const sum = (k: keyof WageRow) => rows.reduce((a, r) => a + Number(r[k] || 0), 0);
  return {
    userId: '', name: 'TOTAL', department: '', joining: '', resigned: '', uan: '', gender: '',
    gross: sum('gross'), daysPresent: sum('daysPresent'), daysUnpaid: sum('daysUnpaid'), daysInMonth: 0,
    basic: sum('basic'), hra: sum('hra'), other: sum('other'), overtime: sum('overtime'), totalGross: sum('totalGross'),
    pfEmployee: sum('pfEmployee'), pt: sum('pt'), esicEmployee: sum('esicEmployee'), pfEmployer: sum('pfEmployer'),
    esicEmployer: sum('esicEmployer'), advance: sum('advance'), totalDeduct: sum('totalDeduct'), net: sum('net'),
    pfMember: '', epsEligible: '',
    pfWages: sum('pfWages'), epsWages: sum('epsWages'), employerEps: sum('employerEps'), employerEpf: sum('employerEpf'), employerCost: sum('employerCost'),
  };
}
