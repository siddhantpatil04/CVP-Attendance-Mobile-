// Two companies: C.V. Patil & Associates (CVPA) and C.V. Patil Consultancy Engineers Pvt. Ltd. (CVPCE).
// The company only decides WHICH employees appear in a report and WHICH name / address is printed on it.
// Attendance, leave, working hours and salary calculations never look at it. Needs supabase/two_companies.sql.
import AsyncStorage from '@react-native-async-storage/async-storage';
import React from 'react';
import { COMPANY_ADDRESS, COMPANY_NAME, COMPANY_PAN } from '../config';
import { supabase } from './supabase';
import { istDateISO } from './time';

export interface Company {
  id: number; short_code: string; legal_name: string; address: string | null; pan_or_cin: string | null; is_active: boolean;
}
export interface CompanyHistoryRow { employee_id: string; company_id: number; from_date: string }

const FALLBACK: Company[] = [
  { id: 1, short_code: 'CVPA', legal_name: 'C.V. Patil & Associates', address: null, pan_or_cin: null, is_active: true },
];

export const companiesApi = {
  list: async (): Promise<Company[]> => {
    const { data, error } = await supabase.from('companies').select('*').eq('is_active', true).order('id');
    if (error) throw error;
    return (data ?? []) as Company[];
  },
  /** HR / Admin read every row; anybody else only their own */
  history: async (): Promise<CompanyHistoryRow[]> => {
    const { data, error } = await supabase.from('employee_company_history').select('employee_id, company_id, from_date').order('from_date').limit(20000);
    if (error) throw error;
    return (data ?? []) as CompanyHistoryRow[];
  },
  setEmployeeCompany: async (userId: string, companyId: number, fromDate: string) => {
    const { error } = await supabase.rpc('admin_set_employee_company', { p_user: userId, p_company: companyId, p_from: fromDate });
    if (error) throw error;
    cache = null;
  },
  create: async (legalName: string, address: string, panOrCin: string) => {
    const { error } = await supabase.rpc('admin_create_company', { p_legal_name: legalName, p_address: address, p_pan_or_cin: panOrCin });
    if (error) throw error;
    cache = null;
  },
  update: async (id: number, legalName: string, address: string, panOrCin: string) => {
    const { error } = await supabase.rpc('admin_update_company', { p_company: id, p_legal_name: legalName, p_address: address, p_pan_or_cin: panOrCin });
    if (error) throw error;
    cache = null;
  },
};

interface Cache { companies: Company[]; history: CompanyHistoryRow[]; at: number; ok: boolean }
let cache: Cache | null = null;

async function loadAll(force = false): Promise<Cache> {
  if (cache && !force && Date.now() - cache.at < 60_000) return cache;
  let ok = true;
  const [companies, history] = await Promise.all([
    companiesApi.list().catch(() => { ok = false; return FALLBACK; }),
    companiesApi.history().catch(() => [] as CompanyHistoryRow[]),
  ]);
  cache = { companies, history, at: Date.now(), ok };
  return cache;
}

/** Companies + company history, with the "which company on this date" helpers */
export function useCompanies() {
  const [data, setData] = React.useState<Cache | null>(cache);
  const reload = React.useCallback(async (force = true) => { setData(await loadAll(force)); }, []);
  React.useEffect(() => { loadAll().then(setData).catch(() => undefined); }, []);
  const companies = data?.companies ?? FALLBACK;
  const history = data?.history ?? [];
  const byEmp = React.useMemo(() => {
    const m = new Map<string, CompanyHistoryRow[]>();
    for (const h of history) { const l = m.get(h.employee_id); if (l) l.push(h); else m.set(h.employee_id, [h]); }
    for (const l of m.values()) l.sort((a, b) => (a.from_date < b.from_date ? -1 : 1));
    return m;
  }, [history]);
  /** the company valid for an employee on a date (same rule as get_employee_company in SQL) */
  const companyAt = React.useCallback((empId: string, date: string, fallbackId?: number | null): number => {
    const l = byEmp.get(empId);
    if (!l || !l.length) return fallbackId ?? companies[0]?.id ?? 0;
    let hit = l[0].company_id;
    for (const h of l) { if (h.from_date <= date) hit = h.company_id; else break; }
    return hit;
  }, [byEmp, companies]);
  /** every company an employee belongs to at some day of from..to (a mid-month move gives two) */
  const companiesDuring = React.useCallback((empId: string, from: string, to: string, fallbackId?: number | null): number[] => {
    const l = byEmp.get(empId);
    if (!l || !l.length) return [fallbackId ?? companies[0]?.id ?? 0];
    const out = new Set<number>([companyAt(empId, from, fallbackId)]);
    for (const h of l) if (h.from_date > from && h.from_date <= to) out.add(h.company_id);
    return [...out];
  }, [byEmp, companyAt, companies]);
  const byId = React.useCallback((id: number) => companies.find((c) => c.id === id), [companies]);
  return { companies, history, reload, companyAt, companiesDuring, byId, ready: !!data, dbOk: data ? data.ok : true };
}

const KEY = 'cvp.reportCompany';
/** The "Company" choice of the report screens (0 = all companies). The last choice is remembered on this device. */
export function useCompanyChoice(): [number, (v: number) => void] {
  const [v, setV] = React.useState(0);
  React.useEffect(() => { AsyncStorage.getItem(KEY).then((s) => { if (s) setV(Number(s) || 0); }).catch(() => undefined); }, []);
  React.useEffect(() => () => setReportCompany(null), []);   // leaving a report screen: the next report starts with the normal heading
  const set = React.useCallback((n: number) => { setV(n); AsyncStorage.setItem(KEY, String(n)).catch(() => undefined); }, []);
  return [v, set];
}

/** Is this employee (company valid at any day of from..to) in the chosen company? 0 = every company. */
export function inChosenCompany(
  hook: ReturnType<typeof useCompanies>, choice: number, empId: string, from: string, to: string, fallbackId?: number | null,
): boolean {
  if (!choice) return true;
  return hook.companiesDuring(empId, from, to, fallbackId).includes(choice);
}

/** Today (IST), handy default for "from date" fields */
export const todayISO = () => istDateISO();
export const firstOfMonthISO = () => istDateISO().slice(0, 8) + '01';

// ---- Heading of the report being made ---------------------------------------------------------------------------
// A screen calls setReportCompany(...) right before it downloads; every PDF / Excel generator reads rh() when it prints
// "Name of the Establishment / PAN / Address". Nothing set = the original text (C.V.Patil & Associates), so old reports do not change.
export interface ReportHeading { name: string; title: string; address: string; pan: string; code: string }
const DEFAULT_HEADING: ReportHeading = { name: 'C.V.Patil & Associates', title: COMPANY_NAME, address: COMPANY_ADDRESS, pan: COMPANY_PAN, code: '' };
let heading: ReportHeading = DEFAULT_HEADING;
/** The selected company -> heading. A list (All companies) joins the names, PAN / CIN and addresses. null = the original heading. */
export function setReportCompany(c: Company | Company[] | null | undefined) {
  if (!c || (Array.isArray(c) && !c.length)) { heading = DEFAULT_HEADING; return; }
  const list = Array.isArray(c) ? c : [c];
  const join = (f: (x: Company) => string | null | undefined, sep: string) => list.map(f).filter(Boolean).join(sep);
  heading = {
    name: join((x) => x.legal_name, ' / '),
    title: join((x) => x.legal_name.toUpperCase(), ' / '),
    address: join((x) => x.address, ' | '),
    pan: join((x) => x.pan_or_cin, ' / '),
    code: list.length === 1 ? list[0].short_code : 'ALL',
  };
}
export const rh = (): ReportHeading => heading;
/** File name with the company code: cvp_attendance_register_all_2026-11.pdf -> cvp_attendance_register_all_CVPCE_2026-11.pdf */
export function withCompanyCode(fileName: string): string {
  const code = heading.code;
  if (!code || fileName.includes(`_${code}_`) || fileName.includes(`_${code}.`)) return fileName;
  const m = fileName.match(/^(.*?)(_\d{4}-\d{2}.*)$/);
  if (m) return `${m[1]}_${code}${m[2]}`;
  return fileName.replace(/(\.[A-Za-z0-9]+)$/, `_${code}$1`);
}
/** Company name list for a screen: the chosen company, or all of them */
export const headingOf = (all: Company[], choice: number) => (choice ? all.find((c) => c.id === choice) : all.length > 1 ? all : all[0]);
