import { rh } from './companies';
import { siteTextCell } from './dailyReportPdf';
import { loadPdfLibs, outputPdf } from './pdf';
import { saveXlsxData } from './xlsx';

/**
 * Leave Register - Monthly (PDF / Excel). Only READS leave requests, approvals and balances.
 * Every leave request that overlaps the month (A-Z, then From date), with the summary row.
 */
export interface LeaveRegRow {
  name: string; empId: string; type: string; from: string; to: string; days: number; pay: string; reason: string; applied: string;
  status: 'Approved' | 'Rejected' | 'Waiting' | 'Cancelled'; by: string;
}
export interface LeaveBalRow { name: string; empId: string; elTaken: number; clTaken: number; slTaken: number; unpaid: number; bEl: number; bCl: number; bSl: number }
export interface LeaveRegInfo { title: string; period: string; month: string; generated: string; by?: string; summary: string; footer: string }

const INK: [number, number, number] = [20, 20, 20];
const clean = (s: unknown) => String(s ?? '').replace(/[    ]/g, ' ');
const sc = (s: LeaveRegRow['status']): [number, number, number] => (s === 'Approved' ? [14, 122, 74] : s === 'Rejected' ? [192, 0, 0] : s === 'Waiting' ? [168, 100, 0] : [110, 110, 110]);
const sa = (s: LeaveRegRow['status']) => (s === 'Approved' ? 'FF0E7A4A' : s === 'Rejected' ? 'FFC00000' : s === 'Waiting' ? 'FFA86400' : 'FF6E6E6E');
const num = (n: number) => (Number.isInteger(n) ? String(n) : String(Number(n.toFixed(2))));
const PAD = 1.6;

export async function leaveRegisterPdf(fileName: string, info: LeaveRegInfo, rows: LeaveRegRow[]) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
  const header = () => {
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5);
    doc.text(clean(info.title), W / 2, 10, { align: 'center' });
    doc.setFontSize(9); doc.text(clean(info.period), W / 2, 15.5, { align: 'center' });
    doc.setFontSize(8); doc.text('Name of the Establishment -', 8, 22);
    doc.setFont('helvetica', 'normal'); doc.text(rh().name, 52, 22);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text('For the Month of -', 165, 22); doc.text(clean(info.month), 198, 22);
    doc.setFontSize(8); doc.text('Address of the Establishment -', 8, 27);
    doc.setFont('helvetica', 'normal'); doc.text(clean(rh().address), 52, 27);
  };
  const CW = [10, 42, 30, 20, 20, 12, 28, 44, 20, 18, 37];
  const head = ['Sr. No.', 'Name of the Employee', 'Leave Type', 'From', 'To', 'Days', 'Paid / Unpaid', 'Reason', 'Applied on', 'Status', 'Approved / Rejected by'];
  autoTable(doc, {
    startY: 31, head: [head], theme: 'grid', showHead: 'everyPage',
    body: [
      ...rows.map((r, i) => [String(i + 1), clean(`${r.name}${r.empId ? `\n${r.empId}` : ''}`), clean(r.type), r.from, r.to, num(r.days), clean(r.pay) || '-', siteTextCell(r.reason, CW[7]), r.applied, r.status, siteTextCell(r.by, CW[10])] as any[]),
      [{ content: clean(info.summary), colSpan: 11, styles: { fillColor: [226, 239, 218], textColor: INK, fontStyle: 'bold', halign: 'left' } }],
    ],
    styles: { font: 'helvetica', fontSize: 7.5, cellPadding: PAD, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', halign: 'center', overflow: 'linebreak' },
    headStyles: { fillColor: [255, 192, 0], textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle' },
    columnStyles: Object.fromEntries(CW.map((w, i) => [i, { cellWidth: w, halign: i === 1 || i === 2 || i === 7 || i === 10 ? 'left' : 'center' }])),
    margin: { left: 8, right: 8, top: 31, bottom: 14 }, rowPageBreak: 'avoid',
    didDrawPage: () => header(),
    willDrawCell: (d: any) => { if (d.section === 'body' && d.column.index === 9) { const r = rows[d.row.index]; if (r) { d.cell.styles.textColor = sc(r.status); d.cell.styles.fontStyle = 'bold'; } } },
    didDrawCell: (d: any) => {
      const raw = d.cell?.raw;   // Marathi / Hindi text is a picture drawn by the browser
      if (d.section === 'body' && raw && raw.img) { try { doc.addImage(raw.img, 'PNG', d.cell.x + PAD, d.cell.y + PAD, raw.iw, raw.ih); } catch { /* skip */ } }
    },
  });
  const n = doc.getNumberOfPages();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.text(clean(info.footer), 8, H - 6);
    doc.text(clean(`Generated ${info.generated}${info.by ? ` by ${info.by}` : ''} - Page ${i} of ${n}`), W - 8, H - 6, { align: 'right' });
  }
  await outputPdf(fileName, doc);
}

export async function leaveRegisterXlsx(fileName: string, info: LeaveRegInfo, rows: LeaveRegRow[]) {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  const wb = new ExcelJS.Workbook();
  const BLACK = { argb: 'FF000000' }; const thin = { style: 'thin' as const, color: BLACK };
  const BORDER = { top: thin, bottom: thin, left: thin, right: thin };
  const font = (bold = false, argb = 'FF000000') => ({ name: 'Calibri', size: 11, bold, color: { argb } });
  const fill = (argb: string) => ({ type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb } });
  const build = (ws: any, widths: number[], heads: string[], lines: string[]) => {
    widths.forEach((w, i) => { ws.getColumn(i + 1).width = w; });
    const n = widths.length;
    lines.forEach((t, i) => { ws.mergeCells(i + 1, 1, i + 1, n); const c = ws.getCell(i + 1, 1); c.value = t; c.font = font(true); c.alignment = { horizontal: i < 2 ? 'center' : 'left', vertical: 'middle' }; });
    const hr = 5; ws.getRow(hr).height = 30;
    heads.forEach((h, i) => { const c = ws.getCell(hr, i + 1); c.value = h; c.font = font(true); c.fill = fill('FFFFC000'); c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true }; c.border = BORDER; });
    ws.autoFilter = { from: { row: hr, column: 1 }, to: { row: hr, column: n } };
    ws.views = [{ state: 'frozen', ySplit: hr }];
    ws.pageSetup = { orientation: 'landscape', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: 0.3, right: 0.3, top: 0.5, bottom: 0.55, header: 0.2, footer: 0.25 } };
    ws.headerFooter = { oddFooter: `&L${info.footer}&RPage &P of &N` };
    return hr;
  };
  const lines = [info.title, info.period, `Name of the Establishment - ${rh().name}        For the Month of - ${info.month}`, `Address of the Establishment - ${rh().address}`];
  const ws = wb.addWorksheet('Leave Register');
  let r = build(ws, [8, 30, 11, 22, 12, 12, 8, 20, 36, 13, 12, 30],
    ['Sr. No.', 'Employee', 'Emp ID', 'Leave Type', 'From', 'To', 'Days', 'Paid / Unpaid', 'Reason', 'Applied on', 'Status', 'Approved / Rejected by'], lines);
  rows.forEach((x, i) => {
    r += 1;
    const v = [i + 1, x.name, x.empId, x.type, x.from, x.to, x.days, x.pay || '-', x.reason, x.applied, x.status, x.by];
    v.forEach((val, k) => {
      const c = ws.getCell(r, k + 1); c.value = val as any; c.font = k === 10 ? font(true, sa(x.status)) : font();
      c.alignment = { horizontal: [1, 3, 7, 8, 11].includes(k) ? 'left' : 'center', vertical: 'middle', wrapText: true }; c.border = BORDER;
    });
  });
  r += 1; ws.mergeCells(r, 1, r, 12);
  const s = ws.getCell(r, 1); s.value = info.summary; s.font = font(true); s.fill = fill('FFE2EFDA'); s.alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };
  for (let k = 1; k <= 12; k++) ws.getCell(r, k).border = BORDER;
  const data = await wb.xlsx.writeBuffer();
  const ab = data instanceof ArrayBuffer ? data : (data as any).buffer.slice((data as any).byteOffset, (data as any).byteOffset + (data as any).byteLength);
  await saveXlsxData(fileName, ab);
}
