// India Standard Time helpers. IST is a fixed UTC+05:30 (no daylight saving),
// so we shift by a constant offset instead of relying on Intl time-zone support.
const IST_OFFSET_MS = 330 * 60 * 1000;

export const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];
export const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** A Date whose UTC getters return IST wall-clock values */
export function toIst(d: Date | number | string): Date {
  const ms = typeof d === 'number' ? d : new Date(d).getTime();
  return new Date(ms + IST_OFFSET_MS);
}

const pad = (n: number) => String(n).padStart(2, '0');

/** "2026-10-12" for the IST date of the given instant (default: now) */
export function istDateISO(d: Date | number | string = Date.now()): string {
  const x = toIst(d);
  return `${x.getUTCFullYear()}-${pad(x.getUTCMonth() + 1)}-${pad(x.getUTCDate())}`;
}

export function istParts(d: Date | number | string = Date.now()) {
  const x = toIst(d);
  return {
    year: x.getUTCFullYear(),
    month: x.getUTCMonth() + 1,
    day: x.getUTCDate(),
    hour: x.getUTCHours(),
    minute: x.getUTCMinutes(),
    second: x.getUTCSeconds(),
    weekday: x.getUTCDay(),
  };
}

/** "09:30 AM" */
export function fmtTime12(d: Date | number | string | null | undefined, withSeconds = false): string {
  if (d === null || d === undefined || d === '') return '-';
  const p = istParts(d);
  const h = p.hour % 12 === 0 ? 12 : p.hour % 12;
  const ampm = p.hour < 12 ? 'AM' : 'PM';
  return `${pad(h)}:${pad(p.minute)}${withSeconds ? ':' + pad(p.second) : ''} ${ampm}`;
}

/** "09:30" (24h) -> "09:30 AM" */
export function hhmmTo12(v?: string | null): string {
  if (!v) return '-';
  const [hs, ms] = v.split(':');
  const h = Number(hs);
  return `${pad(h % 12 === 0 ? 12 : h % 12)}:${ms} ${h < 12 ? 'AM' : 'PM'}`;
}

/** "Mon, 12 Oct 2026" */
export function fmtDateLong(d: Date | number | string = Date.now()): string {
  const p = istParts(d);
  return `${DAYS[p.weekday]}, ${p.day} ${MONTHS[p.month - 1].slice(0, 3)} ${p.year}`;
}

/** "2026-10-12" (a plain date string) -> "12 Oct 2026" */
export function fmtISODate(iso?: string | null): string {
  if (!iso) return '-';
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return `${d} ${MONTHS[m - 1].slice(0, 3)} ${y}`;
}

export function fmtMinutes(mins?: number | null): string {
  if (mins === null || mins === undefined || mins < 0) return '-';
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}h ${pad(m)}m`;
}

export function greeting(hour: number): string {
  return hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
}

/** Local calendar Date (for the date picker) -> "YYYY-MM-DD" */
export function localDateISO(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function isoToLocalDate(iso: string): Date {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d, 12, 0, 0);
}

export function localTimeHHMM(d: Date): string {
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function hhmmToLocalDate(v: string): Date {
  const [h, m] = v.split(':').map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return d;
}

export function initials(name?: string | null): string {
  const parts = (name || 'CVP').split(/\s+/).filter(Boolean);
  return parts.slice(0, 2).map((p) => p[0].toUpperCase()).join('') || 'CV';
}

/** "YYYY-MM-DD" -> "5 yrs 3 mo" (time since joining) */
export function serviceLength(iso?: string | null): string {
  if (!iso) return '-';
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  const n = istParts();
  let months = (n.year - y) * 12 + (n.month - m) - (n.day < d ? 1 : 0);
  if (months < 0) months = 0;
  const yrs = Math.floor(months / 12);
  const mo = months % 12;
  return yrs > 0 ? `${yrs} yr${yrs > 1 ? 's' : ''} ${mo} mo` : `${mo} mo`;
}