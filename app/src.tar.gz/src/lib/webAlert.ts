import { Alert, Platform } from 'react-native';

// React Native's Alert.alert does nothing in a browser, so confirm dialogs (Sign out,
// delete, cancel...) and error popups never appeared on the web version.
// This maps it to the browser's own alert / confirm boxes.
if (Platform.OS === 'web') {
  Alert.alert = (title, message, buttons) => {
    const text = [title, message].filter(Boolean).join('\n\n');
    if (!buttons || buttons.length <= 1) {
      window.alert(text);
      buttons?.[0]?.onPress?.();
      return;
    }
    const cancel = buttons.find((b) => b.style === 'cancel');
    const action = buttons.find((b) => b !== cancel) ?? buttons[0];
    if (window.confirm(text)) action.onPress?.();
    else cancel?.onPress?.();
  };
}
