import { useWindowDimensions } from 'react-native';

/** Screens at least this wide (desktop browser, laptop, large tablet) get the desktop layout. */
export const DESKTOP_MIN_WIDTH = 900;
/** Page content never stretches wider than this on big monitors. */
export const CONTENT_MAX_WIDTH = 1180;
/** Width of the left menu on desktop. */
export const SIDEBAR_WIDTH = 252;

/** true on a desktop-size window. Re-renders when the window is resized. */
export function useIsDesktop(): boolean {
  const { width } = useWindowDimensions();
  return width >= DESKTOP_MIN_WIDTH;
}
