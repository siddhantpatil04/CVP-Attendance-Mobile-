import { rh } from './companies';
import { loadPdfLibs, outputPdf } from './pdf';
import { saveXlsxData } from './xlsx';
import { SELFIE_STATUS } from './wagesRegisterPdf';

/**
 * Office Attendance Register (PDF / Excel): NO selfies - only check-in / check-out times, distance from the office and worked hours.
 *   - one date            : Sr. No. | Name of the Employee | Emp ID | Office | Check-in Time | Check-in Distance | Check-out Time | Check-out Distance | Worked Hours
 *   - whole month (one or all employees): per employee, one row for EVERY date with Sunday / holiday / leave / absent rows and a summary
 */
export interface OfficeRow {
  name: string; empId: string; office: string; date: string; day: string;
  inTime: string; inDist: string; outTime: string; outDist: string; worked: string; tone: 'ok' | 'short' | 'still' | 'none';
  /** Present / Present - no check-out / Present - short day */ statusText?: string;
  /** a date without a check-in: Sunday / holiday / leave / absent */ status?: { kind: 'sun' | 'hol' | 'leave' | 'absent' | 'noreport'; text: string };
}
export interface OfficeEmp { name: string; empId: string; office: string; rows: OfficeRow[]; summary: string }
export interface OfficeInfo { title: string; period: string; month: string; generated: string; by?: string; employee?: string }

const INK: [number, number, number] = [20, 20, 20];
const AMBER: [number, number, number] = [255, 192, 0];
const clean = (s: unknown) => String(s ?? '').replace(/[    ]/g, ' ');
const toneColor = (t: OfficeRow['tone']): [number, number, number] => (t === 'ok' ? [14, 122, 74] : t === 'short' ? [192, 0, 0] : t === 'still' ? [168, 100, 0] : INK);

function header(doc: any, info: OfficeInfo) {
  const W = doc.internal.pageSize.getWidth();
  doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5);
  doc.text(clean(info.title), W / 2, 10, { align: 'center' });
  doc.setFontSize(9); doc.text('Check-in / Check-out times', W / 2, 15, { align: 'center' });
  doc.text(clean(info.period), W / 2, 20, { align: 'center' });
  doc.setFontSize(8); doc.text('Name of the Establishment -', 8, 26);
  doc.setFont('helvetica', 'normal'); doc.text(rh().name, 52, 26);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text('For the Month of -', 165, 26); doc.text(clean(info.month), 198, 26);
  doc.setFontSize(8); doc.text('Address of the Establishment -', 8, 31);
  doc.setFont('helvetica', 'normal'); doc.text(clean(rh().address), 52, 31);
}
function footer(doc: any, info: OfficeInfo) {
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight(); const n = doc.getNumberOfPages();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.text('Distance = metres / km from the office point.', 8, H - 6);
    doc.text(clean(`Generated ${info.generated}${info.by ? ` by ${info.by}` : ''} - Page ${i} of ${n}`), W - 8, H - 6, { align: 'right' });
  }
}

/** One date: all employees in ONE table */
export async function officeDatePdf(fileName: string, info: OfficeInfo, rows: OfficeRow[]) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const head = ['Sr. No.', 'Name of the Employee', 'Office', 'Check-in Time', 'Check-in Distance', 'Check-out Time', 'Check-out Distance', 'Worked Hours'];
  const CW = [12, 70, 62, 25, 28, 25, 28, 31];
  autoTable(doc, {
    startY: 34, head: [head], theme: 'grid', showHead: 'everyPage',
    body: rows.map((r, i) => [String(i + 1), clean(r.name), clean(r.office) || '-', r.inTime || '-', r.inDist || '-', r.outTime || '-', r.outDist || '-', r.worked || '-']),
    styles: { font: 'helvetica', fontSize: 8, cellPadding: 1.6, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', overflow: 'linebreak' },
    headStyles: { fillColor: AMBER, textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle' },
    columnStyles: Object.fromEntries(CW.map((w, i) => [i, { cellWidth: w, halign: i === 1 || i === 2 ? 'left' : 'center' }])),
    margin: { left: 8, right: 8, top: 34, bottom: 14 }, rowPageBreak: 'avoid',
    didDrawPage: () => header(doc, info),
    willDrawCell: (d: any) => { if (d.section === 'body' && d.column.index === 7) { d.cell.styles.textColor = toneColor(rows[d.row.index]?.tone ?? 'none'); d.cell.styles.fontStyle = 'bold'; } },
  });
  footer(doc, info);
  await outputPdf(fileName, doc);
}

/** Whole month: one block per employee (yellow row, orange heading, a row for every date, green summary), employees A-Z */
export async function officeMonthPdf(fileName: string, info: OfficeInfo, emps: OfficeEmp[]) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const H = doc.internal.pageSize.getHeight();
  const head = ['Sr. No.', 'Date', 'Day', 'Check-in Time', 'Check-out Time', 'Worked Hours', 'Status'];
  const CW = [12, 26, 20, 32, 32, 35, 124];
  const TOP = 34;
  let y = TOP;
  emps.forEach((e, k) => {
    if (k > 0 && y + 40 > H - 14) { doc.addPage(); y = TOP; }
    const body: any[][] = e.rows.map((r, i) => {
      if (r.status) {
        const col = SELFIE_STATUS[r.status.kind];
        return [String(i + 1), r.date, r.day, { content: clean(r.status.text), colSpan: 4, styles: { fillColor: col.fill, textColor: col.text, fontStyle: 'bold', halign: 'center' } }];
      }
      return [String(i + 1), r.date, r.day, r.inTime || '-', r.outTime || '-', { content: r.worked || '-', styles: { textColor: toneColor(r.tone), fontStyle: 'bold' } }, clean(r.statusText ?? '')];
    });
    body.push([{ content: clean(e.summary), colSpan: 7, styles: { fillColor: [226, 239, 218], textColor: INK, fontStyle: 'bold', halign: 'left' } }]);
    autoTable(doc, {
      startY: y, theme: 'grid', showHead: 'everyPage', body,
      head: [
        [{ content: clean(`Name of the Employee - ${e.name}${e.empId ? ` (${e.empId})` : ''}${e.office ? `   |   Office - ${e.office}` : ''}`), colSpan: 7, styles: { fillColor: [255, 242, 204], textColor: INK, fontStyle: 'bold', halign: 'left' } }],
        head,
      ],
      styles: { font: 'helvetica', fontSize: 7.5, cellPadding: 1.2, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', overflow: 'linebreak' },
      headStyles: { fillColor: AMBER, textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle' },
      columnStyles: Object.fromEntries(CW.map((w, i) => [i, { cellWidth: w, halign: i === 6 ? 'left' : 'center' }])),
      margin: { left: 8, right: 8, top: TOP, bottom: 14 }, rowPageBreak: 'avoid',
      didDrawPage: () => header(doc, info),
    });
    y = ((doc as any).lastAutoTable?.finalY ?? y) + 4;
  });
  footer(doc, info);
  await outputPdf(fileName, doc);
}

// ---------------------------------------------------------------- Excel
async function newBook(info: OfficeInfo, widths: number[]) {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Office Attendance');
  const n = widths.length;
  widths.forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  const BLACK = { argb: 'FF000000' }; const thin = { style: 'thin' as const, color: BLACK };
  const BORDER = { top: thin, bottom: thin, left: thin, right: thin };
  const font = (bold = false, argb = 'FF000000') => ({ name: 'Calibri', size: 11, bold, color: { argb } });
  const fill = (argb: string) => ({ type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb } });
  const center = { horizontal: 'center' as const, vertical: 'middle' as const };
  let r = 0;
  const borders = () => { for (let k = 1; k <= n; k++) ws.getCell(r, k).border = BORDER; };
  const band = (text: string, bg: string | null, bold = true, align: 'left' | 'center' = 'left', border = true) => {
    r += 1; ws.mergeCells(r, 1, r, n);
    const c = ws.getCell(r, 1); c.value = text; c.font = font(bold); c.alignment = { horizontal: align, vertical: 'middle', wrapText: true };
    if (bg) c.fill = fill(bg);
    if (border) borders();
    ws.getRow(r).height = 20;
  };
  band(info.title, null, true, 'center', false); band('Check-in / Check-out times', null, true, 'center', false); band(info.period, null, true, 'center', false);
  band(`Name of the Establishment - ${rh().name}        For the Month of - ${info.month}`, null, true, 'left', false);
  band(`Address of the Establishment - ${rh().address}`, null, false, 'left', false);
  ws.pageSetup = { orientation: 'landscape', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: 0.3, right: 0.3, top: 0.5, bottom: 0.55, header: 0.2, footer: 0.25 } };
  ws.headerFooter = { oddFooter: `&L${info.title}&RPage &P of &N` };
  const heading = (cols: string[]) => {
    r += 1; ws.getRow(r).height = 30;
    cols.forEach((h, i) => { const c = ws.getCell(r, i + 1); c.value = h; c.font = font(true); c.fill = fill('FFFFC000'); c.alignment = { ...center, wrapText: true }; });
    borders();
  };
  const cell = (col: number, v: any, o: { bold?: boolean; argb?: string; left?: boolean } = {}) => {
    const c = ws.getCell(r, col); c.value = v; c.font = font(!!o.bold, o.argb); c.alignment = { horizontal: o.left ? 'left' : 'center', vertical: 'middle', wrapText: true };
  };
  const save = async () => {
    const data = await wb.xlsx.writeBuffer();
    const ab = data instanceof ArrayBuffer ? data : (data as any).buffer.slice((data as any).byteOffset, (data as any).byteOffset + (data as any).byteLength);
    return ab;
  };
  return { ws, band, heading, cell, next: () => { r += 1; return r; }, borders, save, fill, font, center, n, row: () => r };
}
const toneArgb = (t: OfficeRow['tone']) => (t === 'ok' ? 'FF0E7A4A' : t === 'short' ? 'FFC00000' : t === 'still' ? 'FFA86400' : 'FF000000');

export async function officeDateXlsx(fileName: string, info: OfficeInfo, rows: OfficeRow[]) {
  const x = await newBook(info, [8, 32, 12, 32, 14, 16, 14, 16, 16]);
  x.heading(['Sr. No.', 'Name of the Employee', 'Emp ID', 'Office', 'Check-in Time', 'Check-in Distance', 'Check-out Time', 'Check-out Distance', 'Worked Hours']);
  x.ws.views = [{ state: 'frozen', ySplit: x.row() }];
  rows.forEach((r, i) => {
    x.next();
    x.cell(1, i + 1); x.cell(2, r.name, { left: true }); x.cell(3, r.empId); x.cell(4, r.office || '-', { left: true });
    x.cell(5, r.inTime || '-'); x.cell(6, r.inDist || '-'); x.cell(7, r.outTime || '-'); x.cell(8, r.outDist || '-'); x.cell(9, r.worked || '-', { bold: true, argb: toneArgb(r.tone) });
    x.borders();
  });
  await saveXlsxData(fileName, await x.save());
}

export async function officeMonthXlsx(fileName: string, info: OfficeInfo, emps: OfficeEmp[]) {
  const x = await newBook(info, [8, 13, 8, 16, 16, 16, 46]);
  for (const e of emps) {
    x.band(`Name of the Employee - ${e.name}${e.empId ? ` (${e.empId})` : ''}${e.office ? `   |   Office - ${e.office}` : ''}`, 'FFFFF2CC');
    x.heading(['Sr. No.', 'Date', 'Day', 'Check-in Time', 'Check-out Time', 'Worked Hours', 'Status']);
    e.rows.forEach((r, i) => {
      x.next(); const rn = x.row();
      x.cell(1, i + 1); x.cell(2, r.date); x.cell(3, r.day);
      if (r.status) {
        const col = SELFIE_STATUS[r.status.kind];
        x.ws.mergeCells(rn, 4, rn, 7);
        const c = x.ws.getCell(rn, 4); c.value = r.status.text; c.fill = x.fill(col.argb); c.font = x.font(true, col.targb); c.alignment = x.center;
      } else {
        x.cell(4, r.inTime || '-'); x.cell(5, r.outTime || '-'); x.cell(6, r.worked || '-', { bold: true, argb: toneArgb(r.tone) }); x.cell(7, r.statusText ?? '', { left: true });
      }
      x.borders();
    });
    x.band(e.summary, 'FFE2EFDA');
  }
  await saveXlsxData(fileName, await x.save());
}
