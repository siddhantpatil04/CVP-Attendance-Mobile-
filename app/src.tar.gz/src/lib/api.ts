// Typed wrappers around the Supabase SQL functions (see supabase/cvp_attendance_schema.sql)
import { decode } from 'base64-arraybuffer';
import { supabase } from './supabase';
import { istDateISO } from './time';

export type Role = 'Employee' | 'HR' | 'Admin';

/** 10-digit Indian mobile number -> +91XXXXXXXXXX (numbers that already have a country code are kept) */
const toE164 = (v: string) => { const d = v.replace(/\D/g, ''); return d.length === 10 ? '+91' + d : '+' + d; };

export interface Profile {
  id: string;
  username: string;
  full_name: string;
  role: Role;
  department: string | null;
  designation?: string | null;
  /** false = the employee's username / password were removed and he must register with his mobile number */
  login_claimed?: boolean;
  shift_start: string; // "09:00:00"
  shift_end: string;
  active: boolean;
  site_employee: boolean;
  /** Project Manager: the admin-menu items he may use (project_manager_access.sql); null = no restriction */
  menu_access?: string[] | null;
  /** How many field visits this employee may start in one day (decided by Admin / HR) */
  /** Admin-granted two-stop travel attendance (check in / out at two sites, distance in km) */
  travel_access: boolean;
  /** Admin-granted Tour (apply, expenses, report) and Documents (upload with a remark) */
  tour_access?: boolean;
  documents_access?: boolean;
  /** Wide site: a site employee may check out from a different place than the check-in */
  wide_site_access?: boolean;
  /** Date the employee joined the company (YYYY-MM-DD) */
  joining_date: string | null;
  /** Company the employee belongs to today (two_companies.sql); the company valid on a past date comes from employee_company_history */
  company_id?: number | null;
  /** Saturdays of the month (1-5) that are a holiday for this person */
  saturday_off: number[];
  phone: string | null;
  email?: string | null;
  /** Self registration: Pending until an Admin / HR approves it, Rejected if refused */
  approval_status?: 'Pending' | 'Approved' | 'Rejected';
  registered_at?: string | null;
  created_at: string;
}

export interface AttendanceRow {
  /** 'Foreign Location' when the day was punched through Site Selfie > Foreign Location (foreign_location_place.sql) */
  place_type?: 'Foreign Location' | null; foreign_site_id?: number | null;
  /** metres from the office point at check-in / check-out (office punches) */
  check_in_dist_m?: number | null; check_out_dist_m?: number | null;
  id: number;
  user_id: string;
  work_date: string;
  check_in_at: string | null;
  check_out_at: string | null;
  is_late: boolean;
  source: 'office' | 'site' | 'regularized';
  site_name: string | null;
  note: string | null;
  status: 'Present' | 'Checked In' | null;
  work_minutes: number | null;
}

export interface MyDashboard {
  profile: Profile;
  today: string;
  server_time: string;
  attendance: AttendanceRow | null;
  month: {
    present: number; elapsed: number; working_days: number;
    late: number; absent: number; leave: number; hours: number;
  };
  leave_balance_total: number;
  is_holiday: string | null;
}

export interface MonthDay {
  day: string;
  dow: string;
  status: 'Upcoming' | 'Holiday' | 'Leave' | 'Present' | 'Checked In' | 'Rest Day' | 'Absent';
  in_time: string | null;
  out_time: string | null;
  hours: number | null;
  is_late: boolean;
  notes: string;
  source: string | null;
  site_name: string | null;
}

export interface LeaveBalance {
  leave_type: string; granted: number; used: number; balance: number; counts_balance: boolean;
}

export interface RegistrationRequest {
  id: number; employee_id: string; full_name: string; mobile: string | null; email: string | null;
  department: string | null; designation: string | null; channel: string | null;
  email_verified_at: string | null; phone_verified_at: string | null;
  status: 'Pending Verification' | 'Pending Approval' | 'Approved' | 'Active' | 'Rejected';
  submitted_at: string | null; reviewed_at: string | null; review_note: string | null; login_created_at: string | null;
}
export interface LoginOverviewRow {
  user_id: string; username: string | null; role: string; active: boolean; login_claimed: boolean;
  reg_id: number | null; reg_status: RegistrationRequest['status'] | null; email: string | null;
  email_verified: boolean; phone_verified: boolean; approval: 'Pending' | 'Approved' | 'Rejected' | null;
  reviewed_at: string | null; account_created_at: string | null;
}

/** Leave policy (leave_rules_update.sql): edited by the Admin, read by everybody */
export interface LeavePolicy {
  paid_leaves_per_month: number; eligibility_months: number; notice_days: number; count_weekly_off_between_leave: boolean;
  quotas: Record<string, number>;
}
/** One date of the leave preview */
export interface LeavePreviewDay { day: string; status: 'Paid' | 'Unpaid' | 'Weekly off' | 'Holiday'; per_day: number }

export interface LeaveRequest {
  id: number; user_id: string; leave_type: string; from_day: string; to_day: string;
  days: number; reason: string; status: string; review_note: string | null; created_at: string;
  reviewed_at: string | null; reviewed_by?: string | null; reviewed_by_role?: string | null;
  reviewer?: { full_name: string; role?: string } | null;   // who approved / rejected it
  /** 24-day policy (leave_policy_24.sql): 0.5 for a half day, which half, personal work, certificate, new-policy flag */
  units?: number | null; half_part?: 'first' | 'second' | null; personal_work?: string | null; certificate_path?: string | null; policy_v2?: boolean;
  employee?: { full_name: string; username: string; department: string | null } | null;
  /** leave_cancel_approved.sql: cancel of an approved leave. The leave stays Approved while cancel_status = 'requested'; 'approved' = status Cancelled; 'kept' = Admin kept the leave */
  cancel_status?: 'requested' | 'approved' | 'kept' | null; cancel_reason?: string | null; cancel_requested_at?: string | null; cancel_returned?: number | null;
  cancel_review_note?: string | null; cancel_reviewed_at?: string | null; cancel_reviewed_by?: string | null;
  canceller?: { full_name: string; role?: string } | null;   // Admin / HR who decided the cancellation
}
/** leave_cancel_options(): which cancel button a leave of mine gets */
export interface LeaveCancelOption { leave_id: number; mode: 'pending' | 'request' | 'requested' | 'finalized' }

/** leave_summary(): the numbers on My Leave */
export interface LeaveSummary {
  joining_date: string | null; eligible_from: string | null; eligible: boolean; months_done: number | null; months_total: number;
  days_left: number | null; early_start: boolean; early_reason: string | null;
  el: { balance: number; cap: number; yearly: number; added_this_month: number; saved_before: number };
  cl: { balance: number; yearly: number; added_this_month: number; used_year: number };
  sl: { balance: number; yearly: number; added_this_month: number; used_year: number };
  lop_year: number; paid_available: number; policy: LeavePolicy2;
  /** leave_rules_v3.sql: whole-day buckets and the rule set in force (absent until that SQL is run) */
  credit_from?: string | null;
  buckets?: Record<'EL' | 'CL' | 'SL', { this_month: number; saved: number; total: number }>;
  rules?: LeaveRules;
}
export interface LeaveRules {
  eligibility_months: number; monthly: Record<'EL' | 'CL' | 'SL', number[]>; save_unused: boolean; saved_notice_days: number;
  EL: { notice_days: number; carry_next_year_max: number; encash: boolean };
  CL: { short_notice: boolean; max_in_a_row: number; lapse_31_dec: boolean };
  SL: { same_day: boolean; certificate_after_days: number; lapse_31_dec: boolean };
}
export interface LeavePolicy2 {
  eligibility_months: number; el_notice_days: number; el_cap: number; el_keep_min: number; cl_max_request: number; sl_cert_after: number;
  sl_apply_within: number; lapse_month: number; lapse_day: number; personal_order: 'CL,EL' | 'EL,CL'; personal_max_month: number | null;
}
export interface LeavePreviewV2Day { day: string; status: 'Paid' | 'Unpaid' | 'Weekly off' | 'Holiday'; bucket: 'EL' | 'CL' | 'SL' | 'LOP' | null; units: number; per_day: number; source?: 'this_month' | 'saved' | 'lop' | null }
export interface LeaveLedgerRow {
  month: string; leave_type: string; kind: string; credited: number; used: number; lapsed: number; encashed: number; adjusted: number;
  amount: number | null; reason: string | null; balance_after: number; created_at: string;
}
export interface LeaveReviewInfo {
  policy_v2: boolean; half_part: 'first' | 'second' | null; personal_work: string | null; units: number; days_ahead: number;
  certificate_path: string | null; under_eligibility: boolean;
  before: { EL: number; CL: number; SL: number }; uses: { EL: number; CL: number; SL: number; LOP: number }; after: { EL: number; CL: number; SL: number };
}

export interface Regularization {
  id: number; user_id: string; day: string; requested_in: string; requested_out: string;
  reason: string; status: string; review_note: string | null; created_at: string;
  employee?: { full_name: string; username: string; department: string | null } | null;
}

export interface Tour {
  id: number; user_id: string; city: string; from_day: string; to_day: string;
  reason: string; status: string; review_note: string | null; created_at: string;
  employee?: { full_name: string; username: string; department: string | null } | null;
}

export interface EmployeeDocument {
  id: number; user_id: string; direction: 'from_employee' | 'from_admin'; title: string; remark: string | null;
  file_path: string; file_name: string | null; uploaded_by: string | null; created_at: string;
  /** Review workflow (needs supabase/document_review.sql). Employee uploads start as "Submitted"; Admin / HR sent documents are "Sent". */
  category?: string | null; status?: DocStatus; review_note?: string | null; reviewed_at?: string | null;
}
export type DocStatus = 'Submitted' | 'Under Review' | 'Approved' | 'Rejected' | 'Sent';
/** Documents "From C V Patil" */
export interface DocumentType {
  id: number; name: string; direction: 'from_cvp' | 'to_cvp'; default_visibility: string; can_all: boolean; allow_reshare: boolean; publishers: string[];
}
export type DocAudience = { kind: 'all' | 'site' | 'department' | 'employee'; values: string[] };
export interface SharedDocument {
  id: number; type_id: number; title: string; description: string | null; file_path: string; file_name: string | null;
  uploaded_by: string | null; sender_label: string; allow_download: boolean; visible_until: string | null; audience_kind: string; created_at: string;
  type?: { name: string } | null; uploader?: { full_name: string } | null;
  views?: { user_id: string; viewed_at: string; downloaded: boolean }[];
}
export const DOC_CATEGORIES = ['Letter', 'ID proof', 'Site report', 'Invoice / Bill', 'Medical', 'Other'] as const;

/** One row of the Documents Report (Admin / HR see everyone, an employee sees only his own) */
export interface DocumentReportRow extends EmployeeDocument {
  employee: { full_name: string; username: string } | null;
  sender: { full_name: string } | null;
}

/** Employee Form (personal details) and its documents */
export interface EducationRow { degree: string; specialization: string; year: string; marks: string }
export interface FamilyRow { name: string; relation: string; contact: string }
export interface EmployeeDetails {
  user_id: string;
  surname: string | null; first_name: string | null; father_name: string | null; mother_name: string | null;
  date_of_birth: string | null; gender: string | null; marital_status: string | null;
  permanent_address: string | null; local_address: string | null; tel_no: string | null; cell_no: string | null;
  email: string | null; pan_no: string | null; aadhar_no: string | null;
  education: EducationRow[]; software_skills: string | null; family: FamilyRow[];
  vehicle_company: string | null; vehicle_no: string | null; license_no: string | null;
  bank_name: string | null; bank_address: string | null; bank_branch: string | null;
  bank_account_no: string | null; ifsc_code: string | null; joining_date: string | null; resign_date: string | null; uan_no: string | null;
  /** ESIC IP number (esic_ip_no.sql) */ esic_no?: string | null;
  declared: boolean; updated_at: string;
}
export type DetailFileKind = 'photo' | 'pan' | 'aadhar' | 'graduation' | 'cv' | 'bank';
export interface EmployeeDetailFile {
  id: number; user_id: string; kind: DetailFileKind; file_path: string; file_name: string | null; created_at: string;
}
/** The documents of the Employee Form. required = compulsory in the paper form */
export const DETAIL_FILE_KINDS: { kind: DetailFileKind; label: string; hint: string; required: boolean }[] = [
  { kind: 'photo', label: 'Passport size photo', hint: 'Coloured, 3.5 cm x 4.5 cm', required: true },
  { kind: 'aadhar', label: 'Aadhar card', hint: 'Copy of the Aadhar card', required: true },
  { kind: 'pan', label: 'PAN card', hint: 'Copy of the PAN card', required: true },
  { kind: 'bank', label: 'Bank passbook', hint: '1st page copy', required: true },
  { kind: 'graduation', label: 'Graduation certificate', hint: 'Degree / marksheet', required: false },
  { kind: 'cv', label: 'CV / Resume', hint: 'Latest CV', required: false },
];

export const TOUR_CATEGORIES =['Travel', 'Food', 'Stay', 'Local transport', 'Fuel', 'Other'] as const;
export interface TourExpense {
  id: number; tour_id: number; expense_date: string; category: string; amount: number;
  note: string | null; receipt_path: string | null; created_at: string;
}
export interface TourTask { id: number; tour_id: number; task_date: string; task: string; remark: string | null; created_at: string }
export interface TourDocument { id: number; tour_id: number; title: string; file_path: string; created_at: string }

export interface Holiday { day: string; name: string; kind: 'General' | 'Restricted' }

export interface BoardRow {
  user_id: string; username: string; full_name: string; department: string | null; role: Role;
  site_employee: boolean;
  check_in_at: string | null; check_out_at: string | null;
  in_time: string | null; out_time: string | null;
  status: string; is_late: boolean; work_minutes: number | null;
  source: string | null; site_name: string | null; leave_type: string | null;
}

export interface AdminStats {
  date: string; total_employees: number; active_employees: number; present_today: number;
  checked_out: number; still_working: number; late_today: number; on_leave: number;
  not_checked_in: number; site_checkins: number; pending_leaves: number;
  pending_regularizations: number; is_holiday: string | null;
}

export interface MonthSummaryRow {
  user_id: string; username: string; full_name: string; department: string | null;
  present: number; absent: number; on_leave: number; late: number; holidays: number; hours: number;
  /** leaving date of an employee who has left (the name then ends with "(Resigned ...)") */
  left_on?: string | null;
}

/** "Name (Resigned 31-03-2027)" for an employee who has left; the plain name otherwise */
export const resignedName = (name: string, leftOn?: string | null) =>
  leftOn ? `${name} (Resigned ${leftOn.slice(8, 10)}-${leftOn.slice(5, 7)}-${leftOn.slice(0, 4)})` : name;

/** One line of the Salary Management table */
export interface SalaryOverviewRow {
  user_id: string; username: string; full_name: string; department: string | null; active: boolean;
  joining_date: string | null; left_on: string | null;
  basic: number | null; inc1: number | null; inc1_on: string | null; inc2: number | null; inc2_on: string | null; increments: number;
  /** null = the employee has left and the leaving month is over */
  current_salary: number | null; current_from: string | null;
}
export interface SalaryHistoryRow {
  id: number; kind: 'Basic' | 'Increment'; salary: number; increment: number; effective_date: string; note: string | null;
  created_at: string; set_by: string | null;
}
export interface PayrollMonth { year: number; month: number; status: 'Draft' | 'Ready' | 'Finalized' }
export interface MySalaryRow { kind: 'Basic' | 'Increment'; salary: number; increment: number; effective_date: string }

export interface SelfieRecord {
  id: number; user_id: string; attendance_id: number | null; captured_at: string; kind: 'IN' | 'OUT';
  site_name: string; note: string | null; lat: number | null; lng: number | null;
  /** null when the punch was made outside the site area (no selfie accepted) */
  photo_path: string | null;
  outside: boolean; distance_m: number | null;
  /** check-out from a foreign location (outside the site area, allowed for this employee) and the reason he gave */
  foreign_loc?: boolean; reason?: string | null;
  /** 'Foreign Location' = chosen in Site Selfie > Select place (foreign_location_place.sql); null = an ordinary site record */
  place_type?: 'Foreign Location' | null;
  employee?: { full_name: string; username: string; department: string | null } | null;
}

export interface TravelLeg {
  leg: number; in_at: string; out_at: string | null; site_id?: number | null; site_name?: string | null;
  in_lat: number; in_lng: number; out_lat: number | null; out_lng: number | null;
  /** km travelled from the previous stop to this one (null for stop 1); 'gps' = real route, 'straight' = straight line */
  trip_km?: number | null; trip_source?: 'gps' | 'straight' | null;
  /** metres from the site / office point at check-in and check-out; is_office = the office location (no selfie) */
  in_dist_m?: number | null; out_dist_m?: number | null; is_office?: boolean;
}
export interface TravelDay { date: string; legs: TravelLeg[]; km: number | null; open: boolean; done: boolean; max_legs: number }
export interface TravelStopRow { leg: number; site: string | null; in: string | null; out: string | null; trip_km: number | null; source: 'gps' | 'straight' | null }
export interface TravelReportRow {
  user_id: string; username: string; full_name: string; department: string | null; work_date: string;
  stops: number; trips: number; km: number; route: string | null; legs: TravelStopRow[] | null;
}

/** One pin on the live map: where an employee was at a check-in or check-out (no other time is tracked) */
export interface MapPoint {
  key: string; userId: string; name: string; username: string; department: string | null;
  kind: 'IN' | 'OUT'; at: string; lat: number; lng: number; siteName: string | null;
}

/** One person's day on the road (for the "On the move now" detail): stops, trips, km, and field visits */
export interface DayDetail {
  legs: { leg: number; site_name: string | null; in_at: string; out_at: string | null; trip_km: number | null; trip_source: 'gps' | 'straight' | null; in_dist_m?: number | null; out_dist_m?: number | null }[];
  km: number;
  done: boolean;
}

/** A line on the map (e.g. the route an employee has travelled today) */
export interface MapLine { key: string; color: string; label: string; points: [number, number][]; dashed?: boolean }

export interface LiveLocation {
  user_id: string; lat: number; lng: number; accuracy_m: number | null; kind: 'visit' | 'travel'; updated_at: string;
  employee?: { full_name: string; username: string; department: string | null } | null;
}

/** A coloured dot on the map (e.g. an employee, coloured by status) */
export interface MapDot { key: string; lat: number; lng: number; color: string; label: string; /** always show the label next to the dot */ permanent?: boolean }

export interface Site {
  id: number; name: string; lat: number; lng: number; radius_m: number; active: boolean; is_office?: boolean;
}
/** A site drawn on a map: optional colour, label and whether its range circle is drawn */
export type MapSite = Site & { color?: string; label?: string; circle?: boolean };

/** An allocated site that is inside its radius right now (from my_sites_near_me) */
export interface NearSite { site_id: number; name: string; area: string | null; distance_m: number; radius_m: number; lat: number; lng: number; is_office: boolean }
/** A place within the allowed range of the phone right now (from my_places_near_me) */
export interface NearPlace {
  site_id: number; name: string; place_kind: 'site' | 'office'; distance_m: number; radius_m: number; range_m: number;
  lat: number; lng: number; is_office: boolean;
}
export interface WorkingRule {
  kind: 'site' | 'office'; range_m: number; required_minutes: number; before_required: 'reason' | 'block';
}
export type DayHoursStatus = 'Full day' | 'Short hours' | 'Working' | 'No check-out' | 'Not checked in';
export interface WorkingHoursRow {
  user_id: string; username: string; full_name: string; place: string | null;
  check_in_at: string | null; check_out_at: string | null; worked_minutes: number | null; required_minutes: number;
  status: DayHoursStatus; short_reason: string | null; short_minutes: number | null;
}
export interface WorkingHoursKpis { total: number; checked_in: number; full_day: number; short_hours: number; no_checkout_yesterday: number }
export interface TodaySiteRow { user_id: string; site_name: string | null; check_in_at: string | null; check_out_at: string | null; check_in_dist_m: number | null; check_out_dist_m: number | null }
/** The site of today's open check-in */
export interface OpenSite { site_id: number; name: string; lat: number; lng: number; radius_m: number; is_office: boolean }

export interface AuditRow {
  id: number; action: string; detail: string | null; logged_at: string;
  actor?: { username: string; full_name: string } | null;
}

export interface PayrollRow {
  user_id: string; username: string; full_name: string; department: string | null;
  monthly_salary: number; days_in_month: number; present: number; absent: number;
  leave_days: number; paid_leave: number; unpaid_leave: number; not_joined: number; unpaid_days: number; payable_days: number;
  overtime_hours: number; overtime_pay: number; deduction: number; net_salary: number;
  /** unpaid holidays of the month (leave_rules_update.sql) */
  unpaid_holiday?: number;
  /** leaving date of an employee who has left */
  left_on?: string | null;
}

/** One day of one employee in the Working Hours and Overtime Report (minutes: after the unpaid break) */
export interface WorkHoursRow {
  user_id: string; username: string; full_name: string; department: string | null; site_name: string; work_date: string;
  check_in: string | null; check_out: string | null;
  gross_minutes: number | null; break_minutes: number | null; total_minutes: number | null; regular_minutes: number | null; overtime_minutes: number | null;
}
export interface OvertimeRow {
  user_id: string; username: string; full_name: string; department: string | null; day: string;
  in_time: string | null; out_time: string | null; work_minutes: number; shift_minutes: number; ot_minutes: number;
}
/** Field Site Journey (field_site_journeys.sql): one row per journey; names come from the report view */
export interface FieldSiteJourney {
  id: number; user_id: string; journey_date: string; seq_no: number;
  from_site_id: number; to_site_id: number;
  start_time: string; start_lat: number; start_lng: number; start_accuracy: number | null;
  reached_time: string | null; reached_lat: number | null; reached_lng: number | null; reached_accuracy: number | null;
  distance_km: number | null; duration_minutes: number | null; status: 'travelling' | 'reached' | 'cancelled';
  full_name?: string; emp_code?: string; from_site_name?: string; to_site_name?: string;
  /** field_site_foreign_place.sql: the typed name when the going / start place is a Foreign location */
  from_place_name?: string | null; to_place_name?: string | null;
  // journey_change_plan.sql: to_site_id is always the CURRENT destination
  plan_change_count?: number; original_to_site_id?: number | null;
  cancelled_time?: string | null; cancelled_lat?: number | null; cancelled_lng?: number | null; cancelled_accuracy?: number | null;
}
/** One "Change plan" of a journey (journey_plan_changes): old -> new destination, reason, change point */
export type PlanChangeType = 'back_to_start' | 'other_site' | 'cancel';
export interface JourneyPlanChange {
  id: number; journey_id: number; employee_id: string; changed_at: string;
  old_destination_site_id: number | null; new_destination_site_id: number | null; change_type: PlanChangeType;
  reason: string; remarks: string | null; lat: number | null; lng: number | null; accuracy_m: number | null;
  gps_available: boolean; distance_at_change_km: number | null; client_key?: string | null;
}
/** A plan change as the phone sends it (it can wait on the phone while there is no internet; time and GPS stay the original ones) */
export interface PlanChangeInput {
  journeyId: number; type: PlanChangeType; newSite?: number | null; reason: string; remarks?: string;
  lat?: number | null; lng?: number | null; accuracy?: number | null; changedAt: string; key: string;
}
export interface JourneyPoint { lat: number; lng: number; acc?: number | null; t: string }
export type ArrivalType = 'Verified' | 'Foreign - planned stop' | 'Foreign - mismatch';

/** One leg of v_field_visit_legs (From -> To with travel, km, arrival type and the time spent at the destination) */
export interface FieldLeg {
  id: number; user_id: string; work_date: string; full_name: string; emp_code: string; leg_no: number;
  from_site_name: string; from_foreign: boolean; to_site_name: string; to_foreign: boolean;
  start_at: string; end_at: string | null; travel_min: number | null; travel_km: number | null; travel_source: 'gps' | 'straight' | null;
  dest_dist_m: number | null; status: 'In Progress' | 'Completed'; verified: boolean | null; verify_note: string | null;
  arrival_type: ArrivalType | null; arrival_reason: string | null; arrival_photo_path: string | null;
  stay_min: number | null; stay_until: string | null;
}

/** One day of v_daily_attendance (check-in / out place, stops, legs, km, duty, late, OT and the day status) */
export interface FieldDayRow {
  id: number; user_id: string; work_date: string; full_name: string; emp_code: string;
  checkin_place: string | null; check_in_at: string | null; checkout_place: string | null; check_out_at: string | null; auto_closed: boolean;
  legs_count: number; total_km: number | null; travel_min: number | null; foreign_stops: number | null; foreign_min: number | null;
  duty_min: number | null; late_min: number | null; ot_min: number | null; day_status: string | null; sites_visited: string | null;
  check_in_lat?: number | null; check_in_lng?: number | null; check_out_lat?: number | null; check_out_lng?: number | null;
}

/** One row of v_foreign_register (a check-in / check-out / arrival from a place that is not a registered site) */
export interface ForeignEventRow {
  user_id: string; work_date: string; event_at: string; full_name: string; emp_code: string;
  [key: string]: unknown;
}

/** One row of v_field_live_today (who is on the road right now) */
export interface FieldLiveRow {
  user_id: string; full_name: string; emp_code: string;
  [key: string]: unknown;
}

/** A holiday for Site / Office employees (holiday_setup.sql): all of the category or only the selected employees; Paid or Unpaid */
export interface EmployeeHoliday {
  id: number; day: string; name: string; category: 'Site' | 'Office'; holiday_type: 'Paid' | 'Unpaid'; all_employees: boolean; user_ids: string[];
}

/** Paid leave eligibility (leave_eligibility.sql) */
export interface LeaveEligibility {
  joining_date: string | null; eligible_from: string | null; eligible: boolean; days_left: number | null;
  paid_per_month: number | null; paid_used: number | null; paid_left: number | null;
}

/** Daily Report (supabase/daily_report.sql) */
export type DailyReportStatus = 'Draft' | 'Submitted' | 'Reviewed' | 'Reopened';
export interface DailyReportSite {
  id: number; report_id: number; seq: number; site_id: number | null; site_name: string;
  sub_work: string | null; work_going_on: string | null; work_description: string | null;
  comment_1: string | null; comment_2: string | null; comment_3: string | null; remarks: string | null;
  arrived_at: string | null; departed_at: string | null;
  /** automatic English of the Marathi / Hindi text, per field (report_translation.sql) */
  translations?: Record<string, DailyTranslation> | null;
}
export interface DailyTranslation { lang: string; en: string; src: string; corrected_en?: string; corrected_by?: string; corrected_at?: string }
export interface DailyReport {
  id: number; user_id: string; report_date: string; status: DailyReportStatus; review_note: string | null;
  reviewed_by: string | null; reviewed_at: string | null; submitted_at: string | null;
  gps_km: number | null; has_gps: boolean; created_at: string; updated_at: string;
  daily_report_sites: DailyReportSite[];
  employee?: { full_name: string; username: string } | null;
}
export interface DailyVisit { site_id: number | null; site_name: string; arrived_at: string | null; departed_at: string | null }
export interface DailyReportContext { date: string; checked_in?: boolean; checked_out: boolean; visits: DailyVisit[]; gps_km: number | null; has_gps: boolean }
/** checkout_requires_daily_report.sql: is today's check-out locked until the Daily Report is submitted */
export interface CheckoutReportStatus {
  date: string; required: boolean; report_status: DailyReportStatus | null; submitted_at: string | null;
  allowed_by_admin: boolean; unlocked: boolean;
}
export interface CheckoutReportRow {
  user_id: string; full_name: string; username: string | null; site_name: string | null;
  check_in_at: string | null; check_out_at: string | null; report_status: DailyReportStatus | null; report_submitted_at: string | null;
  allowed_by_admin: boolean; override_reason: string | null; override_by: string | null; override_at: string | null;
}
export interface CheckoutRule { report_required: boolean; draft_unlocks: boolean }
/** What the employee types for one site: the server sets everything else (user, date, status, visit times) */
export interface DailySiteInput {
  site_id: number | null; site_name: string; sub_work: string; work_going_on: string; work_description: string;
  comment_1: string; comment_2: string; comment_3: string; remarks: string;
}
function unwrap<T = unknown>(res: { data: unknown; error: unknown }): T {
  if (res.error) throw res.error;
  return res.data as T;
}

// ---------------- Employee ----------------
export const api = {
  myDashboard: async () => unwrap<MyDashboard>(await supabase.rpc('my_dashboard')),

  checkIn: async (opts: { lat?: number; lng?: number; siteName?: string; siteId?: number; note?: string; photoPath?: string; reason?: string } = {}) =>
    unwrap<AttendanceRow>(await supabase.rpc('check_in', {
      p_lat: opts.lat ?? null, p_lng: opts.lng ?? null,
      p_site_name: opts.siteName ?? null, p_note: opts.note ?? null, p_photo_path: opts.photoPath ?? null,
      p_site_id: opts.siteId ?? null,
      p_reason: opts.reason ?? null,
    })),

  checkOut: async (opts: { lat?: number; lng?: number; siteName?: string; siteId?: number; note?: string; photoPath?: string; reason?: string } = {}) =>
    unwrap<AttendanceRow>(await supabase.rpc('check_out', {
      p_lat: opts.lat ?? null, p_lng: opts.lng ?? null,
      p_site_name: opts.siteName ?? null, p_note: opts.note ?? null, p_photo_path: opts.photoPath ?? null,
      p_site_id: opts.siteId ?? null, p_reason: opts.reason ?? null,
    })),

  /** Work sites (geofences). Employees only need the active ones. */
  sites: async (activeOnly = true) => {
    let q = supabase.from('sites').select('*').order('name');
    if (activeOnly) q = q.eq('active', true);
    return unwrap<Site[]>(await q);
  },

  saveSite: async (s: { id?: number; name: string; lat: number; lng: number; radius_m: number; active?: boolean; is_office?: boolean }) =>
    unwrap<Site>(await supabase.rpc('admin_save_site', {
      p_id: s.id ?? null, p_name: s.name, p_lat: s.lat, p_lng: s.lng,
      p_radius: s.radius_m, p_active: s.active ?? true,
      // sent only when set, so an older database (without section 31) still saves sites
      ...(s.is_office != null ? { p_is_office: s.is_office } : {}),
    })),

  /** HR / Admin: GPS pins captured at check-in and check-out only, for a date range */
  mapPoints: async (from: string, to: string) => {
    const rows = unwrap<any[]>(await supabase.from('attendance')
      .select('id, user_id, check_in_at, check_out_at, check_in_lat, check_in_lng, check_out_lat, check_out_lng, site_name, employee:profiles!attendance_user_id_fkey(full_name, username, department)')
      .gte('work_date', from).lte('work_date', to).order('check_in_at'));
    const pts: MapPoint[] = [];
    for (const r of rows) {
      const base = {
        userId: r.user_id, name: r.employee?.full_name ?? 'Employee', username: r.employee?.username ?? '',
        department: r.employee?.department ?? null, siteName: r.site_name as string | null,
      };
      if (r.check_in_at && r.check_in_lat != null && r.check_in_lng != null) {
        pts.push({ ...base, key: `${r.id}-in`, kind: 'IN', at: r.check_in_at, lat: r.check_in_lat, lng: r.check_in_lng });
      }
      if (r.check_out_at && r.check_out_lat != null && r.check_out_lng != null) {
        pts.push({ ...base, key: `${r.id}-out`, kind: 'OUT', at: r.check_out_at, lat: r.check_out_lat, lng: r.check_out_lng });
      }
    }
    return pts;
  },

  /** Site ids an employee is assigned to (empty = every active site is allowed) */
  employeeSites: async (userId: string) =>
    unwrap<{ site_id: number }[]>(await supabase.from('employee_sites').select('site_id').eq('user_id', userId))
      .map((r) => r.site_id),

  /** HR / Admin: every (employee, site) assignment */
  siteAccess: async () =>
    unwrap<{ user_id: string; site_id: number }[]>(await supabase.from('employee_sites').select('user_id, site_id')),

  setEmployeeSites: async (userId: string, siteIds: number[]) =>
    unwrap<number>(await supabase.rpc('admin_set_employee_sites', { p_user: userId, p_site_ids: siteIds })),

  /** Employee: ONLY the allocated sites that are inside their radius, nearest first (employee_allocated_sites.sql) */
  mySitesNearMe: async (lat: number, lng: number) =>
    unwrap<NearSite[]>(await supabase.rpc('my_sites_near_me', { p_lat: lat, p_lng: lng })),

  /** Employee: the site of today's open check-in (check-out uses the same site); null when there is none */
  myOpenCheckinSite: async () => {
    const r = unwrap<OpenSite[] | OpenSite | null>(await supabase.rpc('my_open_checkin_site'));
    return Array.isArray(r) ? (r[0] ?? null) : (r ?? null);
  },

  // ---- Check-in / check-out places and working hours (supabase/checkin_places_500m.sql) ----
  /** Places the employee may use that are within the range right now (allocated sites + office), nearest first. Nothing is selected for him. */
  placesNearMe: async (lat: number, lng: number) =>
    unwrap<NearPlace[]>(await supabase.rpc('my_places_near_me', { p_lat: lat, p_lng: lng })),
  /** "I am at this place" before a check-out (the server checks it again when the check-out is saved) */
  selectCheckoutPlace: async (siteId: number, lat: number, lng: number) =>
    unwrap<{ site_id: number; name: string; distance_m: number }>(await supabase.rpc('select_checkout_place', { p_site_id: siteId, p_lat: lat, p_lng: lng })),
  /** Reason for checking out before the required hours (saved before the check-out) */
  setShortHoursReason: async (reason: string) =>
    unwrap<null>(await supabase.rpc('set_short_hours_reason', { p_reason: reason })),
  /** Range / required hours for site and office employees (Admin changes them) */
  workingRules: async () =>
    unwrap<WorkingRule[]>(await supabase.from('working_time_rules').select('kind, range_m, required_minutes, before_required')),
  saveWorkingRules: async (r: WorkingRule) =>
    unwrap<WorkingRule>(await supabase.rpc('admin_save_working_time_rules', {
      p_kind: r.kind, p_range_m: r.range_m, p_required_minutes: r.required_minutes, p_before: r.before_required,
    })),
  workingHoursToday: async (date?: string) =>
    unwrap<WorkingHoursRow[]>(await supabase.rpc('admin_working_hours_today', { p_date: date ?? null })),
  workingHoursKpis: async (date?: string) =>
    unwrap<WorkingHoursKpis>(await supabase.rpc('admin_working_hours_kpis', { p_date: date ?? null })),

  /** Profile photos (kind 'photo' of the Employee Form): user id -> storage path. Read only. */
  profilePhotoPaths: async () => {
    const rows = unwrap<{ user_id: string; file_path: string }[]>(await supabase.from('employee_detail_files').select('user_id, file_path').eq('kind', 'photo'));
    return new Map(rows.map((r) => [r.user_id, r.file_path] as [string, string]));
  },
  /** Office Attendance: the check-in / check-out rows of a date range (read only; office check-ins have no selfie records) */
  officeAttendanceRows: async (from: string, to: string) =>
    unwrap<{ id: number; user_id: string; work_date: string; check_in_at: string | null; check_out_at: string | null; site_name: string | null; source: string | null; check_in_dist_m: number | null; check_out_dist_m: number | null; check_in_lat: number | null; check_in_lng: number | null; check_out_lat: number | null; check_out_lng: number | null; note: string | null }[]>(
      await supabase.from('attendance').select('id, user_id, work_date, check_in_at, check_out_at, site_name, source, check_in_dist_m, check_out_dist_m, check_in_lat, check_in_lng, check_out_lat, check_out_lng, note')
        .gte('work_date', from).lte('work_date', to).not('check_in_at', 'is', null).order('work_date').limit(20000)),

  /** Admin / HR: who checked in today (user ids) */
  checkedInToday: async (date: string) =>
    unwrap<TodaySiteRow[]>(await supabase.from('attendance')
      .select('user_id, site_name, check_in_at, check_out_at, check_in_dist_m, check_out_dist_m').eq('work_date', date).not('check_in_at', 'is', null)),

  /** Admin / HR: employees blocked today because no allocated site was in range */
  blockedToday: async (date: string) =>
    unwrap<{ user_id: string }[]>(await supabase.from('checkin_blocked_log').select('user_id').eq('log_date', date)),

  /** Live English preview of Marathi / Hindi report text (nothing is stored) */
  translatePreview: async (texts: Record<string, string>) => {
    const { data, error } = await supabase.functions.invoke('translate-report', { body: { mode: 'preview', texts } });
    if (error) throw error;
    return (data?.en ?? {}) as Record<string, string>;
  },
  /** Translates and stores the English of a whole report (after it is submitted; Admin / HR can also run it) */
  translateReport: async (reportId: number) => {
    const { data, error } = await supabase.functions.invoke('translate-report', { body: { mode: 'report', report_id: reportId } });
    if (error) throw error;
    return data as { ok: boolean; translated: number };
  },
  /** Admin / HR: corrected English for one field of one site entry */
  correctTranslation: async (siteRowId: number, field: string, text: string) =>
    unwrap<DailyTranslation>(await supabase.rpc('admin_correct_translation', { p_site_row: siteRowId, p_field: field, p_text: text })),

  /** Admin / HR: the admin-menu items a Project Manager may use (empty = a normal employee again) */
  setMenuAccess: async (userId: string, items: string[]) =>
    unwrap<Profile>(await supabase.rpc('admin_set_menu_access', { p_user: userId, p_items: items })),

  deleteSite: async (id: number) => unwrap<string>(await supabase.rpc('admin_delete_site', { p_id: id })),

  monthAttendance: async (year: number, month: number, userId?: string) =>
    unwrap<MonthDay[]>(await supabase.rpc('get_month_attendance', {
      p_year: year, p_month: month, p_user: userId ?? null,
    })),

  leaveBalance: async (year?: number, userId?: string) =>
    unwrap<LeaveBalance[]>(await supabase.rpc('get_leave_balance', { p_year: year ?? null, p_user: userId ?? null })),

  // ---- Daily Report photo (optional; daily_report_photo.sql) ----
  dailyReportPhotos: async (reportId: number) =>
    unwrap<{ id: number; file_path: string; file_name: string | null }[]>(
      await supabase.from('daily_report_photos').select('id, file_path, file_name').eq('report_id', reportId).order('id')),
  /** photos of many reports at once (the site-wise monthly PDF); Admin / HR can read all of them */
  dailyReportPhotosFor: async (reportIds: number[]) =>
    unwrap<{ id: number; report_id: number; file_path: string; file_name: string | null }[]>(
      await supabase.from('daily_report_photos').select('id, report_id, file_path, file_name').in('report_id', reportIds).order('id')),
  uploadDailyReportPhoto: async (userId: string, bytes: ArrayBuffer, name: string, contentType: string) => {
    const safe = name.replace(/[^A-Za-z0-9._-]+/g, '_').slice(-60) || 'photo';
    const path = `${userId}/${Date.now()}-${safe}`;
    const { error } = await supabase.storage.from('daily_report_photos').upload(path, bytes, { contentType, upsert: false });
    if (error) throw error;
    return path;
  },
  addDailyReportPhoto: async (reportId: number, path: string, name?: string) =>
    unwrap<{ id: number; file_path: string }>(await supabase.rpc('add_daily_report_photo', { p_report_id: reportId, p_path: path, p_name: name ?? null })),
  removeDailyReportPhoto: async (id: number) => {
    const path = unwrap<string | null>(await supabase.rpc('remove_daily_report_photo', { p_id: id }));
    if (path) await supabase.storage.from('daily_report_photos').remove([path]);
  },
  removeDailyReportFile: async (path: string) => { await supabase.storage.from('daily_report_photos').remove([path]); },
  dailyReportPhotoUrl: async (path: string) => {
    const { data, error } = await supabase.storage.from('daily_report_photos').createSignedUrl(path, 600);
    if (error) throw error;
    return data.signedUrl;
  },
  leaveTypes: async () =>
    unwrap<{ name: string; annual_quota: number }[]>(
      await supabase.from('leave_types').select('name, annual_quota').eq('active', true).order('sort_order')),

  applyLeave: async (type: string, from: string, to: string, reason: string) =>
    unwrap<LeaveRequest>(await supabase.rpc('apply_leave', { p_leave_type: type, p_from: from, p_to: to, p_reason: reason })),

  leavePolicy: async () => unwrap<LeavePolicy>(await supabase.rpc('get_leave_policy')),
  setLeavePolicy: async (p: { paid: number; months: number; notice: number; weeklyOff: boolean; quotas: Record<string, number> }) =>
    unwrap<LeavePolicy>(await supabase.rpc('admin_set_leave_policy', {
      p_paid_per_month: p.paid, p_eligibility_months: p.months, p_notice_days: p.notice, p_count_weekly_off: p.weeklyOff, p_quotas: p.quotas,
    })),
  /** Day-by-day Paid / Unpaid / Weekly off / Holiday for a leave request (userId: HR / Admin previewing somebody else's request) */
  leavePreview: async (type: string, from: string, to: string, userId?: string) =>
    unwrap<LeavePreviewDay[]>(await supabase.rpc('leave_preview', { p_type: type, p_from: from, p_to: to, p_user: userId ?? null })),
  // ---- 24-day leave policy (leave_policy_24.sql) ----
  leaveSummary: async (userId?: string) => unwrap<LeaveSummary>(await supabase.rpc('leave_summary', { p_user: userId ?? null })),
  leaveLedger: async (userId?: string, year?: number) =>
    unwrap<LeaveLedgerRow[]>(await supabase.rpc('leave_ledger_rows', { p_user: userId ?? null, p_year: year ?? null })),
  leavePreviewV2: async (type: string, from: string, to: string, half?: 'first' | 'second' | null, userId?: string) =>
    unwrap<LeavePreviewV2Day[]>(await supabase.rpc('leave_preview_v2', { p_type: type, p_from: from, p_to: to, p_half: half ?? null, p_user: userId ?? null })),
  applyLeaveV2: async (o: { type: string; from: string; to: string; reason: string; half?: 'first' | 'second' | null; personal?: string | null; certificate?: string | null }) =>
    unwrap<LeaveRequest>(await supabase.rpc('apply_leave', {
      p_leave_type: o.type, p_from: o.from, p_to: o.to, p_reason: o.reason,
      p_half: o.half ?? null, p_personal: o.personal ?? null, p_certificate: o.certificate ?? null,
    })),
  /** day chips (EL / CL / SL / LOP, this month / saved); falls back to the old preview until leave_rules_v3.sql is run */
  leaveDayChips: async (type: string, from: string, to: string, userId?: string) => {
    const r = await supabase.rpc('leave_preview_v3', { p_type: type, p_from: from, p_to: to, p_user: userId ?? null });
    if (!r.error) return r.data as LeavePreviewV2Day[];
    return unwrap<LeavePreviewV2Day[]>(await supabase.rpc('leave_preview_v2', { p_type: type, p_from: from, p_to: to, p_half: null, p_user: userId ?? null }));
  },
  /** the server's apply rules as one message (null = leave_rules_v3.sql not run yet) */
  leaveCheck: async (type: string, from: string, to: string, certificate?: string | null) => {
    const r = await supabase.rpc('leave_check', { p_type: type, p_from: from, p_to: to, p_certificate: certificate ?? null });
    if (r.error) return null;
    return { error: ((r.data as { error: string | null } | null)?.error ?? null) };
  },
  leavePolicy2: async () => unwrap<LeavePolicy2>(await supabase.rpc('get_leave_policy2')),
  setLeavePolicy2: async (p: Partial<Record<string, number | string | null>>) => unwrap<LeavePolicy2>(await supabase.rpc('admin_set_leave_policy2', { p })),
  leaveReviewInfo: async (leaveId: number) => unwrap<LeaveReviewInfo>(await supabase.rpc('leave_review_info', { p_leave: leaveId })),
  adjustLeaveBalance: async (userId: string, type: string, days: number, reason: string) =>
    unwrap<LeaveSummary>(await supabase.rpc('admin_adjust_leave_balance', { p_user: userId, p_type: type, p_days: days, p_reason: reason })),
  encashLeave: async (userId: string, days: number, reason?: string) =>
    unwrap<LeaveSummary>(await supabase.rpc('admin_encash_leave', { p_user: userId, p_days: days, p_reason: reason ?? null })),
  setPaidLeaveEarlyStart: async (userId: string, on: boolean, reason?: string) =>
    unwrap<LeaveSummary>(await supabase.rpc('admin_set_paid_leave_early_start', { p_user: userId, p_on: on, p_reason: reason ?? null })),
  runLeaveJobs: async () => unwrap<{ credited_rows_this_month: number; lapsed_now: number; as_of: string }>(await supabase.rpc('run_leave_jobs', { p_asof: null })),
  /** Hours required today (half of the usual on an approved half-day leave) */
  myRequiredToday: async () =>
    unwrap<{ required_minutes: number; half_part: 'first' | 'second' | null; leave_type: string | null }>(await supabase.rpc('my_required_today')),
  /** Medical certificate: private bucket "leave_certs", the employee's own folder */
  uploadLeaveCert: async (userId: string, bytes: ArrayBuffer, name: string, contentType: string) => {
    const safe = name.replace(/[^A-Za-z0-9._-]+/g, '_').slice(-60) || 'certificate';
    const path = `${userId}/${Date.now()}-${safe}`;
    const { error } = await supabase.storage.from('leave_certs').upload(path, bytes, { contentType, upsert: false });
    if (error) throw error;
    return path;
  },
  leaveCertUrl: async (path: string) => {
    const { data, error } = await supabase.storage.from('leave_certs').createSignedUrl(path, 600);
    if (error) throw error;
    return data.signedUrl;
  },
  grantCompOff: async (userId: string, days: number, reason: string) =>
    unwrap<unknown>(await supabase.rpc('admin_grant_comp_off', { p_user: userId, p_days: days, p_reason: reason })),
  /** a PENDING request: cancelled at once, no reason needed */
  cancelLeave: async (id: number) => unwrap(await supabase.rpc('cancel_leave', { p_id: id })),
  /** an APPROVED leave: the employee asks (reason required); the leave stays Approved until Admin / HR decide */
  requestLeaveCancel: async (id: number, reason: string) => unwrap<LeaveRequest>(await supabase.rpc('request_leave_cancel', { p_id: id, p_reason: reason })),
  /** one call for all my leaves: which cancel button each gets (empty until leave_cancel_approved.sql is run) */
  leaveCancelOptions: async () => unwrap<LeaveCancelOption[]>(await supabase.rpc('leave_cancel_options')),
  /** Admin / HR: ONE approval of a cancellation: approve = Cancelled + days returned, false = "Keep leave" */
  reviewLeaveCancel: async (id: number, approve: boolean, note?: string) =>
    unwrap<LeaveRequest>(await supabase.rpc('review_leave_cancel', { p_id: id, p_approve: approve, p_note: note ?? null })),
  /** Admin / HR: cancellation requests waiting for a decision (with who approved the leave earlier) */
  pendingLeaveCancels: async () =>
    unwrap<LeaveRequest[]>(await supabase.from('leaves')
      .select('*, employee:profiles!leaves_user_id_fkey(full_name, username, department), reviewer:profiles!leaves_reviewed_by_fkey(full_name, role)')
      .eq('status', 'Approved').eq('cancel_status', 'requested').order('cancel_requested_at', { ascending: false })),

  myLeaves: async (userId: string) =>
    (async () => {
      // with the name / role of the HR or Admin who decided; plain rows if the profiles cannot be joined
      const c = await supabase.from('leaves').select('*, reviewer:profiles!leaves_reviewed_by_fkey(full_name, role), canceller:profiles!leaves_cancel_reviewed_by_fkey(full_name, role)').eq('user_id', userId).order('id', { ascending: false });
      if (!c.error) return c.data as unknown as LeaveRequest[];   // the cancel columns exist (leave_cancel_approved.sql is run)
      const r = await supabase.from('leaves').select('*, reviewer:profiles!leaves_reviewed_by_fkey(full_name, role)').eq('user_id', userId).order('id', { ascending: false });
      if (!r.error) return r.data as unknown as LeaveRequest[];
      return unwrap<LeaveRequest[]>(await supabase.from('leaves').select('*').eq('user_id', userId).order('id', { ascending: false }));
    })(),

  requestRegularization: async (day: string, inTime: string, outTime: string, reason: string) =>
    unwrap<Regularization>(await supabase.rpc('request_regularization', {
      p_day: day, p_in: inTime, p_out: outTime, p_reason: reason,
    })),

  cancelRegularization: async (id: number) => unwrap(await supabase.rpc('cancel_regularization', { p_id: id })),

  myRegularizations: async (userId: string) =>
    unwrap<Regularization[]>(await supabase.from('regularizations').select('*').eq('user_id', userId).order('id', { ascending: false })),

  // ---------------- Tour (working outside the city) ----------------
  applyTour: async (city: string, from: string, to: string, reason: string) =>
    unwrap<Tour>(await supabase.rpc('apply_tour', { p_city: city, p_from: from, p_to: to, p_reason: reason })),

  cancelTour: async (id: number) => unwrap(await supabase.rpc('cancel_tour', { p_id: id })),

  myTours: async (userId: string) =>
    unwrap<Tour[]>(await supabase.from('tours').select('*').eq('user_id', userId).order('id', { ascending: false })),

  pendingTours: async () =>
    unwrap<Tour[]>(await supabase.from('tours')
      .select('*, employee:profiles!tours_user_id_fkey(full_name, username, department)')
      .eq('status', 'Pending').order('id')),

  reviewTour: async (id: number, approve: boolean, note?: string) =>
    unwrap(await supabase.rpc('review_tour', { p_id: id, p_approve: approve, p_note: note ?? null })),

  // ---- Documents: employee uploads (with a remark) and documents Admin / HR upload for an employee ----
  employeeDocuments: async (userId: string) =>
    unwrap<EmployeeDocument[]>(await supabase.from('employee_documents').select('*').eq('user_id', userId).order('id', { ascending: false })),
  /** userId = null: your own upload. userId = an employee: Admin / HR upload for that employee */
  addEmployeeDocument: async (userId: string | null, title: string, remark: string | undefined, path: string, fileName?: string, category?: string) => {
    const base = { p_user: userId, p_title: title, p_remark: remark ?? null, p_path: path, p_file_name: fileName ?? null };
    const res = await supabase.rpc('add_employee_document', { ...base, p_category: category ?? null });
    // a database that has not got document_review.sql yet: upload as before (without the type) so nothing stops working
    if (res.error && /could not find the function/i.test(res.error.message)) return unwrap<EmployeeDocument>(await supabase.rpc('add_employee_document', base));
    return unwrap<EmployeeDocument>(res);
  },
  /** Admin / HR: set a submitted document to Under Review / Approved / Rejected with a note */
  reviewEmployeeDocument: async (id: number, status: 'Under Review' | 'Approved' | 'Rejected', note?: string) =>
    unwrap<EmployeeDocument>(await supabase.rpc('review_employee_document', { p_id: id, p_status: status, p_note: note ?? null })),
  deleteEmployeeDocument: async (id: number) => {
    const path = unwrap<string | null>(await supabase.rpc('delete_employee_document', { p_id: id }));
    if (path) await supabase.storage.from('employee_docs').remove([path]);
  },
  /** Uploads a file to the private "employee_docs" bucket under the employee's folder and returns its path */
  uploadEmployeeFile: async (forUserId: string, bytes: ArrayBuffer, name: string, contentType: string) => {
    const safe = name.replace(/[^A-Za-z0-9._-]+/g, '_').slice(-60) || 'file';
    const path = `${forUserId}/${Date.now()}-${safe}`;
    const { error } = await supabase.storage.from('employee_docs').upload(path, bytes, { contentType, upsert: false });
    if (error) throw error;
    return path;
  },
  removeEmployeeFile: async (path: string) => { await supabase.storage.from('employee_docs').remove([path]); },

  // ---- Documents "From C V Patil" (document_sharing.sql) ----
  documentTypes: async (direction: 'from_cvp' | 'to_cvp') =>
    unwrap<DocumentType[]>(await supabase.from('document_types').select('*').eq('direction', direction).eq('active', true).order('name')),
  /** Uploads a file to the private "shared_docs" bucket (Admin / HR); the name is random, never the original file name */
  uploadSharedFile: async (bytes: ArrayBuffer, name: string, contentType: string) => {
    const ext = (name.split('.').pop() ?? 'bin').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5) || 'bin';
    const id = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}${Math.random().toString(36).slice(2, 10)}`;
    const path = `from/${new Date().getFullYear()}/${id}.${ext}`;
    const { error } = await supabase.storage.from('shared_docs').upload(path, bytes, { contentType, upsert: false });
    if (error) throw error;
    return path;
  },
  removeSharedFile: async (path: string) => { await supabase.storage.from('shared_docs').remove([path]); },
  previewAudience: async (audience: DocAudience) => unwrap<number>(await supabase.rpc('preview_document_audience', { p_audience: audience })),
  shareDocument: async (o: { typeId: number; title: string; description?: string; path: string; fileName: string; audience: DocAudience; allowDownload: boolean; visibleUntil?: string | null }) =>
    unwrap<{ id: number; visible_to: number }>(await supabase.rpc('share_document', {
      p_type: o.typeId, p_title: o.title, p_description: o.description ?? null, p_path: o.path, p_file_name: o.fileName,
      p_audience: o.audience, p_allow_download: o.allowDownload, p_visible_until: o.visibleUntil ?? null,
    })),
  /** The documents I may see (the database filters them: all / my project / my department / me; Admin and HR see everything) */
  sharedDocuments: async (myId: string) =>
    unwrap<SharedDocument[]>(await supabase.from('shared_documents')
      .select('*, type:document_types(name), uploader:profiles!shared_documents_uploaded_by_fkey(full_name), views:shared_document_views(user_id, viewed_at, downloaded)')
      .order('id', { ascending: false })).map((d) => ({ ...d, views: (d.views ?? []).filter((v) => v.user_id === myId) })),
  /** Checks access, writes the view, then returns a link that works for 2 minutes */
  openSharedDocument: async (id: number, download = false) => {
    const r = unwrap<{ file_path: string; file_name: string | null }>(await supabase.rpc('open_shared_document', { p_id: id, p_download: download }));
    const { data, error } = await supabase.storage.from('shared_docs').createSignedUrl(r.file_path, 120, download ? { download: r.file_name ?? true } : undefined);
    if (error) throw error;
    return data.signedUrl;
  },
  sharedDocumentStats: async (id: number) => unwrap<{ audience: number; viewed: number; not_viewed: string[] }>(await supabase.rpc('shared_document_stats', { p_id: id })),
  deleteSharedDocument: async (id: number) => {
    const path = unwrap<string | null>(await supabase.rpc('delete_shared_document', { p_id: id }));
    if (path) await supabase.storage.from('shared_docs').remove([path]);
  },
  sharedAudienceOf: async (id: number) =>
    unwrap<{ audience_type: string; audience_value: string }[]>(await supabase.from('shared_document_audience').select('audience_type, audience_value').eq('document_id', id)),
  /** Documents report: all documents in a date range (RLS: Admin / HR see everyone, an employee his own) */
  documentsReport: async (from: string, to: string, userId?: string) => {
    let q = supabase.from('employee_documents')
      .select('*, employee:profiles!employee_documents_user_id_fkey(full_name, username), sender:profiles!employee_documents_uploaded_by_fkey(full_name)')
      .gte('created_at', `${from}T00:00:00+05:30`).lte('created_at', `${to}T23:59:59+05:30`)
      .order('id', { ascending: false });
    if (userId) q = q.eq('user_id', userId);
    return unwrap<DocumentReportRow[]>(await q);
  },
  // ---- Employee Form: personal details and KYC documents (userId null = your own) ----
  employeeDetails: async (userId: string) => {
    const { data, error } = await supabase.from('employee_details').select('*').eq('user_id', userId).maybeSingle();
    if (error) throw error;
    return data as EmployeeDetails | null;
  },
  saveEmployeeDetails: async (userId: string | null, data: object) =>
    unwrap<EmployeeDetails>(await supabase.rpc('save_employee_details', { p_user: userId, p_data: data })),
  /** Admin / HR: who has filled the form, and how many documents each person has uploaded */
  detailsOverview: async () => {
    const [forms, files] = await Promise.all([
      supabase.from('employee_details').select('user_id, declared, updated_at'),
      supabase.from('employee_detail_files').select('user_id, kind, file_path, file_name'),
    ]);
    if (forms.error) throw forms.error;
    if (files.error) throw files.error;
    const filled = new Map<string, { declared: boolean; updated_at: string }>();
    for (const r of forms.data ?? []) filled.set(r.user_id, { declared: r.declared, updated_at: r.updated_at });
    const docs = new Map<string, Map<DetailFileKind, { path: string; name: string | null }>>();
    for (const r of files.data ?? []) {
      const m = docs.get(r.user_id) ?? new Map<DetailFileKind, { path: string; name: string | null }>();
      m.set(r.kind as DetailFileKind, { path: r.file_path, name: r.file_name });
      docs.set(r.user_id, m);
    }
    return { filled, docs };
  },
  /** Admin / HR: bank, UAN and gender of everyone (for the salary and bank reports) */
  /** ESIC IP numbers by user (employee_details.esic_no, esic_ip_no.sql). Empty when the column does not exist yet. */
  esicNumbers: async (): Promise<Map<string, string>> => {
    try {
      const { data, error } = await supabase.from('employee_details').select('user_id, esic_no');
      if (error) throw error;
      return new Map((data ?? []).filter((d: any) => d.esic_no).map((d: any) => [d.user_id as string, String(d.esic_no)]));
    } catch { return new Map(); }
  },
  detailsForReports: async () =>
    unwrap<Pick<EmployeeDetails, 'user_id' | 'gender' | 'uan_no' | 'resign_date' | 'pan_no' | 'bank_name' | 'bank_address' | 'bank_branch' | 'bank_account_no' | 'ifsc_code' | 'cell_no'>[]>(
      await supabase.from('employee_details').select('user_id, gender, resign_date, uan_no, pan_no, bank_name, bank_address, bank_branch, bank_account_no, ifsc_code, cell_no')),
  employeeDetailFiles: async (userId: string) =>
    unwrap<EmployeeDetailFile[]>(await supabase.from('employee_detail_files').select('*').eq('user_id', userId)),
  /** Uploads the file, attaches it as `kind` (replacing the old one) and deletes the old file from storage */
  uploadDetailFile: async (forUserId: string, asAdmin: boolean, kind: DetailFileKind, bytes: ArrayBuffer, name: string, contentType: string) => {
    const safe = name.replace(/[^A-Za-z0-9._-]+/g, '_').slice(-60) || 'file';
    const path = `${forUserId}/${kind}-${Date.now()}-${safe}`;
    const up = await supabase.storage.from('employee_detail_docs').upload(path, bytes, { contentType, upsert: false });
    if (up.error) throw up.error;
    try {
      const old = unwrap<string | null>(await supabase.rpc('set_employee_detail_file', {
        p_user: asAdmin ? forUserId : null, p_kind: kind, p_path: path, p_file_name: name,
      }));
      if (old) await supabase.storage.from('employee_detail_docs').remove([old]);
    } catch (e) {
      await supabase.storage.from('employee_detail_docs').remove([path]);
      throw e;
    }
  },
  deleteDetailFile: async (forUserId: string, asAdmin: boolean, kind: DetailFileKind) => {
    const path = unwrap<string | null>(await supabase.rpc('delete_employee_detail_file', { p_user: asAdmin ? forUserId : null, p_kind: kind }));
    if (path) await supabase.storage.from('employee_detail_docs').remove([path]);
  },
  detailFileUrl: async (path: string, downloadName?: string) => {
    const { data, error } = await supabase.storage.from('employee_detail_docs').createSignedUrl(path, 3600, downloadName ? { download: downloadName } : undefined);
    if (error) throw error;
    return data.signedUrl;
  },
  /** downloadName: the browser / phone saves the file under this name instead of just opening it */
  employeeFileUrl: async (path: string, downloadName?: string) => {
    const { data, error } = await supabase.storage.from('employee_docs').createSignedUrl(path, 3600, downloadName ? { download: downloadName } : undefined);
    if (error) throw error;
    return data.signedUrl;
  },
  /** Admin / HR: switch Tour or Documents on / off for an employee */
  setFeatureAccess: async (userId: string, feature: 'tour' | 'documents' | 'wide_site', enabled: boolean) =>
    unwrap<Profile>(await supabase.rpc('admin_set_feature_access', { p_user: userId, p_feature: feature, p_enabled: enabled })),

  // ---- Tour report: expenses, documents and tasks completed ----
  tourExpenses: async (tourId: number) =>
    unwrap<TourExpense[]>(await supabase.from('tour_expenses').select('*').eq('tour_id', tourId)
      .order('expense_date').order('id')),
  tourTasks: async (tourId: number) =>
    unwrap<TourTask[]>(await supabase.from('tour_tasks').select('*').eq('tour_id', tourId)
      .order('task_date').order('id')),
  tourDocuments: async (tourId: number) =>
    unwrap<TourDocument[]>(await supabase.from('tour_documents').select('*').eq('tour_id', tourId).order('id')),

  addTourExpense: async (tourId: number, date: string, category: string, amount: number, note?: string, receipt?: string) =>
    unwrap<TourExpense>(await supabase.rpc('add_tour_expense', {
      p_tour: tourId, p_date: date, p_category: category, p_amount: amount, p_note: note ?? null, p_receipt: receipt ?? null,
    })),
  addTourTask: async (tourId: number, date: string, task: string, remark?: string) =>
    unwrap<TourTask>(await supabase.rpc('add_tour_task', { p_tour: tourId, p_date: date, p_task: task, p_remark: remark ?? null })),
  addTourDocument: async (tourId: number, title: string, path: string) =>
    unwrap<TourDocument>(await supabase.rpc('add_tour_document', { p_tour: tourId, p_title: title, p_path: path })),
  /** Deletes one of your entries and its file */
  deleteTourItem: async (kind: 'expense' | 'task' | 'document', id: number) => {
    const path = unwrap<string | null>(await supabase.rpc('delete_tour_item', { p_kind: kind, p_id: id }));
    if (path) await supabase.storage.from('tour_files').remove([path]);
  },
  /** Uploads a JPEG (base64) to the private "tour_files" bucket and returns its path */
  uploadTourFile: async (userId: string, tourId: number, base64: string) => {
    const path = `${userId}/${tourId}/${Date.now()}.jpg`;
    const { error } = await supabase.storage.from('tour_files').upload(path, decode(base64), { contentType: 'image/jpeg', upsert: false });
    if (error) throw error;
    return path;
  },
  removeTourFile: async (path: string) => { await supabase.storage.from('tour_files').remove([path]); },
  tourFileUrl: async (path: string) => {
    const { data, error } = await supabase.storage.from('tour_files').createSignedUrl(path, 3600);
    if (error) throw error;
    return data.signedUrl;
  },
  /** Admin / HR: approved tours that overlap a date range, with the employee */
  approvedTours: async (from: string, to: string, userId?: string) => {
    let q = supabase.from('tours')
      .select('*, employee:profiles!tours_user_id_fkey(full_name, username, department)')
      .eq('status', 'Approved').lte('from_day', to).gte('to_day', from).order('from_day', { ascending: false }).limit(300);
    if (userId) q = q.eq('user_id', userId);
    return unwrap<Tour[]>(await q);
  },
  /** Admin / HR: total expense per tour id */
  tourExpenseTotals: async (tourIds: number[]) => {
    const out: Record<number, number> = {};
    if (tourIds.length === 0) return out;
    const rows = unwrap<{ tour_id: number; amount: number }[]>(await supabase.from('tour_expenses').select('tour_id, amount').in('tour_id', tourIds));
    for (const r of rows) out[r.tour_id] = (out[r.tour_id] ?? 0) + Number(r.amount);
    return out;
  },

  holidays: async (year: number) =>
    unwrap<Holiday[]>(await supabase.from('holidays').select('day, name, kind')
      .gte('day', `${year}-01-01`).lte('day', `${year}-12-31`).order('day')),

  team: async () =>
    unwrap<Profile[]>(await supabase.from('profiles').select('*').eq('active', true).order('full_name')),

  myActivity: async (userId: string) =>
    unwrap<AuditRow[]>(await supabase.from('audit_log').select('id, action, detail, logged_at')
      .eq('actor_id', userId).order('id', { ascending: false }).limit(6)),

  mySelfies: async (userId: string) =>
    unwrap<SelfieRecord[]>(await supabase.from('selfie_records').select('*')
      .eq('user_id', userId).order('captured_at', { ascending: false }).limit(8)),

  /** Uploads a JPEG (base64) to the private "selfies" bucket and returns its path */
  uploadSelfie: async (userId: string, base64: string, kind: 'IN' | 'OUT', dateISO: string) => {
    const path = `${userId}/${dateISO}_${kind}_${Date.now()}.jpg`;
    const { error } = await supabase.storage.from('selfies').upload(path, decode(base64), {
      contentType: 'image/jpeg', upsert: false,
    });
    if (error) throw error;
    return path;
  },
  removeSelfie: async (path: string) => { await supabase.storage.from('selfies').remove([path]); },
  selfieUrl: async (path: string) => {
    const { data, error } = await supabase.storage.from('selfies').createSignedUrl(path, 3600);
    if (error) throw error;
    return data.signedUrl;
  },

  logPasswordChange: async () => { await supabase.rpc('log_password_change'); },

  // ---------------- HR / Admin ----------------
  board: async (date?: string) =>
    unwrap<BoardRow[]>(await supabase.rpc('admin_today_board', { p_date: date ?? null })),

  stats: async (date?: string) =>
    unwrap<AdminStats>(await supabase.rpc('admin_dashboard_stats', { p_date: date ?? null })),

  monthSummary: async (year: number, month: number) =>
    unwrap<MonthSummaryRow[]>(await supabase.rpc('admin_month_summary', { p_year: year, p_month: month }))
      .map((r) => ({ ...r, full_name: resignedName(r.full_name, r.left_on) })),

  pendingLeaves: async () =>
    unwrap<LeaveRequest[]>(await supabase.from('leaves')
      .select('*, employee:profiles!leaves_user_id_fkey(full_name, username, department)')
      .eq('status', 'Pending').order('id')),

  /** Admin / HR: leave requests already approved or rejected, newest first (Approvals -> Approved / Rejected tabs) */
  reviewedLeaves: async (status: 'Approved' | 'Rejected') =>
    unwrap<LeaveRequest[]>(await supabase.from('leaves')
      .select('*, employee:profiles!leaves_user_id_fkey(full_name, username, department), reviewer:profiles!leaves_reviewed_by_fkey(full_name)')
      .eq('status', status).order('reviewed_at', { ascending: false }).limit(100)),

  pendingRegularizations: async () =>
    unwrap<Regularization[]>(await supabase.from('regularizations')
      .select('*, employee:profiles!regularizations_user_id_fkey(full_name, username, department)')
      .eq('status', 'Pending').order('id')),

  /** Leave Register: every leave request (any status) overlapping a date range, with who approved / rejected it. Read only. */
  leavesForRegister: async (from: string, to: string) =>
    unwrap<LeaveRequest[]>(await supabase.from('leaves')
      .select('*, employee:profiles!leaves_user_id_fkey(full_name, username, department), reviewer:profiles!leaves_reviewed_by_fkey(full_name)')
      .lte('from_day', to).gte('to_day', from).order('from_day').limit(3000)),

  /** Admin / HR: leave requests (any status) that overlap a date range */
  leavesBetween: async (from: string, to: string) =>
    unwrap<LeaveRequest[]>(await supabase.from('leaves')
      .select('*, employee:profiles!leaves_user_id_fkey(full_name, username, department)')
      .lte('from_day', to).gte('to_day', from).order('from_day').limit(2000)),

  /** Admin / HR: correction requests (any status) for a date range */
  regularizationsBetween: async (from: string, to: string) =>
    unwrap<Regularization[]>(await supabase.from('regularizations')
      .select('*, employee:profiles!regularizations_user_id_fkey(full_name, username, department)')
      .gte('day', from).lte('day', to).order('day').limit(2000)),
  /** Pending Login Approvals (employee registration requests) */
  pendingRegistrations: async () =>
    unwrap<RegistrationRequest[]>(await supabase.from('employee_registrations').select('*')
      .eq('status', 'Pending Approval').order('id')),
  reviewRegistration: async (id: number, approve: boolean, note?: string) =>
    unwrap<string>(await supabase.rpc('review_registration_request', { p_id: id, p_approve: approve, p_note: note ?? null })),
  /** Registration / login status of every employee (never the password) */
  loginOverview: async () => unwrap<LoginOverviewRow[]>(await supabase.rpc('admin_login_overview')),

  reviewLeave: async (id: number, approve: boolean, note?: string) =>
    unwrap(await supabase.rpc('review_leave', { p_id: id, p_approve: approve, p_note: note ?? null })),

  reviewRegularization: async (id: number, approve: boolean, note?: string) =>
    unwrap(await supabase.rpc('review_regularization', { p_id: id, p_approve: approve, p_note: note ?? null })),

  allProfiles: async () =>
    unwrap<Profile[]>(await supabase.from('profiles').select('*').eq('approval_status', 'Approved').order('full_name')),

  profile: async (id: string) =>
    unwrap<Profile>(await supabase.from('profiles').select('*').eq('id', id).single()),

  /** Admin: any account. HR: employees and their own account. */
  changeUsername: async (id: string, username: string) =>
    unwrap<Profile>(await supabase.rpc('admin_change_username', { p_user: id, p_username: username })),

  updateProfile: async (id: string, p: {
    full_name?: string; role?: Role; department?: string; designation?: string; site_employee?: boolean;
    shift_start?: string; shift_end?: string; phone?: string;
  }) =>
    unwrap<Profile>(await supabase.rpc('admin_update_profile', {
      p_user: id,
      p_full_name: p.full_name ?? null,
      p_role: p.role ?? null,
      p_department: p.department ?? null,
      p_designation: p.designation ?? null,
      p_site_employee: p.site_employee ?? null,
      p_shift_start: p.shift_start ?? null,
      p_shift_end: p.shift_end ?? null,
      p_phone: p.phone ?? null,
    })),

  /** Calls the "admin-users" Edge Function (create login, reset password, activate/deactivate) */
  adminUsers: async (body: Record<string, unknown>) => {
    const { data, error } = await supabase.functions.invoke('admin-users', { body });
    if (error) {
      // surface the function's own error message when available
      const ctx = (error as { context?: Response }).context;
      if (ctx && typeof ctx.json === 'function') {
        try {
          const j = await ctx.json();
          if (j?.error) throw new Error(j.error);
        } catch (inner) {
          if (inner instanceof Error && inner.message) throw inner;
        }
      }
      throw error;
    }
    if (data?.error) throw new Error(data.error);
    return data;
  },

  selfieRecords: async (opts: { from: string; to: string; userId?: string; kind?: 'IN' | 'OUT'; outside?: boolean; page?: number }) => {
    let q = supabase.from('selfie_records')
      .select('*, employee:profiles(full_name, username, department)', { count: 'exact' })
      .gte('captured_at', `${opts.from}T00:00:00+05:30`)
      .lte('captured_at', `${opts.to}T23:59:59+05:30`)
      .order('captured_at', { ascending: false })
      .range((opts.page ?? 0) * 50, (opts.page ?? 0) * 50 + 49);
    if (opts.userId) q = q.eq('user_id', opts.userId);
    if (opts.kind) q = q.eq('kind', opts.kind);
    if (opts.outside) q = q.eq('outside', true);
    const { data, error, count } = await q;
    if (error) throw error;
    return { rows: (data ?? []) as SelfieRecord[], count: count ?? 0 };
  },

  /** Every selfie record in the range (all pages) for the site-visit CSV export */
  allSelfieRecords: async (opts: { from: string; to: string; userId?: string }) => {
    const out: SelfieRecord[] = [];
    for (let from = 0; ; from += 1000) {
      let q = supabase.from('selfie_records')
        .select('*, employee:profiles(full_name, username, department)')
        .gte('captured_at', `${opts.from}T00:00:00+05:30`)
        .lte('captured_at', `${opts.to}T23:59:59+05:30`)
        .order('captured_at', { ascending: true })
        .range(from, from + 999);
      if (opts.userId) q = q.eq('user_id', opts.userId);
      const { data, error } = await q;
      if (error) throw error;
      out.push(...((data ?? []) as SelfieRecord[]));
      if (!data || data.length < 1000) break;
    }
    return out;
  },

  // ---------------- Foreign Location (place type of Site Selfie) ----------------
  foreignPlaceCheckIn: async (o: { lat: number; lng: number; siteId: number; note?: string; photoPath?: string; reason: string }) =>
    unwrap<AttendanceRow>(await supabase.rpc('foreign_place_check_in', {
      p_lat: o.lat, p_lng: o.lng, p_site_id: o.siteId, p_note: o.note ?? null, p_photo_path: o.photoPath ?? null, p_reason: o.reason,
    })),
  foreignPlaceCheckOut: async (o: { lat: number; lng: number; note?: string; photoPath?: string; reason: string }) =>
    unwrap<AttendanceRow>(await supabase.rpc('foreign_place_check_out', {
      p_lat: o.lat, p_lng: o.lng, p_note: o.note ?? null, p_photo_path: o.photoPath ?? null, p_reason: o.reason,
    })),

  foreignPlaceTravelCheckIn: async (o: { lat: number; lng: number; siteId: number; note?: string; photoPath?: string; reason: string }) =>
    unwrap<TravelDay>(await supabase.rpc('foreign_place_travel_check_in', {
      p_lat: o.lat, p_lng: o.lng, p_site_id: o.siteId, p_note: o.note ?? null, p_photo_path: o.photoPath ?? null, p_reason: o.reason,
    })),
  foreignPlaceTravelCheckOut: async (o: { lat: number; lng: number; note?: string; photoPath?: string; reason: string }) =>
    unwrap<TravelDay>(await supabase.rpc('foreign_place_travel_check_out', {
      p_lat: o.lat, p_lng: o.lng, p_note: o.note ?? null, p_photo_path: o.photoPath ?? null, p_reason: o.reason,
    })),
  // ---------------- Field Site Journey ----------------
  startFieldJourney: async (o: { fromSite: number | null; toSite: number | null; foreignName?: string | null; lat: number; lng: number; accuracy?: number | null; key: string }) =>
    unwrap<FieldSiteJourney>(await supabase.rpc('start_field_journey', {
      p_from_site: o.fromSite, p_to_site: o.toSite, p_lat: o.lat, p_lng: o.lng,
      p_accuracy: o.accuracy != null ? Math.round(o.accuracy) : null, p_key: o.key, p_foreign_name: o.foreignName ?? null,
    })),
  reachFieldJourney: async (id: number, lat: number, lng: number, accuracy?: number | null) =>
    unwrap<FieldSiteJourney>(await supabase.rpc('reach_field_journey', {
      p_journey: id, p_lat: lat, p_lng: lng, p_accuracy: accuracy != null ? Math.round(accuracy) : null,
    })),
  /** Change plan while on the way: go back to the start site, go to another site, or cancel the visit (no approval, no limit) */
  changeJourneyPlan: async (o: PlanChangeInput) =>
    unwrap<FieldSiteJourney>(await supabase.rpc('change_journey_plan', {
      p_journey: o.journeyId, p_change_type: o.type, p_new_site: o.newSite ?? null, p_reason: o.reason, p_remarks: o.remarks ?? null,
      p_lat: o.lat ?? null, p_lng: o.lng ?? null, p_accuracy: o.accuracy != null ? Math.round(o.accuracy) : null,
      p_changed_at: o.changedAt, p_key: o.key,
    })),
  /** Plan changes of some journeys (an employee reads only his own, Admin / HR everybody's). Empty when the database update is not installed. */
  journeyPlanChanges: async (journeyIds: number[]) => {
    if (journeyIds.length === 0) return [] as JourneyPlanChange[];
    const { data, error } = await supabase.from('journey_plan_changes').select('*').in('journey_id', journeyIds).order('changed_at', { ascending: true });
    return error ? ([] as JourneyPlanChange[]) : (data as JourneyPlanChange[]);
  },
  addFieldJourneyPoints: async (id: number, points: JourneyPoint[]) =>
    unwrap<number>(await supabase.rpc('add_field_journey_points', { p_journey: id, p_points: points })),
  /** Journeys between two dates (an employee sees only their own; Admin / HR see everybody's) */
  fieldSiteJourneys: async (from: string, to: string, userId?: string) => {
    let q = supabase.from('v_field_site_journeys').select('*').gte('journey_date', from).lte('journey_date', to)
      .order('journey_date', { ascending: false }).order('start_time', { ascending: true }).limit(2000);
    if (userId) q = q.eq('user_id', userId);
    return unwrap<FieldSiteJourney[]>(await q);
  },
  setJoiningDate: async (userId: string, date: string | null) =>
    unwrap<Profile>(await supabase.rpc('admin_set_joining_date', { p_user: userId, p_date: date })),

  setSaturdays: async (userId: string, saturdays: number[]) =>
    unwrap<Profile>(await supabase.rpc('admin_set_saturdays', { p_user: userId, p_saturdays: saturdays })),

  // ---------------- Salary management ----------------
  /** Admin / HR: Basic, Increment 1, Increment 2 and current salary of everyone (people who left stay in the list) */
  salaryOverview: async (): Promise<{ rows: SalaryOverviewRow[]; setupNeeded: boolean }> => {
    const res = await supabase.rpc('admin_salary_overview');
    if (!res.error) return { rows: res.data as SalaryOverviewRow[], setupNeeded: false };
    // The database update (salary_management.sql) has not been run yet: show the salaries that are saved, read only
    if (!/schema cache|does not exist|Could not find/i.test(res.error.message ?? '')) throw res.error;
    const [people, sal] = await Promise.all([
      supabase.from('profiles').select('id, username, full_name, department, active, joining_date').eq('active', true).order('full_name'),
      supabase.from('employee_salary').select('user_id, monthly_salary'),
    ]);
    if (people.error) throw people.error;
    const pay = new Map((sal.data ?? []).map((s: any) => [s.user_id, Number(s.monthly_salary)]));
    const rows: SalaryOverviewRow[] = (people.data ?? []).map((p: any) => {
      const s = pay.get(p.id);
      return {
        user_id: p.id, username: p.username, full_name: p.full_name, department: p.department, active: p.active,
        joining_date: p.joining_date, left_on: null, basic: s && s > 0 ? s : null, inc1: null, inc1_on: null, inc2: null, inc2_on: null,
        increments: 0, current_salary: s && s > 0 ? s : null, current_from: null,
      };
    });
    return { rows, setupNeeded: true };
  },

  /** Before the database update only: saves a basic salary in the old salary table */
  setBasicLegacy: async (userId: string, amount: number) =>
    unwrap<number>(await supabase.rpc('admin_set_salary', { p_user: userId, p_amount: amount })),

  /** Admin / HR: every salary change of one employee, newest first */
  salaryHistory: async (userId: string) => unwrap<SalaryHistoryRow[]>(await supabase.rpc('admin_salary_history', { p_user: userId })),

  /** Admin only: the first call sets the Basic salary, the next calls add an increment from the effective date */
  incrementSalary: async (userId: string, salary: number, effective: string | null, note: string) =>
    unwrap<SalaryHistoryRow>(await supabase.rpc('admin_increment_salary', {
      p_user: userId, p_salary: salary, p_effective: effective, p_note: note.trim() || null,
    })),

  /** The signed-in person's own salary history (changes that have started) */
  mySalary: async () => unwrap<MySalaryRow[]>(await supabase.rpc('my_salary')),

  /** Admin / HR: the last 6 payroll months with Draft / Ready / Finalized (needs payroll_months.sql) */
  payrollMonths: async (): Promise<PayrollMonth[]> => unwrap<PayrollMonth[]>(await supabase.rpc('admin_payroll_months')),
  /** Admin only: lock a month that is over */
  finalizeMonth: async (year: number, month: number) => unwrap<string>(await supabase.rpc('admin_finalize_month', { p_year: year, p_month: month })),

  /** Admin / HR: salary sheet (paid / unpaid leave, overtime pay, net salary). People who left keep a row with "(Resigned ...)" */
  payroll: async (year: number, month: number) =>
    unwrap<PayrollRow[]>(await supabase.rpc('admin_payroll', { p_year: year, p_month: month }))
      .map((p) => ({ ...p, full_name: resignedName(p.full_name, p.left_on) })),

  /** Admin / HR: every check-in of the period with total, regular (up to 8 h) and overtime hours */
  workingHoursReport: async (from: string, to: string, userId?: string) =>
    unwrap<WorkHoursRow[]>(await supabase.rpc('admin_working_hours_report', { p_from: from, p_to: to, p_user: userId ?? null })),
  /** Admin / HR: every day with overtime */
  overtimeDays: async (year: number, month: number) =>
    unwrap<OvertimeRow[]>(await supabase.rpc('admin_overtime_days', { p_year: year, p_month: month })),
  /** Admin / HR: set one employee's yearly leave days per leave type, e.g. { 'Casual Leave': 12 } */
  setLeaveQuota: async (userId: string, year: number, quotas: Record<string, number>) =>
    unwrap<number>(await supabase.rpc('admin_set_leave_quota', { p_user: userId, p_year: year, p_quotas: quotas })),
  /** Admin / HR: delete the selfie photo of one record (the record itself is kept) */
  deleteSelfiePhoto: async (recordId: number) => {
    const path = unwrap<string | null>(await supabase.rpc('admin_clear_selfie_photo', { p_id: recordId }));
    if (path) {
      const { error } = await supabase.storage.from('selfies').remove([path]);
      if (error) throw error;
    }
  },
  setTravelAccess: async (userId: string, enabled: boolean) =>
    unwrap<Profile>(await supabase.rpc('admin_set_travel_access', { p_user: userId, p_enabled: enabled })),

  /** 'visit' | 'travel' while the signed-in user is on a field visit / between travel stops, otherwise null */
  liveTrackingActive: async () => unwrap<string | null>(await supabase.rpc('live_tracking_active')),
  /** Sends this device's position (the database keeps it only while a visit / travel stop is open) */
  reportLocation: async (lat: number, lng: number, accuracy?: number | null) =>
    unwrap<string | null>(await supabase.rpc('report_location', { p_lat: lat, p_lng: lng, p_accuracy: accuracy != null ? Math.round(accuracy) : null })),
  /** HR / Admin: everyone who is on a visit or travelling right now, with their last position */
  liveLocations: async () =>
    unwrap<LiveLocation[]>(await supabase.from('live_locations')
      .select('user_id, lat, lng, accuracy_m, kind, updated_at, employee:profiles!live_locations_user_id_fkey(full_name, username, department)')),

  /** HR / Admin: everything one employee did on the road on a date: the stop list with trip km, the day total, and visits */
  dayDetail: async (userId: string, date: string): Promise<DayDetail> => {
    let legs: DayDetail['legs'] = [];
    try {
      legs = unwrap<DayDetail['legs']>(await supabase.from('attendance_legs')
        .select('leg, site_name, in_at, out_at, trip_km, trip_source, in_dist_m, out_dist_m').eq('user_id', userId).eq('work_date', date).order('leg'));
    } catch {
      // an older database without the trip columns: still list the stops
      const rows = unwrap<any[]>(await supabase.from('attendance_legs')
        .select('leg, site_name, in_at, out_at').eq('user_id', userId).eq('work_date', date).order('leg'));
      legs = rows.map((r) => ({ ...r, trip_km: null, trip_source: null }));
    }
    let km = 0; let done = false;
    try {
      const att = unwrap<any[]>(await supabase.from('attendance').select('travel_km, travel_done')
        .eq('user_id', userId).eq('work_date', date).limit(1));
      km = Number(att[0]?.travel_km ?? 0); done = !!att[0]?.travel_done;
    } catch { /* optional columns */ }
    return { legs, km, done };
  },

  /** HR / Admin: today's GPS trail of the given employees (only travel days have one), oldest point first */
  liveTracks: async (userIds: string[]) => {
    if (userIds.length === 0) return {} as Record<string, [number, number][]>;
    const since = `${istDateISO()}T00:00:00+05:30`;
    const rows = unwrap<{ user_id: string; lat: number; lng: number }[]>(await supabase.from('travel_track')
      .select('user_id, lat, lng').in('user_id', userIds).gte('recorded_at', since).order('recorded_at'));
    const out: Record<string, [number, number][]> = {};
    for (const r of rows) (out[r.user_id] ??= []).push([r.lat, r.lng]);
    return out;
  },

  /** Site-selfie employees with Travel Access: two stops at two different work sites */
  siteTravelCheckIn: async (o: { lat: number; lng: number; siteId?: number; siteName: string; note?: string; photoPath?: string }) =>
    unwrap<TravelDay>(await supabase.rpc('site_travel_check_in', {
      p_lat: o.lat, p_lng: o.lng, p_site_id: o.siteId ?? null, p_site_name: o.siteName, p_note: o.note ?? null, p_photo_path: o.photoPath ?? null,
    })),
  siteTravelCheckOut: async (o: { lat: number; lng: number; note?: string; photoPath?: string; reason?: string }) =>
    unwrap<TravelDay>(await supabase.rpc('site_travel_check_out', { p_lat: o.lat, p_lng: o.lng, p_note: o.note ?? null, p_photo_path: o.photoPath ?? null, p_reason: o.reason ?? null })),
  /** Ends the travel day: stops the live GPS and fixes the day's trips and km */
  travelReport: async (from: string, to: string) =>
    unwrap<TravelReportRow[]>(await supabase.rpc('admin_travel_report', { p_from: from, p_to: to })),

  allHolidays: async () =>
    unwrap<Holiday[]>(await supabase.from('holidays').select('day, name, kind').order('day', { ascending: false })),

  saveHoliday: async (h: Holiday) =>
    unwrap(await supabase.from('holidays').upsert(h, { onConflict: 'day' })),

  /** HR and Admin can delete any holiday, national or restricted */
  deleteHoliday: async (day: string) => {
    const gone = unwrap<{ day: string }[]>(await supabase.from('holidays').delete().eq('day', day).select('day'));
    if (gone.length === 0) throw new Error('The holiday could not be deleted. Only HR / Admin can delete holidays.');
  },

  audit: async (limit = 300) =>
    unwrap<AuditRow[]>(await supabase.from('audit_log')
      .select('id, action, detail, logged_at, actor:profiles(username, full_name)')
      .order('id', { ascending: false }).limit(limit)),

  // ---------------- Daily report ----------------
  dailyReport: async (id: number) =>
    unwrap<DailyReport | null>(await supabase.from('daily_reports').select('*, daily_report_sites(*)').eq('id', id).maybeSingle()),

  dailyReportContext: async () => unwrap<DailyReportContext>(await supabase.rpc('daily_report_context')),

  /** Admin / HR: reports of a date range, optionally one employee */
  dailyReportsAdmin: async (from: string, to: string, userId?: string) => {
    let q = supabase.from('daily_reports')
      .select('*, daily_report_sites(*), employee:profiles!daily_reports_user_id_fkey(full_name, username)')
      .gte('report_date', from).lte('report_date', to)
      .order('report_date', { ascending: false }).order('id', { ascending: false });
    if (userId) q = q.eq('user_id', userId);
    return unwrap<DailyReport[]>(await q);
  },

  /** The signed-in employee's reports of a date range (RLS lets him read only his own) */
  myDailyReports: async (userId: string, from: string, to: string) =>
    unwrap<DailyReport[]>(await supabase.from('daily_reports').select('*, daily_report_sites(*)')
      .eq('user_id', userId).gte('report_date', from).lte('report_date', to).order('report_date', { ascending: false })),

  reopenDailyReport: async (id: number, note?: string) =>
    unwrap<DailyReport>(await supabase.rpc('reopen_daily_report', { p_id: id, p_note: note ?? null })),

  reviewDailyReport: async (id: number, note?: string) =>
    unwrap<DailyReport>(await supabase.rpc('review_daily_report', { p_id: id, p_note: note ?? null })),

  /** reportId null = today's report (created on the first save, only after check-out) */
  saveDailyReportDraft: async (reportId: number | null, sites: DailySiteInput[]) =>
    unwrap<DailyReport>(await supabase.rpc('save_daily_report_draft', { p_report_id: reportId, p_sites: sites })),

  submitDailyReport: async (reportId: number | null, sites: DailySiteInput[]) =>
    unwrap<DailyReport>(await supabase.rpc('submit_daily_report', { p_report_id: reportId, p_sites: sites })),

  // ---------------- Daily Report required before site check-out ----------------
  /** Employee: is today's check-out locked? Null when the database update has not been run (the app then behaves as before). */
  checkoutReportStatus: async () => {
    const { data, error } = await supabase.rpc('checkout_report_status');
    return error ? null : (data as CheckoutReportStatus);
  },
  checkoutReportToday: async (date?: string) =>
    unwrap<CheckoutReportRow[]>(await supabase.rpc('admin_checkout_report_today', { p_date: date ?? null })),
  allowCheckoutOnce: async (userId: string, reason: string) =>
    unwrap<unknown>(await supabase.rpc('admin_allow_checkout_once', { p_user: userId, p_reason: reason })),
  checkoutRule: async () => {
    const { data } = await supabase.from('checkout_rule_settings').select('report_required, draft_unlocks').eq('id', 1).maybeSingle();
    return (data as CheckoutRule | null) ?? null;
  },
  setCheckoutRule: async (required: boolean, draftUnlocks: boolean) =>
    unwrap<unknown>(await supabase.rpc('admin_set_checkout_rule', { p_required: required, p_draft_unlocks: draftUnlocks })),

  // ---------------- Employee holidays / leave eligibility ----------------
  deleteEmployeeHoliday: async (id: number) =>
    unwrap<unknown>(await supabase.rpc('admin_delete_holiday', { p_id: id })),

  /** Holidays of Site / Office employees. HR / Admin get all; an employee gets only his own. Empty when the database update has not been run. */
  employeeHolidays: async (year?: number): Promise<EmployeeHoliday[]> => {
    let q = supabase.from('employee_holidays').select('id, day, name, category, holiday_type, all_employees').order('day', { ascending: false });
    if (year) q = q.gte('day', `${year}-01-01`).lte('day', `${year}-12-31`);
    const res = await q;
    if (res.error) return [];
    const list = (res.data ?? []) as Omit<EmployeeHoliday, 'user_ids'>[];
    if (list.length === 0) return [];
    const u = await supabase.from('employee_holiday_users').select('holiday_id, user_id').in('holiday_id', list.map((h) => h.id));
    const by = new Map<number, string[]>();
    (u.data ?? []).forEach((r: { holiday_id: number; user_id: string }) => by.set(r.holiday_id, [...(by.get(r.holiday_id) ?? []), r.user_id]));
    return list.map((h) => ({ ...h, user_ids: by.get(h.id) ?? [] }));
  },

  saveEmployeeHoliday: async (h: { id?: number; day: string; name: string; category: 'Site' | 'Office'; type: 'Paid' | 'Unpaid'; all: boolean; userIds: string[] }) =>
    unwrap<unknown>(await supabase.rpc('admin_save_holiday', {
      p_id: h.id ?? null, p_day: h.day, p_name: h.name, p_category: h.category, p_type: h.type, p_all: h.all, p_users: h.all ? [] : h.userIds,
    })),

  /** Paid leave starts after 6 months of service (leave_eligibility.sql); null when the database update has not been run */
  myLeaveEligibility: async (): Promise<LeaveEligibility | null> => {
    const res = await supabase.rpc('my_leave_eligibility');
    if (res.error) return null;
    return ((res.data ?? []) as LeaveEligibility[])[0] ?? null;
  },

  // ---------------- Field day views ----------------
  fieldLegs: async (from: string, to: string, userId?: string) => {
    let q = supabase.from('v_field_visit_legs').select('*').gte('work_date', from).lte('work_date', to)
      .order('work_date', { ascending: false }).order('full_name').order('leg_no');
    if (userId) q = q.eq('user_id', userId);
    return unwrap<FieldLeg[]>(await q);
  },
  fieldDays: async (from: string, to: string, userId?: string) => {
    let q = supabase.from('v_daily_attendance').select('*').gte('work_date', from).lte('work_date', to)
      .order('work_date', { ascending: false }).order('full_name');
    if (userId) q = q.eq('user_id', userId);
    return unwrap<FieldDayRow[]>(await q);
  },
  foreignRegister: async (from: string, to: string, userId?: string) => {
    let q = supabase.from('v_foreign_register').select('*').gte('work_date', from).lte('work_date', to)
      .order('event_at', { ascending: false });
    if (userId) q = q.eq('user_id', userId);
    return unwrap<ForeignEventRow[]>(await q);
  },
  fieldLive: async () => unwrap<FieldLiveRow[]>(await supabase.from('v_field_live_today').select('*').order('full_name')),
  myFieldDay: async (userId: string, date: string) =>
    unwrap<FieldDayRow | null>(await supabase.from('v_daily_attendance').select('*').eq('user_id', userId).eq('work_date', date).maybeSingle()),
  /** Admin / HR: the recorded GPS points between two moments */
  journeyTrack: async (userId: string, fromIso: string, toIso: string) =>
    unwrap<{ lat: number; lng: number; recorded_at: string }[]>(await supabase.from('travel_track')
      .select('lat, lng, recorded_at').eq('user_id', userId).gte('recorded_at', fromIso).lte('recorded_at', toIso).order('recorded_at')),};

