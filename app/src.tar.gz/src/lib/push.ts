// Phone push notifications (expo-notifications). EVERYTHING here is safe when the module is missing: on web / desktop and on an old APK
// (1.0.0, built without the package) every function just does nothing and returns "unavailable".
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';
import { Linking, Platform } from 'react-native';
import { supabase } from './supabase';

const TOKEN_KEY = 'cvp.pushToken';
const ASKED_KEY = 'cvp.pushAsked';

/** The native modules, or null when this build does not have them */
function mods(): { N: any; Device: any } | null {
  if (Platform.OS !== 'android' && Platform.OS !== 'ios') return null;
  try {
    const N = require('expo-notifications');
    const Device = require('expo-device');
    return N && Device ? { N, Device } : null;
  } catch { return null; }
}

export const pushSupported = () => !!mods();

let configured = false;
/** One-time setup: channel "approvals" and the foreground rule (no system pop-up while the app is open: the app shows its own banner) */
export async function configurePush(): Promise<void> {
  const m = mods(); if (!m || configured) return;
  configured = true;
  try {
    m.N.setNotificationHandler({ handleNotification: async () => ({ shouldShowBanner: false, shouldShowList: false, shouldPlaySound: false, shouldSetBadge: false }) });
    if (Platform.OS === 'android') {
      await m.N.setNotificationChannelAsync('approvals', { name: 'Approvals', importance: m.N.AndroidImportance.HIGH, vibrationPattern: [0, 250, 250, 250], sound: 'default' });
    }
  } catch { /* never stop the app */ }
}

export type PushPermission = 'unavailable' | 'granted' | 'denied' | 'undetermined';
export async function pushPermission(): Promise<PushPermission> {
  const m = mods(); if (!m) return 'unavailable';
  try { const p = await m.N.getPermissionsAsync(); return p.granted ? 'granted' : p.canAskAgain === false || p.status === 'denied' ? 'denied' : 'undetermined'; }
  catch { return 'unavailable'; }
}

/** Asks for permission (once automatically; the button in My Profile can ask again), gets the Expo token and saves it for the signed-in user */
export async function registerPush(opts: { ask?: boolean } = {}): Promise<{ ok: boolean; permission: PushPermission; token?: string }> {
  const m = mods(); if (!m) return { ok: false, permission: 'unavailable' };
  try {
    await configurePush();
    if (!m.Device.isDevice) return { ok: false, permission: 'unavailable' };   // an emulator has no push
    let perm = await pushPermission();
    if (perm !== 'granted' && perm !== 'denied') {
      const asked = await AsyncStorage.getItem(ASKED_KEY).catch(() => null);
      if (opts.ask || !asked) {
        await AsyncStorage.setItem(ASKED_KEY, '1').catch(() => undefined);
        const r = await m.N.requestPermissionsAsync();
        perm = r.granted ? 'granted' : 'denied';
      }
    }
    if (perm !== 'granted') return { ok: false, permission: perm };
    const projectId = (Constants.expoConfig as any)?.extra?.eas?.projectId ?? (Constants as any).easConfig?.projectId;
    const token: string = (await m.N.getExpoPushTokenAsync(projectId ? { projectId } : undefined)).data;
    const { error } = await supabase.rpc('save_push_token', { p_token: token, p_platform: Platform.OS === 'ios' ? 'ios' : 'android', p_device_name: m.Device.deviceName ?? m.Device.modelName ?? null });
    if (error) throw error;
    await AsyncStorage.setItem(TOKEN_KEY, token).catch(() => undefined);
    return { ok: true, permission: 'granted', token };
  } catch { return { ok: false, permission: await pushPermission() }; }
}

/** The token this phone has registered (null when none) */
export async function registeredToken(): Promise<string | null> { return AsyncStorage.getItem(TOKEN_KEY).catch(() => null); }

/** On logout, BEFORE signing out: this phone stops receiving this employee's notifications */
export async function unregisterPush(): Promise<void> {
  try {
    const token = await AsyncStorage.getItem(TOKEN_KEY);
    if (token) { await supabase.rpc('remove_push_token', { p_token: token }); await AsyncStorage.removeItem(TOKEN_KEY); }
  } catch { /* offline: the next login moves the token to the next user anyway */ }
}

export const openPhoneSettings = () => { void Linking.openSettings().catch(() => undefined); };

/** Listeners: a notification arrived while the app is open / the employee tapped one. Returns a function that removes them. */
export function listenPush(onForeground: (n: { title: string; body: string; link: string | null; id: number | null }) => void, onTap: (link: string | null, id: number | null) => void): () => void {
  const m = mods(); if (!m) return () => undefined;
  const subs: { remove: () => void }[] = [];
  try {
    subs.push(m.N.addNotificationReceivedListener((n: any) => {
      const c = n?.request?.content ?? {};
      onForeground({ title: c.title ?? '', body: c.body ?? '', link: c.data?.link ?? null, id: c.data?.id ?? null });
    }));
    subs.push(m.N.addNotificationResponseReceivedListener((r: any) => {
      const d = r?.notification?.request?.content?.data ?? {};
      onTap(d.link ?? null, d.id ?? null);
    }));
    // the app was closed and the employee tapped the notification to open it
    m.N.getLastNotificationResponseAsync?.().then((r: any) => {
      if (!r) return;
      const d = r?.notification?.request?.content?.data ?? {};
      onTap(d.link ?? null, d.id ?? null);
    }).catch(() => undefined);
  } catch { /* ignore */ }
  return () => subs.forEach((s) => { try { s.remove(); } catch { /* ignore */ } });
}
