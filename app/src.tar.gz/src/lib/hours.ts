// Working-hours helpers. Pure functions: the DATABASE decides the real hours and status; these only show them live on the phone.

export const DEFAULT_REQUIRED_MIN = 480;   // 8h 00m
export const DEFAULT_RANGE_M = 500;

/** Whole minutes from check-in to check-out (or to `nowMs` while still working). Never negative. */
export function workedMinutes(checkInIso: string | null | undefined, checkOutIso: string | null | undefined, nowMs: number): number | null {
  if (!checkInIso) return null;
  const end = checkOutIso ? new Date(checkOutIso).getTime() : nowMs;
  return Math.max(0, Math.round((end - new Date(checkInIso).getTime()) / 60000));
}

/** "6h 37m" */
export function hm(mins: number): string {
  const m = Math.max(0, Math.round(mins));
  return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`;
}

/** Full day when the required hours are done, otherwise Short hours (with the short time) */
export function hoursStatus(worked: number, required: number): { label: 'Full day' | 'Short hours'; shortBy: number } {
  return worked >= required ? { label: 'Full day', shortBy: 0 } : { label: 'Short hours', shortBy: required - worked };
}

/** The moment the required hours are complete (ISO) */
export function completeAtMs(checkInIso: string, required: number): number {
  return new Date(checkInIso).getTime() + required * 60000;
}

/** Progress 0..1 */
export function progress(worked: number, required: number): number {
  return required <= 0 ? 1 : Math.min(1, worked / required);
}
