// PF / ESIC / PT reports in the layout of the Form II wages register (same heading, same first columns, same colours),
// showing ONLY the columns of that report. The numbers are the Form II numbers of the month (WageRow): nothing new is calculated.
import * as XLSX from 'xlsx-js-style';
import { rh } from './companies';
import { loadPdfLibs, outputPdf } from './pdf';
import type { WageRow } from './wages';
import { saveXlsxData } from './xlsx';

export type StatKind = 'pf' | 'esic' | 'pt';
interface Col { head: string; get: (r: WageRow) => string | number; type: 'text' | 'center' | 'num'; sum?: boolean; w: number; group?: string }

const dmy = (iso: string) => (iso ? `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}` : '');
const AMBER: [number, number, number] = [255, 192, 0];
const INK: [number, number, number] = [20, 20, 20];
const moneyDash = (n: number) => (n ? n.toLocaleString('en-IN') : '-');

/** the first nine columns, the same in every report (as in the Form II register) */
const COMMON: Col[] = [
  { head: 'Sr. No.', get: () => '', type: 'center', w: 6 },                      // filled with the running number
  { head: 'Date of Joining', get: (r) => dmy(r.joining), type: 'center', w: 12 },
  { head: 'Date of Resignation', get: (r) => dmy(r.resigned), type: 'center', w: 12 },
  { head: 'UAN No.', get: (r) => r.uan, type: 'center', w: 15 },
  { head: 'Full Name of the Employees', get: (r) => r.name, type: 'text', w: 32 },
  { head: 'Male / Female', get: (r) => r.gender, type: 'center', w: 8 },
  { head: 'Gross Wages', get: (r) => r.gross, type: 'num', sum: true, w: 11 },
  { head: 'Total Days Present', get: (r) => r.daysPresent, type: 'center', sum: true, w: 9 },
  { head: 'Total Days', get: (r) => r.daysInMonth || '', type: 'center', w: 8 },
];
const GROSS: Col = { head: 'Total Gross Wages', get: (r) => r.totalGross, type: 'num', sum: true, w: 12 };

/** the columns of each report (after the common nine) */
const SPECIFIC: Record<StatKind, Col[]> = {
  pf: [
    { head: 'PF Employee', get: (r) => r.pfEmployee, type: 'num', sum: true, w: 11, group: 'PF' },
    { head: 'PF Employer', get: (r) => r.pfEmployer, type: 'num', sum: true, w: 11, group: 'PF' },
    { head: 'PF Member (Y/N)', get: (r) => r.pfMember, type: 'center', w: 9 },
    { head: 'EPS Eligible (Y/N)', get: (r) => r.epsEligible, type: 'center', w: 9 },
    { head: 'PF Wages (EPF/EDLI wages)', get: (r) => r.pfWages, type: 'num', sum: true, w: 13 },
    { head: 'EPS Wages', get: (r) => r.epsWages, type: 'num', sum: true, w: 11 },
    { head: 'Employer EPS 8.33%', get: (r) => r.employerEps, type: 'num', sum: true, w: 11 },
    { head: 'Employer EPF 3.67% (diff)', get: (r) => r.employerEpf, type: 'num', sum: true, w: 12 },
  ],
  esic: [
    GROSS,
    { head: 'ESIC Employee', get: (r) => r.esicEmployee, type: 'num', sum: true, w: 12, group: 'ESIC' },
    { head: 'ESIC Employer', get: (r) => r.esicEmployer, type: 'num', sum: true, w: 12, group: 'ESIC' },
  ],
  pt: [
    GROSS,
    { head: 'PT', get: (r) => r.pt, type: 'num', sum: true, w: 10 },
  ],
};
export const columnsFor = (k: StatKind): Col[] => [...COMMON, ...SPECIFIC[k]];

/** Only the employees of that report (PF members / people with ESIC / people who pay PT), in the register's order */
export function statutoryRows(k: StatKind, rows: WageRow[]): WageRow[] {
  return rows.filter((r) => (k === 'pf' ? r.pfMember === 'Y' : k === 'esic' ? r.esicEmployee > 0 : r.pt > 0));
}

/** a flat list of the report (used for the "no data" check and as the plain table) */
export function statutoryFlat(k: StatKind, rows: WageRow[]): Record<string, unknown>[] {
  const cols = columnsFor(k);
  return rows.map((r, i) => Object.fromEntries(cols.map((c, j) => [c.head, j === 0 ? i + 1 : c.get(r)])));
}

// ---------------------------------------------------------------------------------------------------------------------- PDF
export async function statutoryPdf(fileName: string, monthLabel: string, k: StatKind, rows: WageRow[], footer?: string) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const cols = columnsFor(k);
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const header = () => {
    doc.setFillColor(255, 255, 0); doc.rect(8, 6, W - 16, 5, 'F');
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
    doc.text('!! Shree !!', W / 2, 9.8, { align: 'center' });
    doc.text('Muster Roll Cum Wages Register', W / 2, 15, { align: 'center' });
    doc.text('FORM (II)', W / 2, 19.5, { align: 'center' });
    doc.setFontSize(8); doc.text('M.W. Rules 1963 Rule 27 (I)', W / 2, 24, { align: 'center' });
    doc.setFont('helvetica', 'bold'); doc.text('Name of the Establishment -', 10, 31); doc.setFont('helvetica', 'normal'); doc.text(rh().name, 52, 31);
    doc.setFont('helvetica', 'bold'); doc.text('Pan NO', 130, 31); doc.setFont('helvetica', 'normal'); doc.text(rh().pan, 144, 31);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text(`For the Month of   ${monthLabel}`, W - 10, 31, { align: 'right' });
    doc.setFontSize(8); doc.text('Address of the Establishment -', 10, 36); doc.setFont('helvetica', 'normal'); doc.text(rh().address, 52, 36);
  };
  const align = (c: Col) => (c.type === 'num' ? 'right' as const : c.type === 'center' ? 'center' as const : 'left' as const);
  const body: any[][] = rows.map((r, i) => cols.map((c, j) => ({ content: j === 0 ? String(i + 1) : c.type === 'num' ? moneyDash(Number(c.get(r))) : String(c.get(r) ?? ''), styles: { halign: align(c) } })));
  // TOTAL row: the label across the name columns, then the sums
  const bold = { fontStyle: 'bold' as const, fillColor: [255, 244, 204] as [number, number, number] };
  const firstSum = cols.findIndex((c) => c.sum);
  const t: any[] = [{ content: 'TOTAL', colSpan: firstSum, styles: { ...bold, halign: 'right' } }];
  for (let j = firstSum; j < cols.length; j++) {
    const c = cols[j];
    t.push({ content: c.sum ? moneyDash(rows.reduce((a, r) => a + Number(c.get(r) || 0), 0)) : '', styles: { ...bold, halign: align(c) } });
  }
  body.push(t);
  // header: grouped columns ("PF", "ESIC") span their sub-columns; everything else spans two rows
  const head1: any[] = []; const head2: string[] = [];
  for (let j = 0; j < cols.length; j++) {
    const c = cols[j];
    if (!c.group) { head1.push({ content: c.head, rowSpan: 2 }); continue; }
    if (j > 0 && cols[j - 1].group === c.group) { head2.push(c.head); continue; }
    const n = cols.filter((x) => x.group === c.group).length;
    head1.push({ content: c.group, colSpan: n, styles: { halign: 'center' } }); head2.push(c.head);
  }
  autoTable(doc, {
    startY: 40, head: [head1, head2], body, theme: 'grid',
    styles: { fontSize: 6.2, cellPadding: 1.2, textColor: INK, lineColor: [60, 60, 60], lineWidth: 0.15, valign: 'middle', halign: 'center', overflow: 'linebreak' },
    headStyles: { fillColor: AMBER, textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle', fontSize: 5.6 },
    columnStyles: { 0: { cellWidth: 8 }, 1: { cellWidth: 17 }, 2: { cellWidth: 17 }, 3: { cellWidth: 21 }, 4: { cellWidth: 48, halign: 'left' }, 5: { cellWidth: 12 } },
    margin: { left: 5, right: 5, top: 40, bottom: 12 }, didDrawPage: () => header(),
  });
  const n = doc.getNumberOfPages(); const H = doc.internal.pageSize.getHeight();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(120, 120, 120);
  for (let i = 1; i <= n; i++) { doc.setPage(i); doc.text(`Page ${i} of ${n}`, W - 10, H - 5, { align: 'right' }); if (footer) doc.text(footer, 8, H - 5); }
  await outputPdf(fileName, doc);
}

// ---------------------------------------------------------------------------------------------------------------------- Excel
export async function statutoryXlsx(fileName: string, monthLabel: string, k: StatKind, rows: WageRow[], footer?: string) {
  const cols = columnsFor(k); const C = cols.length;
  const ws: XLSX.WorkSheet = {};
  const thin = { style: 'thin', color: { rgb: '3C3C3C' } } as const; const BORDER = { top: thin, bottom: thin, left: thin, right: thin };
  const font = (bold = false, sz = 10) => ({ name: 'Arial', sz, bold });
  const NUM = '[>=10000000]##\\,##\\,##\\,##0;[>=100000]##\\,##\\,##0;[=0]"-";##,##0';
  const put = (r: number, c: number, cell: XLSX.CellObject) => { ws[XLSX.utils.encode_cell({ r, c })] = cell; };
  const s = (v: string, style: object = {}): XLSX.CellObject => ({ t: 's', v, s: { font: font(), ...style } } as XLSX.CellObject);
  const n = (v: number, style: object = {}): XLSX.CellObject => ({ t: 'n', v, z: NUM, s: { font: font(), ...style } } as XLSX.CellObject);
  const merges: XLSX.Range[] = []; const centre = { horizontal: 'center', vertical: 'center', wrapText: true };
  const span = (r: number) => merges.push({ s: { r, c: 0 }, e: { r, c: C - 1 } });
  for (let c = 0; c < C; c++) put(0, c, s('', { fill: { fgColor: { rgb: 'FFFF00' } } }));
  put(0, 0, s('!! Shree !!', { fill: { fgColor: { rgb: 'FFFF00' } }, font: font(true, 11), alignment: centre })); span(0);
  put(1, 0, s('Muster Roll Cum Wages Register', { font: font(true, 11), alignment: centre })); span(1);
  put(2, 0, s('FORM (II)', { font: font(true, 11), alignment: centre })); span(2);
  put(3, 0, s('M.W. Rules 1963 Rule 27 (I)', { font: font(true, 10), alignment: centre })); span(3);
  put(5, 0, s('Name of the Establishment -', { font: font(true) })); put(5, 3, s(rh().name));
  put(5, 8, s('Pan NO', { font: font(true) })); put(5, 10, s(rh().pan));
  put(5, Math.max(11, C - 3), s('For the Month of', { font: font(true, 11) })); put(5, Math.max(13, C - 1), s(monthLabel, { font: font(true, 12) }));
  put(7, 0, s('Address of the Establishment -', { font: font(true) })); put(7, 3, s(rh().address));
  // two header rows
  const H = 9; const hs = { font: font(true), fill: { fgColor: { rgb: 'FFC000' } }, border: BORDER, alignment: centre };
  for (let c = 0; c < C; c++) { put(H, c, s('', hs)); put(H + 1, c, s('', hs)); }
  for (let j = 0; j < C; j++) {
    const c = cols[j];
    if (!c.group) { put(H, j, s(c.head, hs)); merges.push({ s: { r: H, c: j }, e: { r: H + 1, c: j } }); continue; }
    put(H + 1, j, s(c.head, hs));
    if (!(j > 0 && cols[j - 1].group === c.group)) { const cnt = cols.filter((x) => x.group === c.group).length; put(H, j, s(c.group, hs)); merges.push({ s: { r: H, c: j }, e: { r: H, c: j + cnt - 1 } }); }
  }
  // rows
  const first = H + 2;
  rows.forEach((w, i) => cols.forEach((c, j) => {
    const st = { border: BORDER, alignment: { horizontal: c.type === 'text' ? 'left' : c.type === 'num' ? 'right' : 'center', vertical: 'center' } };
    const v = j === 0 ? i + 1 : c.get(w);
    put(first + i, j, c.type === 'num' ? n(Number(v), st) : typeof v === 'number' ? n(v, st) : s(String(v ?? ''), st));
  }));
  // TOTAL row: SUM formulas
  const t = first + rows.length; const ts = { border: BORDER, fill: { fgColor: { rgb: 'FFF4CC' } }, font: font(true), alignment: { horizontal: 'center', vertical: 'center' } };
  for (let c = 0; c < C; c++) put(t, c, s('', ts));
  const firstSum = cols.findIndex((c) => c.sum);
  put(t, 0, s('TOTAL', { ...ts, alignment: { horizontal: 'right', vertical: 'center' } })); merges.push({ s: { r: t, c: 0 }, e: { r: t, c: firstSum - 1 } });
  cols.forEach((c, j) => {
    if (!c.sum || !rows.length) return;
    const L = XLSX.utils.encode_col(j);
    put(t, j, { t: 'n', f: `SUM(${L}${first + 1}:${L}${first + rows.length})`, v: rows.reduce((a, r) => a + Number(c.get(r) || 0), 0), z: NUM, s: { ...ts, alignment: { horizontal: 'center', vertical: 'center' } } } as XLSX.CellObject);
  });
  if (footer) put(t + 2, 0, s(footer, { font: font(false, 9) }));
  ws['!ref'] = XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: t + 3, c: C - 1 } });
  ws['!merges'] = merges; ws['!cols'] = cols.map((c) => ({ wch: c.w }));
  (ws as any)['!rows'] = []; (ws as any)['!rows'][H] = { hpt: 30 }; (ws as any)['!rows'][H + 1] = { hpt: 30 };
  (ws as any)['!views'] = [{ state: 'frozen', xSplit: 5, ySplit: H + 2 }];
  (ws as any)['!pageSetup'] = { orientation: 'landscape', paperSize: 9, fitToWidth: 1, fitToHeight: 0 };
  (ws as any)['!sheetPr'] = { pageSetUpPr: { fitToPage: true } };
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, k === 'pf' ? 'PF Report' : k === 'esic' ? 'ESIC Report' : 'PT Report');
  await saveXlsxData(fileName, XLSX.write(wb, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer);
}
