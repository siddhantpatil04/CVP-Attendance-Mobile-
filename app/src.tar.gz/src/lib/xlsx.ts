import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Platform, Share } from 'react-native';
import * as XLSX from 'xlsx-js-style';
import { COMPANY_ADDRESS, COMPANY_NAME, COMPANY_PAN } from '../config';
import { savedNotice, saveToDownloads } from './saveDownload';

export interface Sheet {
  name: string;
  rows: Record<string, unknown>[];
  /** Free-form grid (array of rows), used instead of rows when set; allows merged header cells. */
  aoa?: unknown[][];
  merges?: { s: { r: number; c: number }; e: { r: number; c: number } }[];
  /** Report title and period printed in the heading block (the sheet name when empty) */
  title?: string;
  subtitle?: string;
  /** Compact heading (no empty rows): establishment / PAN / month on one row, address on the next, then the optional employee row */
  compact?: boolean;
  /** Company Reports only: keeps the yellow "!! Shree !!" bar and the PAN. Every other report leaves them out. */
  company?: boolean;
  /** Compact heading only: "For the Month of - <month>" (the period when empty) */
  month?: string;
  /** Compact heading only: green row under the address, e.g. "Name of the Employee - Jivan (emp020)" and "Department - SITE" */
  employee?: { name: string; department?: string };
  /**
   * Live Excel formulas. Called for every body cell with its place in the table (r = 0 is the header row, c = 0 is column A)
   * and `xr(i)`, the Excel row number of table row i. Return a formula without "=" or null to keep the plain value.
   */
  calc?: (r: number, c: number, xr: (i: number) => number, table: unknown[][]) => string | null;
}

const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

/** Excel sheet names: max 31 characters, none of  \ / ? * [ ] :  and unique in the workbook */
function sheetName(name: string, used: Set<string>): string {
  let base = name.replace(/[\\/?*[\]:]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 31) || 'Sheet';
  let n = base;
  for (let i = 2; used.has(n.toLowerCase()); i++) n = `${base.slice(0, 28)} ${i}`;
  used.add(n.toLowerCase());
  return n;
}

const AMBER = 'FFC000';
const YELLOW = 'FFFF00';
const TOTAL_FILL = 'FFF4CC';
const thin = { style: 'thin', color: { rgb: '3C3C3C' } } as const;
const BORDER = { top: thin, bottom: thin, left: thin, right: thin };
const font = (bold = false, sz = 10) => ({ name: 'Arial', sz, bold });

/** Reports other than Company Reports: remove the first sheet row (the yellow Shree bar) and move everything up one row */
function dropFirstRow(ws: XLSX.WorkSheet) {
  const moved: Record<string, any> = {};
  for (const k of Object.keys(ws)) {
    if (k.startsWith('!')) continue;
    const a = XLSX.utils.decode_cell(k);
    if (a.r > 0) moved[XLSX.utils.encode_cell({ r: a.r - 1, c: a.c })] = (ws as any)[k];
    delete (ws as any)[k];
  }
  Object.assign(ws, moved);
  const up = (g: XLSX.Range): XLSX.Range => ({ s: { r: g.s.r - 1, c: g.s.c }, e: { r: g.e.r - 1, c: g.e.c } });
  if (ws['!merges']) ws['!merges'] = (ws['!merges'] as XLSX.Range[]).filter((m) => m.s.r > 0).map(up);
  if (ws['!ref']) { const g = XLSX.utils.decode_range(ws['!ref'] as string); g.e.r = Math.max(0, g.e.r - 1); ws['!ref'] = XLSX.utils.encode_range(g); }
  const rowsInfo = (ws as any)['!rows']; if (Array.isArray(rowsInfo)) rowsInfo.shift();
  const af = (ws as any)['!autofilter']; if (af?.ref) af.ref = XLSX.utils.encode_range(up(XLSX.utils.decode_range(af.ref)));
}
/**
 * Every report sheet gets the same heading as the Muster Roll (Form II): the yellow "!! Shree !!" bar, the report title,
 * the establishment name / PAN / period / address lines, then an amber table header with bordered rows.
 */
function styledSheet(s: Sheet): XLSX.WorkSheet {
  const table: unknown[][] = s.aoa ?? (() => {
    const cols = s.rows[0] ? Object.keys(s.rows[0]) : [];
    return [cols, ...s.rows.map((r) => cols.map((c) => r[c] ?? ''))];
  })();
  const width = Math.max(6, ...table.map((r) => r.length));
  const wide = width >= 12;
  // compact sheets: the heading cell also gets room for the filter button, so "Duration", "Plan change" ... show in full
  const wch = Array.from({ length: width }, (_, c) => Math.min(45, Math.max(c === 0 && s.aoa ? 12 : 9,
    ...table.slice(0, 500).map((r, ri) => String(r[c] ?? '').length + (s.compact && ri === 0 ? 6 : 2)))));
  const title = s.title ?? s.name;
  const period = s.subtitle ?? '';
  const block: unknown[][] = [];
  const put = (r: number, c: number, v: string) => { (block[r] ??= [])[c] = v; };
  if (s.company) put(0, 0, '!! Shree !!');
  put(1, 0, title);
  if (period) put(2, 0, period);
  let HDR: number;
  const bold: [number, number][] = [];
  let empRow = -1; let empSplit = 0;
  if (s.compact) {
    // compact heading: no empty rows. Row 4 = establishment / PAN / month, row 5 = address, row 6 = employee (optional)
    // every value starts in the column right after its label's text (no gap), found from the real column widths
    const next = (from: number, chars: number) => {
      let sum = 0; let k = from;
      while (k < width - 1 && sum < chars * 1.15) { sum += wch[k]; k++; }
      return k;
    };
    const L1 = 'Name of the Establishment -'; const V1 = 'C.V.Patil & Associates';
    const L2 = 'Address of the Establishment -';
    const P = s.company ? `Pan NO - ${COMPANY_PAN}` : ''; const M = `For the Month of - ${s.month || period}`;
    const v1 = next(0, L1.length);
    const pa = Math.min(width - 2, next(v1, V1.length) + 0);
    const mo = Math.min(width - 1, next(pa, P.length));
    empSplit = Math.max(1, pa);
    put(3, 0, L1); put(3, v1, V1);
    // PAN and month are each ONE cell that spills into the empty cells on its right, so nothing is cut off
    if (P) put(3, pa, P);
    put(3, mo, M);
    put(4, 0, L2); put(4, next(0, L2.length), COMPANY_ADDRESS);
    bold.push([3, 0], [3, pa], [3, mo], [4, 0]);
    HDR = 5;
    if (s.employee) {
      empRow = 5; HDR = 6;
      put(5, 0, `Name of the Employee - ${s.employee.name}`);
      if (s.employee.department) put(5, pa, `Department - ${s.employee.department}`);
    }
  } else if (wide) {
    const pa = Math.floor(width * 0.45); const mo = Math.floor(width * 0.72);
    put(4, 0, 'Name of the Establishment -'); put(4, 3, 'C.V.Patil & Associates');
    if (s.company) { put(4, pa, 'Pan NO'); put(4, pa + 2, COMPANY_PAN); }
    if (period) { put(4, mo, 'For the Month of'); put(4, mo + 3, period); bold.push([4, mo + 3]); }
    put(6, 0, 'Address of the Establishment -'); put(6, 3, COMPANY_ADDRESS);
    bold.push([4, 0], [4, pa], [6, 0]); if (period) bold.push([4, mo]);
    HDR = 8;
  } else {
    put(4, 0, 'Name of the Establishment -'); put(4, 2, 'C.V.Patil & Associates');
    if (s.company) { put(5, 0, 'Pan NO'); put(5, 2, COMPANY_PAN); }
    put(6, 0, 'For the Month of'); put(6, 2, period);
    put(7, 0, 'Address of the Establishment -'); put(7, 2, COMPANY_ADDRESS);
    bold.push([4, 0], [5, 0], [6, 0], [7, 0], [6, 2]);
    HDR = 9;
  }
  const all: unknown[][] = Array.from({ length: HDR }, (_, r) => block[r] ?? []);
  all.push(...table);
  const ws = XLSX.utils.aoa_to_sheet(all);

  const cell = (r: number, c: number): any => {
    const ref = XLSX.utils.encode_cell({ r, c });
    return (ws[ref] ??= { t: 's', v: '' });
  };
  for (let c = 0; c < width; c++) cell(0, c).s = { fill: { fgColor: { rgb: YELLOW } }, font: font(true, 11), alignment: { horizontal: 'center', vertical: 'center' } };
  cell(1, 0).s = { font: font(true, 12), alignment: { horizontal: 'center', vertical: 'center' } };
  if (period) cell(2, 0).s = { font: font(true, 10), alignment: { horizontal: 'center', vertical: 'center' } };
  bold.forEach(([r, c]) => { cell(r, c).s = { font: font(true, 10) }; });
  const merges: XLSX.Range[] = [0, 1, ...(period ? [2] : [])].map((r) => ({ s: { r, c: 0 }, e: { r, c: width - 1 } }));
  if (empRow >= 0) {
    // green employee row: name merged across the left part, department across the right part
    for (let c = 0; c < width; c++) cell(empRow, c).s = { fill: { fgColor: { rgb: 'E2EFDA' } }, font: font(true, 10), alignment: { horizontal: 'left', vertical: 'center' } };
    merges.push({ s: { r: empRow, c: 0 }, e: { r: empRow, c: empSplit - 1 } }, { s: { r: empRow, c: empSplit }, e: { r: empRow, c: width - 1 } });
  }
  (s.merges ?? []).forEach((m) => merges.push({ s: { r: m.s.r + HDR, c: m.s.c }, e: { r: m.e.r + HDR, c: m.e.c } }));
  ws['!merges'] = merges;

  // formulas: the TOTAL row of a flat report is a SUM of the rows above; `calc` adds row / column formulas
  const xr = (i: number) => HDR + i + 1;
  const setFormula = (r: number, c: number, f: string) => {
    const x = cell(HDR + r, c);
    x.f = f;
    if (x.t !== 'n') { x.t = 'n'; x.v = 0; }
  };
  const isTotalRow = (r: number) => String(table[r]?.[0] ?? '').toUpperCase() === 'TOTAL' || String(table[r]?.[1] ?? '').toUpperCase() === 'TOTAL';
  const totalAt = s.aoa ? -1 : table.findIndex((_, r) => r > 0 && isTotalRow(r));
  if (totalAt > 1) {
    for (let c = 0; c < width; c++) {
      if (typeof table[totalAt][c] === 'number') {
        const L = XLSX.utils.encode_col(c);
        setFormula(totalAt, c, `SUM(${L}${xr(1)}:${L}${xr(totalAt - 1)})`);
      }
    }
  }
  if (s.calc) {
    const end = totalAt > 0 ? totalAt : table.length;
    for (let r = 1; r < end; r++) {
      for (let c = 0; c < width; c++) {
        const f = s.calc(r, c, xr, table);
        if (f) setFormula(r, c, f);
      }
    }
  }

  // amber header row + bordered body (TOTAL rows in pale yellow)
  for (let c = 0; c < width; c++) cell(HDR, c).s = { font: font(true), fill: { fgColor: { rgb: AMBER } }, border: BORDER, alignment: { horizontal: 'center', vertical: 'center', wrapText: true } };
  for (let r = HDR + 1; r < all.length; r++) {
    const total = String(all[r][0] ?? '').toUpperCase() === 'TOTAL' || String(all[r][1] ?? '').toUpperCase() === 'TOTAL';
    for (let c = 0; c < width; c++) {
      const x = cell(r, c);
      x.s = {
        font: font(total), border: BORDER, ...(total ? { fill: { fgColor: { rgb: TOTAL_FILL } } } : {}),
        alignment: { horizontal: x.t === 'n' || (s.aoa && c > 1) ? 'center' : 'left', vertical: 'center' },
      };
    }
  }
  ws['!ref'] = XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: all.length - 1, c: width - 1 } });
  ws['!cols'] = wch.map((w) => ({ wch: w }));
  const rowsInfo: { hpt?: number }[] = [];
  rowsInfo[HDR] = { hpt: s.compact ? 22 : 30 };
  (ws as any)['!rows'] = rowsInfo;
  (ws as any)['!pageSetup'] = { orientation: 'landscape', paperSize: 9, fitToWidth: 1, fitToHeight: 0 };
  (ws as any)['!sheetPr'] = { pageSetUpPr: { fitToPage: true } };
  if (!s.aoa && s.rows.length && table[0].length) {
    ws['!autofilter'] = { ref: XLSX.utils.encode_range({ s: { r: HDR, c: 0 }, e: { r: all.length - 1, c: table[0].length - 1 } }) };
  }
  if (!s.company) dropFirstRow(ws);
  return ws;
}

function buildWorkbook(sheets: Sheet[]): XLSX.WorkBook {
  const wb = XLSX.utils.book_new();
  const used = new Set<string>();
  for (const s of sheets) XLSX.utils.book_append_sheet(wb, styledSheet(s), sheetName(s.name, used));
  wb.Workbook = { CalcPr: { fullCalcOnLoad: true } } as any; // Excel recalculates every formula when the file opens
  return wb;
}
/**
 * Creates a real Excel workbook (.xlsx: opens and edits in Microsoft Excel, LibreOffice, Google Sheets)
 * and downloads it (web) or opens the share sheet (phone).
 */
export async function shareXlsx(fileName: string, sheets: Sheet[]) {
  const data = XLSX.write(buildWorkbook(sheets), { type: 'array', bookType: 'xlsx' }) as ArrayBuffer;
  await saveXlsxData(fileName, data);
}

/** Downloads (web) or shares (phone) finished .xlsx bytes */
export async function saveXlsxData(fileName: string, data: ArrayBuffer) {

  if (Platform.OS === 'web') {
    const url = URL.createObjectURL(new Blob([data], { type: XLSX_MIME }));
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return;
  }

  try {
    const shareIt = async () => {
      const file = new File(Paths.cache, fileName);
      if (file.exists) file.delete();
      file.create();
      file.write(new Uint8Array(data));
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: XLSX_MIME, dialogTitle: fileName, UTI: 'org.openxmlformats.spreadsheetml.sheet' });
    };
    // Android: into the Download folder (file manager), with a Share button; otherwise the share sheet as before
    if (await saveToDownloads(fileName, new Uint8Array(data), XLSX_MIME)) { savedNotice(fileName, () => { void shareIt(); }); return; }
    await shareIt();
    return;
  } catch {
    /* fall through */
  }
  await Share.share({ title: fileName, message: 'Could not create the Excel file on this device. Open the web version to download it.' });
}
