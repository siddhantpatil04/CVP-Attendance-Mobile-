/**
 * Marathi / Hindi on the PHONE: jsPDF cannot join Devanagari letters, but the phone's WebView can. A hidden WebView (RasterHost)
 * draws each Marathi cell as a picture; the PDF code places that picture in the table cell (the same way as the web / desktop PDF).
 * Nothing here needs a new APK: react-native-webview is already in the app.
 */
export type RasterSeg = { t: string; b?: boolean };
export interface RasterJob { id: string; paras: RasterSeg[][]; widthMm: number }
export interface RasterResult { img: string; hMm: number }
type Runner = (jobs: RasterJob[]) => Promise<Record<string, RasterResult | null>>;

let runner: Runner | null = null;
export const setRasterRunner = (r: Runner | null) => { runner = r; };
export const rasterAvailable = () => runner != null;
/** Draws the jobs in the hidden WebView; an empty result means "not available" */
export async function rasterizeJobs(jobs: RasterJob[]): Promise<Record<string, RasterResult | null>> {
  if (!runner || jobs.length === 0) return {};
  return runner(jobs);
}

export const PX_PER_MM = 8;

/** The page the hidden WebView loads: draws text on a canvas with the phone's own Devanagari font and posts the PNG back */
export const RASTER_HTML = String.raw`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0"><canvas id="c" width="10" height="10"></canvas>
<script>
var PX = ${PX_PER_MM};
var FAM = '"Noto Sans Devanagari","Noto Sans","Noto Serif Devanagari","Nirmala UI","Mangal","Kohinoor Devanagari","Droid Sans",sans-serif';
function post(o) { window.ReactNativeWebView.postMessage(JSON.stringify(o)); }
function renderOne(job) {
  // a NEW canvas for every cell (software canvas): a reused / GPU canvas gave the same picture for every cell on some phones
  var c = document.createElement('canvas');
  c.width = 10; c.height = 10;
  var ctx = c.getContext('2d', { willReadFrequently: true });
  var px = Math.round(2.5 * PX);
  function fontOf(b) { return (b ? 'bold ' : '') + px + 'px ' + FAM; }
  var maxW = job.widthMm * PX;
  var lines = [];
  job.paras.forEach(function (para) {
    var line = []; var lw = 0;
    para.forEach(function (seg) {
      ctx.font = fontOf(seg.b);
      seg.t.split(/(\s+)/).forEach(function (w) {
        if (w === '') return;
        var ww = ctx.measureText(w).width;
        if (lw + ww > maxW && line.length && w.trim() !== '') { lines.push(line); line = []; lw = 0; }
        if (line.length === 0 && /^\s+$/.test(w)) return;
        line.push({ t: w, b: !!seg.b, w: ww }); lw += ww;
      });
    });
    lines.push(line);
  });
  var lh = Math.round(3.4 * PX);
  c.width = Math.max(1, Math.round(maxW)); c.height = Math.max(lh, lines.length * lh) + 4;
  var g = c.getContext('2d', { willReadFrequently: true });
  g.fillStyle = '#141414'; g.textBaseline = 'top';
  lines.forEach(function (ln, i) { var x = 0; ln.forEach(function (p) { g.font = fontOf(p.b); g.fillText(p.t, x, i * lh + 2); x += p.w; }); });
  return { id: job.id, img: c.toDataURL('image/png'), hMm: c.height / PX };
}
// one cell at a time, with a short pause between cells, so every picture is finished before it is read
window.renderJobs = function (jobs) {
  var i = 0;
  (function next() {
    if (i >= jobs.length) return;
    var j = jobs[i++];
    try { post(renderOne(j)); } catch (e) { post({ id: j.id, img: null, hMm: 0 }); }
    setTimeout(next, 25);
  })();
};
post({ ready: true });
</script></body></html>`;