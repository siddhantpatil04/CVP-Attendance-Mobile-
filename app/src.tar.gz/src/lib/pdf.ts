import { File, Paths } from 'expo-file-system';
import type { jsPDF as JsPdfType } from 'jspdf';
import * as Sharing from 'expo-sharing';
import { Platform, Share } from 'react-native';
import { COMPANY_NAME } from '../config';
import { savedNotice, saveToDownloads } from './saveDownload';

export interface PdfInput {
  title: string;
  subtitle: string;
  rows: Record<string, unknown>[];
  /** Free-form grid (same as the Excel sheet). Vertical merges (name / totals over the In and Out rows) become row spans. */
  aoa?: unknown[][];
  merges?: { s: { r: number; c: number }; e: { r: number; c: number } }[];
  /** A second section after `rows`: the day-wise In / Out grid of the whole month (printed on portrait pages) */
  grid?: { aoa: unknown[][]; merges?: { s: { r: number; c: number }; e: { r: number; c: number } }[] };
  /** Company Reports only: keeps the yellow "!! Shree !!" bar */
  company?: boolean;
}

/**
 * Hermes (the phone JS engine) only knows the utf-8 TextDecoder, but jsPDF asks for "latin1" the moment it loads
 * and crashed the whole app. This adds a tiny latin1 decoder before jsPDF is loaded.
 */
function ensureLatin1Decoder() {
  const g = globalThis as any;
  const Native = g.TextDecoder;
  if (!Native) return;
  try { new Native('latin1'); return; } catch { /* needs the shim */ }
  const LATIN = ['latin1', 'iso-8859-1', 'ascii', 'us-ascii', 'windows-1252'];
  g.TextDecoder = class {
    private inner: any; private latin: boolean;
    encoding: string;
    constructor(label: string = 'utf-8', opts?: unknown) {
      this.latin = LATIN.includes(String(label).toLowerCase());
      this.encoding = this.latin ? 'windows-1252' : 'utf-8';
      this.inner = this.latin ? null : new Native(label, opts);
    }
    decode(input?: any, o?: unknown) {
      if (!this.latin) return this.inner.decode(input, o);
      if (!input) return '';
      const u8 = ArrayBuffer.isView(input) ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength) : new Uint8Array(input);
      let s = '';
      for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode(...u8.subarray(i, i + 8192));
      return s;
    }
  };
}

/** jsPDF + the table plug-in are loaded only when a PDF is really requested */
export async function loadPdfLibs() {
  ensureLatin1Decoder();
  const [{ jsPDF }, auto] = await Promise.all([import('jspdf'), import('jspdf-autotable')]);
  return { jsPDF, autoTable: auto.default };
}
const AMBER: [number, number, number] = [255, 192, 0];
const cell = (v: unknown) => (v === null || v === undefined ? '' : String(v));

type Libs = Awaited<ReturnType<typeof loadPdfLibs>>;
type Doc = JsPdfType;

function pageHeader(doc: Doc, input: PdfInput, extra?: string): number {
  // the same heading as the Muster Roll (Form II): yellow "!! Shree !!" bar, company, report title, period
  const w = doc.internal.pageSize.getWidth();
  const o = input.company ? 0 : -7;   // Company Reports keep the Shree bar; every other report has no bar and starts higher
  doc.setTextColor(20, 20, 20); doc.setFont('helvetica', 'bold');
  if (input.company) {
    doc.setFillColor(255, 255, 0); doc.rect(8, 6, w - 16, 5, 'F');
    doc.setFontSize(9); doc.text('!! Shree !!', w / 2, 9.8, { align: 'center' });
  }
  doc.setFontSize(12); doc.text(COMPANY_NAME, w / 2, 17 + o, { align: 'center' });
  doc.setFontSize(10); doc.text(input.title, w / 2, 23 + o, { align: 'center' });
  doc.setFontSize(9); doc.text(`${input.subtitle}${extra ? '  |  ' + extra : ''}`, w / 2, 28.5 + o, { align: 'center' });
  return 33 + o;
}
/** List reports: header row + one row per record. Wide lists use a landscape page. */
function listPdf(input: PdfInput, { jsPDF, autoTable }: Libs): Doc {
  const head = Object.keys(input.rows[0] ?? {});
  const doc = new jsPDF({ orientation: head.length > 9 ? 'landscape' : 'portrait', unit: 'mm', format: 'a4' });
  const y = pageHeader(doc, input);
  autoTable(doc, {
    startY: y,
    head: [head],
    body: input.rows.map((r) => head.map((h) => cell(r[h]))),
    theme: 'grid',
    styles: { fontSize: head.length > 12 ? 6 : head.length > 8 ? 7 : 8, cellPadding: 1.6, overflow: 'linebreak', textColor: [20, 20, 20], lineColor: [60, 60, 60], lineWidth: 0.15 },
    headStyles: { fillColor: AMBER, textColor: [20, 20, 20], fontStyle: 'bold', halign: 'center', valign: 'middle' },
    margin: { left: 10, right: 10, top: 33 + (input.company ? 0 : -7), bottom: 12 },
    didDrawPage: () => { pageHeader(doc, input); },
  });
  return doc;
}

/**
 * Grid report (employees x dates, an In row and an Out row per employee), always portrait:
 * the dates are split across pages (14 per page) and the month totals go on the last page.
 */
function gridPdf(input: PdfInput, { jsPDF, autoTable }: Libs, into?: Doc): Doc {
  const aoa = input.aoa ?? [];
  // landscape: every date of the month and the month totals fit on ONE page width, the employees run down the page
  const doc = into ?? new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const spanCols = new Set((input.merges ?? []).filter((m) => m.s.c === m.e.c && m.e.r > m.s.r && m.s.c > 0).map((m) => m.s.c));
  const width = Math.max(...aoa.map((r) => r.length));
  const dateCols: number[] = []; const totalCols: number[] = [];
  for (let c = 2; c < width; c++) (spanCols.has(c) ? totalCols : dateCols).push(c);
  const chunks: number[][] = [dateCols];
  const body = aoa.slice(1);

  chunks.forEach((chunk) => {
    if (into) doc.addPage('a4', 'landscape');       // the grid starts on a new landscape page after the summary
    const cols = [0, 1, ...chunk, ...totalCols];
    const range = chunk.length ? `${cell(aoa[0][chunk[0]])} to ${cell(aoa[0][chunk[chunk.length - 1]])}` : '';
    const y = pageHeader(doc, input, range);
    const W = doc.internal.pageSize.getWidth();
    const nameW = 34; const inOutW = 7; const totW = 10.5;
    const dayW = Math.min(8, Math.max(4.2, (W - 16 - nameW - inOutW - totW * totalCols.length) / Math.max(1, chunk.length)));
    const colStyles: Record<number, object> = { 0: { halign: 'left', cellWidth: nameW }, 1: { cellWidth: inOutW } };
    cols.slice(2).forEach((_, k) => { colStyles[k + 2] = { cellWidth: k < chunk.length ? dayW : totW }; });
    const rows: any[][] = [];
    for (let i = 0; i + 1 < body.length; i += 2) {
      const a = body[i]; const b = body[i + 1];
      const row1: any[] = [{ content: cell(a[0]), rowSpan: 2, styles: { fontStyle: 'bold', valign: 'middle' } }, cell(a[1])];
      const row2: any[] = [cell(b[1])];
      cols.slice(2).forEach((c) => {
        if (spanCols.has(c)) row1.push({ content: cell(a[c]), rowSpan: 2, styles: { halign: 'center', valign: 'middle', fontStyle: 'bold' } });
        else { row1.push(cell(a[c])); row2.push(cell(b[c])); }
      });
      rows.push(row1, row2);
    }
    autoTable(doc, {
      startY: y,
      // dates are shown as the day number only (the month is in the page title)
      head: [cols.map((c) => (c === 0 ? 'Employee' : c === 1 ? '' : dateCols.includes(c) ? cell(aoa[0][c]).slice(0, 2) : cell(aoa[0][c])))],
      body: rows,
      theme: 'grid',
      styles: { fontSize: 5.2, cellPadding: 0.5, halign: 'center', overflow: 'linebreak', textColor: [20, 20, 20], lineColor: [60, 60, 60], lineWidth: 0.15 },
      headStyles: { fillColor: AMBER, textColor: [20, 20, 20], fontStyle: 'bold', fontSize: 5.2 },
      columnStyles: colStyles as any,
      margin: { left: 8, right: 8, top: 33 + (input.company ? 0 : -7), bottom: 12 },
      didDrawPage: () => { pageHeader(doc, input, range); },
    });
  });
  return doc;
}

/** Page numbers + generated date on every page */
function footers(doc: Doc) {
  const n = doc.getNumberOfPages();
  const w = doc.internal.pageSize.getWidth(); const h = doc.internal.pageSize.getHeight();
  const stamp = new Date().toLocaleDateString('en-GB');
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(140, 152, 166);
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.text(`Generated ${stamp}`, 10, h - 6);
    doc.text(`Page ${i} of ${n}`, w - 10, h - 6, { align: 'right' });
  }
}

/** Creates the PDF and downloads it (web) or opens the share sheet (phone). */
export async function sharePdf(fileName: string, input: PdfInput) {
  const libs = await loadPdfLibs();
  let doc: Doc;
  if (input.grid && input.rows.length) {
    // summary table first, then every day of the month
    doc = listPdf(input, libs);
    gridPdf({ ...input, title: `${input.title} - day-wise attendance (A = Absent, L = Leave, H = Holiday, WO = Week off)`, aoa: input.grid.aoa, merges: input.grid.merges }, libs, doc);
  } else {
    doc = input.aoa ? gridPdf(input, libs) : listPdf(input, libs);
  }
  footers(doc);
  await outputPdf(fileName, doc);
}

/** Downloads a finished jsPDF document (web) or opens the share sheet (phone). */
export async function outputPdf(fileName: string, doc: Doc) {
  const data = doc.output('arraybuffer');

  if (Platform.OS === 'web') {
    const url = URL.createObjectURL(new Blob([data], { type: 'application/pdf' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return;
  }

  try {
    const shareIt = async () => {
      const file = new File(Paths.cache, fileName);
      if (file.exists) file.delete();
      file.create();
      file.write(new Uint8Array(data));
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: 'application/pdf', dialogTitle: fileName, UTI: 'com.adobe.pdf' });
    };
    // Android: into the Download folder (file manager), with a Share button; otherwise the share sheet as before
    if (await saveToDownloads(fileName, new Uint8Array(data), 'application/pdf')) { savedNotice(fileName, () => { void shareIt(); }); return; }
    if (Platform.OS) { await shareIt(); return; }
  } catch {
    /* fall through */
  }
  await Share.share({ title: fileName, message: 'Could not create the PDF on this device. Open the web version to download it.' });
}
