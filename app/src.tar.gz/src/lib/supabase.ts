import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { AppState, Platform } from 'react-native';
import { SUPABASE_ANON_KEY, SUPABASE_URL } from '../config';

let client: SupabaseClient | null = null;

const REQUEST_TIMEOUT_MS = 40000; // photo uploads are the slowest calls
const fetchWithTimeout: typeof fetch = (input, init) => {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), REQUEST_TIMEOUT_MS);
  init?.signal?.addEventListener?.('abort', () => ctl.abort());
  return fetch(input, { ...init, signal: ctl.signal })
    .catch((e) => { throw ctl.signal.aborted && !init?.signal?.aborted ? new Error('The network is too slow. Please try again.') : e; })
    .finally(() => clearTimeout(timer));
};

function getClient(): SupabaseClient {
  if (!client) {
    client = createClient(
      SUPABASE_URL || 'https://not-configured.supabase.co',
      SUPABASE_ANON_KEY || 'not-configured',
      {
        auth: {
          storage: AsyncStorage,
          autoRefreshToken: true,
          persistSession: true,
          detectSessionInUrl: false,
        },
        realtime: { params: { eventsPerSecond: 10 } },
        // A request on a weak mobile network must fail after a while instead of leaving a spinner forever
        global: { fetch: fetchWithTimeout },
      },
    );
  }
  return client;
}

/** Forget the connection so the next call uses the new server address (after Server settings changed) */
export function resetSupabase() {
  client?.removeAllChannels().catch(() => {});
  client = null;
}

// The client is created on first use (after the server address was loaded), but is used like a normal client everywhere.
export const supabase: SupabaseClient = new Proxy({} as SupabaseClient, {
  get(_t, prop) {
    const c = getClient() as any;
    const v = c[prop];
    return typeof v === 'function' ? v.bind(c) : v;
  },
});
// Keep the login token fresh only while the app is in the foreground
if (Platform.OS !== 'web') {
  AppState.addEventListener('change', (state) => {
    if (state === 'active') supabase.auth.startAutoRefresh();
    else supabase.auth.stopAutoRefresh();
  });
}

/** Turns any Supabase / network error into a readable sentence */
export function errorText(e: unknown): string {
  if (!e) return 'Something went wrong';
  if (typeof e === 'string') return e;
  const anyE = e as { message?: string; error_description?: string; context?: unknown };
  const msg = anyE.message || anyE.error_description || 'Something went wrong';
  if (/Failed to fetch|Network request failed/i.test(msg)) return 'No internet connection. Please try again.';
  if (/Invalid login credentials/i.test(msg)) return 'Invalid username or password.';
  if (/JWT expired/i.test(msg)) return 'Session expired. Please sign in again.';
  return msg;
}
