import { api, MonthSummaryRow } from './api';
import { bankPaymentPdf, bankPaymentXlsx, BankPayMeta, BankPayRow } from './bankPaymentReport';
import { fmtMinutes, fmtTime12, hhmmTo12, istDateISO, istParts, MONTHS } from './time';
import { wageRow, WageRow, wageTotals } from './wages';
import { styledTablePdf, wagesRegisterPdf } from './wagesRegisterPdf';
import { styledTableXlsx, wagesRegisterXlsx } from './styledXlsx';
import * as XLSX from 'xlsx-js-style';
import { Sheet } from './xlsx';

type Row = Record<string, unknown>;
export interface ReportResult {
  file: string;
  rows: Row[];
  aoa?: unknown[][];
  merges?: { s: { r: number; c: number }; e: { r: number; c: number } }[];
  /** Day-wise In / Out grid of the whole month, added after `rows` (second Excel sheet / extra PDF pages) */
  grid?: { aoa: unknown[][]; merges: { s: { r: number; c: number }; e: { r: number; c: number } }[] };
  /** A report with its own PDF layout (e.g. the Form II wages register) */
  custom?: { pdf?: (fileName: string) => Promise<void>; xlsx?: (fileName: string) => Promise<void> };
  /** Excel formulas for the main sheet and for the day-wise grid sheet (see Sheet.calc in xlsx.ts) */
  calc?: Sheet['calc'];
  gridCalc?: Sheet['calc'];
}
export interface ReportCtx { year: number; month: number; summary: MonthSummaryRow[]; cache?: Map<string, unknown>; user?: string }
export interface ReportDef {
  id: string;
  group: 'Attendance' | 'Leave' | 'Field & Site' | 'Employees & Company' | 'Salary & Bank';
  /** Financial-year report (April to March) that contains the chosen month */
  fy?: boolean;
  title: string;
  icon: string;
  /** Month-based reports follow the month picker; the others ignore it */
  scope: 'month' | 'year' | 'all';
  adminOnly?: boolean;
  /** Not in Company Reports: downloaded for one employee from Employees -> that employee -> Reports */
  perEmployee?: boolean;
  build: (c: ReportCtx) => Promise<ReportResult>;
}

const mm = (c: ReportCtx) => String(c.month).padStart(2, '0');
const range = (c: ReportCtx) => {
  const last = new Date(c.year, c.month, 0).getDate();
  return { from: `${c.year}-${mm(c)}-01`, to: `${c.year}-${mm(c)}-${String(last).padStart(2, '0')}` };
};
const tag = (c: ReportCtx) => `${c.year}_${mm(c)}`;

/** Every active employee's day list for the month (loaded in parallel batches) */
async function monthDays(c: ReportCtx) {
  const hit = c.cache?.get('days') as Awaited<ReturnType<typeof loadDays>> | undefined;
  if (hit) return hit;
  const res = await loadDays(c);
  c.cache?.set('days', res);
  return res;
}

async function loadDays(c: ReportCtx) {
  const out: { r: MonthSummaryRow; days: Awaited<ReturnType<typeof api.monthAttendance>> }[] = [];
  for (let i = 0; i < c.summary.length; i += 8) {
    const part = c.summary.slice(i, i + 8);
    const got = await Promise.all(part.map((r) => api.monthAttendance(c.year, c.month, r.user_id)));
    part.forEach((r, k) => out.push({ r, days: got[k] }));
  }
  return out;
}

const CODE: Record<string, string> = {
  Present: 'P', 'Checked In': 'P', Absent: 'A', Leave: 'L', Holiday: 'H', 'Rest Day': 'WO', Upcoming: '',
};

type Merge = { s: { r: number; c: number }; e: { r: number; c: number } };
const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;
const t12 = (v: string | null | undefined) => (v ? hhmmTo12(v).replace(/ [AP]M$/, '') : '');

/** All dates of the month as ISO strings */
function monthDates(c: ReportCtx): string[] {
  const last = new Date(c.year, c.month, 0).getDate();
  return Array.from({ length: last }, (_, i) => `${c.year}-${mm(c)}-${String(i + 1).padStart(2, '0')}`);
}

/**
 * The In / Out layout used by every attendance report: employee names down the side,
 * dates across the top, an "In" row and an "Out" row per employee, totals at the end of the row.
 */
function inOutGrid(
  dates: string[],
  people: { id: string; name: string; left?: string | null }[],
  pick: (id: string, iso: string) => { inn: string; out: string },
  totalHead: string[],
  totals: (id: string) => unknown[],
): { aoa: unknown[][]; merges: Merge[] } {
  if (!people.length) return { aoa: [], merges: [] };
  const aoa: unknown[][] = [['Employee Name', '', ...dates.map(dmy), ...totalHead]];
  const merges: Merge[] = [];
  people.forEach((p) => {
    const inRow: unknown[] = [p.name, 'In'];
    const outRow: unknown[] = ['', 'Out'];
    // days after the leaving date of a resigned employee show "-"
    dates.forEach((iso) => { const x = p.left && iso > p.left ? { inn: '-', out: '' } : pick(p.id, iso); inRow.push(x.inn); outRow.push(x.out); });
    const tot = totals(p.id);
    inRow.push(...tot);
    outRow.push(...tot.map(() => ''));
    const r0 = aoa.length;
    merges.push({ s: { r: r0, c: 0 }, e: { r: r0 + 1, c: 0 } });
    for (let k = 0; k < tot.length; k++) merges.push({ s: { r: r0, c: inRow.length - tot.length + k }, e: { r: r0 + 1, c: inRow.length - tot.length + k } });
    aoa.push(inRow, outRow);
  });
  return { aoa, merges };
}

type GridKind = 'present' | 'absent' | 'leave' | 'late' | 'holiday' | 'days' | null;

/**
 * Formulas for the total columns of an In / Out grid: they count the A / L / H codes and the times of the "In" row,
 * so changing a day in the sheet updates Present, Absent, Leave ... straight away. null = keep the value.
 */
function gridCalc(nDates: number, kinds: GridKind[]): Sheet['calc'] {
  const first = 2; const last = first + nDates - 1;
  return (r, c, xr) => {
    if (r % 2 !== 1 || c <= last) return null; // only the "In" row of each employee (the total cells are merged over both rows)
    const kind = kinds[c - last - 1];
    if (!kind) return null;
    const x = xr(r);
    const rng = `${XLSX.utils.encode_col(first)}${x}:${XLSX.utils.encode_col(last)}${x}`;
    const filled = `SUMPRODUCT(--(LEN(${rng})>0))-COUNTIF(${rng},"-")`;   // "-" = days after the employee resigned
    const code = (k: string) => `COUNTIF(${rng},"${k}")`;
    switch (kind) {
      case 'present': return `${filled}-${code('L')}-${code('H')}-${code('WO')}`;
      case 'absent': return null;   // an absent day has no letter in the sheet, so the Absent total keeps its calculated value
      case 'leave': return code('L');
      case 'holiday': return code('H');
      case 'late': return `COUNTIF(${rng},"*~*")`;
      case 'days': return filled;
    }
  };
}

const RAW: ReportDef[] = [
  // ------------------------------------------------------------ Attendance
  {
    id: 'monthly', group: 'Attendance', icon: 'calendar-outline', scope: 'month',
    title: 'Monthly Attendance (Name, In, Out)',
    build: async (c) => {
      const data = await monthDays(c);
      const code: Record<string, string> = { Leave: 'L', Holiday: 'H', 'Rest Day': 'WO' };
      const byId = new Map(data.map((d) => [d.r.user_id, d]));
      const otMin = new Map<string, number>();
      (await api.overtimeDays(c.year, c.month)).forEach((o) => otMin.set(o.user_id, (otMin.get(o.user_id) ?? 0) + o.ot_minutes));
      const g = inOutGrid(
        monthDates(c), data.map((d) => ({ id: d.r.user_id, name: d.r.full_name, left: d.r.left_on })),
        (id, iso) => {
          const d = byId.get(id)?.days.find((x) => x.day === iso);
          if (!d) return { inn: '', out: '' };
          if (d.in_time || d.out_time) return { inn: t12(d.in_time), out: t12(d.out_time) };
          return { inn: code[d.status] ?? '', out: '' };
        },
        ['Present', 'Absent', 'Leave', 'Holidays', 'Total Hours', 'Overtime Hours'],
        (id) => {
          const r = byId.get(id)!.r;
          return [r.present, r.absent, r.on_leave, r.holidays, Number(Number(r.hours).toFixed(2)), Number(((otMin.get(id) ?? 0) / 60).toFixed(2))];
        },
      );
      return { file: `cvp_monthly_attendance_${tag(c)}.xlsx`, rows: [], ...g, calc: gridCalc(monthDates(c).length, ['present', 'absent', 'leave', 'holiday', null, null]) };
    },
  },
  {
    id: 'hours_ot', group: 'Attendance', icon: 'hourglass-outline', scope: 'month',
    title: 'Working Hours and Overtime Report',
    build: async (c) => {
      // One row per employee per day. Hours are after the unpaid break; 8 hours is the standard day, the rest is overtime.
      const { from, to } = range(c);
      const list = await api.workingHoursReport(from, to);
      const h = (m: number | null) => (m === null || m === undefined ? '' : Number((m / 60).toFixed(2)));
      const tm = (v: string | null) => (v ? hhmmTo12(v) : '');
      const names = new Map(c.summary.map((s) => [s.user_id, s.full_name])); // "(Resigned ...)" for people who have left
      const rows: Row[] = list.map((r) => ({
        'Employee Name': names.get(r.user_id) ?? r.full_name, 'Site Name': r.site_name, Date: r.work_date,
        'Check-In Time': tm(r.check_in), 'Check-Out Time': tm(r.check_out),
        'Total Working Hours': h(r.total_minutes), 'Regular Hours': h(r.regular_minutes), 'Overtime Hours': h(r.overtime_minutes),
      }));
      if (rows.length) {
        const sum = (k: string) => Number(rows.reduce((a, x) => a + Number(x[k] || 0), 0).toFixed(2));
        rows.push({
          'Employee Name': 'TOTAL', 'Site Name': '', Date: '', 'Check-In Time': '', 'Check-Out Time': '',
          'Total Working Hours': sum('Total Working Hours'), 'Regular Hours': sum('Regular Hours'), 'Overtime Hours': sum('Overtime Hours'),
        });
      }
      return { file: `cvp_working_hours_overtime_${tag(c)}.xlsx`, rows };
    },
  },  {
    id: 'payroll', group: 'Employees & Company', icon: 'cash-outline', scope: 'month', adminOnly: true,
    title: 'Salary Report (Admin only)',
    build: async (c) => {
      // Salary after all leave rules: paid leave (monthly limit), unpaid leave, absent days, days before joining; overtime pay added at the end
      const list = await api.payroll(c.year, c.month);
      const money = (n: number) => Number(Number(n).toFixed(2));
      // Day-wise attendance of the same people for EVERY date of the month (In / Out times, A / L / H / WO codes)
      const data = await monthDays(c);
      const byId = new Map(data.map((d) => [d.r.user_id, d]));
      const payById = new Map(list.map((p) => [p.user_id, p]));
      const dayCode: Record<string, string> = { Leave: 'L', Holiday: 'H', 'Rest Day': 'WO' };
      const grid = inOutGrid(
        monthDates(c), list.map((p) => ({ id: p.user_id, name: p.full_name, left: p.left_on })),
        (id, iso) => {
          const d = byId.get(id)?.days.find((x) => x.day === iso);
          if (!d) return { inn: '', out: '' };
          if (d.in_time || d.out_time) return { inn: t12(d.in_time), out: t12(d.out_time) };
          return { inn: dayCode[d.status] ?? '', out: '' };
        },
        ['Present', 'Absent', 'Leave', 'Payable Days'],
        (id) => { const p = payById.get(id)!; return [p.present, p.absent, p.leave_days, p.payable_days]; },
      );
      // An employee who has left stays in the sheet: every figure is "-" from the month after the leaving month
      const gone = (p: (typeof list)[number]) => !!p.left_on && p.left_on.slice(0, 7) < `${c.year}-${mm(c)}`;
      // Salary history (Basic, current salary after the increments and when the last increment started), added at the END of every row
      // so the Excel formula columns keep their letters. "Monthly Salary" is the salary of each day of the month averaged:
      // an increment that starts mid-month is paid from its effective date.
      const hist = new Map((await api.salaryOverview().catch(() => ({ rows: [] }))).rows.map((o) => [o.user_id, o]));
      const sixMonths = (iso: string | null | undefined) => {
        if (!iso) return 'Joining date missing';
        const d = new Date(iso + 'T12:00:00');
        d.setMonth(d.getMonth() + 6);
        return d.toISOString().slice(0, 10);
      };
      const hx = (id: string) => {
        const o = hist.get(id);
        return {
          'Paid Leave From (after 6 months)': sixMonths(o?.joining_date),
          'Basic Salary': o?.basic ?? '', 'Current Salary (after increments)': o?.current_salary ?? '',
          'Last Increment From': o && o.increments > 0 ? (o.current_from ?? '') : '',
        };
      };
      const rows: Row[] = list.map((p) => gone(p) ? {
        'Employee Name': p.full_name, Department: p.department ?? '',
        'Monthly Salary': '-', 'Days in Month': '-', 'Per Day Salary': '-', Present: '-', Absent: '-',
        'Leave Taken': '-', 'Monthly Paid Leave': '-', 'Unpaid Leave': '-', 'Before Joining': '-', 'Unpaid Days': '-', 'Payable Days': '-',
        Deduction: '-', 'Overtime Pay': '-', 'Final Salary': '-', ...hx(p.user_id),
      } : {
        'Employee Name': p.full_name, Department: p.department ?? '',
        'Monthly Salary': money(p.monthly_salary), 'Days in Month': p.days_in_month,
        'Per Day Salary': money(p.days_in_month ? Number(p.monthly_salary) / p.days_in_month : 0),
        Present: p.present, Absent: p.absent,
        'Leave Taken': p.leave_days, 'Monthly Paid Leave': p.paid_leave, 'Unpaid Leave': p.unpaid_leave, 'Before Joining': p.not_joined,
        'Unpaid Days': p.unpaid_days, 'Payable Days': p.payable_days,
        Deduction: money(p.deduction), 'Overtime Pay': money(p.overtime_pay), 'Final Salary': money(p.net_salary), ...hx(p.user_id),
      });
      if (rows.length) {
        const sum = (k: string) => money(rows.reduce((a, x) => a + (typeof x[k] === 'number' ? (x[k] as number) : 0), 0));
        rows.push({
          'Employee Name': 'TOTAL', Department: '', 'Monthly Salary': sum('Monthly Salary'), 'Days in Month': '', 'Per Day Salary': '',
          Present: '', Absent: '', 'Leave Taken': '', 'Monthly Paid Leave': '', 'Unpaid Leave': '', 'Before Joining': '', 'Unpaid Days': '', 'Payable Days': '',
          Deduction: sum('Deduction'), 'Overtime Pay': sum('Overtime Pay'), 'Final Salary': sum('Final Salary'),
          'Basic Salary': '', 'Current Salary (after increments)': '', 'Last Increment From': '', 'Paid Leave From (after 6 months)': '',
        });
      }
      // Columns: C salary, D days in month, E per day, G absent, H leave taken, I paid leave, J unpaid leave, K before joining,
      // L unpaid days, M payable days, N deduction, O overtime pay, P final salary (same rules as the salary calculation)
      const calc: Sheet['calc'] = (r, col, xr, table) => {
        if (table[r][2] === '-') return null;   // resigned: nothing to calculate
        const x = xr(r);
        switch (col) {
          case 4: return `ROUND(C${x}/D${x},2)`;
          case 9: return `H${x}-I${x}`;
          case 11: return `MIN(D${x},G${x}+J${x}+K${x})`;
          case 12: return `D${x}-L${x}`;
          case 13: return `ROUND(C${x}/D${x}*L${x},2)`;
          case 15: return `ROUND(C${x}-N${x}+O${x},2)`;
          default: return null;
        }
      };
      return {
        grid: { ...grid }, calc, gridCalc: gridCalc(monthDates(c).length, ['present', 'absent', 'leave', null]),
        file: `cvp_salary_${tag(c)}.xlsx`,
        rows,
      };
    },
  },
  {
    id: 'leave_deduction', group: 'Employees & Company', icon: 'remove-circle-outline', scope: 'month', adminOnly: true,
    title: 'Leave Deduction (Admin only)',
    build: async (c) => {
      // Per-day salary = monthly salary / days in the month.  Unpaid days = absent + unpaid leave + days before joining + unpaid holidays.
      // Deduction = per-day salary x unpaid days (whole rupees).
      const list = await api.payroll(c.year, c.month);
      const rows: Row[] = list.map((p) => {
        const perDay = p.days_in_month ? Number(p.monthly_salary) / p.days_in_month : 0;
        const uh = p.unpaid_holiday ?? 0;
        return {
          'Employee Name': p.full_name, 'Employee ID': p.username, 'Monthly Salary': Math.round(Number(p.monthly_salary)),
          'Days in Month': p.days_in_month, 'Per Day Salary': Number(perDay.toFixed(2)),
          Absent: p.absent, 'Unpaid Leave': p.unpaid_leave, 'Before Joining': p.not_joined, 'Unpaid Holidays': uh,
          'Unpaid Days': p.unpaid_days, Deduction: Math.round(Number(p.deduction)),
          'Salary After Deduction': Math.round(Number(p.monthly_salary) - Number(p.deduction)),
        };
      });
      if (rows.length) {
        const sum = (k: string) => rows.reduce((a, x) => a + Number(x[k] || 0), 0);
        rows.push({ 'Employee Name': 'TOTAL', 'Employee ID': '', 'Monthly Salary': sum('Monthly Salary'), 'Days in Month': '', 'Per Day Salary': '', Absent: '',
          'Unpaid Leave': '', 'Before Joining': '', 'Unpaid Holidays': '', 'Unpaid Days': '', Deduction: sum('Deduction'), 'Salary After Deduction': sum('Salary After Deduction') });
        rows.push({ 'Employee Name': 'Formula: per-day salary = monthly salary / days in the month; unpaid days = absent + unpaid leave + days before joining + unpaid holidays; deduction = per-day salary x unpaid days.' });
      }
      return { file: `cvp_leave_deduction_${tag(c)}.xlsx`, rows };
    },
  },  {
    id: 'detailed', group: 'Attendance', icon: 'document-text-outline', scope: 'month', perEmployee: true,
    title: 'Detailed Day-wise Report',
    build: async (c) => {
      // In / Out layout (no fixed times, so nobody is marked late). Joining date is added at the end of the row.
      const { from, to } = range(c);
      const joined = new Map((await api.allProfiles()).map((p) => [p.id, p.joining_date ?? '']));
      const data = await monthDays(c);
      const byId = new Map(data.map((d) => [d.r.user_id, d]));
      const code: Record<string, string> = { Leave: 'L', Holiday: 'H', 'Rest Day': 'WO' };
      const g = inOutGrid(
        monthDates(c), data.map((d) => ({ id: d.r.user_id, name: d.r.full_name, left: d.r.left_on })),
        (id, iso) => {
          const d = byId.get(id)?.days.find((x) => x.day === iso);
          if (!d) return { inn: '', out: '' };
          if (d.in_time || d.out_time) return { inn: t12(d.in_time), out: t12(d.out_time) };
          return { inn: code[d.status] ?? '', out: '' };
        },
        ['Joined', 'Present', 'Absent', 'Leave', 'Hours'],
        (id) => {
          const r = byId.get(id)!.r;
          return [joined.get(id) ? dmy(joined.get(id)!) : '', r.present, r.absent, r.on_leave, Number(Number(r.hours).toFixed(2))];
        },
      );
      return { file: `cvp_report_${tag(c)}.xlsx`, rows: [], ...g, calc: gridCalc(monthDates(c).length, [null, 'present', 'absent', 'leave', null, null]) };
    },
  },
  // ------------------------------------------------------------ Leave
  {
    id: 'leaves', group: 'Leave', icon: 'airplane-outline', scope: 'month', perEmployee: true,
    title: 'Leave Register',
    build: async (c) => {
      const { from, to } = range(c);
      const list = (await api.leavesBetween(from, to)).filter((l) => !c.user || l.user_id === c.user);
      return {
        file: `cvp_leave_register_${tag(c)}.xlsx`,
        rows: list.map((l) => ({
          'Employee Name': l.employee?.full_name, Department: l.employee?.department ?? '',
          'Leave Type': l.leave_type, From: l.from_day, To: l.to_day, Days: l.days, Reason: l.reason,
          Status: l.status, 'Reviewer Note': l.review_note ?? '', Applied: istDateISO(l.created_at),
        })),
      };
    },
  },
  {
    id: 'balance', group: 'Leave', icon: 'wallet-outline', scope: 'year',
    title: 'Yearly Leaves (granted, used, balance)',
    build: async (c) => {
      const rows: Row[] = [];
      for (let i = 0; i < c.summary.length; i += 8) {
        const part = c.summary.slice(i, i + 8);
        const got = await Promise.all(part.map((r) => api.leaveBalance(c.year, r.user_id)));
        part.forEach((r, k) => {
          const row: Row = { 'Employee Name': r.full_name, Department: r.department ?? '' };
          got[k].forEach((b) => {
            row[`${b.leave_type} - Granted`] = b.granted;
            row[`${b.leave_type} - Used`] = b.used;
            row[`${b.leave_type} - Balance`] = b.counts_balance ? b.balance : '';
          });
          rows.push(row);
        });
      }
      // Balance = Granted - Used (only for the leave types that keep a balance)
      const calc: Sheet['calc'] = (r, col, xr, table) => {
        if (!String(table[0][col]).endsWith('- Balance') || table[r][col] === '') return null;
        const x = xr(r);
        return `${XLSX.utils.encode_col(col - 2)}${x}-${XLSX.utils.encode_col(col - 1)}${x}`;
      };
      return { file: `cvp_yearly_leaves_${c.year}.xlsx`, rows, calc };
    },
  },  {
    id: 'regs', group: 'Leave', icon: 'create-outline', scope: 'month',
    title: 'Attendance Corrections',
    build: async (c) => {
      const { from, to } = range(c);
      const list = await api.regularizationsBetween(from, to);
      return {
        file: `cvp_corrections_${tag(c)}.xlsx`,
        rows: list.map((g) => ({
          'Employee Name': g.employee?.full_name, Date: g.day,
          'Requested In': hhmmTo12(g.requested_in), 'Requested Out': hhmmTo12(g.requested_out),
          Reason: g.reason, Status: g.status, 'Reviewer Note': g.review_note ?? '',
        })),
      };
    },
  },

  // ------------------------------------------------------------ Employees & Company
  {
    id: 'employees', group: 'Employees & Company', icon: 'people-outline', scope: 'all',
    title: 'Employee List',
    build: async () => {
      const ord = ['', '1st', '2nd', '3rd', '4th', '5th'];
      const list = await api.allProfiles();
      return {
        file: `cvp_employees_${istDateISO()}.xlsx`,
        rows: list.map((p) => ({
          'Employee Name': p.full_name, Role: p.role, Department: p.department ?? '', Phone: p.phone ?? '',
          'Joining Date': p.joining_date ?? '',
          'Saturdays Off': (p.saturday_off ?? []).map((n) => ord[n]).join(' '), 'Site Employee': p.site_employee ? 'Yes' : 'No',
          Status: p.active ? 'Active' : 'Inactive',
        })),
      };
    },
  },
  {
    id: 'holidays', group: 'Employees & Company', icon: 'sunny-outline', scope: 'year',
    title: 'Holiday List (year)',
    build: async (c) => ({
      file: `cvp_holidays_${c.year}.xlsx`,
      rows: (await api.holidays(c.year)).map((h) => ({ Date: h.day, Holiday: h.name, Type: h.kind, Month: MONTHS[Number(h.day.slice(5, 7)) - 1] })),
    }),
  },
];

// ------------------------------------------------------------ Salary & Bank
/** Financial year (April to March) that contains the chosen month; only the months up to today are listed */
function fyInfo(c: { year: number; month: number }) {
  const start = c.month >= 4 ? c.year : c.year - 1;
  const now = istParts();
  const months: { y: number; m: number }[] = [];
  for (let i = 0; i < 12; i++) {
    const idx = 3 + i;
    const y = start + Math.floor(idx / 12); const m = (idx % 12) + 1;
    if (y > now.year || (y === now.year && m > now.month)) break;
    months.push({ y, m });
  }
  return { start, months };
}
const fyLabel = (c: { year: number; month: number }) => { const s = fyInfo(c).start; return `FY ${s}-${String(s + 1).slice(2)} (April ${s} to March ${s + 1})`; };
const monthHead = (y: number, m: number) => `${MONTHS[m - 1].slice(0, 3)} ${y}`;

/** Joining dates, UAN, gender and bank details of everyone */
async function people() {
  const [prof, det] = await Promise.all([api.allProfiles(), api.detailsForReports()]);
  return { prof: new Map(prof.map((p) => [p.id, p])), det: new Map(det.map((d) => [d.user_id, d])) };
}
type People = Awaited<ReturnType<typeof people>>;

/** One month's wage rows (people with a salary only) */
async function monthWages(y: number, m: number, ppl: People): Promise<WageRow[]> {
  const list = await api.payroll(y, m);
  // people who have left keep their row (salary "-" from the month after leaving)
  return list.filter((p) => Number(p.monthly_salary) > 0 || p.left_on).map((p) => wageRow(p, m, {
    joining: ppl.prof.get(p.user_id)?.joining_date, resigned: p.left_on ?? ppl.det.get(p.user_id)?.resign_date, uan: ppl.det.get(p.user_id)?.uan_no, gender: ppl.det.get(p.user_id)?.gender,
  }));
}
const bankOf = (ppl: People, id: string) => {
  const d = ppl.det.get(id);
  return { 'Bank Name': d?.bank_name ?? '', Branch: d?.bank_branch ?? '', 'Account No': d?.bank_account_no ?? '', 'IFSC Code': d?.ifsc_code ?? '' };
};

/** Styled, editable Excel of a flat report: the TOTAL row is rebuilt as SUM formulas */
function tableCustom(sheet: string, title: string, subtitle: string, rows: Row[], sumFrom: number, rowSum?: { col: number; from: number; to: number }) {
  const data = rows.filter((r) => r['Employee Name'] !== 'TOTAL');
  const head = Object.keys(rows[0] ?? {});
  const body = data.map((r) => head.map((h) => (r[h] ?? '') as string | number));
  return {
    xlsx: (name: string) => styledTableXlsx(name, sheet, title, subtitle, head, body, { sumFrom, rowSum }),
    pdf: (name: string) => styledTablePdf(name, title, subtitle, head, body, { sumFrom, company: true }),
  };
}

/** Fixed details printed on the bank's bulk payment sheet */
const BANK_PAY = { company: 'C V Patil & Associates', debitAccount: '239305500264', product: 'PAB_VENDOR', email: 'patilcvoffice@gmail.com' };

const SALARY: ReportDef[] = [
  {
    id: 'bank_payment', group: 'Salary & Bank', icon: 'business-outline', scope: 'month', adminOnly: true,
    title: 'Salary Payment Report (bank bulk payment)',
    build: async (c) => {
      // Same layout as the Bank Yearly Salary Statement: employee, bank details and the net salary of the month, with a TOTAL row
      const ppl = await people();
      const head = `Net Salary ${monthHead(c.year, c.month)}`;
      const list = (await monthWages(c.year, c.month, ppl)).sort((a, b) => a.name.localeCompare(b.name));
      const rows: Row[] = list.map((w) => ({ 'Employee Name': w.name, ...bankOf(ppl, w.userId), [head]: w.net }));
      if (rows.length) {
        rows.push({ 'Employee Name': 'TOTAL', 'Bank Name': '', Branch: '', 'Account No': '', 'IFSC Code': '', [head]: rows.reduce((a, r) => a + Number(r[head] || 0), 0) });
      }
      return {
        file: `cvp_salary_payment_${tag(c)}.xlsx`, rows,
        custom: tableCustom('Salary Payment', 'Salary Payment Report (bank bulk payment)', `${MONTHS[c.month - 1]} ${c.year}`, rows, 5),
      };
    },
  },  {
    id: 'bank_upload', group: 'Salary & Bank', icon: 'business-outline', scope: 'month', adminOnly: true,
    title: 'Bank Upload File (bulk payment format)',
    build: async (c) => {
      const ppl = await people();
      const list = await monthWages(c.year, c.month, ppl);
      const rows: BankPayRow[] = list.map((w) => {
        const d = ppl.det.get(w.userId);
        const ifsc = (d?.ifsc_code ?? '').toUpperCase();
        const mobile = (d?.cell_no || ppl.prof.get(w.userId)?.phone || '').replace(/\D/g, '').slice(-10);
        return {
          name: w.name, mode: ifsc.startsWith('ICIC') ? 'FT' : 'NEFT', account: d?.bank_account_no ?? '', ifsc,
          amount: w.net, mobile, email: BANK_PAY.email,
        };
      });
      const meta: BankPayMeta = { company: BANK_PAY.company, paymentDate: dmy(istDateISO()), debitAccount: BANK_PAY.debitAccount, product: BANK_PAY.product };
      const flat: Row[] = rows.map((r, i) => ({
        Sr: i + 1, 'Beneficiary name': r.name, Mode: r.mode, 'Beneficiary A/c No': r.account, IFSC: r.ifsc,
        'Amount (Rs.)': r.amount, Mobile: r.mobile, Email: r.email,
      }));
      return {
        file: `cvp_bank_upload_${tag(c)}.xlsx`, rows: flat,
        custom: {
          pdf: (name: string) => bankPaymentPdf(name, meta, rows),
          xlsx: (name: string) => bankPaymentXlsx(name, meta, rows),
        },
      };
    },
  },
  {
    id: 'bank_year', group: 'Salary & Bank', icon: 'card-outline', scope: 'year', fy: true, adminOnly: true,
    title: 'Bank Yearly Salary Statement - all employees',
    build: async (c) => {
      const { start, months } = fyInfo(c);
      const ppl = await people();
      const per = new Map<string, { name: string; net: Record<string, number> }>();
      for (const { y, m } of months) {
        for (const w of await monthWages(y, m, ppl)) {
          const e = per.get(w.userId) ?? { name: w.name, net: {} };
          e.net[monthHead(y, m)] = w.net;
          per.set(w.userId, e);
        }
      }
      const rows: Row[] = [...per.entries()].sort((a, b) => a[1].name.localeCompare(b[1].name)).map(([id, e]) => {
        const o: Row = { 'Employee Name': e.name, ...bankOf(ppl, id) };
        months.forEach(({ y, m }) => { o[monthHead(y, m)] = e.net[monthHead(y, m)] ?? 0; });
        o['Total Net Salary'] = Object.values(e.net).reduce((a, b) => a + b, 0);
        return o;
      });
      if (rows.length) {
        const t: Row = { 'Employee Name': 'TOTAL', 'Bank Name': '', Branch: '', 'Account No': '', 'IFSC Code': '' };
        Object.keys(rows[0]).slice(5).forEach((k) => { t[k] = rows.reduce((a, r) => a + Number(r[k] || 0), 0); });
        rows.push(t);
      }
      return {
        file: `cvp_bank_yearly_salary_FY${start}_${String(start + 1).slice(2)}.xlsx`, rows,
        custom: tableCustom('Bank Yearly Salary', 'Bank Yearly Salary Statement - all employees', fyLabel(c), rows, 5,
          { col: 5 + months.length, from: 5, to: 4 + months.length }),
      };
    },
  },
  {
    id: 'wages_register', group: 'Salary & Bank', icon: 'document-text-outline', scope: 'month', adminOnly: true,
    title: 'Muster Roll cum Wages Register - Form II (month)',
    build: async (c) => {
      const ppl = await people();
      const rows = await monthWages(c.year, c.month, ppl);
      const total = wageTotals(rows);
      const flat = (r: WageRow, i: number | string) => ({
        'Sr. No.': i, 'Date of Joining': r.joining, 'Date of Resignation': r.resigned, 'UAN No.': r.uan, 'Full Name of the Employees': r.name, 'Male/Female': r.gender,
        'Gross Wages': r.gross, 'Total Days Present': r.daysPresent, 'Total Days': r.daysInMonth || '',
        'Basic @ 50%': r.basic, 'HRA @ 40%': r.hra, 'Other Allowances': r.other, 'Total Gross Wages': r.totalGross,
        'PF Employee': r.pfEmployee, PT: r.pt, 'ESIC Employee': r.esicEmployee, 'PF Employer': r.pfEmployer, 'ESIC Employer': r.esicEmployer,
        Advance: r.advance, 'Total Deduct': r.totalDeduct, 'Net Wages Paid': r.net,
        'PF Member (Y/N)': r.pfMember, 'EPS Eligible (Y/N)': r.epsEligible, 'PF Wages (EPF/EDLI wages)': r.pfWages, 'EPS Wages': r.epsWages,
        'Employer EPS 8.33%': r.employerEps, 'Employer EPF 3.67% (diff)': r.employerEpf, 'Employer Cost (Gross + Er PF + Er ESIC)': r.employerCost,
      });
      const file = `cvp_wages_register_${tag(c)}.xlsx`;
      return {
        file,
        rows: [...rows.map((r, i) => flat(r, i + 1)), flat(total, '')],
        custom: {
          pdf: (name: string) => wagesRegisterPdf(name, `${MONTHS[c.month - 1]} ${c.year}`, rows, total),
          xlsx: (name: string) => wagesRegisterXlsx(name, `${MONTHS[c.month - 1]} ${c.year}`, rows, c.month),
        },
      };
    },
  },
  {
    id: 'salary_year', group: 'Salary & Bank', icon: 'calendar-number-outline', scope: 'year', fy: true, adminOnly: true,
    title: 'Yearly Salary - all employees (month by month)',
    build: async (c) => {
      const { start, months } = fyInfo(c);
      const ppl = await people();
      const per = new Map<string, { name: string; dept: string; net: Record<string, number>; gross: number; ded: number }>();
      for (const { y, m } of months) {
        for (const w of await monthWages(y, m, ppl)) {
          const e = per.get(w.userId) ?? { name: w.name, dept: w.department, net: {}, gross: 0, ded: 0 };
          e.net[monthHead(y, m)] = w.net; e.gross += w.totalGross; e.ded += w.totalDeduct;
          per.set(w.userId, e);
        }
      }
      const list = [...per.values()].sort((a, b) => a.name.localeCompare(b.name));
      const row = (e: { name: string; dept: string; net: Record<string, number>; gross: number; ded: number }) => {
        const o: Row = { 'Employee Name': e.name, Department: e.dept };
        months.forEach(({ y, m }) => { o[monthHead(y, m)] = e.net[monthHead(y, m)] ?? 0; });
        o['Total Gross Wages'] = e.gross; o['Total Deductions'] = e.ded; o['Total Net Salary'] = Object.values(e.net).reduce((a, b) => a + b, 0);
        return o;
      };
      const rows = list.map(row);
      if (rows.length) {
        const t: Row = { 'Employee Name': 'TOTAL', Department: '' };
        Object.keys(rows[0]).slice(2).forEach((k) => { t[k] = rows.reduce((a, r) => a + Number(r[k] || 0), 0); });
        rows.push(t);
      }
      return {
        file: `cvp_yearly_salary_FY${start}_${String(start + 1).slice(2)}.xlsx`, rows,
        // Total Net Salary of each person = the sum of the months, so editing a month updates it (and the TOTAL row)
        custom: tableCustom('Yearly Salary', 'Yearly Salary - all employees', fyLabel(c), rows, 2, { col: 2 + months.length + 2, from: 2, to: 1 + months.length }),
      };
    },
  },
];

const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;
const readable = (v: unknown) => {
  const m = typeof v === 'string' ? ISO_DATE.exec(v) : null;
  return m ? `${m[3]}-${m[2]}-${m[1]}` : v;
};

/** Every report shows dates as dd-mm-yyyy */
export const REPORTS: ReportDef[] = [...RAW, ...SALARY].map((def) => ({
  ...def,
  build: async (c: ReportCtx) => {
    const res = await def.build(c);
    return { ...res, rows: res.rows.map((row) => Object.fromEntries(Object.entries(row).map(([k, v]) => [k, readable(v)]))) };
  },
}));
export const periodLabel = (def: ReportDef, c: { year: number; month: number }) =>
  def.fy ? fyLabel(c) : def.scope === 'month' ? `${MONTHS[c.month - 1]} ${c.year}` : def.scope === 'year' ? `Year ${c.year}` : 'All records';
