import { api, MonthSummaryRow } from './api';
import { bankPaymentPdf, bankPaymentXlsx, BankPayMeta, BankPayRow, iciciSalaryPdf, iciciSalaryXlsx } from './bankPaymentReport';
import { fmtMinutes, fmtTime12, hhmmTo12, istDateISO, istParts, MONTHS } from './time';
import { wageRow, WageRow, wageTotals } from './wages';
import { loadPf, pfForMonth, settingOn, pfMonthStart } from './pf';
import { computeSlip, shareSalarySlips, SlipData } from './salarySlip';
import { footerText, formulasForMonth } from './salaryFormulas';
import { statutoryFlat, statutoryPdf, statutoryRows, statutoryXlsx } from './statutoryRegister';
import { styledTablePdf, wagesRegisterPdf } from './wagesRegisterPdf';
import { styledTableXlsx, wagesRegisterXlsx } from './styledXlsx';
import * as XLSX from 'xlsx-js-style';
import { Sheet } from './xlsx';

type Row = Record<string, unknown>;
export interface ReportResult {
  file: string;
  rows: Row[];
  aoa?: unknown[][];
  merges?: { s: { r: number; c: number }; e: { r: number; c: number } }[];
  /** Day-wise In / Out grid of the whole month, added after `rows` (second Excel sheet / extra PDF pages) */
  grid?: { aoa: unknown[][]; merges: { s: { r: number; c: number }; e: { r: number; c: number } }[] };
  /** A report with its own PDF layout (e.g. the Form II wages register) */
  custom?: { pdf?: (fileName: string) => Promise<void>; xlsx?: (fileName: string) => Promise<void>; txt?: (fileName: string) => Promise<void> };
  /** a message shown after the download (e.g. employees left out of the ECR file) */
  notice?: string;
  /** Excel formulas for the main sheet and for the day-wise grid sheet (see Sheet.calc in xlsx.ts) */
  calc?: Sheet['calc'];
  gridCalc?: Sheet['calc'];
}
export interface ReportCtx {
  year: number; month: number; summary: MonthSummaryRow[]; cache?: Map<string, unknown>; user?: string;
  /** Company filter: is this employee in the chosen company on this date? (undefined = every company) */
  allow?: (userId: string, date: string) => boolean;
  /** PF filter of the salary and PF reports (undefined = everybody) */
  pf?: 'on' | 'off';
}
export interface ReportDef {
  id: string;
  group: 'Attendance' | 'Leave' | 'Field & Site' | 'Employees & Company' | 'Salary & Bank' | 'Provident Fund (PF)';
  /** Financial-year report (April to March) that contains the chosen month */
  fy?: boolean;
  title: string;
  icon: string;
  /** Month-based reports follow the month picker; the others ignore it */
  scope: 'month' | 'year' | 'all';
  adminOnly?: boolean;
  /** Not in Company Reports: downloaded for one employee from Employees -> that employee -> Reports */
  perEmployee?: boolean;
  /** Not a row of its own: a choice of the dropdown of another report (e.g. PF report under the Form II row) */
  variantOf?: string;
  /** The only download is a text file (PF ECR) */
  textOnly?: boolean;
  /** The only download is a PDF (salary slips) */
  pdfOnly?: boolean;
  build: (c: ReportCtx) => Promise<ReportResult>;
}

const mm = (c: ReportCtx) => String(c.month).padStart(2, '0');
const range = (c: ReportCtx) => {
  const last = new Date(c.year, c.month, 0).getDate();
  return { from: `${c.year}-${mm(c)}-01`, to: `${c.year}-${mm(c)}-${String(last).padStart(2, '0')}` };
};
const tag = (c: ReportCtx) => `${c.year}_${mm(c)}`;

/** Every active employee's day list for the month (loaded in parallel batches) */
async function monthDays(c: ReportCtx) {
  const hit = c.cache?.get('days') as Awaited<ReturnType<typeof loadDays>> | undefined;
  if (hit) return hit;
  const res = await loadDays(c);
  c.cache?.set('days', res);
  return res;
}

async function loadDays(c: ReportCtx) {
  const out: { r: MonthSummaryRow; days: Awaited<ReturnType<typeof api.monthAttendance>> }[] = [];
  for (let i = 0; i < c.summary.length; i += 8) {
    const part = c.summary.slice(i, i + 8);
    const got = await Promise.all(part.map((r) => api.monthAttendance(c.year, c.month, r.user_id)));
    part.forEach((r, k) => out.push({ r, days: got[k] }));
  }
  return out;
}

const CODE: Record<string, string> = {
  Present: 'P', 'Checked In': 'P', Absent: 'A', Leave: 'L', Holiday: 'H', 'Rest Day': 'WO', Upcoming: '',
};

type Merge = { s: { r: number; c: number }; e: { r: number; c: number } };
const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;
const t12 = (v: string | null | undefined) => (v ? hhmmTo12(v).replace(/ [AP]M$/, '') : '');

/** All dates of the month as ISO strings */
function monthDates(c: ReportCtx): string[] {
  const last = new Date(c.year, c.month, 0).getDate();
  return Array.from({ length: last }, (_, i) => `${c.year}-${mm(c)}-${String(i + 1).padStart(2, '0')}`);
}

/**
 * The In / Out layout used by every attendance report: employee names down the side,
 * dates across the top, an "In" row and an "Out" row per employee, totals at the end of the row.
 */
function inOutGrid(
  dates: string[],
  people: { id: string; name: string; left?: string | null }[],
  pick: (id: string, iso: string) => { inn: string; out: string },
  totalHead: string[],
  totals: (id: string) => unknown[],
): { aoa: unknown[][]; merges: Merge[] } {
  if (!people.length) return { aoa: [], merges: [] };
  const aoa: unknown[][] = [['Employee Name', '', ...dates.map(dmy), ...totalHead]];
  const merges: Merge[] = [];
  people.forEach((p) => {
    const inRow: unknown[] = [p.name, 'In'];
    const outRow: unknown[] = ['', 'Out'];
    // days after the leaving date of a resigned employee show "-"
    dates.forEach((iso) => { const x = p.left && iso > p.left ? { inn: '-', out: '' } : pick(p.id, iso); inRow.push(x.inn); outRow.push(x.out); });
    const tot = totals(p.id);
    inRow.push(...tot);
    outRow.push(...tot.map(() => ''));
    const r0 = aoa.length;
    merges.push({ s: { r: r0, c: 0 }, e: { r: r0 + 1, c: 0 } });
    for (let k = 0; k < tot.length; k++) merges.push({ s: { r: r0, c: inRow.length - tot.length + k }, e: { r: r0 + 1, c: inRow.length - tot.length + k } });
    aoa.push(inRow, outRow);
  });
  return { aoa, merges };
}

type GridKind = 'present' | 'absent' | 'leave' | 'late' | 'holiday' | 'days' | null;

/**
 * Formulas for the total columns of an In / Out grid: they count the A / L / H codes and the times of the "In" row,
 * so changing a day in the sheet updates Present, Absent, Leave ... straight away. null = keep the value.
 */
function gridCalc(nDates: number, kinds: GridKind[]): Sheet['calc'] {
  const first = 2; const last = first + nDates - 1;
  return (r, c, xr) => {
    if (r % 2 !== 1 || c <= last) return null; // only the "In" row of each employee (the total cells are merged over both rows)
    const kind = kinds[c - last - 1];
    if (!kind) return null;
    const x = xr(r);
    const rng = `${XLSX.utils.encode_col(first)}${x}:${XLSX.utils.encode_col(last)}${x}`;
    const filled = `SUMPRODUCT(--(LEN(${rng})>0))-COUNTIF(${rng},"-")`;   // "-" = days after the employee resigned
    const code = (k: string) => `COUNTIF(${rng},"${k}")`;
    switch (kind) {
      case 'present': return `${filled}-${code('L')}-${code('H')}-${code('WO')}`;
      case 'absent': return null;   // an absent day has no letter in the sheet, so the Absent total keeps its calculated value
      case 'leave': return code('L');
      case 'holiday': return code('H');
      case 'late': return `COUNTIF(${rng},"*~*")`;
      case 'days': return filled;
    }
  };
}

const RAW: ReportDef[] = [
  // ------------------------------------------------------------ Attendance
  {
    id: 'monthly', group: 'Attendance', icon: 'calendar-outline', scope: 'month',
    title: 'Monthly Attendance (Name, In, Out)',
    build: async (c) => {
      const data = await monthDays(c);
      const code: Record<string, string> = { Leave: 'L', Holiday: 'H', 'Rest Day': 'WO' };
      const byId = new Map(data.map((d) => [d.r.user_id, d]));
      const otMin = new Map<string, number>();
      (await api.overtimeDays(c.year, c.month)).filter((o) => !c.allow || c.allow(o.user_id, `${c.year}-${String(c.month).padStart(2, '0')}-01`)).forEach((o) => otMin.set(o.user_id, (otMin.get(o.user_id) ?? 0) + o.ot_minutes));
      const g = inOutGrid(
        monthDates(c), data.map((d) => ({ id: d.r.user_id, name: d.r.full_name, left: d.r.left_on })),
        (id, iso) => {
          const d = byId.get(id)?.days.find((x) => x.day === iso);
          if (!d) return { inn: '', out: '' };
          if (d.in_time || d.out_time) return { inn: t12(d.in_time), out: t12(d.out_time) };
          return { inn: code[d.status] ?? '', out: '' };
        },
        ['Present', 'Absent', 'Leave', 'Holidays', 'Total Hours', 'Overtime Hours'],
        (id) => {
          const r = byId.get(id)!.r;
          return [r.present, r.absent, r.on_leave, r.holidays, Number(Number(r.hours).toFixed(2)), Number(((otMin.get(id) ?? 0) / 60).toFixed(2))];
        },
      );
      return { file: `cvp_monthly_attendance_${tag(c)}.xlsx`, rows: [], ...g, calc: gridCalc(monthDates(c).length, ['present', 'absent', 'leave', 'holiday', null, null]) };
    },
  },
  {
    id: 'detailed', group: 'Attendance', icon: 'document-text-outline', scope: 'month', perEmployee: true,
    title: 'Detailed Day-wise Report',
    build: async (c) => {
      // In / Out layout (no fixed times, so nobody is marked late). Joining date is added at the end of the row.
      const { from, to } = range(c);
      const joined = new Map((await api.allProfiles()).map((p) => [p.id, p.joining_date ?? '']));
      const data = await monthDays(c);
      const byId = new Map(data.map((d) => [d.r.user_id, d]));
      const code: Record<string, string> = { Leave: 'L', Holiday: 'H', 'Rest Day': 'WO' };
      const g = inOutGrid(
        monthDates(c), data.map((d) => ({ id: d.r.user_id, name: d.r.full_name, left: d.r.left_on })),
        (id, iso) => {
          const d = byId.get(id)?.days.find((x) => x.day === iso);
          if (!d) return { inn: '', out: '' };
          if (d.in_time || d.out_time) return { inn: t12(d.in_time), out: t12(d.out_time) };
          return { inn: code[d.status] ?? '', out: '' };
        },
        ['Joined', 'Present', 'Absent', 'Leave', 'Hours'],
        (id) => {
          const r = byId.get(id)!.r;
          return [joined.get(id) ? dmy(joined.get(id)!) : '', r.present, r.absent, r.on_leave, Number(Number(r.hours).toFixed(2))];
        },
      );
      return { file: `cvp_report_${tag(c)}.xlsx`, rows: [], ...g, calc: gridCalc(monthDates(c).length, [null, 'present', 'absent', 'leave', null, null]) };
    },
  },
  // ------------------------------------------------------------ Leave
  {
    id: 'leaves', group: 'Leave', icon: 'airplane-outline', scope: 'month', perEmployee: true,
    title: 'Leave Register',
    build: async (c) => {
      const { from, to } = range(c);
      const list = (await api.leavesBetween(from, to)).filter((l) => (!c.user || l.user_id === c.user) && (!c.allow || c.allow(l.user_id, l.from_day)));
      return {
        file: `cvp_leave_register_${tag(c)}.xlsx`,
        rows: list.map((l) => ({
          'Employee Name': l.employee?.full_name, Department: l.employee?.department ?? '',
          'Leave Type': l.leave_type, From: l.from_day, To: l.to_day, Days: l.days, Reason: l.reason,
          Status: l.status, 'Reviewer Note': l.review_note ?? '', Applied: istDateISO(l.created_at),
        })),
      };
    },
  },
  {
    id: 'balance', group: 'Leave', icon: 'wallet-outline', scope: 'year',
    title: 'Yearly Leaves (granted, used, balance)',
    build: async (c) => {
      const rows: Row[] = [];
      for (let i = 0; i < c.summary.length; i += 8) {
        const part = c.summary.slice(i, i + 8);
        const got = await Promise.all(part.map((r) => api.leaveBalance(c.year, r.user_id)));
        part.forEach((r, k) => {
          const row: Row = { 'Employee Name': r.full_name, Department: r.department ?? '' };
          got[k].forEach((b) => {
            row[`${b.leave_type} - Granted`] = b.granted;
            row[`${b.leave_type} - Used`] = b.used;
            row[`${b.leave_type} - Balance`] = b.counts_balance ? b.balance : '';
          });
          rows.push(row);
        });
      }
      // Balance = Granted - Used (only for the leave types that keep a balance)
      const calc: Sheet['calc'] = (r, col, xr, table) => {
        if (!String(table[0][col]).endsWith('- Balance') || table[r][col] === '') return null;
        const x = xr(r);
        return `${XLSX.utils.encode_col(col - 2)}${x}-${XLSX.utils.encode_col(col - 1)}${x}`;
      };
      return { file: `cvp_yearly_leaves_${c.year}.xlsx`, rows, calc };
    },
  },
];

// ------------------------------------------------------------ Salary & Bank
/** Financial year (April to March) that contains the chosen month; only the months up to today are listed */
function fyInfo(c: { year: number; month: number }) {
  const start = c.month >= 4 ? c.year : c.year - 1;
  const now = istParts();
  const months: { y: number; m: number }[] = [];
  for (let i = 0; i < 12; i++) {
    const idx = 3 + i;
    const y = start + Math.floor(idx / 12); const m = (idx % 12) + 1;
    if (y > now.year || (y === now.year && m > now.month)) break;
    months.push({ y, m });
  }
  return { start, months };
}
const fyLabel = (c: { year: number; month: number }) => { const s = fyInfo(c).start; return `FY ${s}-${String(s + 1).slice(2)} (April ${s} to March ${s + 1})`; };
const monthHead = (y: number, m: number) => `${MONTHS[m - 1].slice(0, 3)} ${y}`;

/** Joining dates, UAN, gender and bank details of everyone */
async function people() {
  const [prof, det] = await Promise.all([api.allProfiles(), api.detailsForReports()]);
  return { prof: new Map(prof.map((p) => [p.id, p])), det: new Map(det.map((d) => [d.user_id, d])) };
}
type People = Awaited<ReturnType<typeof people>>;

/** One month's wage rows (people with a salary only) */
async function monthWages(y: number, m: number, ppl: People, allow?: ReportCtx['allow'], pfOnly?: ReportCtx['pf']): Promise<WageRow[]> {
  const pf = await loadPf();
  const end = `${y}-${String(m).padStart(2, '0')}-${String(new Date(y, m, 0).getDate()).padStart(2, '0')}`;
  const list = (await api.payroll(y, m)).filter((p) => !allow || allow(p.user_id, end));
  // people who have left keep their row (salary "-" from the month after leaving)
  const rows = list.filter((p) => (Number(p.monthly_salary) > 0 || p.left_on) && ppl.prof.get(p.user_id)?.role !== 'Admin');   // Admin accounts have no salary
  const items = (await formulasForMonth(y, m)).items;   // the salary formulas of THAT month (earlier months keep the old ones)
  const all = rows.map((p) => {
    const pr = ppl.prof.get(p.user_id);
    return wageRow(p, m, {
      joining: pr?.joining_date, resigned: p.left_on ?? ppl.det.get(p.user_id)?.resign_date, uan: ppl.det.get(p.user_id)?.uan_no, gender: ppl.det.get(p.user_id)?.gender,
      userId: p.user_id, pf: pfForMonth(pf, p.user_id, y, m),
    }, items);
  });
  return pfOnly ? all.filter((r) => (r.pfMember === 'Y') === (pfOnly === 'on')) : all;
}
/** The Wages Register rows of a month: the one calculation used by the register, the slips and the PF screens */
export async function wagesOfMonth(y: number, m: number, allow?: ReportCtx['allow'], pfOnly?: ReportCtx['pf']) {
  return monthWages(y, m, await people(), allow, pfOnly);
}
const bankOf = (ppl: People, id: string) => {
  const d = ppl.det.get(id);
  return { 'Bank Name': d?.bank_name ?? '', Branch: d?.bank_branch ?? '', 'Account No': d?.bank_account_no ?? '', 'IFSC Code': d?.ifsc_code ?? '' };
};

/** Styled, editable Excel of a flat report: the TOTAL row is rebuilt as SUM formulas */
function tableCustom(sheet: string, title: string, subtitle: string, rows: Row[], sumFrom: number, rowSum?: { col: number; from: number; to: number }) {
  const data = rows.filter((r) => r['Employee Name'] !== 'TOTAL');
  const head = Object.keys(rows[0] ?? {});
  const body = data.map((r) => head.map((h) => (r[h] ?? '') as string | number));
  return {
    xlsx: (name: string) => styledTableXlsx(name, sheet, title, subtitle, head, body, { sumFrom, rowSum }),
    pdf: (name: string) => styledTablePdf(name, title, subtitle, head, body, { sumFrom, company: true }),
  };
}

/** Fixed details printed on the bank's bulk payment sheet */
const BANK_PAY = { company: 'C V Patil & Associates', debitAccount: '239305500264', product: 'PAB_VENDOR', email: 'patilcvoffice@gmail.com' };

const SALARY: ReportDef[] = [
  {
    id: 'bank_payment', group: 'Salary & Bank', icon: 'business-outline', scope: 'month', adminOnly: true,
    title: 'Salary Payment Report (bank bulk payment)',
    build: async (c) => {
      // Same layout as the Bank Yearly Salary Statement: employee, bank details and the net salary of the month, with a TOTAL row
      const ppl = await people();
      const head = `Net Salary ${monthHead(c.year, c.month)}`;
      const list = (await monthWages(c.year, c.month, ppl, c.allow, c.pf)).sort((a, b) => a.name.localeCompare(b.name));
      const rows: Row[] = list.map((w) => ({ 'Employee Name': w.name, ...bankOf(ppl, w.userId), [head]: w.net }));
      if (rows.length) {
        rows.push({ 'Employee Name': 'TOTAL', 'Bank Name': '', Branch: '', 'Account No': '', 'IFSC Code': '', [head]: rows.reduce((a, r) => a + Number(r[head] || 0), 0) });
      }
      return {
        file: `cvp_salary_payment_${tag(c)}.xlsx`, rows,
        custom: tableCustom('Salary Payment', 'Salary Payment Report (bank bulk payment)', `${MONTHS[c.month - 1]} ${c.year}`, rows, 5),
      };
    },
  },  {
    id: 'bank_icici', group: 'Salary & Bank', icon: 'business-outline', scope: 'month', adminOnly: true,
    title: 'Bank Salary Upload - ICICI template (monthly)',
    build: async (c) => {
      // The bank's own upload sheet (NEFT): one row per employee with the net salary of the month
      const ppl = await people();
      const list = (await monthWages(c.year, c.month, ppl, c.allow, c.pf)).sort((a, b) => a.name.localeCompare(b.name));
      const rows: BankPayRow[] = list.map((w) => {
        const d = ppl.det.get(w.userId);
        const ifsc = (d?.ifsc_code ?? '').toUpperCase();
        const mobile = (d?.cell_no || ppl.prof.get(w.userId)?.phone || '').replace(/\D/g, '').slice(-10);
        return { name: w.name, mode: ifsc.startsWith('ICIC') ? 'FT' : 'NEFT', account: d?.bank_account_no ?? '', ifsc, amount: w.net, mobile, email: BANK_PAY.email };
      });
      const meta: BankPayMeta = { company: BANK_PAY.company, paymentDate: dmy(istDateISO()), debitAccount: BANK_PAY.debitAccount, product: BANK_PAY.product };
      const flat: Row[] = rows.map((r, i) => ({ Sr: i + 1, 'Beneficiary name': r.name, Mode: r.mode, 'Beneficiary A/c No': r.account, IFSC: r.ifsc, 'Amount (Rs.)': r.amount, Mobile: r.mobile, Email: r.email }));
      return {
        file: `cvp_bank_salary_upload_icici_${tag(c)}.xlsx`, rows: flat,
        custom: {
          pdf: (name: string) => iciciSalaryPdf(name, meta, rows, `${MONTHS[c.month - 1]} ${c.year}`),
          xlsx: (name: string) => iciciSalaryXlsx(name, meta, rows),
        },
      };
    },
  },
  {
    id: 'bank_year', group: 'Salary & Bank', icon: 'card-outline', scope: 'year', fy: true, adminOnly: true,
    title: 'Bank Yearly Salary Statement - all employees',
    build: async (c) => {
      const { start, months } = fyInfo(c);
      const ppl = await people();
      const per = new Map<string, { name: string; net: Record<string, number> }>();
      for (const { y, m } of months) {
        for (const w of await monthWages(y, m, ppl, c.allow, c.pf)) {
          const e = per.get(w.userId) ?? { name: w.name, net: {} };
          e.net[monthHead(y, m)] = w.net;
          per.set(w.userId, e);
        }
      }
      const rows: Row[] = [...per.entries()].sort((a, b) => a[1].name.localeCompare(b[1].name)).map(([id, e]) => {
        const o: Row = { 'Employee Name': e.name, ...bankOf(ppl, id) };
        months.forEach(({ y, m }) => { o[monthHead(y, m)] = e.net[monthHead(y, m)] ?? 0; });
        o['Total Net Salary'] = Object.values(e.net).reduce((a, b) => a + b, 0);
        return o;
      });
      if (rows.length) {
        const t: Row = { 'Employee Name': 'TOTAL', 'Bank Name': '', Branch: '', 'Account No': '', 'IFSC Code': '' };
        Object.keys(rows[0]).slice(5).forEach((k) => { t[k] = rows.reduce((a, r) => a + Number(r[k] || 0), 0); });
        rows.push(t);
      }
      return {
        file: `cvp_bank_yearly_salary_FY${start}_${String(start + 1).slice(2)}.xlsx`, rows,
        custom: tableCustom('Bank Yearly Salary', 'Bank Yearly Salary Statement - all employees', fyLabel(c), rows, 5,
          { col: 5 + months.length, from: 5, to: 4 + months.length }),
      };
    },
  },
  {
    id: 'wages_register', group: 'Salary & Bank', icon: 'document-text-outline', scope: 'month', adminOnly: true,
    title: 'Muster Roll cum Wages Register - Form II (month)',
    build: async (c) => {
      const ppl = await people();
      const rows = await monthWages(c.year, c.month, ppl, c.allow, c.pf);
      const total = wageTotals(rows);
      const fm = await formulasForMonth(c.year, c.month);
      const foot = footerText(fm);
      const flat = (r: WageRow, i: number | string) => ({
        'Sr. No.': i, 'Date of Joining': r.joining, 'Date of Resignation': r.resigned, 'UAN No.': r.uan, 'Full Name of the Employees': r.name, 'Male/Female': r.gender,
        'Gross Wages': r.gross, 'Total Days Present': r.daysPresent, 'Total Days': r.daysInMonth || '',
        'Basic @ 50%': r.basic, 'HRA @ 40%': r.hra, 'Other Allowances': r.other, 'Total Gross Wages': r.totalGross,
        'PF Employee': r.pfEmployee, PT: r.pt, 'ESIC Employee': r.esicEmployee, 'PF Employer': r.pfEmployer, 'ESIC Employer': r.esicEmployer,
        Advance: r.advance, 'Total Deduct': r.totalDeduct, 'Net Wages Paid': r.net,
        'PF Member (Y/N)': r.pfMember, 'EPS Eligible (Y/N)': r.epsEligible, 'PF Wages (EPF/EDLI wages)': r.pfWages, 'EPS Wages': r.epsWages,
        'Employer EPS 8.33%': r.employerEps, 'Employer EPF 3.67% (diff)': r.employerEpf, 'Employer Cost (Gross + Er PF + Er ESIC)': r.employerCost,
      });
      const file = `cvp_wages_register_${tag(c)}.xlsx`;
      return {
        file,
        rows: [...rows.map((r, i) => flat(r, i + 1)), flat(total, '')],
        custom: {
          pdf: (name: string) => wagesRegisterPdf(name, `${MONTHS[c.month - 1]} ${c.year}`, rows, total, foot),
          xlsx: (name: string) => wagesRegisterXlsx(name, `${MONTHS[c.month - 1]} ${c.year}`, rows, c.month, !fm.fromDatabase || fm.applyFrom <= '2000-01-01', foot),
        },
      };
    },
  },
  // ---------------------------------------------------------------------------------------------------------------- statutory reports
  // Same layout as Form II (same heading and first columns) with ONLY the columns of that report, for the employees of that report.
  // The numbers are the Form II numbers of the month: nothing new is calculated.
  ...(['pf', 'esic', 'pt'] as const).map((k): ReportDef => ({
    id: `${k}_report`, variantOf: 'wages_register', group: 'Salary & Bank', icon: 'document-text-outline', scope: 'month', adminOnly: true,
    title: k === 'pf' ? 'PF Report (month)' : k === 'esic' ? 'ESIC Report (month)' : 'PT Report (month)',
    build: async (c) => {
      const ppl = await people();
      const rows = statutoryRows(k, await monthWages(c.year, c.month, ppl, c.allow, c.pf));
      const foot = footerText(await formulasForMonth(c.year, c.month));
      const label = `${MONTHS[c.month - 1]} ${c.year}`;
      return {
        file: `cvp_${k}_report_${c.year}-${mm(c)}.xlsx`, rows: statutoryFlat(k, rows),
        custom: { pdf: (name: string) => statutoryPdf(name, label, k, rows, foot), xlsx: (name: string) => statutoryXlsx(name, label, k, rows, foot) },
      };
    },
  })),
  {
    id: 'salary_year', group: 'Salary & Bank', icon: 'calendar-number-outline', scope: 'year', fy: true, adminOnly: true,
    title: 'Yearly Salary - all employees (month by month)',
    build: async (c) => {
      const { start, months } = fyInfo(c);
      const ppl = await people();
      const per = new Map<string, { name: string; dept: string; net: Record<string, number>; gross: number; ded: number }>();
      for (const { y, m } of months) {
        for (const w of await monthWages(y, m, ppl, c.allow, c.pf)) {
          const e = per.get(w.userId) ?? { name: w.name, dept: w.department, net: {}, gross: 0, ded: 0 };
          e.net[monthHead(y, m)] = w.net; e.gross += w.totalGross; e.ded += w.totalDeduct;
          per.set(w.userId, e);
        }
      }
      const list = [...per.values()].sort((a, b) => a.name.localeCompare(b.name));
      const row = (e: { name: string; dept: string; net: Record<string, number>; gross: number; ded: number }) => {
        const o: Row = { 'Employee Name': e.name, Department: e.dept };
        months.forEach(({ y, m }) => { o[monthHead(y, m)] = e.net[monthHead(y, m)] ?? 0; });
        o['Total Gross Wages'] = e.gross; o['Total Deductions'] = e.ded; o['Total Net Salary'] = Object.values(e.net).reduce((a, b) => a + b, 0);
        return o;
      };
      const rows = list.map(row);
      if (rows.length) {
        const t: Row = { 'Employee Name': 'TOTAL', Department: '' };
        Object.keys(rows[0]).slice(2).forEach((k) => { t[k] = rows.reduce((a, r) => a + Number(r[k] || 0), 0); });
        rows.push(t);
      }
      return {
        file: `cvp_yearly_salary_FY${start}_${String(start + 1).slice(2)}.xlsx`, rows,
        // Total Net Salary of each person = the sum of the months, so editing a month updates it (and the TOTAL row)
        custom: tableCustom('Yearly Salary', 'Yearly Salary - all employees', fyLabel(c), rows, 2, { col: 2 + months.length + 2, from: 2, to: 1 + months.length }),
      };
    },
  },
];

// ------------------------------------------------------------ Provident Fund
const PF_GROUP = 'Provident Fund (PF)' as const;
const sumRow = (rows: Row[], textCols: number) => {
  const t: Row = {};
  Object.keys(rows[0]).forEach((k, i) => { t[k] = i === 0 ? 'TOTAL' : i < textCols ? '' : rows.reduce((a, r) => a + Number(r[k] || 0), 0); });
  return t;
};
const PF_REPORTS: ReportDef[] = [
  {
    id: 'salary_pf', group: 'Salary & Bank', icon: 'cash-outline', scope: 'month', adminOnly: true,
    title: 'Salary with PF - net pay (month)',
    build: async (c) => {
      const list = (await monthWages(c.year, c.month, await people(), c.allow, c.pf)).sort((a, b) => a.name.localeCompare(b.name));
      const rows: Row[] = list.map((w) => ({
        'Employee Name': w.name, PF: w.pfMember === 'Y' ? 'ON' : 'OFF', 'Monthly salary': w.gross, 'Unpaid days': w.daysUnpaid, 'Earned salary': w.totalGross,
        'Employee PF': w.pfEmployee, 'Employer PF': w.pfEmployer, PT: w.pt, ESIC: w.esicEmployee, 'Net salary': w.net,
      }));
      if (rows.length) rows.push(sumRow(rows, 2));
      return {
        file: `cvp_salary_pf_${tag(c)}.xlsx`, rows,
        custom: tableCustom('Salary with PF', 'Salary with PF - net pay', `${MONTHS[c.month - 1]} ${c.year}`, rows, 2),
      };
    },
  },
  {
    id: 'salary_slips_all', group: 'Salary & Bank', icon: 'receipt-outline', scope: 'month', adminOnly: true, pdfOnly: true,
    title: 'Salary slips - all in one PDF (month)',
    build: async (c) => {
      const ppl = await people();
      const wages = (await monthWages(c.year, c.month, ppl, c.allow, c.pf)).sort((a, b) => a.name.localeCompare(b.name));
      const pay = await api.payroll(c.year, c.month);
      const slips: SlipData[] = [];
      const skipped: string[] = [];
      for (const w of wages) {
        const p = ppl.prof.get(w.userId);
        const res = computeSlip(pay.find((x) => x.user_id === w.userId), ppl.det.get(w.userId),
          { designation: p?.designation ?? '', joining: p?.joining_date ?? null, department: p?.department ?? null }, c.year, c.month, w);
        if (res.ok) slips.push(res.slip); else skipped.push(w.name);
      }
      return {
        file: `cvp_salary_slips_${tag(c)}.pdf`, rows: slips.map((s) => ({ 'Employee Name': s.name })),
        notice: skipped.length ? `No slip (salary, bank details or PAN missing) for: ${skipped.join(', ')}` : undefined,
        custom: { pdf: (name: string) => shareSalarySlips(name, slips) },
      };
    },
  },
  {
    id: 'pf_members', group: PF_GROUP, icon: 'shield-checkmark-outline', scope: 'month', adminOnly: true,
    title: 'PF Report - PF members',
    build: async (c) => {
      const list = (await monthWages(c.year, c.month, await people(), c.allow, 'on')).sort((a, b) => a.name.localeCompare(b.name));
      const rows: Row[] = list.map((w) => ({
        'Employee Name': w.name, 'UAN No.': w.uan || 'UAN missing', 'Days Present': w.daysPresent, 'Gross Wages earned': w.totalGross,
        'EPF Wages': w.pfWages, 'EPS Wages': w.epsWages, 'EDLI Wages': w.pfWages, 'Employee PF': w.pfEmployee,
        'Employer EPS': w.employerEps, 'Employer EPF': w.employerEpf, 'Total PF': w.pfEmployee + w.pfEmployer,
      }));
      if (rows.length) rows.push(sumRow(rows, 2));
      const noUan = list.filter((w) => !w.uan).map((w) => w.name);
      return {
        file: `cvp_pf_members_${tag(c)}.xlsx`, rows,
        notice: noUan.length ? `UAN missing for: ${noUan.join(', ')}. Add it before filing.` : undefined,
        custom: tableCustom('PF Report', 'PF Report - PF members', `${MONTHS[c.month - 1]} ${c.year}`, rows, 2),
      };
    },
  },
  {
    id: 'pf_year', group: PF_GROUP, icon: 'calendar-number-outline', scope: 'year', fy: true, adminOnly: true,
    title: 'PF Yearly Statement (April to March)',
    build: async (c) => {
      const { start, months } = fyInfo(c);
      const ppl = await people();
      const per = new Map<string, Row[]>();
      for (const { y, m } of months) {
        for (const w of await monthWages(y, m, ppl, c.allow, 'on')) {
          per.set(w.userId, [...(per.get(w.userId) ?? []), {
            'Employee Name': w.name, Month: monthHead(y, m), 'Days present': w.daysPresent, 'EPF wages': w.pfWages,
            'Employee PF': w.pfEmployee, 'Employer EPS': w.employerEps, 'Employer EPF': w.employerEpf, Total: w.pfEmployee + w.pfEmployer,
          }]);
        }
      }
      // each employee: the months, then that employee's yearly total
      const rows: Row[] = [...per.values()].sort((a, b) => String(a[0]['Employee Name']).localeCompare(String(b[0]['Employee Name'])))
        .flatMap((list) => [...list, { ...sumRow(list, 2), 'Employee Name': list[0]['Employee Name'], Month: 'Year total' }]);
      return { file: `cvp_pf_yearly_FY${start}_${String(start + 1).slice(2)}.xlsx`, rows };
    },
  },
  {
    id: 'pf_check', group: PF_GROUP, icon: 'alert-circle-outline', scope: 'month', adminOnly: true,
    title: 'PF check - missing UAN / amount problems',
    build: async (c) => {
      const pf = await loadPf();
      const ppl = await people();
      const wages = new Map((await monthWages(c.year, c.month, ppl, c.allow)).map((w) => [w.userId, w]));
      const start = pfMonthStart(c.year, c.month);
      const rows: Row[] = [];
      const add = (id: string, problem: string) => rows.push({ 'Employee Name': ppl.prof.get(id)?.full_name ?? id, 'UAN No.': ppl.det.get(id)?.uan_no ?? '', Problem: problem });
      for (const id of new Set(pf.settings.map((s) => s.user_id))) {
        if (c.allow && !c.allow(id, start)) continue;
        const now = settingOn(pf, id, start);
        const later = pf.settings.find((s) => s.user_id === id && s.from_date > start && s.applicable);
        if (later) add(id, `PF change starts later: from ${dmy(later.from_date)}`);
        if (!now?.applicable) continue;
        if (!ppl.det.get(id)?.uan_no) add(id, 'UAN missing');
        if (now.amount_mode === 'fixed' && !now.fixed_amount) add(id, 'Fixed PF amount has no value');
        if (wages.get(id)?.pfCapped) add(id, `Fixed amount ${now.fixed_amount} is more than the earned Basic ${wages.get(id)!.basic}: the Basic is used`);
      }
      return { file: `cvp_pf_check_${tag(c)}.xlsx`, rows };
    },
  },
];

const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;
const readable = (v: unknown) => {
  const m = typeof v === 'string' ? ISO_DATE.exec(v) : null;
  return m ? `${m[3]}-${m[2]}-${m[1]}` : v;
};

/** Every report shows dates as dd-mm-yyyy */
export const REPORTS: ReportDef[] = [...RAW, ...SALARY, ...PF_REPORTS].map((def) => ({
  ...def,
  build: async (c: ReportCtx) => {
    const res = await def.build(c);
    // the file name shows the PF filter (not for the PF-only reports)
    if (c.pf && def.group === 'Salary & Bank') res.file = res.file.replace(/(\.\w+)$/, `${c.pf === 'on' ? '_PF' : '_NonPF'}$1`);
    return { ...res, rows: res.rows.map((row) => Object.fromEntries(Object.entries(row).map(([k, v]) => [k, readable(v)]))) };
  },
}));
export const periodLabel = (def: ReportDef, c: { year: number; month: number }) =>
  def.fy ? fyLabel(c) : def.scope === 'month' ? `${MONTHS[c.month - 1]} ${c.year}` : def.scope === 'year' ? `Year ${c.year}` : 'All records';
