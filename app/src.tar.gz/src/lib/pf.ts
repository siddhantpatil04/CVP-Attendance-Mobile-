// PF ON / OFF per employee and the PF rules. Needs supabase/pf_on_off.sql.
// Until that file is run, or for months before the PF start month, every month is calculated exactly as before.
import type { PfInput } from './salaryEngine';
import { supabase } from './supabase';

export interface PfSetting { user_id: string; from_date: string; applicable: boolean; amount_mode: 'auto' | 'fixed'; fixed_amount: number | null }
export interface PfRule { effective_from: string; employee_rate: number; employer_rate: number; eps_rate: number; wage_ceiling: number; apply_ceiling: boolean }
export interface PfData { installed: boolean; switchFrom: string | null; settings: PfSetting[]; rules: PfRule[] }

const missing = (e: { code?: string } | null) => !!e && (e.code === '42P01' || e.code === 'PGRST205');
export const pfMonthStart = (y: number, m: number) => `${y}-${String(m).padStart(2, '0')}-01`;

/** Everything PF. Only a missing table means "not installed"; any other error is thrown so that pay is never silently wrong. */
export async function loadPf(userId?: string): Promise<PfData> {
  const control = await supabase.from('pf_control').select('switch_from').eq('id', 1);
  if (missing(control.error)) return { installed: false, switchFrom: null, settings: [], rules: [] };
  if (control.error) throw control.error;
  let q = supabase.from('employee_pf').select('user_id, from_date, applicable, amount_mode, fixed_amount').order('from_date', { ascending: false });
  if (userId) q = q.eq('user_id', userId);
  const [settings, rules] = await Promise.all([q, supabase.from('pf_rules').select('*').order('effective_from', { ascending: false })]);
  if (settings.error) throw settings.error;
  if (rules.error) throw rules.error;
  return { installed: true, switchFrom: control.data?.[0]?.switch_from ?? null, settings: (settings.data ?? []) as PfSetting[], rules: (rules.data ?? []) as PfRule[] };
}

/** The employee's PF row that is valid in the month starting `start` */
export const settingOn = (d: PfData, userId: string, start: string) => d.settings.find((s) => s.user_id === userId && s.from_date <= start);
export const ruleOn = (d: PfData, start: string) => d.rules.find((r) => r.effective_from <= start);

export function pfInput(rule: PfRule, applicable: boolean, mode: 'auto' | 'fixed', fixed: number | null): PfInput {
  return {
    applicable, fixed: mode === 'fixed' ? Number(fixed) : null,
    employeeRate: Number(rule.employee_rate), employerRate: Number(rule.employer_rate), epsRate: Number(rule.eps_rate),
    ceiling: rule.apply_ceiling ? Number(rule.wage_ceiling) : null,
  };
}

/** PF input of one employee for one month; undefined = the month is before the PF start month (old calculation) */
export function pfForMonth(d: PfData, userId: string, y: number, m: number): PfInput | undefined {
  const start = pfMonthStart(y, m);
  if (!d.installed || !d.switchFrom || start < d.switchFrom) return undefined;
  const rule = ruleOn(d, start);
  if (!rule) return undefined;
  const s = settingOn(d, userId, start);
  return pfInput(rule, !!s?.applicable, s?.amount_mode ?? 'auto', s?.fixed_amount ?? null);
}

export const pfApi = {
  save: async (userId: string, from: string, applicable: boolean, mode: 'auto' | 'fixed', fixed: number | null, uan: string) => {
    const { error } = await supabase.rpc('set_employee_pf', { p_user: userId, p_from: from, p_applicable: applicable, p_mode: mode, p_fixed: fixed, p_uan: uan });
    if (error) throw error;
  },
  saveRules: async (r: PfRule) => {
    const { error } = await supabase.rpc('save_pf_rules', { p_from: r.effective_from, p_employee: r.employee_rate, p_employer: r.employer_rate, p_eps: r.eps_rate, p_ceiling: r.wage_ceiling, p_apply_ceiling: r.apply_ceiling });
    if (error) throw error;
  },
  setSwitchMonth: async (from: string | null) => {
    const { error } = await supabase.rpc('set_pf_switch_month', { p_from: from });
    if (error) throw error;
  },
};
