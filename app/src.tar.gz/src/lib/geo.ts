import * as Location from 'expo-location';

/**
 * Current GPS position that can never hang: gives up after `ms`, then falls back to the phone's last known position
 * (so a weak signal inside a building does not leave the Submit button spinning forever).
 */
export async function currentPosition(accuracy = Location.Accuracy.Balanced, ms = 12000): Promise<Location.LocationObject> {
  const fresh = await Promise.race([
    Location.getCurrentPositionAsync({ accuracy }).catch(() => null),
    new Promise<null>((r) => setTimeout(() => r(null), ms)),
  ]);
  if (fresh) return fresh;
  const last = await Location.getLastKnownPositionAsync({ maxAge: 10 * 60000 }).catch(() => null);
  if (last) return last;
  throw new Error('Could not get your location. Turn on GPS, move to an open area and try again.');
}

/** Distance in metres between two GPS points (haversine). Same formula the database uses. */
export function distanceM(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const rad = (d: number) => (d * Math.PI) / 180;
  const a = Math.sin(rad(lat2 - lat1) / 2) ** 2
    + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(rad(lng2 - lng1) / 2) ** 2;
  return 2 * 6371000 * Math.asin(Math.min(1, Math.sqrt(a)));
}

/** "850 m", "2.3 km" or "15 km" */
export function fmtDistance(m: number): string {
  if (m < 1000) return `${Math.round(m)} m`;
  const km = m / 1000;
  return `${Number.isInteger(km) ? km : km.toFixed(1)} km`;
}

/** The work site that stands for "any place outside the work sites" (Work Sites -> "Foreign location"): it has NO radius limit */
export const isForeignSiteName = (name?: string | null) => /^\s*foreign\s*location\s*$/i.test(name ?? '');

/** The real work site nearest to a point (the "Foreign location" site and the office are not real work sites) */
export function nearestWorkSite<T extends { name: string; lat: number; lng: number; is_office?: boolean | null }>(lat: number, lng: number, sites: T[]): T | undefined {
  return sites
    .filter((s) => !s.is_office && !isForeignSiteName(s.name))
    .sort((a, b) => distanceM(lat, lng, a.lat, a.lng) - distanceM(lat, lng, b.lat, b.lng))[0];
}
