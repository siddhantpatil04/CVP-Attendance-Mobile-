// Sending salary slips + proof (sent / opened / downloaded / acknowledged). Needs supabase/salary_slips.sql.
// The slip PDF is made by the EXISTING slip code (salarySlip.ts), uploaded to the private bucket "salary-slips" and recorded with record_slip_sent().
import { Platform } from 'react-native';
import { salarySlipBytes, SlipData } from './salarySlip';
import { supabase } from './supabase';
import { saveXlsxData } from './xlsx';

export interface SlipSend {
  id: number; user_id: string; month: string; slip_no: string; net_pay: number; file_path: string; file_sha256: string;
  sent_at: string; sent_by: string | null; opened_at: string | null; downloaded_at: string | null; acknowledged_at: string | null; ack_device: string | null;
  reminder_sent_at: string | null; query_text: string | null; query_at: string | null; query_answer: string | null; answered_by: string | null; answered_at: string | null;
  replaced_by: number | null; created_at: string; sender?: string;
}

// ---- SHA-256 of the file (pure JavaScript: crypto.subtle does not exist on every phone) ---------------------------------------------
const K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
export function sha256Hex(buf: ArrayBuffer): string {
  const data = new Uint8Array(buf); const l = data.length;
  const padded = new Uint8Array(((l + 9 + 63) >> 6) << 6); padded.set(data); padded[l] = 0x80;
  const dv = new DataView(padded.buffer); dv.setUint32(padded.length - 4, (l * 8) >>> 0); dv.setUint32(padded.length - 8, Math.floor((l * 8) / 4294967296));
  const H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]; const w = new Uint32Array(64);
  const rr = (x: number, n: number) => (x >>> n) | (x << (32 - n));
  for (let o = 0; o < padded.length; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
    for (let i = 16; i < 64; i++) { const s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3); const s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0; }
    let [a, b, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const t1 = (h + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) >>> 0;
      const t2 = ((rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0; H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
  }
  return H.map((x) => x.toString(16).padStart(8, '0')).join('');
}

const pad = (n: number) => String(n).padStart(2, '0');
export const monthStart = (y: number, m: number) => `${y}-${pad(m)}-01`;
const safe = (t: string) => t.replace(/[^A-Za-z0-9._-]+/g, '-');

export const salarySlipsApi = {
  /** Is this month finalized (payroll_months)? */
  isFinalized: async (y: number, m: number): Promise<boolean> => {
    const { data } = await supabase.from('payroll_months').select('year').eq('year', y).eq('month', m).limit(1);
    return !!(data && data.length);
  },
  /** every send of a month (Admin / HR): active and replaced ones */
  forMonth: async (y: number, m: number): Promise<SlipSend[]> => {
    const { data, error } = await supabase.from('salary_slip_sends').select('*').eq('month', monthStart(y, m)).order('id', { ascending: false });
    if (error) throw error;
    const rows = (data ?? []) as SlipSend[];
    const ids = [...new Set(rows.map((r) => r.sent_by).filter(Boolean))] as string[];
    if (ids.length) {
      const { data: ps } = await supabase.from('profiles').select('id, full_name').in('id', ids);
      const nm = new Map((ps ?? []).map((p: any) => [p.id, p.full_name]));
      rows.forEach((r) => { r.sender = r.sent_by ? nm.get(r.sent_by) : undefined; });
    }
    return rows;
  },
  /** my own sent slips, newest first (RLS: only mine) */
  mine: async (): Promise<SlipSend[]> => {
    const { data, error } = await supabase.from('salary_slip_sends').select('*').order('month', { ascending: false }).order('id', { ascending: false });
    if (error) throw error;
    return (data ?? []) as SlipSend[];
  },
  /** make the slip PDF with the existing slip code, keep it in the private bucket and record the send */
  send: async (userId: string, slip: SlipData, slipNo: string) => {
    const bytes = await salarySlipBytes({ ...slip, slipNo });
    const sha = sha256Hex(bytes);
    const path = `${userId}/${slip.year}-${pad(slip.month)}/${safe(slipNo)}.pdf`;
    const up = await supabase.storage.from('salary-slips').upload(path, bytes, { contentType: 'application/pdf', upsert: false });
    if (up.error && !/already exists|Duplicate/i.test(up.error.message)) throw up.error;
    const { error } = await supabase.rpc('record_slip_sent', { p_user: userId, p_month: monthStart(slip.year, slip.month), p_slip_no: slipNo, p_net: slip.net, p_path: path, p_sha256: sha });
    if (error) throw error;
  },
  remind: async (ids: number[]) => {
    const { data, error } = await supabase.rpc('send_slip_reminder', { p_ids: ids });
    if (error) throw error;
    return Number(data ?? 0);
  },
  answer: async (id: number, answer: string) => { const { error } = await supabase.rpc('answer_slip_query', { p_id: id, p_answer: answer }); if (error) throw error; },
  opened: async (id: number) => { await supabase.rpc('mark_slip_opened', { p_id: id }); },
  downloaded: async (id: number) => { await supabase.rpc('mark_slip_downloaded', { p_id: id }); },
  acknowledge: async (id: number) => {
    const device = Platform.OS === 'web' ? (typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 120) : 'web') : Platform.OS;
    const { error } = await supabase.rpc('acknowledge_slip', { p_id: id, p_device: device }); if (error) throw error;
  },
  query: async (id: number, text: string) => { const { error } = await supabase.rpc('raise_slip_query', { p_id: id, p_text: text }); if (error) throw error; },
  /** the SAVED PDF (not a new one): a short-lived link; the employee can only get his own folder (storage policy) */
  fileUrl: async (path: string, downloadName?: string) => {
    const { data, error } = await supabase.storage.from('salary-slips').createSignedUrl(path, 3600, downloadName ? { download: downloadName } : undefined);
    if (error) throw error;
    return data.signedUrl;
  },
};

const dt = (iso: string | null) => { if (!iso) return ''; const d = new Date(new Date(iso).getTime() + 330 * 60000); return `${pad(d.getUTCDate())}-${pad(d.getUTCMonth() + 1)}-${d.getUTCFullYear()} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`; };
export const fmtDT = dt;

/** cvp_salary_slip_proof_<yyyy-mm>.xlsx : Arial, coloured header row, frozen header */
export async function downloadProofXlsx(y: number, m: number, rows: { empId: string; name: string; send?: SlipSend }[]) {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Proof');
  const head = ws.addRow(['Emp ID', 'Name', 'Month', 'Net pay', 'Slip no', 'Sent on', 'Sent by', 'Opened on', 'Downloaded on', 'Acknowledged on', 'Query', 'Answer']);
  head.eachCell((c: any) => { c.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF06253F' } }; c.alignment = { vertical: 'middle' }; });
  ws.views = [{ state: 'frozen', ySplit: 1 }];
  const ml = `${['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][m - 1]} ${y}`;
  rows.forEach(({ empId, name, send: s }) => {
    const r = ws.addRow([empId, name, ml, s ? Number(s.net_pay) : '', s?.slip_no ?? 'Not sent', dt(s?.sent_at ?? null), s?.sender ?? '', dt(s?.opened_at ?? null), dt(s?.downloaded_at ?? null), s?.acknowledged_at ? dt(s.acknowledged_at) : s ? 'Not yet' : '', s?.query_text ?? '', s?.query_answer ?? '']);
    r.eachCell((c: any) => { c.font = { name: 'Arial', size: 10 }; });
    r.getCell(4).numFmt = '#,##0.00';
  });
  [10, 28, 16, 12, 24, 18, 22, 18, 18, 20, 36, 36].forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  const buf: ArrayBuffer = await wb.xlsx.writeBuffer();
  await saveXlsxData(`cvp_salary_slip_proof_${y}-${pad(m)}.xlsx`, buf, true);
}
