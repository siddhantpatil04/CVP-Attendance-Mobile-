import { rh, withCompanyCode } from './companies';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Platform, Share } from 'react-native';
import { savedNotice, saveToDownloads } from './saveDownload';

export function cell(v: unknown): string {
  if (v === null || v === undefined) return '';
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function toCsv(rows: Record<string, unknown>[], columns?: string[]): string {
  const cols = columns ?? (rows[0] ? Object.keys(rows[0]) : []);
  return [cols.join(','), ...rows.map((r) => cols.map((c) => cell(r[c])).join(','))].join('\n');
}

/** Saves a CSV file and opens the phone's share sheet (WhatsApp, Email, Drive, Excel...) */
export async function shareCsv(fileName: string, rows: Record<string, unknown>[], columns?: string[]) {
  return shareCsvText(fileName, toCsv(rows, columns));
}

/** Same as shareCsv, for a CSV that is already written as text (a report with blocks and several heading rows) */
export async function shareCsvText(fileNameIn: string, text: string) {
  const fileName = withCompanyCode(fileNameIn);
  // The BOM makes Excel read Marathi / Hindi text correctly
  // the company name is the heading of every report (a CSV cannot carry the logo)
  const csv = '\uFEFF' + (/^C\. V\. PATIL/.test(text) ? text : `C. V. PATIL & ASSOCIATES\n${text}`);

  // Web / installed web app: download the file directly
  if (Platform.OS === 'web') {
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return;
  }

  try {
    const shareIt = async () => {
      const file = new File(Paths.cache, fileName);
      if (file.exists) file.delete();
      file.create();
      file.write(csv);
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: 'text/csv', dialogTitle: fileName, UTI: 'public.comma-separated-values-text' });
    };
    // Android: into the Download folder (file manager), with a Share button; otherwise the share sheet as before
    if (await saveToDownloads(fileName, csv, 'text/csv')) { savedNotice(fileName, () => { void shareIt(); }); return; }
    await shareIt();
    return;
  } catch {
    /* fall back to plain-text share below */
  }
  await Share.share({ title: fileName, message: csv });
}

/** A plain text file exactly as given (no BOM, no heading line): the PF ECR file for the EPFO portal */
export async function shareTextFile(fileNameIn: string, text: string) {
  const fileName = withCompanyCode(fileNameIn);
  if (Platform.OS === 'web') {
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url; a.download = fileName;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return;
  }
  try {
    const shareIt = async () => {
      const file = new File(Paths.cache, fileName);
      if (file.exists) file.delete();
      file.create(); file.write(text);
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: 'text/plain', dialogTitle: fileName });
    };
    if (await saveToDownloads(fileName, text, 'text/plain')) { savedNotice(fileName, () => { void shareIt(); }); return; }
    await shareIt();
    return;
  } catch { /* fall back below */ }
  await Share.share({ title: fileName, message: text });
}
