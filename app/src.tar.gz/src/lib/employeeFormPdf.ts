import { COMPANY_ADDRESS, COMPANY_NAME } from '../config';
import { fmtISODate } from './time';
import { loadPdfLibs, outputPdf } from './pdf';
import { WATERMARK_H, WATERMARK_PNG, WATERMARK_W } from './watermark';

export interface EmployeeFormPdfData {
  surname: string; first_name: string; father_name: string; mother_name: string;
  date_of_birth: string; gender: string; marital_status: string;
  permanent_address: string; local_address: string; tel_no: string; cell_no: string; email: string;
  pan_no: string; aadhar_no: string; software_skills: string;
  vehicle_company: string; vehicle_no: string; license_no: string;
  bank_name: string; bank_address: string; bank_branch: string; bank_account_no: string; ifsc_code: string;
  joining_date: string; resign_date: string; uan_no: string;
  education: { degree: string; specialization: string; year: string; marks: string }[];
  family: { name: string; relation: string; contact: string }[];
}

/** Loads an image from a (signed) URL as a data URL for the PDF. Returns null when it cannot be read. */
async function imageData(url: string | null): Promise<{ data: string; type: 'JPEG' | 'PNG' } | null> {
  if (!url) return null;
  try {
    const blob = await (await fetch(url)).blob();
    const type = blob.type.includes('png') ? 'PNG' : blob.type.includes('jpeg') || blob.type.includes('jpg') ? 'JPEG' : null;
    if (!type) return null;   // PDF / Word / webp files are not drawn
    const data: string = await new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result));
      fr.onerror = () => reject(fr.error);
      fr.readAsDataURL(blob);
    });
    return { data, type };
  } catch { return null; }
}

/** The company "Employee Form" as a 2-page A4 PDF: the same structure and numbering as the paper form (CVPA-Employee Form). */
export async function downloadEmployeeFormPdf(f: EmployeeFormPdfData, opts: { photoUrl: string | null; uploaded: string[]; fileName: string }) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  (doc as any).cvpHasCompany = true;
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
  const L = 14; const R = W - 14;
  const BLACK: [number, number, number] = [20, 20, 20];

  const header = () => {
    try { doc.addImage(WATERMARK_PNG, 'PNG', L, 8, 24, 24 * (WATERMARK_H / WATERMARK_W)); } catch { /* no logo */ }
    doc.setTextColor(...BLACK);
    doc.setFont('times', 'bold'); doc.setFontSize(15); doc.text(COMPANY_NAME + ',', 58, 17);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.text(COMPANY_ADDRESS, 58, 23, { maxWidth: R - 58 });
    doc.setDrawColor(...BLACK); doc.setLineWidth(0.3); doc.line(8, 34, W - 8, 34);
  };
  const footer = () => {
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.setTextColor(...BLACK);
    doc.text(COMPANY_NAME + ',', W / 2, H - 14, { align: 'center' });
    doc.setFont('helvetica', 'normal'); doc.text(COMPANY_ADDRESS, W / 2, H - 10, { align: 'center' });
  };
  // an address is saved as 6 lines (house, street, area, city, state, PIN): printed as one text
  const oneLine = (a: string) => (a ?? '').split('\n').map((x) => x.trim()).filter(Boolean).join(', ');
  const val = (v: string) => (v ?? '').trim();

  /** "label ______" : bold label, the value written on the line from x to xEnd */
  const field = (label: string, value: string, x: number, y: number, xEnd: number) => {
    doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(...BLACK);
    doc.text(label, x, y);
    const x0 = x + doc.getTextWidth(label + ' ');
    doc.setDrawColor(90, 90, 90); doc.setLineWidth(0.2); doc.line(x0, y + 1, xEnd, y + 1);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5);
    doc.text(val(value), x0 + 1.5, y - 0.4, { maxWidth: xEnd - x0 - 2 });
  };
  /** a label followed by a value that may run over two ruled lines */
  const twoLines = (label: string, value: string, y: number) => {
    doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(...BLACK);
    doc.text(label, L, y);
    const x0 = L + doc.getTextWidth(label + ' ');
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5);
    const text = val(value);
    const first: string = (doc.splitTextToSize(text, R - x0 - 2) as string[])[0] ?? '';
    const rest = text.slice(first.length).trim();
    const second: string[] = rest ? (doc.splitTextToSize(rest, R - L - 2) as string[]) : [];
    doc.setDrawColor(90, 90, 90); doc.setLineWidth(0.2);
    doc.line(x0, y + 1, R, y + 1); doc.line(L, y + 9, R, y + 9);
    doc.text(first, x0 + 1.5, y - 0.4);
    doc.text(second[0] ?? '', L + 1.5, y + 7.6);
  };
  const tbl = {
    theme: 'grid' as const,
    styles: { fontSize: 9, cellPadding: 2, textColor: BLACK, lineColor: BLACK, lineWidth: 0.2, halign: 'left' as const, valign: 'middle' as const, minCellHeight: 8 },
    headStyles: { fillColor: [255, 255, 255] as [number, number, number], textColor: BLACK, fontStyle: 'normal' as const, halign: 'center' as const },
    margin: { left: L, right: L },
  };

  // ---------------------------------------------------------------- page 1
  header();
  doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(...BLACK);
  doc.text('EMPLOYEE FORM', W / 2 - 22, 52);
  const tw = doc.getTextWidth('EMPLOYEE FORM'); doc.setLineWidth(0.4); doc.line(W / 2 - 22, 53.2, W / 2 - 22 + tw, 53.2);

  // photo box (passport size 3.5 x 4.5 cm)
  const px = R - 40; const py = 40;
  doc.setDrawColor(...BLACK); doc.setLineWidth(0.3); doc.rect(px, py, 40, 45);
  const photo = await imageData(opts.photoUrl);
  if (photo) { try { doc.addImage(photo.data, photo.type, px + 2.5, py + 0.5, 35, 44); } catch { /* keep the empty box */ } }
  else {
    doc.setFont('helvetica', 'normal'); doc.setFontSize(6.5);
    doc.text('Please paste a passport\nsize (3.5cm x 4.5cm)\ncolored photograph here', px + 20, py + 20, { align: 'center' });
  }

  doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.text('(*** Marked are compulsory.)', W / 2 - 5, 91, { align: 'center' });

  // 1 full name: values on the line, captions under it
  let y = 100;
  doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.text('1.. FULL NAME:', L, y);
  const nx = L + 36;
  doc.setDrawColor(90, 90, 90); doc.setLineWidth(0.2); doc.line(nx, y + 1, R, y + 1);
  const cols = [nx, nx + 38, nx + 76, nx + 118];
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5);
  [f.surname, f.first_name, f.father_name, f.mother_name].forEach((v, i) => doc.text(val(v), cols[i], y - 0.4, { maxWidth: 36 }));
  doc.setFontSize(8.5);
  ['Surname', 'First Name', 'Father Name', 'Mother Name'].forEach((c, i) => doc.text(c, cols[i] + 4, y + 5));

  y = 116; field('2.. Date of Birth:', f.date_of_birth ? fmtISODate(f.date_of_birth) : '', L, y, 100); field('3.. Gender:', f.gender, 110, y, R);
  y = 127; field('4.. Marital Status:', f.marital_status, L, y, 100);
  twoLines('5.. Permanent Address***:', oneLine(f.permanent_address), 139);
  twoLines('6.. Local Address***:', oneLine(f.local_address), 159);
  y = 178; field('7.. Tel. Phone No.:', f.tel_no, L, y, 105); field('8.. Cell No***.:', f.cell_no, 112, y, R);
  y = 188; field('9.. E-mail Address:', f.email, L, y, 105);
  y = 197; field('10.. PAN Card No.:', f.pan_no, L, y, 105);
  y = 206; field('11.. Aadhar Card No.:', f.aadhar_no, L, y, 105);

  doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.text('12.. Educational Qualification:', L, 215);
  autoTable(doc, {
    ...tbl, startY: 217,
    head: [['Sr.No.', 'Degree', 'Specialization', 'Year of Passing', '% Marks / Grade']],
    body: f.education.map((e, i) => [String(i + 1), e.degree, val(e.specialization), val(e.year), val(e.marks)]),
    columnStyles: { 0: { cellWidth: 16, halign: 'center' }, 1: { cellWidth: 44 }, 2: { cellWidth: 42 }, 3: { cellWidth: 40 } },
  });
  y = (doc as any).lastAutoTable.finalY + 10;
  twoLines('13.. Software Skills:', val(f.software_skills), y);
  footer();

  // ---------------------------------------------------------------- page 2
  doc.addPage(); header();
  doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(...BLACK); doc.text('14.. Family Details:', L, 48);
  autoTable(doc, {
    ...tbl, startY: 55,
    head: [['Sr. No.', 'Family Member', 'Relation with you', 'Contact Number']],
    body: f.family.map((m, i) => [String(i + 1), val(m.name), val(m.relation), val(m.contact)]),
    columnStyles: { 0: { cellWidth: 20, halign: 'center' }, 1: { cellWidth: 70 }, 2: { cellWidth: 48 } },
  });
  y = (doc as any).lastAutoTable.finalY + 12;

  const list = (title: string, rows: [string, string][]) => {
    doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(...BLACK); doc.text(title, L, y); y += 7;
    rows.forEach(([lab, v], i) => { field(`${i + 1}. ${lab}`, v, L + 6, y, R); y += 8; });
    y += 3;
  };
  list('15.. Vehicle Details:', [['Vehicle Company Name:', f.vehicle_company], ['Vehicle No.:', f.vehicle_no], ['License No.:', f.license_no]]);
  list('16.. Bank Details***:', [['Bank Name:', f.bank_name], ['Address of Bank .:', f.bank_address], ['Branch Name :', f.bank_branch], ['Account No.:', f.bank_account_no], ['IFSC Code:', f.ifsc_code]]);
  y += 3; field('17..Joining Date***:', f.joining_date ? fmtISODate(f.joining_date) : '', L, y, R);

  y += 12;
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.text('Declaration,', L, y);
  doc.text('I hereby declare the information furnished by me is correct. I bear the responsibility for all above information.', L, y + 7, { maxWidth: R - L });
  doc.setDrawColor(...BLACK); doc.setLineWidth(0.5); doc.line(R - 65, y + 32, R, y + 32);
  doc.setFontSize(8.5); doc.text("Applicant's Name & Signature", R - 60, y + 37);

  y += 46;
  doc.setFont('helvetica', 'bold'); doc.setFontSize(14); doc.text('Compulsory Required Documents -', L, y);
  doc.setLineWidth(0.5); doc.line(L, y + 1.5, L + doc.getTextWidth('Compulsory Required Documents -'), y + 1.5);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5);
  ['PAN Card Copy', 'Aadhar Card Copy', 'Bank Passbook-1st page Copy', 'Photo Attach'].forEach((t, i) => doc.text(`${i + 1}. ${t}`, L + 6, y + 9 + i * 7));
  doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
  doc.text('(Note for Soft Copy-Please Send you Document in printable format with proper naming i.e.', L + 6, y + 40);
  doc.text('Your Name _Document name)', L + 8, y + 46);
  footer();

  await outputPdf(opts.fileName, doc);
}
