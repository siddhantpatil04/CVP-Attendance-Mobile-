import { COMPANY_ADDRESS, COMPANY_NAME } from '../config';
import { fmtISODate } from './time';
import { loadPdfLibs, outputPdf } from './pdf';

export interface EmployeeFormPdfData {
  surname: string; first_name: string; father_name: string; mother_name: string;
  date_of_birth: string; gender: string; marital_status: string;
  permanent_address: string; local_address: string; tel_no: string; cell_no: string; email: string;
  pan_no: string; aadhar_no: string; software_skills: string;
  vehicle_company: string; vehicle_no: string; license_no: string;
  bank_name: string; bank_address: string; bank_branch: string; bank_account_no: string; ifsc_code: string;
  joining_date: string; resign_date: string; uan_no: string;
  education: { degree: string; specialization: string; year: string; marks: string }[];
  family: { name: string; relation: string; contact: string }[];
}

const NAVY: [number, number, number] = [16, 42, 69];
const LINE: [number, number, number] = [200, 211, 224];
const dash = (v: string) => (v && v.trim() ? v.trim() : '-');

/** Loads an image from a (signed) URL as a data URL for the PDF. Returns null when it cannot be read. */
async function imageData(url: string | null): Promise<{ data: string; type: 'JPEG' | 'PNG' } | null> {
  if (!url) return null;
  try {
    const blob = await (await fetch(url)).blob();
    const type = blob.type.includes('png') ? 'PNG' : blob.type.includes('jpeg') || blob.type.includes('jpg') ? 'JPEG' : null;
    if (!type) return null;   // PDF / Word / webp files are not drawn
    const data: string = await new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result));
      fr.onerror = () => reject(fr.error);
      fr.readAsDataURL(blob);
    });
    return { data, type };
  } catch { return null; }
}

/** The company "Employee Form" as an A4 PDF: same sections and order as the paper form. */
export async function downloadEmployeeFormPdf(f: EmployeeFormPdfData, opts: { photoUrl: string | null; uploaded: string[]; fileName: string }) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const L = 12; const R = W - 12;

  // header
  doc.setFont('helvetica', 'bold'); doc.setFontSize(14); doc.setTextColor(...NAVY);
  doc.text(COMPANY_NAME, L, 14);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(110, 124, 140);
  doc.text(COMPANY_ADDRESS, L, 19, { maxWidth: R - L });
  doc.setDrawColor(...LINE); doc.line(L, 23, R, 23);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(...NAVY);
  doc.text('EMPLOYEE FORM', W / 2 - 15, 33);

  // photo box 35 x 45 mm (as on the paper form)
  const px = R - 35; const py = 27;
  doc.setDrawColor(...NAVY); doc.rect(px, py, 35, 45);
  const photo = await imageData(opts.photoUrl);
  if (photo) { try { doc.addImage(photo.data, photo.type, px + 0.5, py + 0.5, 34, 44); } catch { /* keep the empty box */ } }
  else {
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.setTextColor(110, 124, 140);
    doc.text('Passport size photo\n3.5 cm x 4.5 cm', px + 17.5, py + 22, { align: 'center' });
  }

  const full = [f.surname, f.first_name, f.father_name, f.mother_name].map((x) => x.trim()).filter(Boolean).join('  ');
  // an address is saved as 6 lines (house, street, area, city, state, PIN): printed on one line
  const oneLine = (a: string) => (a ?? '').split('\n').map((x) => x.trim()).filter(Boolean).join(', ');
  const kv = (label: string, v: string): any[] => [{ content: label, styles: { fontStyle: 'bold', cellWidth: 38 } }, dash(v)];
  const base = {
    theme: 'grid' as const,
    styles: { fontSize: 8.5, cellPadding: 1.8, textColor: [32, 57, 81] as [number, number, number], lineColor: LINE, lineWidth: 0.2, overflow: 'linebreak' as const },
    headStyles: { fillColor: NAVY, textColor: 255, fontStyle: 'bold' as const },
    margin: { left: L, right: L },
  };

  // 1-4 personal (left of the photo)
  autoTable(doc, {
    ...base, startY: 40, margin: { left: L, right: W - (px - 4) },
    body: [
      kv('1. Full name', full),
      kv('   Surname', f.surname), kv('   First name', f.first_name), kv('   Father name', f.father_name), kv('   Mother name', f.mother_name),
      kv('2. Date of birth', f.date_of_birth ? fmtISODate(f.date_of_birth) : ''),
      kv('3. Gender', f.gender), kv('4. Marital status', f.marital_status),
    ],
  });
  let y = Math.max((doc as any).lastAutoTable.finalY, py + 45) + 4;

  autoTable(doc, {
    ...base, startY: y,
    body: [
      kv('5. Permanent address *', oneLine(f.permanent_address)),
      kv('6. Local address *', oneLine(f.local_address)),
      kv('7. Tel. phone no.', f.tel_no), kv('8. Cell no. *', f.cell_no),
      kv('9. E-mail address', f.email),
      kv('10. PAN card no.', f.pan_no), kv('11. Aadhar card no.', f.aadhar_no),
    ],
  });
  y = (doc as any).lastAutoTable.finalY + 4;

  // 12 education
  autoTable(doc, {
    ...base, startY: y,
    head: [['12. Educational qualification', 'Specialization', 'Year of passing', '% marks / grade']],
    body: f.education.map((e) => [e.degree, dash(e.specialization), dash(e.year), dash(e.marks)]),
  });
  y = (doc as any).lastAutoTable.finalY + 4;
  autoTable(doc, { ...base, startY: y, body: [kv('13. Software skills', f.software_skills)] });
  y = (doc as any).lastAutoTable.finalY + 4;

  // 14 family
  autoTable(doc, {
    ...base, startY: y,
    head: [['14. Family details', 'Family member', 'Relation with you', 'Contact number']],
    body: f.family.map((m, i) => [String(i + 1), dash(m.name), dash(m.relation), dash(m.contact)]),
    columnStyles: { 0: { cellWidth: 38 } },
  });
  y = (doc as any).lastAutoTable.finalY + 4;

  // 15 vehicle, 16 bank, 17 joining
  autoTable(doc, {
    ...base, startY: y,
    body: [
      kv('15. Vehicle company', f.vehicle_company), kv('    Vehicle no.', f.vehicle_no), kv('    License no.', f.license_no),
    ],
  });
  y = (doc as any).lastAutoTable.finalY + 4;
  autoTable(doc, {
    ...base, startY: y,
    body: [
      kv('16. Bank name *', f.bank_name), kv('    Address of bank', f.bank_address), kv('    Branch name', f.bank_branch),
      kv('    Account no.', f.bank_account_no), kv('    IFSC code', f.ifsc_code),
      kv('17. Joining date *', f.joining_date ? fmtISODate(f.joining_date) : ''),
      kv('    Resign date', f.resign_date ? fmtISODate(f.resign_date) : ''),
      kv('    UAN no. (PF)', f.uan_no),
    ],
  });
  y = (doc as any).lastAutoTable.finalY + 6;

  // declaration + signature (new page when there is no room)
  const H = doc.internal.pageSize.getHeight();
  if (y > H - 55) { doc.addPage(); y = 20; }
  doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(...NAVY);
  doc.text('Declaration', L, y);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(32, 57, 81);
  doc.text('I hereby declare the information furnished by me is correct. I bear the responsibility for all above information.', L, y + 5, { maxWidth: R - L });
  doc.setDrawColor(...NAVY); doc.line(R - 65, y + 24, R, y + 24);
  doc.setFontSize(8); doc.text("Applicant's Name & Signature", R - 65, y + 28);

  doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(...NAVY);
  doc.text('Compulsory required documents', L, y + 38);
  const have = new Set(opts.uploaded);
  const docs: [string, string][] = [['pan', 'PAN card copy'], ['aadhar', 'Aadhar card copy'], ['bank', 'Bank passbook - 1st page copy'], ['photo', 'Photo attached']];
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(32, 57, 81);
  docs.forEach(([k, label], i) => doc.text(`${i + 1}. ${label}  -  ${have.has(k) ? 'Attached' : 'Not attached'}`, L, y + 44 + i * 5));

  await outputPdf(opts.fileName, doc);
}
