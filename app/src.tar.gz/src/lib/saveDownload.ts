import AsyncStorage from '@react-native-async-storage/async-storage';
import { Directory } from 'expo-file-system';
import { Alert, Linking, Platform } from 'react-native';

/**
 * Android: downloaded documents and reports are saved in a folder inside the phone's "Download" folder, so they show up in the
 * file manager. Android does not let an app write straight into the top level of Download without a native package, so the first
 * time the employee makes (or picks) a folder inside Download, e.g. "CVP Attendance"; the app remembers it and saves there after that.
 * Other platforms (web, iPhone) keep their normal download / share sheet.
 */
const KEY = 'cvp_download_dir';
const DOWNLOAD_ROOT = 'content://com.android.externalstorage.documents/document/primary%3ADownload';

const MIME: Record<string, string> = {
  pdf: 'application/pdf', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', csv: 'text/csv', txt: 'text/plain',
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', doc: 'application/msword',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xls: 'application/vnd.ms-excel',
};
export const mimeOf = (name: string) => MIME[(name.split('.').pop() ?? '').toLowerCase()] ?? 'application/octet-stream';

async function pickDir(): Promise<Directory> {
  Alert.alert('Choose a folder in Download', 'Next, open "Download", tap "Create new folder", name it "CVP Attendance" (or choose a folder you already made) and tap "Use this folder". Your downloads will be saved there.');
  let dir: Directory;
  try { dir = await Directory.pickDirectoryAsync(DOWNLOAD_ROOT); } catch { dir = await Directory.pickDirectoryAsync(); }
  await AsyncStorage.setItem(KEY, dir.uri).catch(() => {});
  return dir;
}
async function savedDir(): Promise<Directory | null> {
  try { const u = await AsyncStorage.getItem(KEY); if (u) { const d = new Directory(u); if (d.exists) return d; } } catch { /* pick again */ }
  return null;
}

/** Saves the bytes / text in the Download folder (Android). Returns the file's address, or null when it was not saved (other platforms, or the folder was not chosen). */
export async function saveToDownloads(fileName: string, data: Uint8Array | string, mime?: string): Promise<string | null> {
  if (Platform.OS !== 'android') return null;
  const m = mime ?? mimeOf(fileName);
  const write = (dir: Directory) => { const f = dir.createFile(fileName, m); f.write(data); return f.uri; };
  try {
    const dir = (await savedDir()) ?? (await pickDir());
    try { return write(dir); }
    catch { return write(await pickDir()); }   // the saved folder is no longer allowed: choose again
  } catch { return null; }                      // cancelled: the caller falls back to the share sheet
}

/** "Saved in Download/..." message; with a Share button for WhatsApp, e-mail ... */
export function savedNotice(fileName: string, share?: () => void) {
  Alert.alert('Saved', `${fileName} was saved in your Download folder (CVP Attendance). Open it from the file manager.`,
    share ? [{ text: 'OK' }, { text: 'Share', onPress: share }] : [{ text: 'OK' }]);
}

/** Documents: Android -> download the file into the Download folder; everywhere else -> open the link as before */
export async function downloadOrOpen(url: string, fileName: string | undefined, save: boolean) {
  if (Platform.OS !== 'android' || !save || !fileName) { await Linking.openURL(url); return; }
  const res = await fetch(url);
  if (!res.ok) throw new Error('The file could not be downloaded.');
  const bytes = new Uint8Array(await res.arrayBuffer());
  const uri = await saveToDownloads(fileName, bytes);
  if (uri) savedNotice(fileName);
  else await Linking.openURL(url);   // the folder was not chosen: the browser download as before
}
