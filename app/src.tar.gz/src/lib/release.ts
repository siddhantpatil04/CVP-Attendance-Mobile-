import AsyncStorage from '@react-native-async-storage/async-storage';
import { useCallback, useEffect, useRef } from 'react';
import { Platform } from 'react-native';
import { useRealtime } from './realtime';
import { supabase } from './supabase';

const SEEN_KEY = 'cvp_seen_release';
/** Set when everyone was signed out by an update; the Login screen shows it once */
export const UPDATE_NOTICE_KEY = 'cvp_update_notice';

export interface ReleaseInfo { release: number; note: string | null; published_at: string }

export async function fetchRelease(): Promise<ReleaseInfo | null> {
  const { data, error } = await supabase.from('app_release').select('release, note, published_at').eq('id', 1).maybeSingle();
  if (error || !data) return null;
  return data as ReleaseInfo;
}

/** Admin: tell every phone and desktop that a new version is out (they sign out and load it) */
export async function publishUpdate(note: string) {
  const { data, error } = await supabase.rpc('admin_publish_update', { p_note: note || null });
  if (error) throw error;
  return data as ReleaseInfo;
}

/** Downloads the newest code: a page reload on the web, an over-the-air update (EAS Update) on a phone */
async function loadNewCode() {
  if (Platform.OS === 'web') {
    // A service worker is serving the latest files network-first, so a reload is enough
    if (typeof window !== 'undefined') window.location.reload();
    return;
  }
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Updates = require('expo-updates');
    if (Updates.isEnabled) {
      const check = await Updates.checkForUpdateAsync();
      if (check.isAvailable) {
        await Updates.fetchUpdateAsync();
        await Updates.reloadAsync();
      }
    }
  } catch {
    /* running in Expo Go / development: nothing to download */
  }
}

/**
 * When the Admin publishes an update:
 *   signed-in screens (phones and desktops) sign out, download the new version and show the Login screen.
 * People who are signed out when it happens just remember the new number, so they are not signed out again after logging in.
 */
export function useReleaseWatcher(signedIn: boolean, signOut: () => Promise<void>) {
  const busy = useRef(false);
  const signedInRef = useRef(signedIn);
  signedInRef.current = signedIn;

  const check = useCallback(async () => {
    if (busy.current) return;
    busy.current = true;
    try {
      const r = await fetchRelease();
      if (!r) return;
      let seen: number | null = null;
      try { const v = await AsyncStorage.getItem(SEEN_KEY); seen = v === null ? null : Number(v); } catch { /* ignore */ }
      if (seen === null || Number.isNaN(seen) || !signedInRef.current) {
        await AsyncStorage.setItem(SEEN_KEY, String(r.release)).catch(() => {});
        return;
      }
      if (r.release > seen) {
        await AsyncStorage.setItem(SEEN_KEY, String(r.release)).catch(() => {});
        await AsyncStorage.setItem(UPDATE_NOTICE_KEY, r.note || 'update').catch(() => {});
        await signOut();
        await loadNewCode();
      }
    } finally {
      busy.current = false;
    }
  }, [signOut]);

  useEffect(() => { check(); }, [check, signedIn]);
  // live (a new release arrives while the app is open) + whenever the app comes back to the front / the network returns
  useRealtime('app-release', [{ table: 'app_release' }], () => { check(); });
}
