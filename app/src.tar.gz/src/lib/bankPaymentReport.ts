import * as XLSX from 'xlsx-js-style';
import { loadPdfLibs, outputPdf } from './pdf';
import { saveXlsxData } from './xlsx';

/** One person to pay: the same columns as the bank's bulk payment sheet */
export interface BankPayRow {
  name: string; mode: 'NEFT' | 'FT'; account: string; ifsc: string; amount: number; mobile: string; email: string;
}
export interface BankPayMeta {
  company: string;      // C V Patil & Associates
  paymentDate: string;  // dd-mm-yyyy
  debitAccount: string;
  product: string;
}

const NAVY: [number, number, number] = [31, 56, 100];
const LINE: [number, number, number] = [180, 198, 231];
const ZEBRA: [number, number, number] = [244, 247, 252];
const TOTAL: [number, number, number] = [230, 236, 246];
const INK: [number, number, number] = [30, 30, 30];

const money = (n: number) => Math.round(n).toLocaleString('en-US');
const modes = (rows: BankPayRow[]) => {
  const n = (m: string) => rows.filter((r) => r.mode === m).length;
  return [n('NEFT') ? `NEFT: ${n('NEFT')}` : '', n('FT') ? `FT: ${n('FT')}` : ''].filter(Boolean).join(', ');
};
const subtitle = (m: BankPayMeta) =>
  `ICICI Bank bulk payment (sheet: NEFT)  |  Payment date: ${m.paymentDate}  |  Debit A/c: ${m.debitAccount}  |  Product: ${m.product}`;
const HEAD = ['Sr', 'Beneficiary name', 'Mode', 'Beneficiary A/c No', 'IFSC', 'Amount (Rs.)', 'Mobile', 'Email'];

/** "Salary Payment Report": title, bank line, summary box, then the beneficiary table with a TOTAL row (landscape A4) */
export async function bankPaymentPdf(fileName: string, meta: BankPayMeta, rows: BankPayRow[]) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const total = rows.reduce((s, r) => s + r.amount, 0);

  doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(17);
  doc.text(`${meta.company} — Salary Payment Report`, W / 2, 20, { align: 'center' });
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(90, 90, 90);
  doc.text(subtitle(meta), W / 2, 27, { align: 'center' });

  const boxW = 190;
  autoTable(doc, {
    startY: 32,
    head: [['Beneficiaries', 'Total amount (Rs.)', 'Payment modes']],
    body: [[String(rows.length), money(total), modes(rows)]],
    theme: 'grid',
    tableWidth: boxW,
    margin: { left: (W - boxW) / 2 },
    styles: { fontSize: 9.5, halign: 'center', textColor: INK, lineColor: LINE, lineWidth: 0.2, cellPadding: 2 },
    headStyles: { fillColor: [232, 239, 250], textColor: INK, fontStyle: 'bold' },
  });
  const afterBox = (doc as any).lastAutoTable.finalY as number;

  const body: any[][] = rows.map((r, i) => [
    String(i + 1), r.name, r.mode, r.account, r.ifsc, { content: money(r.amount), styles: { halign: 'right' } }, r.mobile, r.email,
  ]);
  const bold = { fontStyle: 'bold' as const, fillColor: TOTAL };
  body.push([
    { content: '', styles: bold }, { content: 'TOTAL', styles: bold }, { content: '', styles: bold }, { content: '', styles: bold }, { content: '', styles: bold },
    { content: money(total), styles: { ...bold, halign: 'right' } }, { content: '', styles: bold }, { content: '', styles: bold },
  ]);

  autoTable(doc, {
    startY: afterBox + 7,
    head: [HEAD],
    body,
    theme: 'grid',
    styles: { fontSize: 8, cellPadding: 1.6, textColor: INK, lineColor: LINE, lineWidth: 0.15, valign: 'middle', halign: 'left' },
    headStyles: { fillColor: NAVY, textColor: [255, 255, 255], fontStyle: 'bold', halign: 'left' },
    alternateRowStyles: { fillColor: ZEBRA },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' }, 1: { cellWidth: 58 }, 2: { cellWidth: 15, halign: 'center' }, 3: { cellWidth: 40 },
      4: { cellWidth: 30 }, 5: { cellWidth: 26 }, 6: { cellWidth: 28 },
    },
    margin: { left: 10, right: 10, top: 14, bottom: 14 },
  });

  const n = doc.getNumberOfPages();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(140, 140, 140);
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.text('Source: CVP Attendance payroll', 10, H - 6);
    doc.text(`Page ${i}`, W - 10, H - 6, { align: 'right' });
  }
  await outputPdf(fileName, doc);
}

/** The same report as an Excel sheet: the amounts and the totals are formulas, so edits keep adding up */
export async function bankPaymentXlsx(fileName: string, meta: BankPayMeta, rows: BankPayRow[]) {
  const ws: XLSX.WorkSheet = {};
  const hex = (c: [number, number, number]) => c.map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase();
  const thin = { style: 'thin', color: { rgb: hex(LINE) } } as const;
  const border = { top: thin, bottom: thin, left: thin, right: thin };
  const font = (bold = false, sz = 10, rgb = '1E1E1E') => ({ name: 'Arial', sz, bold, color: { rgb } });
  const put = (r: number, c: number, cell: XLSX.CellObject) => { ws[XLSX.utils.encode_cell({ r, c })] = cell; };
  const txt = (v: string, s: object = {}): XLSX.CellObject => ({ t: 's', v, s: { font: font(), ...s } } as XLSX.CellObject);
  const num = (v: number, s: object = {}): XLSX.CellObject => ({ t: 'n', v, z: '#,##0', s: { font: font(), ...s } } as XLSX.CellObject);
  const fx = (f: string, v: number, s: object = {}): XLSX.CellObject => ({ t: 'n', f, v, z: '#,##0', s: { font: font(), ...s } } as XLSX.CellObject);
  const centre = { horizontal: 'center', vertical: 'center' } as const;
  const COLS = 8;
  const merges: XLSX.Range[] = [];
  const span = (r: number, c1 = 0, c2 = COLS - 1) => merges.push({ s: { r, c: c1 }, e: { r, c: c2 } });
  const total = rows.reduce((s, r) => s + r.amount, 0);

  put(0, 0, txt(`${meta.company} — Salary Payment Report`, { font: font(true, 15), alignment: centre })); span(0);
  put(1, 0, txt(subtitle(meta), { font: font(false, 9, '5A5A5A'), alignment: centre })); span(1);

  // summary box (columns B-D)
  const sh = { font: font(true), fill: { fgColor: { rgb: 'E8EFFA' } }, border, alignment: centre };
  const sv = { font: font(false, 11), border, alignment: centre };
  put(3, 1, txt('Beneficiaries', sh)); put(3, 2, txt('Total amount (Rs.)', sh)); put(3, 3, txt('Payment modes', sh));
  put(4, 1, num(rows.length, sv));
  const first = 7;                                    // first data row (0-based) -> Excel row 8
  const last = first + rows.length - 1;
  put(4, 2, fx(`SUM(F${first + 1}:F${last + 1})`, total, sv));
  put(4, 3, txt(modes(rows), sv));

  // beneficiary table
  const hs = { font: font(true, 10, 'FFFFFF'), fill: { fgColor: { rgb: hex(NAVY) } }, border, alignment: { horizontal: 'left', vertical: 'center' } };
  HEAD.forEach((h, c) => put(6, c, txt(h, hs)));
  rows.forEach((r, i) => {
    const fill = i % 2 ? { fill: { fgColor: { rgb: hex(ZEBRA) } } } : {};
    const cs = { border, ...fill, alignment: { horizontal: 'left', vertical: 'center' } };
    const mid = { border, ...fill, alignment: centre };
    put(first + i, 0, num(i + 1, mid));
    put(first + i, 1, txt(r.name, cs));
    put(first + i, 2, txt(r.mode, mid));
    put(first + i, 3, txt(r.account, cs));      // text, so long account numbers keep their leading zeros
    put(first + i, 4, txt(r.ifsc, cs));
    put(first + i, 5, num(r.amount, { border, ...fill, alignment: { horizontal: 'right', vertical: 'center' } }));
    put(first + i, 6, txt(r.mobile, cs));
    put(first + i, 7, txt(r.email, cs));
  });
  const t = last + 1;
  const ts = { border, fill: { fgColor: { rgb: hex(TOTAL) } }, font: font(true), alignment: { horizontal: 'left', vertical: 'center' } };
  for (let c = 0; c < COLS; c++) put(t, c, txt('', ts));
  put(t, 1, txt('TOTAL', ts));
  put(t, 5, fx(`SUM(F${first + 1}:F${last + 1})`, total, { ...ts, alignment: { horizontal: 'right', vertical: 'center' } }));

  ws['!ref'] = XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: t, c: COLS - 1 } });
  ws['!merges'] = merges;
  ws['!cols'] = [6, 32, 18, 22, 14, 14, 14, 30].map((wch) => ({ wch }));
  (ws as any)['!pageSetup'] = { orientation: 'landscape', paperSize: 9, fitToWidth: 1, fitToHeight: 0 };
  (ws as any)['!sheetPr'] = { pageSetUpPr: { fitToPage: true } };
  (ws as any)['!views'] = [{ state: 'frozen', xSplit: 0, ySplit: 7 }];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Salary Payment');
  await saveXlsxData(fileName, XLSX.write(wb, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer);
}
