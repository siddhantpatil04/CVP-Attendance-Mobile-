import { Platform, StyleSheet, Text, TextInput } from 'react-native';
import { APP_FONT } from '../rnshim/fontFamily';

/**
 * Web / Windows desktop app: Arial Black as the DEFAULT font of all text (see fontFamily.ts).
 * Text that sets its own font (the icons) keeps it.
 * Phone builds do the same through rn-shim.tsx (React Native's Text is not patchable there).
 */
function withDefaultFont(Component: any) {
  const original = Component?.render;
  if (!original || Component.__fontPatched || !APP_FONT) return;
  Component.__fontPatched = true;
  Component.render = function render(props: any, ref: any) {
    const own = StyleSheet.flatten(props?.style);
    const next = own && own.fontFamily ? props : { ...props, style: [{ fontFamily: APP_FONT }, props?.style] };
    return original.call(this, next, ref);
  };
}

if (Platform.OS === 'web') {
  withDefaultFont(Text);
  withDefaultFont(TextInput);

  // the plain HTML controls (drop-down lists, date boxes) use the same font
  if (typeof document !== 'undefined' && APP_FONT) {
    const css = `body, select, option, input, textarea, button { font-family: ${APP_FONT}; }`;
    const el = document.createElement('style');
    el.setAttribute('data-app-font', '1');
    el.appendChild(document.createTextNode(css));
    document.head.appendChild(el);
  }
}
