import { rh } from './companies';
import { api } from './api';
import type { DailyReport, DailyReportSite, LeaveRequest, MonthDay } from './api';
import { cell as csvCell, shareCsvText } from './csv';
import { imageDataUrl } from './imageData';
import { PX_PER_MM, rasterizeJobs, RasterJob, RasterResult } from './marathiRaster';
import { fmtISODate, fmtTime12, istDateISO, MONTHS } from './time';
import { Platform } from 'react-native';
import { loadPdfLibs, outputPdf } from './pdf';
import { saveXlsxData } from './xlsx';
import { cityCmp, cityOfSite, natCmp } from './siteCity';
import { getAttendanceKind, isOfficeEmployee, officeNameSet } from './attendanceKind';

const AMBER: [number, number, number] = [255, 192, 0];
const t = (v: unknown) => (v === null || v === undefined ? '' : String(v));
const times = (a: string | null, b: string | null) => (a || b ? `${a ? fmtTime12(a) : '-'} - ${b ? fmtTime12(b) : '-'}` : '');
export const dailyReportNo = (id: number) => `DR-${String(id).padStart(6, '0')}`;

/** The fields that are translated to English for Admin */
export type DailyField = 'sub_work' | 'work_going_on' | 'work_description' | 'comment_1' | 'comment_2' | 'comment_3' | 'remarks';
/** English text of a field: the Admin's correction, else the automatic English, else the text itself (it was already English) */
export const englishOf = (s: DailyReportSite, f: DailyField): string => {
  const tr = s.translations?.[f];
  return (tr ? (tr.corrected_en || tr.en) : '') || (s[f] ?? '') || '';
};
/** Language of the original text of an entry (null = written in English) */
export const writtenIn = (s: DailyReportSite): string | null => Object.values(s.translations ?? {})[0]?.lang ?? null;

/** One row per site entry: used by the CSV export and the PDF table */
export function dailyReportRows(reports: DailyReport[], withOriginal = false): Record<string, unknown>[] {
  return reports.flatMap((r): Record<string, unknown>[] => {
    const sites = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
    const base = {
      Date: fmtISODate(r.report_date),
      'Report No': dailyReportNo(r.id),
      Employee: r.employee?.full_name ?? '',
      'Employee ID': r.employee?.username ?? '',
      Status: r.status,
      Submitted: r.submitted_at ? `${fmtISODate(r.submitted_at.slice(0, 10))} ${fmtTime12(r.submitted_at)}` : '',
      'GPS distance (km)': r.gps_km ?? 'GPS not available',
    };
    const review = { 'Review note': r.review_note ?? '' };
    if (!sites.length) return [{ ...base, '#': '', Site: '', 'Arrival - Departure': '', 'Sub work': '', 'Work description': '', 'Comment 1': '', 'Comment 2': '', 'Comment 3': '', Remarks: '', ...review }];
    return sites.map((s) => ({
      ...base, '#': s.seq, Site: s.site_name, 'Arrival - Departure': times(s.arrived_at, s.departed_at),
      'Sub work': englishOf(s, 'sub_work'), 'Work description': englishOf(s, 'work_description'),
      'Comment 1': englishOf(s, 'comment_1'), 'Comment 2': englishOf(s, 'comment_2'), 'Comment 3': englishOf(s, 'comment_3'), Remarks: englishOf(s, 'remarks'), ...review,
      ...(withOriginal ? { 'Sub work (original)': s.sub_work ?? '', 'Work description (original)': s.work_description ?? '',
        'Comment 1 (original)': s.comment_1 ?? '', 'Comment 2 (original)': s.comment_2 ?? '', 'Comment 3 (original)': s.comment_3 ?? '', 'Remarks (original)': s.remarks ?? '' } : {}),
    }));
  });
}


/**
 * Marathi / Hindi (Devanagari) cannot be typed by the PDF's built-in font (it printed garbage). On the web / desktop the browser draws
 * the text with its own font (so the letters join correctly) and the picture is placed in the table cell. The phone has no canvas:
 * there the cell says the text is Marathi and points to the Excel / CSV.
 */
const INDIC = /[\u0900-\u097F]/;
const PX = 8;   // picture pixels per mm
function indicPicture(text: string, widthMm: number): { img: string; hMm: number } | null {
  if (Platform.OS !== 'web' || typeof document === 'undefined') return null;
  try {
    const c = document.createElement('canvas');
    const ctx = c.getContext('2d'); if (!ctx) return null;
    const font = `${Math.round(2.5 * PX)}px "Nirmala UI","Noto Sans Devanagari","Mangal","Kohinoor Devanagari",sans-serif`;
    ctx.font = font;
    const maxW = widthMm * PX; const lines: string[] = [];
    for (const para of text.split(/\r?\n/)) {
      let cur = '';
      for (const word of para.split(' ')) {
        const tryLine = cur ? `${cur} ${word}` : word;
        if (ctx.measureText(tryLine).width <= maxW) { cur = tryLine; continue; }
        if (cur) lines.push(cur);
        cur = word;
        while (ctx.measureText(cur).width > maxW && cur.length > 1) {   // a very long word is cut to fit
          let n = cur.length - 1; while (n > 1 && ctx.measureText(cur.slice(0, n)).width > maxW) n--;
          lines.push(cur.slice(0, n)); cur = cur.slice(n);
        }
      }
      lines.push(cur);
    }
    const lh = Math.round(3.4 * PX);
    c.width = Math.max(1, Math.round(maxW)); c.height = lines.length * lh + 4;
    const g = c.getContext('2d')!; g.font = font; g.fillStyle = '#141414'; g.textBaseline = 'top';
    lines.forEach((l, i) => g.fillText(l, 0, i * lh + 2));
    return { img: c.toDataURL('image/png'), hMm: c.height / PX };
  } catch { return null; }
}
/** A table cell: plain text, or (Marathi / Hindi) a picture of the text */
function bodyCell(text: string, colMm: number, pad = 1.6): unknown {
  if (!INDIC.test(text)) return text;
  const p = indicPicture(text, colMm - 2 * pad);
  if (!p) return { content: '(Marathi text - see the Excel / CSV)', styles: { fontStyle: 'italic', textColor: [120, 120, 120] } };
  return { content: '', img: p.img, ih: p.hMm, iw: colMm - 2 * pad, styles: { minCellHeight: p.hMm + 2 * pad } };
}
/** One page (or more) per report: employee, date, visit sequence, GPS distance, every site entry and the review note */
export async function dailyReportsPdf(fileName: string, subtitle: string, reports: DailyReport[], withOriginal = false) {
  // with withOriginal the written (Marathi / Hindi) text is printed under the English text, like the CSV does
  const field = (s: DailyReportSite, f: DailyField) => { const en = englishOf(s, f); const o = s[f] ?? ''; return withOriginal && o && o.trim() !== en.trim() ? (en ? `${en}\n${o}` : o) : en; };
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const CW = [8, 38, 26, 40, 54, 34, 25, 25, 27];   // fixed column widths (mm): the Marathi pictures are made to fit them

  const header = () => {
    doc.setTextColor(20, 20, 20); doc.setFont('helvetica', 'bold');
    (doc as any).cvpHasCompany = true;
    doc.setFontSize(12); doc.text(rh().title, W / 2, 10, { align: 'center' });
    doc.setFontSize(10); doc.text('Daily Report', W / 2, 16, { align: 'center' });
    doc.setFontSize(9); doc.text(subtitle, W / 2, 21.5, { align: 'center' });
  };

  reports.forEach((r, i) => {
    if (i > 0) doc.addPage();
    header();
    const sites = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
    const seq = sites.filter((s) => s.arrived_at).map((s, k) => `${k + 1}. ${s.site_name} (${times(s.arrived_at, s.departed_at)})`).join('   ');
    let y = 36;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10);
    doc.text(`${r.employee?.full_name ?? ''} (${r.employee?.username ?? ''})   |   ${fmtISODate(r.report_date)}   |   ${dailyReportNo(r.id)}   |   ${r.status}`, 10, y);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9);
    y += 5.5;
    doc.text(`Submitted: ${r.submitted_at ? `${fmtISODate(r.submitted_at.slice(0, 10))} ${fmtTime12(r.submitted_at)}` : 'not submitted'}   |   GPS distance: ${r.gps_km != null ? r.gps_km + ' km' : 'GPS not available'}`, 10, y);
    if (seq) { y += 5; const lines = doc.splitTextToSize(`Visit sequence: ${seq}`, W - 20); doc.text(lines, 10, y); y += (lines.length - 1) * 4.2; }
    autoTable(doc, {
      startY: y + 4,
      head: [['#', 'Site', 'Arrival - Departure', 'Sub work', 'Work description', 'Comment 1', 'Comment 2', 'Comment 3', 'Remarks']],
      body: sites.map((s) => [s.seq, bodyCell(s.site_name ?? '', CW[1]), times(s.arrived_at, s.departed_at), bodyCell(field(s, 'sub_work'), CW[3]), bodyCell(field(s, 'work_description'), CW[4]), bodyCell(field(s, 'comment_1'), CW[5]), bodyCell(field(s, 'comment_2'), CW[6]), bodyCell(field(s, 'comment_3'), CW[7]), bodyCell(field(s, 'remarks'), CW[8])]) as any,
      theme: 'grid',
      columnStyles: Object.fromEntries(CW.map((w, i) => [i, { cellWidth: w }])),
      didDrawCell: (d: any) => {
        const raw = d.cell?.raw;
        if (d.section === 'body' && raw && raw.img) { try { doc.addImage(raw.img, 'PNG', d.cell.x + 1.6, d.cell.y + 1.6, raw.iw, raw.ih); } catch { /* skip */ } }
      },
      styles: { fontSize: 7, cellPadding: 1.6, overflow: 'linebreak', textColor: [20, 20, 20], lineColor: [60, 60, 60], lineWidth: 0.15 },
      headStyles: { fillColor: AMBER, textColor: [20, 20, 20], fontStyle: 'bold', halign: 'center' },
      margin: { left: 10, right: 10, top: 36, bottom: 12 },
      didDrawPage: () => { header(); },
    });
    if (r.review_note) {
      const endY = ((doc as any).lastAutoTable?.finalY ?? y) + 6;
      doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
      doc.text(`Review note: ${r.review_note}`, 10, Math.min(endY, doc.internal.pageSize.getHeight() - 14));
    }
  });

  const n = doc.getNumberOfPages(); const h = doc.internal.pageSize.getHeight();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(140, 152, 166);
  for (let p = 1; p <= n; p++) {
    doc.setPage(p);
    doc.text(`Generated ${new Date().toLocaleDateString('en-GB')}`, 10, h - 6);
    doc.text(`Page ${p} of ${n}`, W - 10, h - 6, { align: 'right' });
  }
  await outputPdf(fileName, doc);
}

// =====================================================================================================================
// Site-wise monthly PDF: blocks "Name of the Site - X   Name of the Employee - Y", six columns, Remarks + Comments in ONE column,
// "Photo of the Site" (the photos attached to the Daily Report). Marathi / Hindi is printed from a browser picture (see above).
// =====================================================================================================================
type Seg = { t: string; b?: boolean };
const PAD = 1.6;
const SW_CW = [12, 22, 38, 76, 73, 54];   // site-wise PDF column widths (275 mm)

/** Text with optional bold parts drawn by the browser (correct Devanagari joining), as a picture for a table cell */
const rasterCache = new Map<string, RasterResult>();   // phone: pictures of Marathi cells, drawn by the hidden WebView
const rasterKey = (paras: Seg[][], widthMm: number) => `${Math.round(widthMm * 10)}|${JSON.stringify(paras)}`;
function richPicture(paras: Seg[][], widthMm: number): { img: string; hMm: number } | null {
  if (Platform.OS !== 'web') return rasterCache.get(rasterKey(paras, widthMm)) ?? null;
  if (typeof document === 'undefined') return null;
  try {
    const c = document.createElement('canvas');
    const ctx = c.getContext('2d'); if (!ctx) return null;
    const fam = '"Nirmala UI","Noto Sans Devanagari","Mangal","Kohinoor Devanagari",sans-serif';
    const px = Math.round(2.5 * PX);
    const fontOf = (b?: boolean) => `${b ? 'bold ' : ''}${px}px ${fam}`;
    const maxW = widthMm * PX;
    type Piece = { t: string; b: boolean; w: number };
    const lines: Piece[][] = [];
    for (const para of paras) {
      let line: Piece[] = []; let lw = 0;
      for (const seg of para) {
        ctx.font = fontOf(seg.b);
        for (const w of seg.t.split(/(\s+)/)) {
          if (w === '') continue;
          const ww = ctx.measureText(w).width;
          if (lw + ww > maxW && line.length && w.trim() !== '') { lines.push(line); line = []; lw = 0; }
          if (line.length === 0 && /^\s+$/.test(w)) continue;
          line.push({ t: w, b: !!seg.b, w: ww }); lw += ww;
        }
      }
      lines.push(line);
    }
    const lh = Math.round(3.4 * PX);
    c.width = Math.max(1, Math.round(maxW)); c.height = Math.max(lh, lines.length * lh) + 4;
    const g = c.getContext('2d')!; g.fillStyle = '#141414'; g.textBaseline = 'top';
    lines.forEach((ln, i) => { let x = 0; ln.forEach((p) => { g.font = fontOf(p.b); g.fillText(p.t, x, i * lh + 2); x += p.w; }); });
    return { img: c.toDataURL('image/png'), hMm: c.height / PX };
  } catch { return null; }
}
const picCell = (p: { img: string; hMm: number }, colMm: number) => ({ content: '', img: p.img, ih: p.hMm, iw: colMm - 2 * PAD, styles: { minCellHeight: p.hMm + 2 * PAD } });
const MARATHI_NOTE = { content: '(Marathi text - see the Excel / CSV)', styles: { fontStyle: 'italic', textColor: [120, 120, 120] } };

/** Plain text stays real PDF text; Marathi / Hindi becomes a picture (web / desktop) */
export function siteTextCell(text: string, colMm: number): unknown {
  const s = (text ?? '').replace(/[\u00a0\u2007\u2009\u202f]/g, ' ').trim();
  if (!s) return '';
  if (!INDIC.test(s)) return s;
  const p = richPicture(s.split(/\r?\n/).map((l) => [{ t: l }]), colMm - 2 * PAD);
  return p ? picCell(p, colMm) : MARATHI_NOTE;
}
const NOISE = /^(na|n\/a|n\.a\.?|nil|none|-+|\.+|_+)$/i;
/** Remark + Comment 1..3 in one cell: only the filled ones, numbered 1, 2, 3 in order, the label in bold */
function remarksCell(items: { label: string; text: string }[], colMm: number): unknown {
  if (!items.length) return '-';
  const paras: Seg[][] = items.flatMap((i) => i.text.split(/\r?\n/).map((l, k) => (k === 0 ? [{ t: `${i.label} `, b: true }, { t: l }] : [{ t: l }])));
  const p = richPicture(paras, colMm - 2 * PAD);
  if (p) return picCell(p, colMm);
  if (items.some((i) => INDIC.test(i.text))) return MARATHI_NOTE;
  return items.map((i) => `${i.label} ${i.text}`).join('\n');
}
const weekday3 = (iso: string) => new Date(`${iso}T12:00:00Z`).toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' });
const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;

/** up to 2 image photos per report, as small JPEG data URLs (null = could not be loaded) */
async function loadReportPhotos(reports: DailyReport[], download = true): Promise<Map<number, (string | null)[]>> {
  const ids = reports.map((r) => r.id);
  const rows: { report_id: number; file_path: string; file_name: string | null }[] = [];
  for (let i = 0; i < ids.length; i += 100) rows.push(...await api.dailyReportPhotosFor(ids.slice(i, i + 100)).catch(() => []));
  const isImage = (r: { file_path: string; file_name: string | null }) => /\.(jpe?g|png|webp)$/i.test(r.file_name || r.file_path);
  const per = new Map<number, string[]>();
  for (const r of rows) { if (!isImage(r)) continue; const l = per.get(r.report_id) ?? []; if (l.length < 2) { l.push(r.file_path); per.set(r.report_id, l); } }
  const paths = download ? [...new Set([...per.values()].flat())] : [];
  const got = new Map<string, string | null>();
  for (let i = 0; i < paths.length; i += 6) {
    await Promise.all(paths.slice(i, i + 6).map(async (p) => {
      try { got.set(p, await imageDataUrl(await api.dailyReportPhotoUrl(p), 300)); } catch { got.set(p, null); }
    }));
  }
  const out = new Map<number, (string | null)[]>();
  per.forEach((l, id) => out.set(id, l.map((p) => (download ? got.get(p) ?? null : p))));
  return out;
}


/** Phone: finds every Marathi / Hindi cell of the site-wise PDF and draws it as a picture (cached for the PDF code) */
async function prepareMarathi(blocks: SiteWiseEntry[][]) {
  const jobs: RasterJob[] = []; const seen = new Set<string>();
  const add = (paras: Seg[][], widthMm: number) => {
    const key = rasterKey(paras, widthMm);
    if (rasterCache.has(key) || seen.has(key)) return;
    seen.add(key); jobs.push({ id: key, paras, widthMm });
  };
  const plain = (s: string) => s.replace(/[\u00a0\u2007\u2009\u202f]/g, ' ').trim();
  for (const list of blocks) {
    for (const e of list) {
      const sub = plain(e.sub); const desc = plain(e.desc);
      if (INDIC.test(sub)) add(sub.split(/\r?\n/).map((l) => [{ t: l }]), SW_CW[2] - 2 * PAD);
      if (INDIC.test(desc)) add(desc.split(/\r?\n/).map((l) => [{ t: l }]), SW_CW[3] - 2 * PAD);
      if (e.items.some((i) => INDIC.test(i.text))) {
        add(e.items.flatMap((i) => i.text.split(/\r?\n/).map((l, k) => (k === 0 ? [{ t: `${i.label} `, b: true }, { t: l }] : [{ t: l }]))), SW_CW[4] - 2 * PAD);
      }
    }
  }
  for (let i = 0; i < jobs.length; i += 60) {
    const got = await rasterizeJobs(jobs.slice(i, i + 60));
    for (const [id, r] of Object.entries(got)) if (r) rasterCache.set(id, r);
  }
}
/** One entry of the site-wise Daily Report (one site row of one report) */
export interface SiteWiseEntry {
  city: string; site: string; emp: string; empId: string; date: string; seq: number; reportId: number; status: string; sub: string; desc: string;
  items: { label: string; text: string }[]; remark: string; comments: string[];
}
/** City -> Site -> Employee tree of the blocks (cities A-Z with "Other" last, sites A-Z, employees A-Z) */
export interface CityGroup { city: string; sites: { site: string; blocks: SiteWiseEntry[][] }[] }
export function groupByCity(blocks: SiteWiseEntry[][]): CityGroup[] {
  const cities = new Map<string, Map<string, SiteWiseEntry[][]>>();
  for (const b of blocks) {
    const c = cities.get(b[0].city) ?? new Map<string, SiteWiseEntry[][]>();
    c.set(b[0].site, [...(c.get(b[0].site) ?? []), b]);
    cities.set(b[0].city, c);
  }
  return [...cities.entries()].sort((a, b) => cityCmp(a[0], b[0])).map(([city, sm]) => ({
    city,
    sites: [...sm.entries()].sort((a, b) => natCmp(a[0], b[0])).map(([site, bl]) => ({ site, blocks: bl.sort((x, y) => natCmp(x[0].emp, y[0].emp)) })),
  }));
}
/** Blocks by site then employee: the same arrangement for the PDF and the CSV (city / site filters optional) */
function buildSiteWiseBlocks(reports: DailyReport[], photos: Map<number, (string | null)[]>, site?: string, city?: string): SiteWiseEntry[][] {
  type Entry = SiteWiseEntry;
  const entries: Entry[] = [];
  const wantSite = site?.trim().toLowerCase();
  for (const r of reports) {
    const emp = r.employee?.full_name ?? 'Employee'; const empId = r.employee?.username ?? '';
    const sites = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
    const mk = (site: string, s?: DailyReportSite): Entry => {
      const items: { label: string; text: string }[] = [];
      const ok = (v: string | null | undefined) => { const x = (v ?? '').trim(); return x && !NOISE.test(x) ? x : ''; };
      if (s && ok(s.remarks)) items.push({ label: 'Remark:', text: ok(s.remarks) });
      let n = 0;
      for (const c of [s?.comment_1, s?.comment_2, s?.comment_3]) if (ok(c)) { n += 1; items.push({ label: `Comment ${n}:`, text: ok(c) }); }
      return {
        city: cityOfSite(site), site, emp, empId, date: r.report_date, seq: s?.seq ?? 0, reportId: r.id, status: r.status,
        sub: (s?.sub_work ?? '').trim(), desc: ((s?.work_description ?? '') || (s?.work_going_on ?? '')).trim(), items,
        remark: ok(s?.remarks), comments: [ok(s?.comment_1), ok(s?.comment_2), ok(s?.comment_3)],
      };
    };
    if (sites.length === 0) { if (!wantSite && (photos.get(r.id)?.length ?? 0) > 0) entries.push(mk('(site not entered)')); continue; }
    for (const s of sites) {
      const site = (s.site_name ?? '').trim() || '(site not entered)';
      if (wantSite && site.toLowerCase() !== wantSite) continue;
      if (city && cityOfSite(site) !== city) continue;
      entries.push(mk(site, s));
    }
  }
  if (entries.length === 0) throw new Error('No daily report entries match the filters.');

  const blocks = new Map<string, Entry[]>();
  for (const e of entries) { const k = `${e.site}\u0000${e.empId || e.emp}\u0000${e.emp}`; blocks.set(k, [...(blocks.get(k) ?? []), e]); }
  return [...blocks.values()].sort((a, b) => cityCmp(a[0].city, b[0].city) || natCmp(a[0].site, b[0].site) || natCmp(a[0].emp, b[0].emp));
}

/** Counts of a list of employee blocks: employees (once each) and distinct reports */
export function blockStats(blocks: SiteWiseEntry[][]) {
  const emps = new Set(blocks.map((b) => b[0].empId || b[0].emp));
  const reps = new Set(blocks.flatMap((b) => b.map((e) => e.reportId)));
  return { emps: emps.size, reps: reps.size };
}
const plural = (n: number, w: string) => `${n} ${w.replace('(s)', n === 1 ? '' : 's')}`;

// =====================================================================================================================
// Daily Report downloads (PDF / Excel / CSV): SIMPLE layout - heading, then SITE -> EMPLOYEE -> table. Sites are ordered by city A-Z
// then site A-Z (the city is only used for the order, it is not printed). No index, no city rows, no counts, no filters line.
// =====================================================================================================================
export interface DailyDownloadOpts {
  /** first heading line without the site / employee: "Daily Report - Monthly" | "Daily Report - 18-11-2026" | "Daily Report - 10-11-2026 to 18-11-2026" */ base: string;
  /** second heading line: "November 2026 (01-11-2026 to 30-11-2026)" | "Wednesday, 18-11-2026" */ periodLine: string;
  /** period in the footer: "November 2026" | "18-11-2026" | "10-11-2026 to 18-11-2026" */ period: string;
  reports: DailyReport[]; site?: string; city?: string; employee?: string;
}
const baseTitle = (o: DailyDownloadOpts) => o.base;
/** Line 1 of the heading: one site -> + site name; one employee -> + employee name */
export const dailyHeading = (o: DailyDownloadOpts) => { const who = o.site?.trim() || o.employee?.trim(); return who ? `${baseTitle(o)} - ${who}` : baseTitle(o); };
const dailyPeriodLine = (o: DailyDownloadOpts) => o.periodLine;
const sitesOf = (blocks: SiteWiseEntry[][]) => groupByCity(blocks).flatMap((c) => c.sites);
const empTitle = (f: SiteWiseEntry) => `Name of the Employee - ${f.emp}${f.empId ? ` (${f.empId})` : ''}`;

/** PDF: A4 landscape, 12 mm margins. Site row (light blue) -> employee row (light yellow) -> orange heading -> rows, oldest first. */
export async function dailyReportSiteWisePdf(fileName: string, opts: DailyDownloadOpts) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const photos = await loadReportPhotos(opts.reports);
  const blocks = buildSiteWiseBlocks(opts.reports, photos, opts.site, opts.city);
  // phone: draw every Marathi cell as a picture in the hidden WebView first (the PDF code below only places the pictures)
  if (Platform.OS !== 'web') await prepareMarathi(blocks);
  const sites = sitesOf(blocks);

  const X0 = 12; const TOP = 12; const BOT = 14; const BAR = 6.5;
  const CW = SW_CW; const TW = CW.reduce((a, b) => a + b, 0);   // 273 mm = A4 landscape - 2 x 12 mm
  const INK: [number, number, number] = [20, 20, 20];
  const SKY: [number, number, number] = [221, 235, 247]; const YEL: [number, number, number] = [255, 242, 204];
  const HEAD = ['Sr. No.', 'Date', 'Sub Work', 'Description of Work', 'Remarks & Comments', 'Photo of the Site'];
  const cleanTxt = (s: string) => s.replace(/[    ]/g, ' ');

  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
  const siteBar = (yy: number, text: string) => {
    doc.setFillColor(...SKY); doc.setDrawColor(0, 0, 0); doc.setLineWidth(0.2);
    doc.rect(X0, yy, TW, BAR, 'FD');
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5);
    doc.text(cleanTxt(text), X0 + 2, yy + BAR / 2, { baseline: 'middle' });
  };

  // heading: only these two lines
  doc.setTextColor(...INK); doc.setFont('helvetica', 'bold');
  doc.setFontSize(12); doc.text(cleanTxt(dailyHeading(opts)), W / 2, TOP + 4, { align: 'center' });
  doc.setFontSize(10); doc.text(cleanTxt(dailyPeriodLine(opts)), W / 2, TOP + 10, { align: 'center' });
  let y = TOP + 16;

  sites.forEach((s) => {
    if (y + BAR + BAR + 6 + 30 > H - BOT) { doc.addPage(); y = TOP; }
    siteBar(y, `Name of the Site - ${s.site}`); y += BAR;
    s.blocks.forEach((list) => {
      list.sort((a, b) => a.date.localeCompare(b.date) || a.seq - b.seq);
      if (y + BAR + 6 + 30 > H - BOT) { doc.addPage(); siteBar(TOP, `Name of the Site - ${s.site} (continued)`); y = TOP + BAR; }
      const startPage = doc.getNumberOfPages();
      const body = list.map((e, i) => {
        const ph = photos.get(e.reportId) ?? [];
        const ok = ph.filter((x): x is string => !!x);
        const photoCell = ph.length === 0
          ? { content: 'No photo', styles: { textColor: [130, 130, 130], fontSize: 6.5, halign: 'center' } }
          : ok.length === 0 ? { content: 'Photo not available', styles: { textColor: [130, 130, 130], fontSize: 6.5, halign: 'center' } }
          : { content: '', photos: ok, styles: { minCellHeight: 28 } };
        return [String(i + 1), dmy(e.date), siteTextCell(e.sub, CW[2]), siteTextCell(e.desc, CW[3]), remarksCell(e.items, CW[4]), photoCell] as any[];
      });
      const colStyles: Record<number, any> = {};
      CW.forEach((w, i) => { colStyles[i] = { cellWidth: w, halign: i < 2 ? 'center' : 'left' }; });
      autoTable(doc, {
        startY: y, theme: 'grid', showHead: 'everyPage',
        // the employee row is ABOVE the column heading; both repeat on a new page
        head: [
          [{ content: cleanTxt(empTitle(list[0])), colSpan: 6, styles: { fillColor: YEL, textColor: INK, fontStyle: 'bold', halign: 'left', fontSize: 8.5, cellPadding: 1.8 } }],
          HEAD,
        ],
        body,
        styles: { font: 'helvetica', fontSize: 7.5, cellPadding: PAD, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', overflow: 'linebreak' },
        headStyles: { fillColor: [255, 192, 0], textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle', fontSize: 7.5 },
        columnStyles: colStyles,
        margin: { left: X0, right: X0, top: TOP + BAR, bottom: BOT },
        rowPageBreak: 'avoid',
        didDrawPage: (d: any) => { if (d.pageNumber > startPage) siteBar(TOP, `Name of the Site - ${s.site} (continued)`); },
        didDrawCell: (d: any) => {
          if (d.section !== 'body') return;
          const raw = d.cell?.raw;
          if (raw && raw.img) { try { doc.addImage(raw.img, 'PNG', d.cell.x + PAD, d.cell.y + PAD, raw.iw, raw.ih); } catch { /* skip */ } return; }
          if (raw && Array.isArray(raw.photos)) {
            const arr: string[] = raw.photos; const n = arr.length; const gap = 2;
            const cw = d.cell.width - 4; const ch = d.cell.height - 4;
            const bw = n === 1 ? Math.min(cw, 34) : (cw - gap) / 2; const bh = n === 1 ? Math.min(ch, 23.5) : Math.min(ch, 20);
            arr.forEach((src, k) => {
              try {
                const p = doc.getImageProperties(src); const sc = Math.min(bw / p.width, bh / p.height);
                const w = p.width * sc; const h = p.height * sc;
                const x0 = d.cell.x + 2 + (n === 1 ? (cw - w) / 2 : k * (bw + gap) + (bw - w) / 2);
                doc.addImage(src, src.startsWith('data:image/png') ? 'PNG' : 'JPEG', x0, d.cell.y + (d.cell.height - h) / 2, w, h);
              } catch { /* one picture that cannot be placed never stops the PDF */ }
            });
          }
        },
      });
      y = ((doc as any).lastAutoTable?.finalY ?? y) + 3;
    });
    y += 3;
  });

  const n = doc.getNumberOfPages();
  const foot = `${baseTitle(opts)} · ${opts.site?.trim() ? `${opts.site.trim()} · ` : ''}${opts.period}`;
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.text(cleanTxt(foot), X0, H - 6);
    doc.text(`Page ${i} of ${n}`, W - X0, H - 6, { align: 'right' });
  }
  await outputPdf(fileName, doc);
}

/** signed links of the photos of each report (several in one cell are separated by a new line in the CSV) */
async function photoLinks(reports: DailyReport[]): Promise<Map<number, string[]>> {
  const paths = await loadReportPhotos(reports, false);   // storage paths
  const links = new Map<string, string>();
  const all = [...new Set([...paths.values()].flat().filter((p): p is string => !!p))];
  for (let i = 0; i < all.length; i += 6) {
    await Promise.all(all.slice(i, i + 6).map(async (p) => { try { links.set(p, await api.dailyReportPhotoUrl(p)); } catch { /* no link */ } }));
  }
  const out = new Map<number, string[]>();
  paths.forEach((l, id) => out.set(id, l.map((p) => (p ? links.get(p) : undefined)).filter((u): u is string => !!u)));
  return out;
}

/** Excel: ONE sheet "Daily Report", same Site -> Employee -> table structure as the PDF, plus a Day column; photos are "Open photo" links */
export async function dailyReportSiteWiseXlsx(fileName: string, opts: DailyDownloadOpts) {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  const photos = await loadReportPhotos(opts.reports, false);
  const blocks = buildSiteWiseBlocks(opts.reports, photos, opts.site, opts.city);
  const links = await photoLinks(opts.reports);
  const sites = sitesOf(blocks);
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Daily Report');
  const WIDTHS = [8, 12, 8, 24, 46, 44, 16]; const N = WIDTHS.length;
  WIDTHS.forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  const BLACK = { argb: 'FF000000' }; const thin = { style: 'thin' as const, color: BLACK };
  const BORDER = { top: thin, bottom: thin, left: thin, right: thin };
  const fill = (argb: string) => ({ type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb } });
  const font = (bold = false, argb = 'FF000000') => ({ name: 'Calibri', size: 11, bold, color: { argb } });
  let r = 0;
  const borders = () => { for (let k = 1; k <= N; k++) ws.getCell(r, k).border = BORDER; };
  const bandRow = (text: string, bg: string | null, border: boolean, center: boolean) => {
    r += 1; ws.mergeCells(r, 1, r, N);
    const c = ws.getCell(r, 1); c.value = text; c.font = font(true);
    c.alignment = { horizontal: center ? 'center' : 'left', vertical: 'middle' };
    if (bg) c.fill = fill(bg);
    if (border) borders();
    ws.getRow(r).height = 20;
  };
  bandRow(dailyHeading(opts), null, false, true);
  bandRow(dailyPeriodLine(opts), null, false, true);
  ws.views = [{ state: 'frozen', ySplit: 2 }];
  ws.pageSetup = { orientation: 'landscape', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: 0.47, right: 0.47, top: 0.47, bottom: 0.55, header: 0.2, footer: 0.25 } };
  ws.headerFooter = { oddFooter: `&L${baseTitle(opts)} · ${opts.site?.trim() ? `${opts.site.trim()} · ` : ''}${opts.period}&RPage &P of &N` };

  for (const s of sites) {
    bandRow(`Name of the Site - ${s.site}`, 'FFDDEBF7', true, false);
    for (const list of s.blocks) {
      list.sort((a, b) => a.date.localeCompare(b.date) || a.seq - b.seq);
      bandRow(empTitle(list[0]), 'FFFFF2CC', true, false);
      r += 1; ws.getRow(r).height = 22;
      ['Sr. No.', 'Date', 'Day', 'Sub Work', 'Description of Work', 'Remarks & Comments', 'Photo of the Site'].forEach((h, i) => {
        const c = ws.getCell(r, i + 1); c.value = h; c.font = font(true); c.fill = fill('FFFFC000'); c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      });
      borders();
      list.forEach((e, i) => {
        r += 1;
        const put = (col: number, v: any, left = false) => { const c = ws.getCell(r, col); c.value = v; c.font = font(); c.alignment = { horizontal: left ? 'left' : 'center', vertical: 'middle', wrapText: true }; return c; };
        put(1, i + 1); put(2, dmy(e.date)); put(3, weekday3(e.date));
        put(4, e.sub, true); put(5, e.desc, true);
        // bold labels ("Remark:", "Comment 1:") inside one cell
        const rt: any[] = [];
        e.items.forEach((it, k) => { rt.push({ text: `${it.label} `, font: { ...font(true) } }); rt.push({ text: `${it.text}${k < e.items.length - 1 ? '\n' : ''}`, font: font() }); });
        const rc = ws.getCell(r, 6); rc.value = e.items.length ? { richText: rt } : '-'; rc.font = font(); rc.alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };
        const url = (links.get(e.reportId) ?? [])[0];
        const pc = ws.getCell(r, 7);
        if (url) { pc.value = { text: 'Open photo', hyperlink: url }; pc.font = { name: 'Calibri', size: 11, color: { argb: 'FF0563C1' }, underline: true }; }
        else { pc.value = 'No photo'; pc.font = font(false, 'FF828282'); }
        pc.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
        borders();
      });
    }
  }
  const data = await wb.xlsx.writeBuffer();
  const ab = data instanceof ArrayBuffer ? data : (data as any).buffer.slice((data as any).byteOffset, (data as any).byteOffset + (data as any).byteLength);
  await saveXlsxData(fileName, ab);
}

/** CSV: a simple list, one row per report entry, same order and filters as the PDF. UTF-8 with BOM for Excel. */
export async function dailyReportSiteWiseCsv(fileName: string, opts: DailyDownloadOpts) {
  const photos = await loadReportPhotos(opts.reports, false);
  const blocks = buildSiteWiseBlocks(opts.reports, photos, opts.site, opts.city);
  const links = await photoLinks(opts.reports);
  const lines: string[] = [];
  const line = (cells: unknown[]) => lines.push(cells.map(csvCell).join(','));
  line(['Site', 'Employee', 'Emp ID', 'Date', 'Day', 'Sub Work', 'Description of Work', 'Remark', 'Comment 1', 'Comment 2', 'Comment 3', 'Photo']);
  for (const s of sitesOf(blocks)) for (const list of s.blocks) {
    list.sort((a, b) => a.date.localeCompare(b.date) || a.seq - b.seq);
    for (const e of list) {
      const ph = links.get(e.reportId) ?? [];
      line([e.site, e.emp, e.empId, dmy(e.date), weekday3(e.date), e.sub, e.desc, e.remark, e.comments[0], e.comments[1], e.comments[2], ph.length ? ph.join('\n') : '-']);
    }
  }
  await shareCsvText(fileName, lines.join('\n'));
}

// =====================================================================================================================
// MONTHLY report: City -> Site -> Employee -> ONE ROW FOR EVERY DATE of the month (1st .. last), with Sunday / Saturday holiday /
// Holiday / Leave / Half day / Absent / Present - no report / Worked at another site rows. PDF + Excel.
// Attendance, holidays (Holidays Setup incl. unpaid), weekly offs (Sunday + the Saturdays chosen per employee), approved leaves and tours
// come from get_month_attendance(): the SAME rules the app uses everywhere. Half-day leaves come from the approved leaves.
// =====================================================================================================================
export interface MonthlyOpts {
  year: number; month: number; reports: DailyReport[]; site?: string; city?: string; employee?: string;
  /** a date range inside the month (default: the whole month, 1st .. last) */
  from?: string; to?: string;
  onProgress?: (done: number, total: number) => void;
}
type StatusKind = 'sun' | 'hol' | 'leave' | 'half' | 'halfNote' | 'noreport' | 'absent' | 'future' | 'other';
type MRow = { t: 'report'; e: SiteWiseEntry } | { t: 'status'; kind: StatusKind; text: string; date: string };
interface MEmp { name: string; empId: string; rows: MRow[]; summary: string }
interface MCity { city: string; sites: { site: string; emps: MEmp[] }[] }

const ORD = ['1st', '2nd', '3rd', '4th', '5th'];
/** colours of the status rows: [fill, text] (PDF as rgb, Excel as argb) */
const STATUS_COLORS: Record<StatusKind, { fill: [number, number, number]; text: [number, number, number]; argb: string; targb: string }> = {
  sun: { fill: [217, 217, 217], text: [64, 64, 64], argb: 'FFD9D9D9', targb: 'FF404040' },
  hol: { fill: [198, 224, 180], text: [30, 77, 30], argb: 'FFC6E0B4', targb: 'FF1E4D1E' },
  leave: { fill: [189, 215, 238], text: [31, 56, 100], argb: 'FFBDD7EE', targb: 'FF1F3864' },
  half: { fill: [189, 215, 238], text: [31, 56, 100], argb: 'FFBDD7EE', targb: 'FF1F3864' },
  halfNote: { fill: [189, 215, 238], text: [31, 56, 100], argb: 'FFBDD7EE', targb: 'FF1F3864' },
  noreport: { fill: [255, 230, 153], text: [127, 96, 0], argb: 'FFFFE699', targb: 'FF7F6000' },
  absent: { fill: [248, 203, 173], text: [156, 0, 6], argb: 'FFF8CBAD', targb: 'FF9C0006' },
  future: { fill: [242, 242, 242], text: [140, 140, 140], argb: 'FFF2F2F2', targb: 'FF8C8C8C' },
  other: { fill: [237, 237, 237], text: [89, 89, 89], argb: 'FFEDEDED', targb: 'FF595959' },
};
const LEGEND: [string, StatusKind][] = [['Sunday / 2nd-4th Saturday', 'sun'], ['Holiday', 'hol'], ['Leave', 'leave'], ['Absent', 'absent'], ['Present - no report', 'noreport']];

interface MonthlyData { cities: MCity[]; from: string; to: string; entries: SiteWiseEntry[]; monthLabel: string; periodLine: string; inProgress: boolean }
async function buildMonthly(o: MonthlyOpts, photos: Map<number, (string | null)[]>): Promise<MonthlyData> {
  const mm = String(o.month).padStart(2, '0');
  const lastDay = new Date(o.year, o.month, 0).getDate();
  const first = `${o.year}-${mm}-01`; const last = `${o.year}-${mm}-${String(lastDay).padStart(2, '0')}`;
  const from = o.from && o.from > first ? o.from : first; const to = o.to && o.to < last ? o.to : last;
  const days: string[] = [];
  for (let d = Number(from.slice(8, 10)); d <= Number(to.slice(8, 10)); d++) days.push(`${o.year}-${mm}-${String(d).padStart(2, '0')}`);

  // only dates up to today: upcoming dates are never printed
  const todayIso = istDateISO();
  for (let i = days.length - 1; i >= 0; i--) if (days[i] > todayIso) days.pop();
  const blocks = buildSiteWiseBlocks(o.reports, photos, o.site, o.city);
  const tree = groupByCity(blocks);
  // user id of an employee block + every site (and date) the employee has a report line for
  const userOf = new Map<string, string>(); const onDate = new Map<string, Map<string, Set<string>>>(); const mySites = new Map<string, Set<string>>();
  for (const r of o.reports) {
    userOf.set(r.employee?.username || r.employee?.full_name || r.user_id, r.user_id);
    for (const s of r.daily_report_sites) {
      const site = (s.site_name ?? '').trim() || '(site not entered)';
      const dm = onDate.get(r.user_id) ?? new Map<string, Set<string>>(); onDate.set(r.user_id, dm);
      dm.set(r.report_date, (dm.get(r.report_date) ?? new Set<string>()).add(site));
      mySites.set(r.user_id, (mySites.get(r.user_id) ?? new Set<string>()).add(site.toLowerCase()));
    }
  }
  const ids = [...new Set(blocks.map((b) => userOf.get(b[0].empId || b[0].emp)).filter((u): u is string => !!u))];
  const att = new Map<string, Map<string, MonthDay>>();
  let done = 0; o.onProgress?.(0, ids.length);
  for (let i = 0; i < ids.length; i += 4) {
    await Promise.all(ids.slice(i, i + 4).map(async (uid) => {
      const rows = await api.monthAttendance(o.year, o.month, uid);
      att.set(uid, new Map(rows.map((x) => [String(x.day).slice(0, 10), x])));
      done += 1; o.onProgress?.(done, ids.length);
    }));
  }
  const officeNames = officeNameSet(await api.sites().catch(() => []));   // office locations: an OFFICE-kind day needs no Daily Report
  const leaves = (await api.leavesBetween(first, last).catch(() => [] as LeaveRequest[])).filter((l) => l.status === 'Approved');
  const halfOn = (uid: string, d: string) => leaves.find((l) => l.user_id === uid && l.from_day <= d && d <= l.to_day && (l.half_part || (l.units ?? 1) === 0.5));

  const entries: SiteWiseEntry[] = [];
  const cities: MCity[] = tree.map((c) => ({
    city: c.city,
    sites: c.sites.map((s) => ({
      site: s.site,
      emps: s.blocks.map((list): MEmp => {
        entries.push(...list);
        const f = list[0]; const uid = userOf.get(f.empId || f.emp) ?? '';
        const a = att.get(uid); const rows: MRow[] = [];
        const n = { rep: 0, noRep: 0, leave: 0, half: 0, absent: 0, off: 0, future: 0, other: 0, officeDay: 0 };
        for (const d of days) {
          const mine = list.filter((e) => e.date === d).sort((x, y) => x.seq - y.seq);
          const half = halfOn(uid, d);
          const halfText = half ? `Half day ${half.leave_type} - ${half.half_part === 'second' ? 'Afternoon' : 'Morning'}` : '';
          if (mine.length) {
            n.rep += 1; if (half) { n.half += 1; rows.push({ t: 'status', kind: 'halfNote', text: halfText, date: d }); }
            mine.forEach((e) => rows.push({ t: 'report', e }));
            continue;
          }
          const others = [...(onDate.get(uid)?.get(d) ?? [])].filter((x) => x !== s.site);
          if (others.length) { n.other += 1; rows.push({ t: 'status', kind: 'other', text: `Worked at ${others.join(', ')}`, date: d }); continue; }
          const x = a?.get(d);
          const st = x?.status;
          if (st === 'Upcoming') { n.future += 1; rows.push({ t: 'status', kind: 'future', text: '-', date: d }); }
          else if (half) { n.half += 1; rows.push({ t: 'status', kind: 'half', text: halfText, date: d }); }
          else if (st === 'Holiday') {
            n.off += 1; const nm = (x?.notes ?? '').replace(/^Unpaid holiday - /i, '');
            rows.push({ t: 'status', kind: 'hol', text: `Holiday${/^Unpaid holiday/i.test(x?.notes ?? '') ? ' (unpaid)' : ''} - ${nm}`, date: d });
          } else if (st === 'Leave') { n.leave += 1; rows.push({ t: 'status', kind: 'leave', text: `${x?.notes || 'Leave'} (approved)`, date: d }); }
          else if (st === 'Rest Day') {
            n.off += 1; const dd = Number(d.slice(8, 10)); const sat = new Date(`${d}T12:00:00Z`).getUTCDay() === 6;
            rows.push({ t: 'status', kind: 'sun', text: sat ? `${ORD[Math.ceil(dd / 7) - 1]} Saturday - holiday` : 'Sunday - weekly off', date: d });
          } else if ((st === 'Present' || st === 'Checked In') && getAttendanceKind({ site_name: x?.site_name, source: x?.source }, officeNames, isOfficeEmployee({ username: f.empId, site_employee: true })) === 'office') {
            n.officeDay += 1; rows.push({ t: 'status', kind: 'other', text: 'Office day - Daily Report not needed', date: d });
          } else if (st === 'Present' || st === 'Checked In') {
            const ci = (x?.site_name ?? '').trim();
            if (ci && ci.toLowerCase() !== s.site.toLowerCase() && mySites.get(uid)?.has(ci.toLowerCase())) { n.other += 1; rows.push({ t: 'status', kind: 'other', text: `Worked at ${ci}`, date: d }); }
            else { n.noRep += 1; rows.push({ t: 'status', kind: 'noreport', text: 'Present - Daily Report not submitted', date: d }); }
          } else { n.absent += 1; rows.push({ t: 'status', kind: 'absent', text: 'Absent - no check-in', date: d }); }
        }
        const extra = `${n.other ? ` | Other site ${n.other}` : ''}${n.future ? ` | Upcoming ${n.future}` : ''}${n.officeDay ? ` | Office day ${n.officeDay}` : ''}`;
        return {
          name: f.emp, empId: f.empId, rows,
          summary: `Summary ${from.slice(8, 10)}-${to.slice(8, 10)} ${MONTHS[o.month - 1].slice(0, 3)} - ${f.emp}: Reports ${n.rep} | No report ${n.noRep} | Leave ${n.leave} | Half day ${n.half} | Absent ${n.absent} | Holiday / Sunday ${n.off}${extra}`,
        };
      }),
    })),
  }));
  const monthLabel = `${MONTHS[o.month - 1]} ${o.year}`;
  const inProgress = to < last;   // the month is not completed: the period ends today
  const filt = [o.city?.trim(), o.site?.trim(), o.employee?.trim()].filter(Boolean).join(' · ');
  const periodLine = `${dmy(from)} to ${dmy(to)}${inProgress ? ' (Month in progress - up to today)' : ''}${filt ? ` · ${filt}` : ''}`;
  return { cities, from, to, entries, monthLabel, periodLine, inProgress };
}
/** "Daily Report - November 2026" */
const monthlyTitle = (m: MonthlyData) => `Daily Report - ${m.monthLabel}`;
const monthlyCounts = (c: MCity) => `${plural(c.sites.length, 'site(s)')}  |  ${plural(new Set(c.sites.flatMap((s) => s.emps.map((e) => e.empId || e.name))).size, 'employee(s)')}`;

/** PDF: A4 landscape, 12 mm margins. City bar -> site bar -> employee bar + orange heading -> one row per date -> green month summary. */
export async function dailyReportMonthlyPdf(fileName: string, o: MonthlyOpts) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const photos = await loadReportPhotos(o.reports);
  const m = await buildMonthly(o, photos);
  if (Platform.OS !== 'web') await prepareMarathi([m.entries]);   // phone: Marathi cells are drawn as pictures first

  const X0 = 12; const TOP = 12; const BOT = 14; const BAR = 6.5;
  const CW = SW_CW; const TW = CW.reduce((a, b) => a + b, 0);
  const INK: [number, number, number] = [20, 20, 20];
  const NAVY: [number, number, number] = [11, 42, 74]; const SKY: [number, number, number] = [221, 235, 247];
  const YEL: [number, number, number] = [255, 242, 204]; const GREEN: [number, number, number] = [226, 239, 218];
  const HEAD = ['Sr. No.', 'Date', 'Sub Work', 'Description of Work', 'Remarks & Comments', 'Photo'];
  const cleanTxt = (s: string) => s.replace(/[    ]/g, ' ');
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
  const bar = (yy: number, left: string, right: string, fill: [number, number, number], color: [number, number, number]) => {
    doc.setFillColor(...fill); doc.setDrawColor(0, 0, 0); doc.setLineWidth(0.2); doc.rect(X0, yy, TW, BAR, 'FD');
    doc.setTextColor(...color); doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5);
    doc.text(cleanTxt(left), X0 + 2, yy + BAR / 2, { baseline: 'middle' });
    if (right) doc.text(cleanTxt(right), X0 + TW - 2, yy + BAR / 2, { align: 'right', baseline: 'middle' });
    doc.setTextColor(...INK);
  };

  // heading + colour legend (page 1 only)
  doc.setTextColor(...INK); doc.setFont('helvetica', 'bold');
  doc.setFontSize(12); doc.text(cleanTxt(monthlyTitle(m)), W / 2, TOP + 4, { align: 'center' });
  doc.setFontSize(10); doc.text(cleanTxt(m.periodLine), W / 2, TOP + 10, { align: 'center' });
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5);
  const labels = LEGEND.map(([t, k]) => ({ t, k, w: doc.getTextWidth(t) + 7 }));
  let lx = (W - labels.reduce((a, l) => a + l.w + 4, -4)) / 2;
  labels.forEach((l) => { doc.setFillColor(...STATUS_COLORS[l.k].fill); doc.setDrawColor(90, 90, 90); doc.setLineWidth(0.15); doc.rect(lx, TOP + 13.4, 3.4, 3.4, 'FD'); doc.setTextColor(...INK); doc.text(l.t, lx + 5, TOP + 16.2); lx += l.w + 4; });
  let y = TOP + 21;

  const NEED = 2 * BAR + 48;   // city + site + employee bar + heading + a first row
  m.cities.forEach((c) => {
    const cityRight = monthlyCounts(c);
    const contBars = (site: string) => { bar(TOP, `City - ${c.city} (continued)`, '', NAVY, [255, 255, 255]); bar(TOP + BAR, `Name of the Site - ${site}`, '', SKY, INK); return TOP + 2 * BAR; };
    if (y + NEED > H - BOT) { doc.addPage(); y = TOP; }
    bar(y, `City - ${c.city}`, cityRight, NAVY, [255, 255, 255]); y += BAR;
    c.sites.forEach((s, si) => {
      if (si > 0 && y + BAR + 48 > H - BOT) { doc.addPage(); y = TOP; bar(y, `City - ${c.city} (continued)`, '', NAVY, [255, 255, 255]); y += BAR; }
      bar(y, `Name of the Site - ${s.site}`, '', SKY, INK); y += BAR;
      s.emps.forEach((e) => {
        if (y + BAR + 40 > H - BOT) { doc.addPage(); y = contBars(s.site); }
        const startPage = doc.getNumberOfPages();
        let sr = 0;
        const body: any[][] = e.rows.map((r) => {
          if (r.t === 'status') {
            const col = STATUS_COLORS[r.kind]; const numbered = r.kind !== 'halfNote';
            if (numbered) sr += 1;
            return [numbered ? String(sr) : '', numbered ? `${dmy(r.date)}\n${weekday3(r.date)}` : '',
              { content: r.text, colSpan: 4, styles: { fillColor: col.fill, textColor: col.text, halign: 'center', fontStyle: r.kind === 'future' ? 'normal' : 'bold', fontSize: 7, cellPadding: 1.2 } }];
          }
          sr += 1; const x = r.e;
          const ph = photos.get(x.reportId) ?? []; const ok = ph.filter((p): p is string => !!p);
          const photoCell = ph.length === 0 ? { content: 'No photo', styles: { textColor: [130, 130, 130], fontSize: 6.5, halign: 'center' } }
            : ok.length === 0 ? { content: 'Photo not available', styles: { textColor: [130, 130, 130], fontSize: 6.5, halign: 'center' } }
            : { content: '', photos: ok, styles: { minCellHeight: 17 } };
          return [String(sr), `${dmy(x.date)}\n${weekday3(x.date)}`, siteTextCell(x.sub, CW[2]), siteTextCell(x.desc, CW[3]), remarksCell(x.items, CW[4]), photoCell];
        });
        body.push([{ content: cleanTxt(e.summary), colSpan: 6, styles: { fillColor: GREEN, textColor: INK, fontStyle: 'bold', halign: 'left', fontSize: 7.5 } }]);
        const colStyles: Record<number, any> = {};
        CW.forEach((w, i) => { colStyles[i] = { cellWidth: w, halign: i < 2 ? 'center' : 'left' }; });
        autoTable(doc, {
          startY: y, theme: 'grid', showHead: 'everyPage',
          head: [[{ content: cleanTxt(`Name of the Employee - ${e.name}${e.empId ? ` (${e.empId})` : ''}`), colSpan: 6, styles: { fillColor: YEL, textColor: INK, fontStyle: 'bold', halign: 'left', fontSize: 8.5, cellPadding: 1.8 } }], HEAD],
          body,
          styles: { font: 'helvetica', fontSize: 7, cellPadding: 1.2, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', overflow: 'linebreak', minCellHeight: 6.5 },
          headStyles: { fillColor: [255, 192, 0], textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle', fontSize: 7.5 },
          columnStyles: colStyles,
          margin: { left: X0, right: X0, top: TOP + 2 * BAR, bottom: BOT },
          rowPageBreak: 'avoid',
          didDrawPage: (d: any) => { if (d.pageNumber > startPage) contBars(s.site); },
          didDrawCell: (d: any) => {
            if (d.section !== 'body') return;
            const raw = d.cell?.raw;
            if (raw && raw.img) { try { doc.addImage(raw.img, 'PNG', d.cell.x + PAD, d.cell.y + PAD, raw.iw, raw.ih); } catch { /* skip */ } return; }
            if (raw && Array.isArray(raw.photos)) {
              const arr: string[] = raw.photos; const n = arr.length; const gap = 2;
              const cw = d.cell.width - 4; const ch = d.cell.height - 3;
              const bw = n === 1 ? Math.min(cw, 22) : Math.min((cw - gap) / 2, 22); const bh = Math.min(ch, 15);
              const total = n === 1 ? bw : n * bw + gap;
              arr.forEach((src, k) => {
                try {
                  const p = doc.getImageProperties(src); const sc = Math.min(bw / p.width, bh / p.height);
                  const w = p.width * sc; const h = p.height * sc;
                  const x0 = d.cell.x + (d.cell.width - total) / 2 + k * (bw + gap) + (bw - w) / 2;
                  doc.addImage(src, src.startsWith('data:image/png') ? 'PNG' : 'JPEG', x0, d.cell.y + (d.cell.height - h) / 2, w, h);
                } catch { /* one picture that cannot be placed never stops the PDF */ }
              });
            }
          },
        });
        y = ((doc as any).lastAutoTable?.finalY ?? y) + 3;
      });
      y += 2;
    });
    y += 3;
  });

  const n = doc.getNumberOfPages();
  const foot = `Daily Report · ${dmy(m.from)} to ${dmy(m.to)} · City -> Site -> Employee`;
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
  for (let i = 1; i <= n; i++) { doc.setPage(i); doc.text(cleanTxt(foot), X0, H - 6); doc.text(`Page ${i} of ${n}`, W - X0, H - 6, { align: 'right' }); }
  await outputPdf(fileName, doc);
}

/** Excel: sheet "Daily Report - Monthly", same blocks and colours; status rows merge D:G; photos are "Open photo" links */
export async function dailyReportMonthlyXlsx(fileName: string, o: MonthlyOpts) {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  const photos = await loadReportPhotos(o.reports, false);
  const m = await buildMonthly(o, photos);
  const links = await photoLinks(o.reports);
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Daily Report');
  const WIDTHS = [8, 12, 8, 24, 46, 44, 16]; const N = WIDTHS.length;
  WIDTHS.forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  const BLACK = { argb: 'FF000000' }; const thin = { style: 'thin' as const, color: BLACK };
  const BORDER = { top: thin, bottom: thin, left: thin, right: thin };
  const fill = (argb: string) => ({ type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb } });
  const font = (bold = false, argb = 'FF000000') => ({ name: 'Calibri', size: 11, bold, color: { argb } });
  let r = 0;
  const borders = () => { for (let k = 1; k <= N; k++) ws.getCell(r, k).border = BORDER; };
  const band = (text: string, bg: string | null, fg: string, border: boolean, center: boolean, right = '') => {
    r += 1;
    if (right) { ws.mergeCells(r, 1, r, N - 2); ws.mergeCells(r, N - 1, r, N); } else ws.mergeCells(r, 1, r, N);
    const c = ws.getCell(r, 1); c.value = text; c.font = font(true, fg); c.alignment = { horizontal: center ? 'center' : 'left', vertical: 'middle' };
    if (right) { const d = ws.getCell(r, N - 1); d.value = right; d.font = font(true, fg); d.alignment = { horizontal: 'right', vertical: 'middle' }; if (bg) d.fill = fill(bg); }
    if (bg) c.fill = fill(bg);
    if (border) borders();
    ws.getRow(r).height = 20;
  };
  band(monthlyTitle(m), null, 'FF000000', false, true);
  band(m.periodLine, null, 'FF000000', false, true);
  ws.views = [{ state: 'frozen', ySplit: 2 }];
  ws.pageSetup = { orientation: 'landscape', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: 0.47, right: 0.47, top: 0.47, bottom: 0.55, header: 0.2, footer: 0.25 } };
  ws.headerFooter = { oddFooter: `&LDaily Report · ${dmy(m.from)} to ${dmy(m.to)} · City -> Site -> Employee&RPage &P of &N` };

  for (const c of m.cities) {
    band(`City - ${c.city}`, 'FF0B2A4A', 'FFFFFFFF', true, false, monthlyCounts(c));
    for (const s of c.sites) {
      band(`Name of the Site - ${s.site}`, 'FFDDEBF7', 'FF000000', true, false);
      for (const e of s.emps) {
        band(`Name of the Employee - ${e.name}${e.empId ? ` (${e.empId})` : ''}`, 'FFFFF2CC', 'FF000000', true, false);
        r += 1; ws.getRow(r).height = 22;
        ['Sr. No.', 'Date', 'Day', 'Sub Work', 'Description of Work', 'Remarks & Comments', 'Photo'].forEach((h, i) => {
          const x = ws.getCell(r, i + 1); x.value = h; x.font = font(true); x.fill = fill('FFFFC000'); x.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
        });
        borders();
        let sr = 0;
        for (const row of e.rows) {
          r += 1;
          const put = (col: number, v: any, left = false) => { const x = ws.getCell(r, col); x.value = v; x.font = font(); x.alignment = { horizontal: left ? 'left' : 'center', vertical: 'middle', wrapText: true }; return x; };
          if (row.t === 'status') {
            const col = STATUS_COLORS[row.kind]; const numbered = row.kind !== 'halfNote';
            if (numbered) { sr += 1; put(1, sr); put(2, dmy(row.date)); put(3, weekday3(row.date)); }
            ws.mergeCells(r, 4, r, 7);
            const x = ws.getCell(r, 4); x.value = row.text; x.fill = fill(col.argb); x.font = font(row.kind !== 'future', col.targb); x.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
            ws.getRow(r).height = 18; borders();
            continue;
          }
          sr += 1; const x = row.e;
          put(1, sr); put(2, dmy(x.date)); put(3, weekday3(x.date)); put(4, x.sub, true); put(5, x.desc, true);
          const rt: any[] = [];
          x.items.forEach((it, k) => { rt.push({ text: `${it.label} `, font: font(true) }); rt.push({ text: `${it.text}${k < x.items.length - 1 ? '\n' : ''}`, font: font() }); });
          const rc = ws.getCell(r, 6); rc.value = x.items.length ? { richText: rt } : '-'; rc.font = font(); rc.alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };
          const url = (links.get(x.reportId) ?? [])[0]; const pc = ws.getCell(r, 7);
          if (url) { pc.value = { text: 'Open photo', hyperlink: url }; pc.font = { name: 'Calibri', size: 11, color: { argb: 'FF0563C1' }, underline: true }; }
          else { pc.value = 'No photo'; pc.font = font(false, 'FF828282'); }
          pc.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
          borders();
        }
        band(e.summary, 'FFE2EFDA', 'FF000000', true, false);
      }
    }
  }
  const data = await wb.xlsx.writeBuffer();
  const ab = data instanceof ArrayBuffer ? data : (data as any).buffer.slice((data as any).byteOffset, (data as any).byteOffset + (data as any).byteLength);
  await saveXlsxData(fileName, ab);
}

// =====================================================================================================================
// PARTICULAR DATE report: heading + dark date bar, orange heading (Sr. No. | Name of the Employee | ...), then City -> Site -> that
// site's reports of the day (employees A-Z), Sr. No. 1..n through the whole day. Optional list "Not reported today".
// =====================================================================================================================
export interface DateReportOpts {
  date: string; reports: DailyReport[]; site?: string; city?: string; employee?: string;
  /** all active profiles: used for the "Not reported today" list (only when no City / Site / Employee filter is chosen) */
  team?: { id: string; full_name: string; username: string; role: string }[];
}
interface DateData { tree: CityGroup[]; dayName: string; title: string; filtLine: string; bar: string; notRep: { name: string; id: string; why: string }[]; stats: { emps: number; reps: number } }
const DCW = [12, 40, 38, 76, 73, 34];   // columns 2..4 have the same widths as the monthly PDF, so the phone's Marathi pictures fit

async function buildDateData(o: DateReportOpts, photos: Map<number, (string | null)[]>): Promise<DateData> {
  const blocks = buildSiteWiseBlocks(o.reports.filter((r) => r.report_date === o.date), photos, o.site, o.city);
  const tree = groupByCity(blocks);
  const stats = blockStats(blocks);
  const dayName = new Date(`${o.date}T12:00:00Z`).toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });
  const title = `Daily Report - ${dmy(o.date)} (${dayName})`;
  const filtLine = [o.city?.trim() || 'All cities', o.site?.trim() || 'All sites', o.employee?.trim() || 'All employees'].join(' · ');
  const bar = `${dmy(o.date)} ${dayName} · ${tree.length} ${tree.length === 1 ? 'city' : 'cities'} · ${plural(stats.emps, 'employee(s)')} · ${plural(stats.reps, 'report(s)')}`;
  // "Not reported today": active employees without a report that day, with the reason (leave / absent / present - no report)
  const notRep: DateData['notRep'] = [];
  if (o.team && !o.site && !o.city && !o.employee) {
    const reported = new Set(o.reports.filter((r) => r.report_date === o.date).map((r) => r.user_id));
    const todo = o.team.filter((p) => p.role === 'Employee' && !reported.has(p.id));
    const y = Number(o.date.slice(0, 4)); const m = Number(o.date.slice(5, 7));
    const leaves = (await api.leavesBetween(o.date, o.date).catch(() => [] as LeaveRequest[])).filter((l) => l.status === 'Approved');
    for (let i = 0; i < todo.length; i += 4) {
      await Promise.all(todo.slice(i, i + 4).map(async (p) => {
        try {
          const row = (await api.monthAttendance(y, m, p.id)).find((x) => String(x.day).slice(0, 10) === o.date);
          const half = leaves.find((l) => l.user_id === p.id && l.from_day <= o.date && o.date <= l.to_day && (l.half_part || (l.units ?? 1) === 0.5));
          const st = row?.status;
          let why = '';
          if (st === 'Leave') why = `${row?.notes || 'Leave'} (approved)`;
          else if (half) why = `Half day ${half.leave_type}`;
          else if (st === 'Present' || st === 'Checked In') why = 'Present - Daily Report not submitted';
          else if (st === 'Absent') why = 'Absent - no check-in';
          if (why) notRep.push({ name: p.full_name, id: p.username, why });
        } catch { /* one employee that cannot be read never stops the report */ }
      }));
    }
    notRep.sort((a, b) => natCmp(a.name, b.name));
  }
  return { tree, dayName, title, filtLine, bar, notRep, stats };
}
const siteEntries = (blocks: SiteWiseEntry[][]) => blocks.flatMap((b) => [...b].sort((x, y) => x.seq - y.seq));
const cityEmps = (c: CityGroup) => new Set(c.sites.flatMap((s) => s.blocks.map((b) => b[0].empId || b[0].emp))).size;
const notRepKind = (why: string): StatusKind => (/^Absent/.test(why) ? 'absent' : /^Present/.test(why) ? 'noreport' : 'leave');

export async function dailyReportDatePdf(fileName: string, o: DateReportOpts) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const photos = await loadReportPhotos(o.reports.filter((r) => r.report_date === o.date));
  const d = await buildDateData(o, photos);
  if (Platform.OS !== 'web') await prepareMarathi(d.tree.flatMap((c) => c.sites.flatMap((s) => s.blocks)));

  const X0 = 12; const TOP = 12; const BOT = 14; const BAR = 6.5;
  const TW = DCW.reduce((a, b) => a + b, 0);
  const INK: [number, number, number] = [20, 20, 20];
  const NAVY: [number, number, number] = [11, 42, 74]; const SKY: [number, number, number] = [221, 235, 247];
  const ORANGE: [number, number, number] = [255, 192, 0]; const DARK: [number, number, number] = [64, 64, 64];
  const HEAD = ['Sr. No.', 'Name of the Employee', 'Sub Work', 'Description of Work', 'Remarks & Comments', 'Photo'];
  const cleanTxt = (s: string) => s.replace(/[    ]/g, ' ');
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
  const bar = (yy: number, left: string, right: string, fill: [number, number, number], color: [number, number, number]) => {
    doc.setFillColor(...fill); doc.setDrawColor(0, 0, 0); doc.setLineWidth(0.2); doc.rect(X0, yy, TW, BAR, 'FD');
    doc.setTextColor(...color); doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5);
    doc.text(cleanTxt(left), X0 + 2, yy + BAR / 2, { baseline: 'middle' });
    if (right) doc.text(cleanTxt(right), X0 + TW - 2, yy + BAR / 2, { align: 'right', baseline: 'middle' });
    doc.setTextColor(...INK);
  };
  /** the orange column heading as one drawn row (repeated on every page) */
  const orange = (yy: number) => {
    let x = X0; doc.setLineWidth(0.2); doc.setDrawColor(0, 0, 0); doc.setFillColor(...ORANGE); doc.setFont('helvetica', 'bold'); doc.setFontSize(7.5); doc.setTextColor(...INK);
    DCW.forEach((w, i) => { doc.rect(x, yy, w, BAR, 'FD'); doc.text(HEAD[i], x + w / 2, yy + BAR / 2, { align: 'center', baseline: 'middle' }); x += w; });
  };
  const contBars = (c: string, s: string) => { orange(TOP); bar(TOP + BAR, `City - ${c} (continued)`, '', NAVY, [255, 255, 255]); bar(TOP + 2 * BAR, `Name of the Site - ${s} (continued)`, '', SKY, INK); };

  doc.setTextColor(...INK); doc.setFont('helvetica', 'bold');
  doc.setFontSize(12); doc.text(cleanTxt(d.title), W / 2, TOP + 4, { align: 'center' });
  doc.setFontSize(10); doc.text(cleanTxt(d.filtLine), W / 2, TOP + 10, { align: 'center' });
  let y = TOP + 14;
  bar(y, d.bar, '', DARK, [255, 255, 255]); y += BAR;
  orange(y); y += BAR;

  let sr = 0;
  d.tree.forEach((c) => {
    if (y + 2 * BAR + 36 > H - BOT) { doc.addPage(); y = TOP; orange(y); y += BAR; }
    bar(y, `City - ${c.city}`, `${plural(c.sites.length, 'site(s)')}  |  ${plural(cityEmps(c), 'employee(s)')}`, NAVY, [255, 255, 255]); y += BAR;
    c.sites.forEach((s, si) => {
      if (si > 0 && y + BAR + 36 > H - BOT) { doc.addPage(); y = TOP; orange(y); y += BAR; bar(y, `City - ${c.city} (continued)`, '', NAVY, [255, 255, 255]); y += BAR; }
      bar(y, `Name of the Site - ${s.site}`, '', SKY, INK); y += BAR;
      const startPage = doc.getNumberOfPages();
      const body = siteEntries(s.blocks).map((e) => {
        sr += 1;
        const ph = photos.get(e.reportId) ?? []; const ok = ph.filter((p): p is string => !!p);
        const photoCell = ph.length === 0 ? { content: 'No photo', styles: { textColor: [130, 130, 130], fontSize: 6.5, halign: 'center' } }
          : ok.length === 0 ? { content: 'Photo not available', styles: { textColor: [130, 130, 130], fontSize: 6.5, halign: 'center' } }
          : { content: '', photos: ok, styles: { minCellHeight: 22 } };
        return [String(sr), cleanTxt(`${e.emp}${e.empId ? `\n(${e.empId})` : ''}`), siteTextCell(e.sub, DCW[2]), siteTextCell(e.desc, DCW[3]), remarksCell(e.items, DCW[4]), photoCell] as any[];
      });
      const colStyles: Record<number, any> = {};
      DCW.forEach((w, i) => { colStyles[i] = { cellWidth: w, halign: i < 1 ? 'center' : 'left' }; });
      autoTable(doc, {
        startY: y, theme: 'grid', showHead: 'never', body,
        styles: { font: 'helvetica', fontSize: 7.5, cellPadding: PAD, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', overflow: 'linebreak' },
        columnStyles: colStyles,
        margin: { left: X0, right: X0, top: TOP + 3 * BAR, bottom: BOT },
        rowPageBreak: 'avoid',
        didDrawPage: (g: any) => { if (g.pageNumber > startPage) contBars(c.city, s.site); },
        didDrawCell: (g: any) => {
          if (g.section !== 'body') return;
          const raw = g.cell?.raw;
          if (raw && raw.img) { try { doc.addImage(raw.img, 'PNG', g.cell.x + PAD, g.cell.y + PAD, raw.iw, raw.ih); } catch { /* skip */ } return; }
          if (raw && Array.isArray(raw.photos)) {
            const arr: string[] = raw.photos; const n = arr.length; const gap = 1.5;
            const cw = g.cell.width - 3; const ch = g.cell.height - 3;
            const bw = n === 1 ? Math.min(cw, 28) : (cw - gap) / 2; const bh = Math.min(ch, 20);
            arr.forEach((src, k) => {
              try {
                const p = doc.getImageProperties(src); const sc = Math.min(bw / p.width, bh / p.height);
                const w = p.width * sc; const h = p.height * sc;
                const x0 = g.cell.x + 1.5 + (n === 1 ? (cw - w) / 2 : k * (bw + gap) + (bw - w) / 2);
                doc.addImage(src, src.startsWith('data:image/png') ? 'PNG' : 'JPEG', x0, g.cell.y + (g.cell.height - h) / 2, w, h);
              } catch { /* skip */ }
            });
          }
        },
      });
      y = ((doc as any).lastAutoTable?.finalY ?? y) + 3;
    });
    y += 2;
  });

  if (d.notRep.length) {
    if (y + BAR + 20 > H - BOT) { doc.addPage(); y = TOP; }
    bar(y, `Not reported today (${d.notRep.length})`, '', DARK, [255, 255, 255]); y += BAR;
    autoTable(doc, {
      startY: y, theme: 'grid', showHead: 'never', rowPageBreak: 'avoid',
      body: d.notRep.map((n, i) => {
        const col = STATUS_COLORS[notRepKind(n.why)];
        return [String(i + 1), cleanTxt(`${n.name}${n.id ? ` (${n.id})` : ''}`), { content: n.why, styles: { fillColor: col.fill, textColor: col.text, fontStyle: 'bold' } }];
      }) as any,
      styles: { font: 'helvetica', fontSize: 7.5, cellPadding: 1.2, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2 },
      columnStyles: { 0: { cellWidth: DCW[0], halign: 'center' }, 1: { cellWidth: DCW[1] + DCW[2] + 30 }, 2: { cellWidth: TW - DCW[0] - DCW[1] - DCW[2] - 30 } },
      margin: { left: X0, right: X0, top: TOP, bottom: BOT },
    });
  }

  const n = doc.getNumberOfPages();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
  for (let i = 1; i <= n; i++) { doc.setPage(i); doc.text(cleanTxt(`Daily Report · ${dmy(o.date)} · City -> Site -> Employee`), X0, H - 6); doc.text(`Page ${i} of ${n}`, W - X0, H - 6, { align: 'right' }); }
  await outputPdf(fileName, doc);
}

export async function dailyReportDateXlsx(fileName: string, o: DateReportOpts) {
  const mod: any = await import('exceljs/dist/exceljs.bare.min.js');
  const ExcelJS = mod.default ?? mod;
  const dayReports = o.reports.filter((r) => r.report_date === o.date);
  const photos = await loadReportPhotos(dayReports, false);
  const d = await buildDateData(o, photos);
  const links = await photoLinks(dayReports);
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Daily Report');
  const WIDTHS = [8, 28, 24, 46, 44, 16]; const N = WIDTHS.length;
  WIDTHS.forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  const BLACK = { argb: 'FF000000' }; const thin = { style: 'thin' as const, color: BLACK };
  const BORDER = { top: thin, bottom: thin, left: thin, right: thin };
  const fill = (argb: string) => ({ type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb } });
  const font = (bold = false, argb = 'FF000000') => ({ name: 'Calibri', size: 11, bold, color: { argb } });
  let r = 0;
  const borders = () => { for (let k = 1; k <= N; k++) ws.getCell(r, k).border = BORDER; };
  const band = (text: string, bg: string | null, fg: string, border: boolean, center: boolean, right = '') => {
    r += 1;
    if (right) { ws.mergeCells(r, 1, r, N - 2); ws.mergeCells(r, N - 1, r, N); } else ws.mergeCells(r, 1, r, N);
    const c = ws.getCell(r, 1); c.value = text; c.font = font(true, fg); c.alignment = { horizontal: center ? 'center' : 'left', vertical: 'middle' };
    if (right) { const x = ws.getCell(r, N - 1); x.value = right; x.font = font(true, fg); x.alignment = { horizontal: 'right', vertical: 'middle' }; if (bg) x.fill = fill(bg); }
    if (bg) c.fill = fill(bg);
    if (border) borders();
    ws.getRow(r).height = 20;
  };
  band(d.title, null, 'FF000000', false, true);
  band(d.filtLine, null, 'FF000000', false, true);
  ws.views = [{ state: 'frozen', ySplit: 2 }];
  ws.pageSetup = { orientation: 'landscape', paperSize: 9, fitToPage: true, fitToWidth: 1, fitToHeight: 0, margins: { left: 0.47, right: 0.47, top: 0.47, bottom: 0.55, header: 0.2, footer: 0.25 } };
  ws.headerFooter = { oddFooter: `&LDaily Report · ${dmy(o.date)} · City -> Site -> Employee&RPage &P of &N` };
  band(d.bar, 'FF404040', 'FFFFFFFF', true, false);
  r += 1; ws.getRow(r).height = 22;
  ['Sr. No.', 'Name of the Employee', 'Sub Work', 'Description of Work', 'Remarks & Comments', 'Photo'].forEach((h, i) => {
    const x = ws.getCell(r, i + 1); x.value = h; x.font = font(true); x.fill = fill('FFFFC000'); x.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
  });
  borders();
  let sr = 0;
  for (const c of d.tree) {
    band(`City - ${c.city}`, 'FF0B2A4A', 'FFFFFFFF', true, false, `${plural(c.sites.length, 'site(s)')} | ${plural(cityEmps(c), 'employee(s)')}`);
    for (const s of c.sites) {
      band(`Name of the Site - ${s.site}`, 'FFDDEBF7', 'FF000000', true, false);
      for (const e of siteEntries(s.blocks)) {
        r += 1; sr += 1;
        const put = (col: number, v: any, left = false) => { const x = ws.getCell(r, col); x.value = v; x.font = font(); x.alignment = { horizontal: left ? 'left' : 'center', vertical: 'middle', wrapText: true }; return x; };
        put(1, sr); put(2, `${e.emp}${e.empId ? ` (${e.empId})` : ''}`, true); put(3, e.sub, true); put(4, e.desc, true);
        const rt: any[] = [];
        e.items.forEach((it, k) => { rt.push({ text: `${it.label} `, font: font(true) }); rt.push({ text: `${it.text}${k < e.items.length - 1 ? '\n' : ''}`, font: font() }); });
        const rc = ws.getCell(r, 5); rc.value = e.items.length ? { richText: rt } : '-'; rc.font = font(); rc.alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };
        const url = (links.get(e.reportId) ?? [])[0]; const pc = ws.getCell(r, 6);
        if (url) { pc.value = { text: 'Open photo', hyperlink: url }; pc.font = { name: 'Calibri', size: 11, color: { argb: 'FF0563C1' }, underline: true }; }
        else { pc.value = 'No photo'; pc.font = font(false, 'FF828282'); }
        pc.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
        borders();
      }
    }
  }
  if (d.notRep.length) {
    band(`Not reported today (${d.notRep.length})`, 'FF404040', 'FFFFFFFF', true, false);
    d.notRep.forEach((n, i) => {
      r += 1; const col = STATUS_COLORS[notRepKind(n.why)];
      const a = ws.getCell(r, 1); a.value = i + 1; a.font = font(); a.alignment = { horizontal: 'center', vertical: 'middle' };
      const b = ws.getCell(r, 2); b.value = `${n.name}${n.id ? ` (${n.id})` : ''}`; b.font = font(); b.alignment = { vertical: 'middle', wrapText: true };
      ws.mergeCells(r, 3, r, N);
      const x = ws.getCell(r, 3); x.value = n.why; x.fill = fill(col.argb); x.font = font(true, col.targb); x.alignment = { horizontal: 'center', vertical: 'middle' };
      borders();
    });
  }
  const data = await wb.xlsx.writeBuffer();
  const ab = data instanceof ArrayBuffer ? data : (data as any).buffer.slice((data as any).byteOffset, (data as any).byteOffset + (data as any).byteLength);
  await saveXlsxData(fileName, ab);
}
