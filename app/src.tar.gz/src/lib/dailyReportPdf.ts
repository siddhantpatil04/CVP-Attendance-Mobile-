import { COMPANY_NAME } from '../config';
import { api } from './api';
import type { DailyReport, DailyReportSite } from './api';
import { cell as csvCell, shareCsvText } from './csv';
import { imageDataUrl } from './imageData';
import { PX_PER_MM, rasterizeJobs, RasterJob, RasterResult } from './marathiRaster';
import { fmtISODate, fmtTime12 } from './time';
import { Platform } from 'react-native';
import { loadPdfLibs, outputPdf } from './pdf';
import { cityCmp, cityOfSite, natCmp } from './siteCity';

const AMBER: [number, number, number] = [255, 192, 0];
const t = (v: unknown) => (v === null || v === undefined ? '' : String(v));
const times = (a: string | null, b: string | null) => (a || b ? `${a ? fmtTime12(a) : '-'} - ${b ? fmtTime12(b) : '-'}` : '');
export const dailyReportNo = (id: number) => `DR-${String(id).padStart(6, '0')}`;

/** The fields that are translated to English for Admin */
export type DailyField = 'sub_work' | 'work_going_on' | 'work_description' | 'comment_1' | 'comment_2' | 'comment_3' | 'remarks';
/** English text of a field: the Admin's correction, else the automatic English, else the text itself (it was already English) */
export const englishOf = (s: DailyReportSite, f: DailyField): string => {
  const tr = s.translations?.[f];
  return (tr ? (tr.corrected_en || tr.en) : '') || (s[f] ?? '') || '';
};
/** Language of the original text of an entry (null = written in English) */
export const writtenIn = (s: DailyReportSite): string | null => Object.values(s.translations ?? {})[0]?.lang ?? null;

/** One row per site entry: used by the CSV export and the PDF table */
export function dailyReportRows(reports: DailyReport[], withOriginal = false): Record<string, unknown>[] {
  return reports.flatMap((r): Record<string, unknown>[] => {
    const sites = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
    const base = {
      Date: fmtISODate(r.report_date),
      'Report No': dailyReportNo(r.id),
      Employee: r.employee?.full_name ?? '',
      'Employee ID': r.employee?.username ?? '',
      Status: r.status,
      Submitted: r.submitted_at ? `${fmtISODate(r.submitted_at.slice(0, 10))} ${fmtTime12(r.submitted_at)}` : '',
      'GPS distance (km)': r.gps_km ?? 'GPS not available',
    };
    const review = { 'Review note': r.review_note ?? '' };
    if (!sites.length) return [{ ...base, '#': '', Site: '', 'Arrival - Departure': '', 'Sub work': '', 'Work description': '', 'Comment 1': '', 'Comment 2': '', 'Comment 3': '', Remarks: '', ...review }];
    return sites.map((s) => ({
      ...base, '#': s.seq, Site: s.site_name, 'Arrival - Departure': times(s.arrived_at, s.departed_at),
      'Sub work': englishOf(s, 'sub_work'), 'Work description': englishOf(s, 'work_description'),
      'Comment 1': englishOf(s, 'comment_1'), 'Comment 2': englishOf(s, 'comment_2'), 'Comment 3': englishOf(s, 'comment_3'), Remarks: englishOf(s, 'remarks'), ...review,
      ...(withOriginal ? { 'Sub work (original)': s.sub_work ?? '', 'Work description (original)': s.work_description ?? '',
        'Comment 1 (original)': s.comment_1 ?? '', 'Comment 2 (original)': s.comment_2 ?? '', 'Comment 3 (original)': s.comment_3 ?? '', 'Remarks (original)': s.remarks ?? '' } : {}),
    }));
  });
}


/**
 * Marathi / Hindi (Devanagari) cannot be typed by the PDF's built-in font (it printed garbage). On the web / desktop the browser draws
 * the text with its own font (so the letters join correctly) and the picture is placed in the table cell. The phone has no canvas:
 * there the cell says the text is Marathi and points to the Excel / CSV.
 */
const INDIC = /[\u0900-\u097F]/;
const PX = 8;   // picture pixels per mm
function indicPicture(text: string, widthMm: number): { img: string; hMm: number } | null {
  if (Platform.OS !== 'web' || typeof document === 'undefined') return null;
  try {
    const c = document.createElement('canvas');
    const ctx = c.getContext('2d'); if (!ctx) return null;
    const font = `${Math.round(2.5 * PX)}px "Nirmala UI","Noto Sans Devanagari","Mangal","Kohinoor Devanagari",sans-serif`;
    ctx.font = font;
    const maxW = widthMm * PX; const lines: string[] = [];
    for (const para of text.split(/\r?\n/)) {
      let cur = '';
      for (const word of para.split(' ')) {
        const tryLine = cur ? `${cur} ${word}` : word;
        if (ctx.measureText(tryLine).width <= maxW) { cur = tryLine; continue; }
        if (cur) lines.push(cur);
        cur = word;
        while (ctx.measureText(cur).width > maxW && cur.length > 1) {   // a very long word is cut to fit
          let n = cur.length - 1; while (n > 1 && ctx.measureText(cur.slice(0, n)).width > maxW) n--;
          lines.push(cur.slice(0, n)); cur = cur.slice(n);
        }
      }
      lines.push(cur);
    }
    const lh = Math.round(3.4 * PX);
    c.width = Math.max(1, Math.round(maxW)); c.height = lines.length * lh + 4;
    const g = c.getContext('2d')!; g.font = font; g.fillStyle = '#141414'; g.textBaseline = 'top';
    lines.forEach((l, i) => g.fillText(l, 0, i * lh + 2));
    return { img: c.toDataURL('image/png'), hMm: c.height / PX };
  } catch { return null; }
}
/** A table cell: plain text, or (Marathi / Hindi) a picture of the text */
function bodyCell(text: string, colMm: number, pad = 1.6): unknown {
  if (!INDIC.test(text)) return text;
  const p = indicPicture(text, colMm - 2 * pad);
  if (!p) return { content: '(Marathi text - see the Excel / CSV)', styles: { fontStyle: 'italic', textColor: [120, 120, 120] } };
  return { content: '', img: p.img, ih: p.hMm, iw: colMm - 2 * pad, styles: { minCellHeight: p.hMm + 2 * pad } };
}
/** One page (or more) per report: employee, date, visit sequence, GPS distance, every site entry and the review note */
export async function dailyReportsPdf(fileName: string, subtitle: string, reports: DailyReport[], withOriginal = false) {
  // with withOriginal the written (Marathi / Hindi) text is printed under the English text, like the CSV does
  const field = (s: DailyReportSite, f: DailyField) => { const en = englishOf(s, f); const o = s[f] ?? ''; return withOriginal && o && o.trim() !== en.trim() ? (en ? `${en}\n${o}` : o) : en; };
  const { jsPDF, autoTable } = await loadPdfLibs();
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const CW = [8, 38, 26, 40, 54, 34, 25, 25, 27];   // fixed column widths (mm): the Marathi pictures are made to fit them

  const header = () => {
    doc.setTextColor(20, 20, 20); doc.setFont('helvetica', 'bold');
    doc.setFontSize(12); doc.text(COMPANY_NAME, W / 2, 10, { align: 'center' });
    doc.setFontSize(10); doc.text('Daily Report', W / 2, 16, { align: 'center' });
    doc.setFontSize(9); doc.text(subtitle, W / 2, 21.5, { align: 'center' });
  };

  reports.forEach((r, i) => {
    if (i > 0) doc.addPage();
    header();
    const sites = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
    const seq = sites.filter((s) => s.arrived_at).map((s, k) => `${k + 1}. ${s.site_name} (${times(s.arrived_at, s.departed_at)})`).join('   ');
    let y = 36;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10);
    doc.text(`${r.employee?.full_name ?? ''} (${r.employee?.username ?? ''})   |   ${fmtISODate(r.report_date)}   |   ${dailyReportNo(r.id)}   |   ${r.status}`, 10, y);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9);
    y += 5.5;
    doc.text(`Submitted: ${r.submitted_at ? `${fmtISODate(r.submitted_at.slice(0, 10))} ${fmtTime12(r.submitted_at)}` : 'not submitted'}   |   GPS distance: ${r.gps_km != null ? r.gps_km + ' km' : 'GPS not available'}`, 10, y);
    if (seq) { y += 5; const lines = doc.splitTextToSize(`Visit sequence: ${seq}`, W - 20); doc.text(lines, 10, y); y += (lines.length - 1) * 4.2; }
    autoTable(doc, {
      startY: y + 4,
      head: [['#', 'Site', 'Arrival - Departure', 'Sub work', 'Work description', 'Comment 1', 'Comment 2', 'Comment 3', 'Remarks']],
      body: sites.map((s) => [s.seq, bodyCell(s.site_name ?? '', CW[1]), times(s.arrived_at, s.departed_at), bodyCell(field(s, 'sub_work'), CW[3]), bodyCell(field(s, 'work_description'), CW[4]), bodyCell(field(s, 'comment_1'), CW[5]), bodyCell(field(s, 'comment_2'), CW[6]), bodyCell(field(s, 'comment_3'), CW[7]), bodyCell(field(s, 'remarks'), CW[8])]) as any,
      theme: 'grid',
      columnStyles: Object.fromEntries(CW.map((w, i) => [i, { cellWidth: w }])),
      didDrawCell: (d: any) => {
        const raw = d.cell?.raw;
        if (d.section === 'body' && raw && raw.img) { try { doc.addImage(raw.img, 'PNG', d.cell.x + 1.6, d.cell.y + 1.6, raw.iw, raw.ih); } catch { /* skip */ } }
      },
      styles: { fontSize: 7, cellPadding: 1.6, overflow: 'linebreak', textColor: [20, 20, 20], lineColor: [60, 60, 60], lineWidth: 0.15 },
      headStyles: { fillColor: AMBER, textColor: [20, 20, 20], fontStyle: 'bold', halign: 'center' },
      margin: { left: 10, right: 10, top: 36, bottom: 12 },
      didDrawPage: () => { header(); },
    });
    if (r.review_note) {
      const endY = ((doc as any).lastAutoTable?.finalY ?? y) + 6;
      doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
      doc.text(`Review note: ${r.review_note}`, 10, Math.min(endY, doc.internal.pageSize.getHeight() - 14));
    }
  });

  const n = doc.getNumberOfPages(); const h = doc.internal.pageSize.getHeight();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(140, 152, 166);
  for (let p = 1; p <= n; p++) {
    doc.setPage(p);
    doc.text(`Generated ${new Date().toLocaleDateString('en-GB')}`, 10, h - 6);
    doc.text(`Page ${p} of ${n}`, W - 10, h - 6, { align: 'right' });
  }
  await outputPdf(fileName, doc);
}

// =====================================================================================================================
// Site-wise monthly PDF: blocks "Name of the Site - X   Name of the Employee - Y", six columns, Remarks + Comments in ONE column,
// "Photo of the Site" (the photos attached to the Daily Report). Marathi / Hindi is printed from a browser picture (see above).
// =====================================================================================================================
type Seg = { t: string; b?: boolean };
const PAD = 1.6;
const SW_CW = [12, 22, 38, 76, 73, 54];   // site-wise PDF column widths (275 mm)

/** Text with optional bold parts drawn by the browser (correct Devanagari joining), as a picture for a table cell */
const rasterCache = new Map<string, RasterResult>();   // phone: pictures of Marathi cells, drawn by the hidden WebView
const rasterKey = (paras: Seg[][], widthMm: number) => `${Math.round(widthMm * 10)}|${JSON.stringify(paras)}`;
function richPicture(paras: Seg[][], widthMm: number): { img: string; hMm: number } | null {
  if (Platform.OS !== 'web') return rasterCache.get(rasterKey(paras, widthMm)) ?? null;
  if (typeof document === 'undefined') return null;
  try {
    const c = document.createElement('canvas');
    const ctx = c.getContext('2d'); if (!ctx) return null;
    const fam = '"Nirmala UI","Noto Sans Devanagari","Mangal","Kohinoor Devanagari",sans-serif';
    const px = Math.round(2.5 * PX);
    const fontOf = (b?: boolean) => `${b ? 'bold ' : ''}${px}px ${fam}`;
    const maxW = widthMm * PX;
    type Piece = { t: string; b: boolean; w: number };
    const lines: Piece[][] = [];
    for (const para of paras) {
      let line: Piece[] = []; let lw = 0;
      for (const seg of para) {
        ctx.font = fontOf(seg.b);
        for (const w of seg.t.split(/(\s+)/)) {
          if (w === '') continue;
          const ww = ctx.measureText(w).width;
          if (lw + ww > maxW && line.length && w.trim() !== '') { lines.push(line); line = []; lw = 0; }
          if (line.length === 0 && /^\s+$/.test(w)) continue;
          line.push({ t: w, b: !!seg.b, w: ww }); lw += ww;
        }
      }
      lines.push(line);
    }
    const lh = Math.round(3.4 * PX);
    c.width = Math.max(1, Math.round(maxW)); c.height = Math.max(lh, lines.length * lh) + 4;
    const g = c.getContext('2d')!; g.fillStyle = '#141414'; g.textBaseline = 'top';
    lines.forEach((ln, i) => { let x = 0; ln.forEach((p) => { g.font = fontOf(p.b); g.fillText(p.t, x, i * lh + 2); x += p.w; }); });
    return { img: c.toDataURL('image/png'), hMm: c.height / PX };
  } catch { return null; }
}
const picCell = (p: { img: string; hMm: number }, colMm: number) => ({ content: '', img: p.img, ih: p.hMm, iw: colMm - 2 * PAD, styles: { minCellHeight: p.hMm + 2 * PAD } });
const MARATHI_NOTE = { content: '(Marathi text - see the Excel / CSV)', styles: { fontStyle: 'italic', textColor: [120, 120, 120] } };

/** Plain text stays real PDF text; Marathi / Hindi becomes a picture (web / desktop) */
export function siteTextCell(text: string, colMm: number): unknown {
  const s = (text ?? '').replace(/[\u00a0\u2007\u2009\u202f]/g, ' ').trim();
  if (!s) return '';
  if (!INDIC.test(s)) return s;
  const p = richPicture(s.split(/\r?\n/).map((l) => [{ t: l }]), colMm - 2 * PAD);
  return p ? picCell(p, colMm) : MARATHI_NOTE;
}
const NOISE = /^(na|n\/a|n\.a\.?|nil|none|-+|\.+|_+)$/i;
/** Remark + Comment 1..3 in one cell: only the filled ones, numbered 1, 2, 3 in order, the label in bold */
function remarksCell(items: { label: string; text: string }[], colMm: number): unknown {
  if (!items.length) return '-';
  const paras: Seg[][] = items.flatMap((i) => i.text.split(/\r?\n/).map((l, k) => (k === 0 ? [{ t: `${i.label} `, b: true }, { t: l }] : [{ t: l }])));
  const p = richPicture(paras, colMm - 2 * PAD);
  if (p) return picCell(p, colMm);
  if (items.some((i) => INDIC.test(i.text))) return MARATHI_NOTE;
  return items.map((i) => `${i.label} ${i.text}`).join('\n');
}
const weekday3 = (iso: string) => new Date(`${iso}T12:00:00Z`).toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' });
const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;

/** up to 2 image photos per report, as small JPEG data URLs (null = could not be loaded) */
async function loadReportPhotos(reports: DailyReport[], download = true): Promise<Map<number, (string | null)[]>> {
  const ids = reports.map((r) => r.id);
  const rows: { report_id: number; file_path: string; file_name: string | null }[] = [];
  for (let i = 0; i < ids.length; i += 100) rows.push(...await api.dailyReportPhotosFor(ids.slice(i, i + 100)).catch(() => []));
  const isImage = (r: { file_path: string; file_name: string | null }) => /\.(jpe?g|png|webp)$/i.test(r.file_name || r.file_path);
  const per = new Map<number, string[]>();
  for (const r of rows) { if (!isImage(r)) continue; const l = per.get(r.report_id) ?? []; if (l.length < 2) { l.push(r.file_path); per.set(r.report_id, l); } }
  const paths = download ? [...new Set([...per.values()].flat())] : [];
  const got = new Map<string, string | null>();
  for (let i = 0; i < paths.length; i += 6) {
    await Promise.all(paths.slice(i, i + 6).map(async (p) => {
      try { got.set(p, await imageDataUrl(await api.dailyReportPhotoUrl(p), 300)); } catch { got.set(p, null); }
    }));
  }
  const out = new Map<number, (string | null)[]>();
  per.forEach((l, id) => out.set(id, l.map((p) => (download ? got.get(p) ?? null : p))));
  return out;
}


/** Phone: finds every Marathi / Hindi cell of the site-wise PDF and draws it as a picture (cached for the PDF code) */
async function prepareMarathi(blocks: SiteWiseEntry[][]) {
  const jobs: RasterJob[] = []; const seen = new Set<string>();
  const add = (paras: Seg[][], widthMm: number) => {
    const key = rasterKey(paras, widthMm);
    if (rasterCache.has(key) || seen.has(key)) return;
    seen.add(key); jobs.push({ id: key, paras, widthMm });
  };
  const plain = (s: string) => s.replace(/[\u00a0\u2007\u2009\u202f]/g, ' ').trim();
  for (const list of blocks) {
    for (const e of list) {
      const sub = plain(e.sub); const desc = plain(e.desc);
      if (INDIC.test(sub)) add(sub.split(/\r?\n/).map((l) => [{ t: l }]), SW_CW[2] - 2 * PAD);
      if (INDIC.test(desc)) add(desc.split(/\r?\n/).map((l) => [{ t: l }]), SW_CW[3] - 2 * PAD);
      if (e.items.some((i) => INDIC.test(i.text))) {
        add(e.items.flatMap((i) => i.text.split(/\r?\n/).map((l, k) => (k === 0 ? [{ t: `${i.label} `, b: true }, { t: l }] : [{ t: l }]))), SW_CW[4] - 2 * PAD);
      }
    }
  }
  for (let i = 0; i < jobs.length; i += 60) {
    const got = await rasterizeJobs(jobs.slice(i, i + 60));
    for (const [id, r] of Object.entries(got)) if (r) rasterCache.set(id, r);
  }
}
/** One entry of the site-wise Daily Report (one site row of one report) */
export interface SiteWiseEntry {
  city: string; site: string; emp: string; empId: string; date: string; seq: number; reportId: number; status: string; sub: string; desc: string;
  items: { label: string; text: string }[]; remark: string; comments: string[];
}
/** City -> Site -> Employee tree of the blocks (cities A-Z with "Other" last, sites A-Z, employees A-Z) */
export interface CityGroup { city: string; sites: { site: string; blocks: SiteWiseEntry[][] }[] }
export function groupByCity(blocks: SiteWiseEntry[][]): CityGroup[] {
  const cities = new Map<string, Map<string, SiteWiseEntry[][]>>();
  for (const b of blocks) {
    const c = cities.get(b[0].city) ?? new Map<string, SiteWiseEntry[][]>();
    c.set(b[0].site, [...(c.get(b[0].site) ?? []), b]);
    cities.set(b[0].city, c);
  }
  return [...cities.entries()].sort((a, b) => cityCmp(a[0], b[0])).map(([city, sm]) => ({
    city,
    sites: [...sm.entries()].sort((a, b) => natCmp(a[0], b[0])).map(([site, bl]) => ({ site, blocks: bl.sort((x, y) => natCmp(x[0].emp, y[0].emp)) })),
  }));
}
/** Blocks by site then employee: the same arrangement for the PDF and the CSV (city / site filters optional) */
function buildSiteWiseBlocks(reports: DailyReport[], photos: Map<number, (string | null)[]>, site?: string, city?: string): SiteWiseEntry[][] {
  type Entry = SiteWiseEntry;
  const entries: Entry[] = [];
  const wantSite = site?.trim().toLowerCase();
  for (const r of reports) {
    const emp = r.employee?.full_name ?? 'Employee'; const empId = r.employee?.username ?? '';
    const sites = [...r.daily_report_sites].sort((a, b) => a.seq - b.seq);
    const mk = (site: string, s?: DailyReportSite): Entry => {
      const items: { label: string; text: string }[] = [];
      const ok = (v: string | null | undefined) => { const x = (v ?? '').trim(); return x && !NOISE.test(x) ? x : ''; };
      if (s && ok(s.remarks)) items.push({ label: 'Remark:', text: ok(s.remarks) });
      let n = 0;
      for (const c of [s?.comment_1, s?.comment_2, s?.comment_3]) if (ok(c)) { n += 1; items.push({ label: `Comment ${n}:`, text: ok(c) }); }
      return {
        city: cityOfSite(site), site, emp, empId, date: r.report_date, seq: s?.seq ?? 0, reportId: r.id, status: r.status,
        sub: (s?.sub_work ?? '').trim(), desc: ((s?.work_description ?? '') || (s?.work_going_on ?? '')).trim(), items,
        remark: ok(s?.remarks), comments: [ok(s?.comment_1), ok(s?.comment_2), ok(s?.comment_3)],
      };
    };
    if (sites.length === 0) { if (!wantSite && (photos.get(r.id)?.length ?? 0) > 0) entries.push(mk('(site not entered)')); continue; }
    for (const s of sites) {
      const site = (s.site_name ?? '').trim() || '(site not entered)';
      if (wantSite && site.toLowerCase() !== wantSite) continue;
      if (city && cityOfSite(site) !== city) continue;
      entries.push(mk(site, s));
    }
  }
  if (entries.length === 0) throw new Error('No daily report entries match the filters.');

  const blocks = new Map<string, Entry[]>();
  for (const e of entries) { const k = `${e.site}\u0000${e.empId || e.emp}\u0000${e.emp}`; blocks.set(k, [...(blocks.get(k) ?? []), e]); }
  return [...blocks.values()].sort((a, b) => cityCmp(a[0].city, b[0].city) || natCmp(a[0].site, b[0].site) || natCmp(a[0].emp, b[0].emp));
}

/** Counts of a list of employee blocks: employees (once each) and distinct reports */
export function blockStats(blocks: SiteWiseEntry[][]) {
  const emps = new Set(blocks.map((b) => b[0].empId || b[0].emp));
  const reps = new Set(blocks.flatMap((b) => b.map((e) => e.reportId)));
  return { emps: emps.size, reps: reps.size };
}
const plural = (n: number, w: string) => `${n} ${w.replace('(s)', n === 1 ? '' : 's')}`;

/**
 * Daily Report monthly / date-range PDF: CITY -> SITE -> EMPLOYEE. A4 landscape.
 * Page 1 lists the cities and sites; every city starts with its navy row and a table of ALL its sites; then each site (light blue),
 * and for each employee (A-Z): yellow employee row, orange column heading row, the employee's report rows (oldest -> newest).
 * Sr. No. | Date | Sub Work | Description of Work | Remarks & Comments | Photo of the Site.
 */
export async function dailyReportSiteWisePdf(fileName: string, opts: { period: string; reports: DailyReport[]; site?: string; city?: string; filters?: string }) {
  const { jsPDF, autoTable } = await loadPdfLibs();
  const photos = await loadReportPhotos(opts.reports);
  const blocks = buildSiteWiseBlocks(opts.reports, photos, opts.site, opts.city);
  // phone: draw every Marathi cell as a picture in the hidden WebView first (the PDF code below only places the pictures)
  if (Platform.OS !== 'web') await prepareMarathi(blocks);
  const tree = groupByCity(blocks);

  const X0 = 8; const TOP = 10; const BOT = 14; const BAR = 6.5;
  const CW = SW_CW; const TW = CW.reduce((a, b) => a + b, 0);
  const INK: [number, number, number] = [20, 20, 20];
  const NAVY: [number, number, number] = [11, 42, 74]; const SKY: [number, number, number] = [221, 235, 247]; const YEL: [number, number, number] = [255, 242, 204];
  const HEAD = ['Sr. No.', 'Date', 'Sub Work', 'Description of Work', 'Remarks & Comments', 'Photo of the Site'];
  const cleanTxt = (s: string) => s.replace(/[    ]/g, ' ');
  const counts = (bl: SiteWiseEntry[][]) => { const s = blockStats(bl); return `${plural(bl.length ? new Set(bl.map((b) => b[0].site)).size : 0, 'site(s)')}  |  ${plural(s.emps, 'employee(s)')}  |  ${plural(s.reps, 'report(s)')}`; };

  const render = (pageMap: Map<string, number>) => {
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const W = doc.internal.pageSize.getWidth(); const H = doc.internal.pageSize.getHeight();
    const pages = new Map<string, number>();
    let y = TOP;
    const bar = (yy: number, left: string, right: string, fill: [number, number, number], color: [number, number, number]) => {
      doc.setFillColor(...fill); doc.setDrawColor(0, 0, 0); doc.setLineWidth(0.2);
      doc.rect(X0, yy, TW, BAR, 'FD');
      doc.setTextColor(...color); doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5);
      doc.text(cleanTxt(left), X0 + 2, yy + BAR / 2, { baseline: 'middle' });
      if (right) doc.text(cleanTxt(right), X0 + TW - 2, yy + BAR / 2, { align: 'right', baseline: 'middle' });
      doc.setTextColor(...INK);
    };

    // ---- page 1: the cities and sites of this report
    doc.setTextColor(...INK); doc.setFont('helvetica', 'bold'); doc.setFontSize(12);
    doc.text(cleanTxt(COMPANY_NAME), W / 2, 12, { align: 'center' });
    doc.setFontSize(10); doc.text(`Daily Report - ${cleanTxt(opts.period)}`, W / 2, 18, { align: 'center' });
    if (opts.filters) { doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.text(cleanTxt(opts.filters), W / 2, 23, { align: 'center' }); }
    y = 30;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text('Cities and sites in this report (A-Z)', X0, y); y += 6;
    tree.forEach((c, ci) => {
      if (y + 12 > H - BOT) { doc.addPage(); y = TOP; }
      doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.text(cleanTxt(`${ci + 1}. ${c.city}`), X0, y); y += 4.6;
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8);
      c.sites.forEach((s, si) => {
        if (y + 5 > H - BOT) { doc.addPage(); y = TOP; }
        doc.text(cleanTxt(`${ci + 1}.${si + 1}  ${s.site}`), X0 + 6, y);
        doc.text(`p. ${pageMap.get(`${ci}.${si}`) ?? '-'}`, X0 + 160, y);
        y += 4.2;
      });
      y += 2;
    });

    // ---- one section per city
    tree.forEach((c, ci) => {
      doc.addPage(); y = TOP;
      const cityTitle = `${ci + 1}. City - ${c.city}`;
      const cityBlocks = c.sites.flatMap((s) => s.blocks);
      bar(y, cityTitle, counts(cityBlocks), NAVY, [255, 255, 255]); y += BAR + 2;

      // table of ALL sites of the city
      const rows = c.sites.map((s, si) => { const st = blockStats(s.blocks); return [`${ci + 1}.${si + 1}`, s.site, String(st.emps), String(st.reps), String(pageMap.get(`${ci}.${si}`) ?? '-')]; });
      const tot = blockStats(cityBlocks);
      autoTable(doc, {
        startY: y, theme: 'grid',
        head: [['No.', `Site in ${c.city} (A-Z)`, 'Employees', 'Reports', 'Page']],
        body: [...rows, [{ content: `Total - ${c.city}`, colSpan: 2, styles: { fontStyle: 'bold', fillColor: [225, 225, 225] } }, { content: String(tot.emps), styles: { fontStyle: 'bold', fillColor: [225, 225, 225] } }, { content: String(tot.reps), styles: { fontStyle: 'bold', fillColor: [225, 225, 225] } }, { content: '', styles: { fillColor: [225, 225, 225] } }]] as any,
        styles: { font: 'helvetica', fontSize: 8, cellPadding: 1.4, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle' },
        headStyles: { fillColor: [255, 192, 0], textColor: INK, fontStyle: 'bold', halign: 'center' },
        columnStyles: { 0: { cellWidth: 18, halign: 'center' }, 1: { cellWidth: 165 }, 2: { cellWidth: 32, halign: 'center' }, 3: { cellWidth: 32, halign: 'center' }, 4: { cellWidth: 28, halign: 'center' } },
        margin: { left: X0, right: X0, top: TOP, bottom: BOT },
      });
      y = ((doc as any).lastAutoTable?.finalY ?? y) + 5;
      doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(...INK);
      doc.text(cleanTxt(`Site-wise reports - ${c.city}`), X0, y); y += 3;

      const contBars = (site: string, si: number) => {
        bar(TOP, `${cityTitle} (continued)`, '', NAVY, [255, 255, 255]);
        bar(TOP + BAR, `${ci + 1}.${si + 1} Name of the Site - ${site} (continued)`, '', SKY, INK);
        return TOP + 2 * BAR;
      };

      c.sites.forEach((s, si) => {
        if (y + 2 * BAR + 40 > H - BOT) { doc.addPage(); y = TOP; bar(y, `${cityTitle} (continued)`, '', NAVY, [255, 255, 255]); y += BAR; }
        pages.set(`${ci}.${si}`, doc.getNumberOfPages());
        const st = blockStats(s.blocks);
        bar(y, `${ci + 1}.${si + 1}  Name of the Site - ${s.site}`, `${plural(st.emps, 'employee(s)')}  |  ${plural(st.reps, 'report(s)')}`, SKY, INK); y += BAR;

        s.blocks.forEach((list) => {
          list.sort((a, b) => a.date.localeCompare(b.date) || a.seq - b.seq);
          const f = list[0];
          if (y + BAR + 6 + 30 > H - BOT) { doc.addPage(); y = contBars(s.site, si); }
          const nRep = new Set(list.map((e) => e.reportId)).size;
          const empTitle = cleanTxt(`Name of the Employee - ${f.emp}${f.empId ? ` (${f.empId})` : ''}  |  ${plural(nRep, 'report(s)')}`);
          const startPage = doc.getNumberOfPages();
          const body = list.map((e, i) => {
            const ph = photos.get(e.reportId) ?? [];
            const ok = ph.filter((x): x is string => !!x);
            const photoCell = ph.length === 0
              ? { content: 'No photo', styles: { textColor: [130, 130, 130], fontSize: 6.5, halign: 'center' } }
              : ok.length === 0 ? { content: 'Photo not available', styles: { textColor: [130, 130, 130], fontSize: 6.5, halign: 'center' } }
              : { content: '', photos: ok, styles: { minCellHeight: 28 } };
            return [String(i + 1), `${dmy(e.date)}\n `, siteTextCell(e.sub, CW[2]), siteTextCell(e.desc, CW[3]), remarksCell(e.items, CW[4]), photoCell] as any[];
          });
          const colStyles: Record<number, any> = {};
          CW.forEach((w, i) => { colStyles[i] = { cellWidth: w, halign: i < 2 ? 'center' : 'left' }; });
          autoTable(doc, {
            startY: y, theme: 'grid', showHead: 'everyPage',
            // the employee row is ABOVE the column heading; both repeat on a new page
            head: [
              [{ content: empTitle, colSpan: 6, styles: { fillColor: YEL, textColor: INK, fontStyle: 'bold', halign: 'left', fontSize: 8.5, cellPadding: 1.8 } }],
              HEAD,
            ],
            body,
            styles: { font: 'helvetica', fontSize: 7.5, cellPadding: PAD, textColor: INK, lineColor: [0, 0, 0], lineWidth: 0.2, valign: 'middle', overflow: 'linebreak' },
            headStyles: { fillColor: [255, 192, 0], textColor: INK, fontStyle: 'bold', halign: 'center', valign: 'middle', fontSize: 7.5 },
            columnStyles: colStyles,
            margin: { left: X0, right: X0, top: TOP + 2 * BAR, bottom: BOT },
            rowPageBreak: 'avoid',
            didDrawPage: (d: any) => { if (d.pageNumber > startPage) contBars(s.site, si); },
            didDrawCell: (d: any) => {
              if (d.section !== 'body') return;
              const raw = d.cell?.raw; const e = list[d.row.index];
              if (d.column.index === 1 && e) {   // the weekday under the date, small and grey
                doc.setFont('helvetica', 'normal'); doc.setFontSize(6.5); doc.setTextColor(120, 120, 120);
                doc.text(weekday3(e.date), d.cell.x + d.cell.width / 2, d.cell.y + d.cell.height / 2 + 3.6, { align: 'center' });
                doc.setTextColor(...INK); return;
              }
              if (raw && raw.img) { try { doc.addImage(raw.img, 'PNG', d.cell.x + PAD, d.cell.y + PAD, raw.iw, raw.ih); } catch { /* skip */ } return; }
              if (raw && Array.isArray(raw.photos)) {
                const arr: string[] = raw.photos; const n = arr.length; const gap = 2;
                const cw = d.cell.width - 4; const ch = d.cell.height - 4;
                const bw = n === 1 ? Math.min(cw, 34) : (cw - gap) / 2; const bh = n === 1 ? Math.min(ch, 23.5) : Math.min(ch, 20);
                arr.forEach((src, k) => {
                  try {
                    const p = doc.getImageProperties(src); const sc = Math.min(bw / p.width, bh / p.height);
                    const w = p.width * sc; const h = p.height * sc;
                    const x0 = d.cell.x + 2 + (n === 1 ? (cw - w) / 2 : k * (bw + gap) + (bw - w) / 2);
                    doc.addImage(src, src.startsWith('data:image/png') ? 'PNG' : 'JPEG', x0, d.cell.y + (d.cell.height - h) / 2, w, h);
                  } catch { /* one picture that cannot be placed never stops the PDF */ }
                });
              }
            },
          });
          y = ((doc as any).lastAutoTable?.finalY ?? y) + 3;
        });
        y += 3;
      });
    });

    const n = doc.getNumberOfPages();
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110, 110, 110);
    for (let i = 1; i <= n; i++) {
      doc.setPage(i);
      doc.text(cleanTxt(`Daily Report - ${opts.period} - City -> Site -> Employee`), X0, H - 6);
      doc.text(`Page ${i} of ${n}`, W - X0, H - 6, { align: 'right' });
    }
    return { doc, pages };
  };

  // pass 1 finds the page of every site; pass 2 prints those page numbers in the city tables
  const first = render(new Map());
  const second = render(first.pages);
  await outputPdf(fileName, second.doc);
}

/**
 * Daily Report CSV: City | Site | Employee | Emp ID | Date | Day | Report No. | Status | Sub Work | Description of Work |
 * Remark | Comment 1..3 | Photo (link or "-"). Sorted City -> Site -> Employee -> Date; the text is as written (Marathi / Hindi
 * included; UTF-8 with BOM for Excel).
 */
export async function dailyReportSiteWiseCsv(fileName: string, opts: { reports: DailyReport[]; site?: string; city?: string }) {
  const photos = await loadReportPhotos(opts.reports, false);   // storage paths
  const blocks = buildSiteWiseBlocks(opts.reports, photos, opts.site, opts.city);
  const links = new Map<string, string>();
  const paths = [...new Set([...photos.values()].flat().filter((p): p is string => !!p))];
  for (let i = 0; i < paths.length; i += 6) {
    await Promise.all(paths.slice(i, i + 6).map(async (p) => { try { links.set(p, await api.dailyReportPhotoUrl(p)); } catch { /* no link */ } }));
  }
  const lines: string[] = [];
  const line = (cells: unknown[]) => lines.push(cells.map(csvCell).join(','));
  line(['City', 'Site', 'Employee', 'Emp ID', 'Date', 'Day', 'Report No.', 'Status', 'Sub Work', 'Description of Work', 'Remark', 'Comment 1', 'Comment 2', 'Comment 3', 'Photo']);
  for (const c of groupByCity(blocks)) for (const s of c.sites) for (const list of s.blocks) {
    list.sort((a, b) => a.date.localeCompare(b.date) || a.seq - b.seq);
    for (const e of list) {
      const ph = (photos.get(e.reportId) ?? []).map((p) => (p ? links.get(p) : undefined)).filter((u): u is string => !!u);
      line([e.city, e.site, e.emp, e.empId, dmy(e.date), weekday3(e.date), dailyReportNo(e.reportId), e.status, e.sub, e.desc, e.remark, e.comments[0], e.comments[1], e.comments[2], ph.length ? ph.join('\n') : '-']);
    }
  }
  await shareCsvText(fileName, lines.join('\n'));
}
