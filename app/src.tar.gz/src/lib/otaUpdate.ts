import { useEffect } from 'react';
import { AppState, Platform } from 'react-native';

function updatesModule(): any | null {
  if (Platform.OS === 'web') return null;
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const U = require('expo-updates');
    return U && U.isEnabled ? U : null;
  } catch { return null; }
}

/**
 * Phone only (EAS Update). Without this, a new version is only downloaded in the background and shows on the SECOND start,
 * so a phone looked as if it still had the old version.
 *   - when the app opens: look for a newer version; if there is one, download it and restart into it at once
 *   - when the app comes back to the front: download it quietly (it is used the next time the app opens, nothing is interrupted)
 */
export function useAutoUpdate() {
  useEffect(() => {
    const U = updatesModule();
    if (!U) return;
    let stopped = false;
    const run = async (apply: boolean) => {
      try {
        const c = await U.checkForUpdateAsync();
        if (!c.isAvailable) return;
        await U.fetchUpdateAsync();
        if (apply && !stopped) await U.reloadAsync();
      } catch { /* offline or no update: the app simply keeps the version it has */ }
    };
    run(true);
    const sub = AppState.addEventListener('change', (s) => { if (s === 'active') run(false); });
    return () => { stopped = true; sub.remove(); };
  }, []);
}

/** "Version 1.0.0 - update 01a1ed02 - 18 Nov 14:16": shows which code this device is really running */
export function appVersionText(): string {
  if (Platform.OS === 'web') return '';
  const U = updatesModule();
  if (!U) return 'Version 1.0.0 (development)';
  const id = U.updateId ? String(U.updateId).slice(0, 8) : 'built-in';
  let when = '';
  try {
    const d: Date | null = U.createdAt ?? null;
    if (d) when = ` - ${d.toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false })}`;
  } catch { /* ignore */ }
  return `Version 1.0.0 - update ${id}${when}`;
}
