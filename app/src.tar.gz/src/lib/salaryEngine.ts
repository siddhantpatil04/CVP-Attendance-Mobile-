// ONE salary calculator for the Wage Register, bank report and the Salary Formulas screen.
// The formulas of Basic, HRA, Other, PF, ESIC, PT (and added rows) are TEXT typed by the Admin. They are NEVER run with eval() / new Function() / SQL:
// the small parser below reads them and allows ONLY the words, numbers, operators and functions listed here. Anything else = an error.
import type { PayrollRow } from './api';

// ------------------------------------------------------------------------------------------------------------------ what a formula may use
export const BASE_NAMES = ['SALARY', 'EARNED', 'PAID_DAYS', 'MONTH_DAYS', 'MONTH', 'GENDER_F'] as const;
export const BUILTIN_CODES = ['BASIC', 'HRA', 'OTHER', 'PF', 'ESIC', 'PT'] as const;
/** The only functions allowed */
export const ALLOWED_FUNCTIONS = ['IF', 'MIN', 'MAX', 'ROUND', 'ROUNDUP'] as const;
const ARITY: Record<string, [number, number]> = { IF: [3, 3], MIN: [2, 20], MAX: [2, 20], ROUND: [1, 2], ROUNDUP: [1, 2] };
/** Codes an added row can never use */
export const RESERVED_CODES = new Set<string>([...BASE_NAMES, ...BUILTIN_CODES, 'GROSS', 'NET', 'ADVANCE', 'TRUE', 'FALSE', ...ALLOWED_FUNCTIONS, 'ROUNDDOWN', 'AND', 'OR', 'NOT',
  'UNPAID_DAYS', 'PRESENT_DAYS', 'OT_HOURS', 'YEARS_OF_SERVICE', 'SITE_EMPLOYEE', 'PF_MEMBER']);

// ------------------------------------------------------------------------------------------------------------------ safe parser
type Tok = { t: 'num'; v: number } | { t: 'id'; v: string } | { t: 'op'; v: string };
type Node =
  | { k: 'num'; v: number } | { k: 'name'; v: string } | { k: 'neg'; a: Node } | { k: 'pct'; a: Node }
  | { k: 'bin'; op: string; a: Node; b: Node } | { k: 'call'; fn: string; args: Node[] };

const MAX_LEN = 500;
const MAX_DEPTH = 40;

function tokenize(src: string): Tok[] {
  if (src.length > MAX_LEN) throw new Error(`The formula is longer than ${MAX_LEN} characters`);
  // the symbols x, ×, ≤, ≥, ≠ are converted
  const s = src.replace(/×/g, '*').replace(/≤/g, '<=').replace(/≥/g, '>=').replace(/≠/g, '<>').replace(/!=/g, '<>');
  const out: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (c === ' ' || c === '\t' || c === '\n' || c === '\r') { i++; continue; }
    if (/[0-9.]/.test(c)) {
      const m = /^(\d+(\.\d+)?|\.\d+)/.exec(s.slice(i));
      if (!m) throw new Error(`Wrong number near "${s.slice(i, i + 6)}"`);
      out.push({ t: 'num', v: Number(m[0]) }); i += m[0].length; continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      const m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(s.slice(i))!;
      const id = m[0].toUpperCase();
      if (id === 'X') out.push({ t: 'op', v: '*' }); else out.push({ t: 'id', v: id });
      i += m[0].length; continue;
    }
    const two = s.slice(i, i + 2);
    if (two === '<=' || two === '>=' || two === '<>') { out.push({ t: 'op', v: two }); i += 2; continue; }
    if ('+-*/%(),=<>'.includes(c)) { out.push({ t: 'op', v: c }); i++; continue; }
    throw new Error(`Not allowed: "${c}"`);
  }
  return out;
}

/** Text -> syntax tree. Throws an Error with a plain message. */
export function parseFormula(src: string): Node {
  if (!src || !src.trim()) throw new Error('The formula is empty');
  const toks = tokenize(src);
  let p = 0;
  const peek = () => toks[p];
  const isOp = (v: string) => peek()?.t === 'op' && (peek() as any).v === v;
  const need = (v: string) => { if (!isOp(v)) throw new Error(v === ')' ? 'A closing bracket ")" is missing' : `"${v}" is expected`); p++; };
  const expr = (d: number): Node => cmp(d);
  const cmp = (d: number): Node => {
    let a = add(d);
    const t = peek();
    if (t?.t === 'op' && ['=', '<>', '<', '<=', '>', '>='].includes(t.v)) { p++; const b = add(d); a = { k: 'bin', op: t.v, a, b }; }
    return a;
  };
  const add = (d: number): Node => {
    let a = mul(d);
    while (isOp('+') || isOp('-')) { const op = (toks[p++] as any).v; a = { k: 'bin', op, a, b: mul(d) }; }
    return a;
  };
  const mul = (d: number): Node => {
    let a = unary(d);
    while (isOp('*') || isOp('/')) { const op = (toks[p++] as any).v; a = { k: 'bin', op, a, b: unary(d) }; }
    return a;
  };
  const unary = (d: number): Node => {
    if (d > MAX_DEPTH) throw new Error('The formula is too deep');
    if (isOp('-')) { p++; return { k: 'neg', a: unary(d + 1) }; }
    if (isOp('+')) { p++; return unary(d + 1); }
    return postfix(d);
  };
  const postfix = (d: number): Node => {
    let a = primary(d + 1);
    while (isOp('%')) { p++; a = { k: 'pct', a }; }
    return a;
  };
  const primary = (d: number): Node => {
    if (d > MAX_DEPTH) throw new Error('The formula is too deep');
    const t = peek();
    if (!t) throw new Error('The formula ends too early');
    if (t.t === 'num') { p++; return { k: 'num', v: t.v }; }
    if (t.t === 'id') {
      p++;
      if (isOp('(')) {
        p++;
        const rule = ARITY[t.v];
        if (!rule) throw new Error(`Unknown function ${t.v}`);
        const args: Node[] = [];
        if (!isOp(')')) { args.push(expr(d + 1)); while (isOp(',')) { p++; args.push(expr(d + 1)); } }
        need(')');
        if (args.length < rule[0] || args.length > rule[1]) throw new Error(`${t.v} needs ${rule[0] === rule[1] ? rule[0] : `${rule[0]} to ${rule[1]}`} values`);
        return { k: 'call', fn: t.v, args };
      }
      if (ARITY[t.v]) throw new Error(`${t.v} needs brackets, e.g. ${t.v}(...)`);
      return { k: 'name', v: t.v };
    }
    if (t.v === '(') { p++; const e = expr(d + 1); need(')'); return e; }
    throw new Error(`Unexpected "${t.v}"`);
  };
  const tree = expr(0);
  if (p < toks.length) { const t = toks[p]; throw new Error(t.t === 'op' && t.v === ')' ? 'A bracket ")" has no opening bracket' : `Unexpected "${(t as any).v}"`); }
  return tree;
}

/** Every function a tree calls */
export function functionsIn(n: Node, out = new Set<string>()): Set<string> {
  if (n.k === 'neg' || n.k === 'pct') functionsIn(n.a, out);
  else if (n.k === 'bin') { functionsIn(n.a, out); functionsIn(n.b, out); }
  else if (n.k === 'call') { out.add(n.fn); n.args.forEach((a) => functionsIn(a, out)); }
  return out;
}

/** Every name a tree uses */
export function namesIn(n: Node, out = new Set<string>()): Set<string> {
  if (n.k === 'name') out.add(n.v);
  else if (n.k === 'neg' || n.k === 'pct') namesIn(n.a, out);
  else if (n.k === 'bin') { namesIn(n.a, out); namesIn(n.b, out); }
  else if (n.k === 'call') n.args.forEach((a) => namesIn(a, out));
  return out;
}

const RND = (x: number, n: number, mode: 'round' | 'up' | 'down') => {
  const f = Math.pow(10, n);
  const y = Number((x * f).toFixed(8));
  return (mode === 'round' ? Math.round(y) : mode === 'up' ? (y < 0 ? -Math.ceil(-y) : Math.ceil(y)) : (y < 0 ? -Math.floor(-y) : Math.floor(y))) / f;
};

/** Value of a tree. `ctx` holds the names; any unknown name or division by zero throws. */
export function evaluate(n: Node, ctx: Record<string, number>): number {
  switch (n.k) {
    case 'num': return n.v;
    case 'name': { if (!(n.v in ctx)) throw new Error(`Unknown name ${n.v}`); return ctx[n.v]; }
    case 'neg': return -evaluate(n.a, ctx);
    case 'pct': return evaluate(n.a, ctx) / 100;
    case 'bin': {
      const a = evaluate(n.a, ctx); const b = evaluate(n.b, ctx);
      switch (n.op) {
        case '+': return a + b; case '-': return a - b; case '*': return a * b;
        case '/': if (b === 0) throw new Error('Division by zero'); return a / b;
        case '=': return a === b ? 1 : 0; case '<>': return a !== b ? 1 : 0;
        case '<': return a < b ? 1 : 0; case '<=': return a <= b ? 1 : 0; case '>': return a > b ? 1 : 0; default: return a >= b ? 1 : 0;
      }
    }
    case 'call': {
      if (n.fn === 'IF') return evaluate(n.args[0], ctx) !== 0 ? evaluate(n.args[1], ctx) : evaluate(n.args[2], ctx);
      const v = n.args.map((a) => evaluate(a, ctx));
      switch (n.fn) {
        case 'MIN': return Math.min(...v); case 'MAX': return Math.max(...v);
        case 'ROUND': return RND(v[0], v[1] ?? 0, 'round'); case 'ROUNDUP': return RND(v[0], v[1] ?? 0, 'up'); case 'ROUNDDOWN': return RND(v[0], v[1] ?? 0, 'down');
        case 'AND': return v.every((x) => x !== 0) ? 1 : 0; case 'OR': return v.some((x) => x !== 0) ? 1 : 0; default: return v[0] === 0 ? 1 : 0;
      }
    }
  }
}

/** Checks a formula text: syntax, brackets, only allowed names (values + formulas above it). Returns the message to show in red. */
export function checkFormula(text: string, allowedNames: Iterable<string>): { ok: true } | { ok: false; error: string } {
  try {
    const tree = parseFormula(text);
    const allowed = new Set(allowedNames);
    for (const nm of namesIn(tree)) {
      if (!allowed.has(nm)) {
        const later = ['BASIC', 'HRA', 'OTHER', 'GROSS', 'PF', 'ESIC', 'PT'].includes(nm);
        throw new Error(later ? `${nm} is calculated later than this formula - a formula can use only the ones above it` : `Unknown name ${nm}`);
      }
    }
    return { ok: true };
  } catch (e: any) { return { ok: false, error: String(e?.message ?? e) }; }
}


// ------------------------------------------------------------------------------------------------------------------ the formula rows
export interface FormulaItem { code: string; name: string; type: 'builtin' | 'earning' | 'deduction'; formula: string }

/** Today's formulas (wages.ts): the starting rows of the Salary Formulas screen and the fallback when the database cannot be read */
export const STARTING_ITEMS: FormulaItem[] = [
  { code: 'BASIC', name: 'Basic', type: 'builtin', formula: 'ROUND(EARNED * 50%)' },
  { code: 'HRA', name: 'HRA', type: 'builtin', formula: 'ROUND(BASIC * 40%)' },
  { code: 'OTHER', name: 'Other allowances', type: 'builtin', formula: 'ROUND(BASIC * 60%)' },
  { code: 'PF', name: 'PF', type: 'builtin', formula: 'IF(SALARY > 0, ROUND(MIN(MAX(BASIC, ROUND(GROSS / 2)), 25000) * 12%), 0)' },
  { code: 'ESIC', name: 'ESIC', type: 'builtin', formula: 'IF(SALARY > 0, IF(SALARY <= 21000, IF(GROSS > 0, ROUNDUP(GROSS * 0.75%), 0), 0), 0)' },
  { code: 'PT', name: 'Professional Tax', type: 'builtin', formula: 'IF(GROSS <= 0, 0, IF(GENDER_F = 1, IF(GROSS <= 25000, 0, IF(MONTH = 2, 300, 200)), IF(GROSS <= 7500, 0, IF(GROSS <= 10000, 175, IF(MONTH = 2, 300, 200)))))' },
];

/** The names row `index` may use. BASIC / HRA / OTHER cannot use GROSS (Gross is made from them); an added Earning is worked out before Gross. */
export function allowedNamesFor(items: FormulaItem[], index: number): string[] {
  const f = items[index];
  const names: string[] = [...BASE_NAMES];
  const added = (kind: 'earning' | 'deduction') => items.slice(0, index).filter((x) => x.type === kind).map((x) => x.code);
  if (f.type === 'builtin') {
    const order = ['BASIC', 'HRA', 'OTHER'];
    const at = order.indexOf(f.code);
    if (at >= 0) names.push(...order.slice(0, at));              // BASIC: none, HRA: BASIC, OTHER: BASIC + HRA
    else names.push('BASIC', 'HRA', 'OTHER', 'GROSS', ...items.filter((x) => x.type === 'earning').map((x) => x.code), ...(f.code === 'ESIC' ? ['PF'] : f.code === 'PT' ? ['PF', 'ESIC'] : []));
  } else if (f.type === 'earning') names.push('BASIC', 'HRA', 'OTHER', ...added('earning'));
  else names.push('BASIC', 'HRA', 'OTHER', 'GROSS', 'PF', 'ESIC', 'PT', ...items.filter((x) => x.type === 'earning').map((x) => x.code), ...added('deduction'));
  return names;
}

/** Checks one row: the red message, or null when the formula is correct (and uses only IF / MIN / MAX / ROUND / ROUNDUP) */
export function checkRow(items: FormulaItem[], index: number): string | null {
  const f = items[index];
  if (!f.formula.trim()) return 'Type the formula';
  const r = checkFormula(f.formula, allowedNamesFor(items, index));
  if (!r.ok) return r.error;
  try {
    for (const fn of functionsIn(parseFormula(f.formula))) if (!(ALLOWED_FUNCTIONS as readonly string[]).includes(fn)) return `${fn} is not allowed. Use only IF, MIN, MAX, ROUND, ROUNDUP`;
  } catch (e: any) { return String(e?.message ?? e); }
  return null;
}
/** One message per row (null = correct) */
export const checkAll = (items: FormulaItem[]) => items.map((_, i) => checkRow(items, i));

// ------------------------------------------------------------------------------------------------------------------ the calculator
export interface WageExtra { joining?: string | null; resigned?: string | null; uan?: string | null; gender?: string | null; advance?: number; userId?: string }
export interface WageResult {
  userId: string; name: string; department: string; joining: string; resigned: string; uan: string; gender: string;
  gross: number; daysPresent: number; daysUnpaid: number; daysInMonth: number;
  basic: number; hra: number; other: number; overtime: number; totalGross: number;
  pfEmployee: number; pt: number; esicEmployee: number; pfEmployer: number; esicEmployer: number; advance: number;
  totalDeduct: number; net: number;
  pfMember: 'Y' | 'N' | ''; epsEligible: 'Y' | 'N' | '';
  pfWages: number; epsWages: number; employerEps: number; employerEpf: number; employerCost: number;
  /** amount of every ADDED row by code */
  extras: Record<string, number>;
}
const r0 = (n: number) => Math.round(n);
const up = (n: number) => Math.ceil(Number(n.toFixed(6)));

/**
 * One employee, one month, one set of formulas -> every wage column.
 * Order: EARNED -> BASIC, HRA, OTHER -> added Earnings -> GROSS -> PF -> ESIC -> PT -> added Deductions.
 * Net = Gross - PF - ESIC - PT - Advance - added Deductions.
 * With the starting formulas the numbers are exactly the old Wage Register numbers. A broken formula gives 0 (it can never be saved).
 * The employer-side columns (employer PF = PF, employer ESIC 3.25 %, EPS 8.33 %) keep the starting rates.
 */
export function computeSalary(p: PayrollRow, month: number, items: FormulaItem[], extra: WageExtra = {}): WageResult {
  const salary = Number(p.monthly_salary);
  const days = p.payable_days + p.unpaid_days || 1;
  const earned = (salary * p.payable_days) / days;
  const fem = (extra.gender ?? '').toLowerCase().startsWith('f');
  const ctx: Record<string, number> = { SALARY: salary, EARNED: earned, PAID_DAYS: p.payable_days, MONTH_DAYS: days, MONTH: month, GENDER_F: fem ? 1 : 0 };
  const extras: Record<string, number> = {};
  const run = (f: FormulaItem | undefined): number => {
    if (!f) return 0;
    let v = 0;
    try { v = evaluate(parseFormula(f.formula), ctx); if (!Number.isFinite(v)) v = 0; } catch { v = 0; }
    ctx[f.code] = v; if (f.type !== 'builtin') extras[f.code] = v;
    return v;
  };
  const by = (code: string) => items.find((x) => x.code === code);
  const basic = run(by('BASIC')); const hra = run(by('HRA')); const other = run(by('OTHER'));
  let earn = 0; for (const f of items.filter((x) => x.type === 'earning')) earn += run(f);
  const totalGross = basic + hra + other + earn; ctx.GROSS = totalGross;
  const pf = run(by('PF')); const esic = run(by('ESIC')); const pt = run(by('PT'));
  let ded = 0; for (const f of items.filter((x) => x.type === 'deduction')) ded += run(f);
  const advance = extra.advance ?? 0;
  const totalDeduct = pf + pt + esic + advance + ded;
  const member = salary > 0;
  const pfWages = member ? Math.min(Math.max(basic, r0(totalGross / 2)), 25000) : 0;
  const esicEmployer = esic > 0 ? up(totalGross * 0.0325) : 0;
  const employerEps = r0(pfWages * 0.0833);
  const g = (extra.gender ?? '').toLowerCase();
  return {
    userId: p.user_id, name: p.full_name.replace(/\s*\(Resigned[^)]*\)\s*$/i, ''), department: p.department ?? '',
    joining: extra.joining ?? '', resigned: extra.resigned ?? '', uan: extra.uan ?? '', gender: g.startsWith('m') ? 'M' : g.startsWith('f') ? 'F' : g ? 'O' : '',
    gross: r0(salary), daysPresent: p.payable_days, daysUnpaid: p.unpaid_days, daysInMonth: p.payable_days + p.unpaid_days,
    basic, hra, other, overtime: 0, totalGross,
    pfEmployee: pf, pt, esicEmployee: esic, pfEmployer: pf, esicEmployer, advance,
    totalDeduct, net: totalGross - totalDeduct,
    pfMember: member ? 'Y' : 'N', epsEligible: member ? 'Y' : 'N',
    pfWages, epsWages: pfWages, employerEps, employerEpf: pf - employerEps, employerCost: totalGross + pf + esicEmployer,
    extras,
  };
}
