import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import * as Location from 'expo-location';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { MonthCalendar } from '../../components/MonthCalendar';
import PlacePicker from '../../components/PlacePicker';
import ShortHoursSheet from '../../components/ShortHoursSheet';
import WorkingHoursCard from '../../components/WorkingHoursCard';
import {
  Avatar, Banner, Button, Card, Empty, Hero, InfoTile, Kpi, KpiGrid, ListItem, Loading, Pill, Row, Screen, SectionTitle,
} from '../../components/ui';
import { api, AuditRow, DailyReport, MonthDay, MyDashboard } from '../../lib/api';
import { DR_TONE } from '../../components/DailyReportView';
import { ForeignPunch } from '../../components/ForeignPunch';
import { distanceM, fmtDistance } from '../../lib/geo';
import { useAuth } from '../../lib/auth';
import { hm } from '../../lib/hours';
import { usePlaces } from '../../lib/usePlaces';
import { useRealtime, useTicker } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtDateLong, fmtMinutes, fmtTime12, greeting, istDateISO, istParts } from '../../lib/time';
import { Dropdown } from '../../components/Pickers';
import { C } from '../../theme';
import { shownRole } from '../../navigation/menu';

/** Best-effort GPS (never blocks attendance if permission is refused) */
async function tryLocation(): Promise<{ lat?: number; lng?: number }> {
  try {
    const perm = await Location.requestForegroundPermissionsAsync();
    if (perm.status !== 'granted') return {};
    const pos = await Promise.race([
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
      new Promise<null>((r) => setTimeout(() => r(null), 6000)),
    ]);
    return pos ? { lat: pos.coords.latitude, lng: pos.coords.longitude } : {};
  } catch {
    return {};
  }
}

export default function HomeScreen() {
  const { profile, isAdmin } = useAuth();
  const nav = useNavigation<any>();
  const [dash, setDash] = useState<MyDashboard | null>(null);
  const [days, setDays] = useState<MonthDay[]>([]);
  const [activity, setActivity] = useState<AuditRow[]>([]);
  const [actView, setActView] = useState(-1); // "Recent activity" drop-down: -1 = hidden, 0 = today, 1 = all recent
  const todayActivity = useMemo(() => activity.filter((a) => istDateISO(a.logged_at) === istDateISO()), [activity]);
  const shownActivity = actView === 0 ? todayActivity : activity;
  const [refreshing, setRefreshing] = useState(false);
  const [daily, setDaily] = useState<DailyReport | null | undefined>(undefined);   // undefined = no card (not checked out, or not available)
  const [busy, setBusy] = useState<'in' | 'out' | null>(null);
  // Office employees: the nearest office location within the range is used automatically (no selfie)
  // every employee uses the normal check-in / check-out, whatever the Travel Access switch says
  const officeEmp = !!profile && !profile.site_employee;
  const plc = usePlaces(officeEmp, false);
  const [placeId, setPlaceId] = useState<number | null>(null);
  const [shortSheet, setShortSheet] = useState(false);
  const [offset, setOffset] = useState(0); // server clock - phone clock
  const now = useTicker(1000) + offset;

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      const d = await api.myDashboard();
      setDash(d);
      // Daily Report card (only after check-out). Loaded on its own: if it fails, the rest of Home is not affected.
      if (profile.site_employee && d.attendance?.check_out_at) {   // Daily Report: automatic for site employees
        api.myDailyReports(profile.id, istDateISO(), istDateISO()).then((r) => setDaily(r[0] ?? null)).catch(() => setDaily(undefined));
      } else setDaily(undefined);
      setOffset(new Date(d.server_time).getTime() - Date.now());
      const p = istParts(new Date(d.server_time));
      const [m, a] = await Promise.all([api.monthAttendance(p.year, p.month), api.myActivity(profile.id)]);
      setDays(m);
      setActivity(a);
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [profile]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  // Same account open on another phone, or HR approves a leave -> refresh instantly
  useRealtime(`home-${profile?.id}`, [
    { table: 'attendance', filter: `user_id=eq.${profile?.id}` },
    { table: 'leaves', filter: `user_id=eq.${profile?.id}` },
  ], () => load(), !!profile);

  const t = dash?.attendance;
  const workingFor = useMemo(() => {
    if (!t?.check_in_at) return null;
    if (t.work_minutes != null) return t.work_minutes;
    return Math.max(0, Math.floor((now - new Date(t.check_in_at).getTime()) / 60000));
  }, [t, now]);
  const requiredMin = plc.rule.required_minutes;
  const rangeM = plc.rule.range_m;
  // Office employees: the NEAREST office location within the range is used automatically (they can tap another office if there is more than one)
  const picked = officeEmp ? ((plc.places ?? []).find((p) => p.site_id === placeId) ?? (plc.places ?? [])[0] ?? null) : null;
  const needPlace = officeEmp && !picked;

  const punch = async (kind: 'in' | 'out', shortReason?: string) => {
    // Site employees must use selfie + location, never the plain punch
    if (profile?.site_employee) {
      nav.navigate('SiteSelfie');   // straight to Site Selfie: choose the place, take the selfie, then check in / out
      return;
    }
    if (!picked) { Alert.alert('No office near you', `No office location within ${fmtDistance(rangeM)}. Move closer and refresh your location.`); return; }
    setShortSheet(false);
    setBusy(kind);
    try {
      const loc = await tryLocation();
      if (loc.lat == null || loc.lng == null) {
        Alert.alert('Location required', 'Allow location access and turn on GPS, then try again.');
        return;
      }
      if (distanceM(loc.lat, loc.lng, picked.lat, picked.lng) > rangeM) {
        Alert.alert('Too far from this place', `You are more than ${fmtDistance(rangeM)} from ${picked.name}. Move closer and refresh your location.`);
        plc.refresh();
        return;
      }
      if (kind === 'out') {
        await api.selectCheckoutPlace(picked.site_id, loc.lat, loc.lng);     // the place he checks out at is saved
        if (shortReason) await api.setShortHoursReason(shortReason);
      }
      const row = kind === 'in' ? await api.checkIn(loc) : await api.checkOut(loc);
      setPlaceId(null);
      const dm = kind === 'in' ? row.check_in_dist_m : row.check_out_dist_m;
      const wm = kind === 'out' ? row.work_minutes : null;
      Alert.alert(kind === 'in' ? 'Checked in' : 'Checked out',
        `${dm != null ? `You were ${dm} m from ${picked.name}.` : picked.name}`
        + (wm != null ? ` Worked ${hm(wm)} - ${wm >= requiredMin ? 'Full day' : `Short hours (${hm(requiredMin - wm)} short)`}.` : ''));
      await load();
    } catch (e) {
      Alert.alert(kind === 'in' ? 'Check-in failed' : 'Check-out failed', errorText(e));
    } finally {
      setBusy(null);
    }
  };

  const confirmOut = () => {
    // Site employees check out in Site Selfie (place + selfie): go there at once, without a question first
    if (profile?.site_employee) { nav.navigate('SiteSelfie'); return; }
    // Before the required hours: warning + a reason (saved with the day)
    if (workingFor != null && workingFor < requiredMin) { setShortSheet(true); return; }
    Alert.alert('Check out now?', 'Your working hours for today will be closed.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Check Out', style: 'destructive', onPress: () => punch('out') },
    ]);
  };
  if (!profile || !dash) return <Loading />;
  const p = istParts(now);
  const m = dash.month;
  const todayStatus =t?.check_out_at ? 'Present' : t?.check_in_at ? 'Checked In' : 'Not Checked In';

  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      <Pressable onPress={() => nav.navigate('Profile')} accessibilityRole="button" accessibilityLabel="Open my profile">
        <Hero
          title={`${greeting(p.hour)}, ${profile.full_name}`}
          subtitle={`${fmtDateLong(now)} - tap to open My Profile`}
        />
      </Pressable>

      {dash.is_holiday ?<Banner tone="blue" icon="sunny-outline" text={`Today is a company holiday: ${dash.is_holiday}`} /> : null}

      {/* Clock + punch card */}
      <Card>
        <Row style={{ justifyContent: 'space-between' }}>
          <View>
            <Text style={st.caption}>Office - India Time (IST)</Text>
            <Text style={st.clock}>{fmtTime12(now, true)}</Text>
          </View>
          <Pill text={todayStatus} />
        </Row>

        {officeEmp && !t?.check_out_at ? (
          <>
            <Banner tone="blue" icon="time-outline" text={`No time limit - check in any time. ${hm(requiredMin)} counted from your check-in.`} />
            <PlacePicker
              title={t?.check_in_at ? 'Your check-out office location' : 'Your office location'}
              hint={`Nearest office location within ${fmtDistance(rangeM)} is selected for you. You can check ${t?.check_in_at ? 'out' : 'in'} here.`}
              places={plc.places} selectedId={picked?.site_id ?? null} onSelect={(p) => setPlaceId(p.site_id)}
              rangeM={rangeM} loading={plc.loading} error={plc.error} onRefresh={plc.refresh} />
          </>
        ) : null}
        <Row style={{ marginTop: 14 }}>
          {!t?.check_in_at ? (
            <>
              <Button title={needPlace ? 'No office near you' : 'Check In'} icon="log-in-outline" variant="success" style={{ flex: 1 }} loading={busy === 'in'} disabled={needPlace} onPress={() => punch('in')} />
              <Button title="Check Out" icon="log-out-outline" variant="secondary" style={{ flex: 1 }} disabled />
            </>
          ) : !t.check_out_at ? (
            <>
              <Button title="Checked In" icon="checkmark-circle" variant="secondary" style={{ flex: 1 }} disabled />
              <Button title={needPlace ? 'No office near you' : 'Check Out'} icon="log-out-outline" style={{ flex: 1 }} loading={busy === 'out'} disabled={needPlace} onPress={confirmOut} />
            </>
          ) : (
            <>
              <Button title="Checked In" icon="checkmark-circle" variant="secondary" style={{ flex: 1 }} disabled />
              <Button title="Checked Out" icon="checkmark-done" variant="secondary" style={{ flex: 1 }} disabled />
            </>
          )}
        </Row>
        {profile.wide_site_access && !profile.site_employee && !t?.check_out_at ? (
          <ForeignPunch kind={t?.check_in_at ? 'out' : 'in'} onDone={load} />
        ) : null}
        {profile.site_employee && !t?.check_out_at ? (
          <Button title="Use Site Selfie instead" icon="camera-outline" variant="ghost" small style={{ marginTop: 6 }}
            onPress={() => nav.navigate('SiteSelfie')} />
        ) : null}

        <View style={st.todayGrid}>
          <InfoTile label="Check In" value={fmtTime12(t?.check_in_at)} />
          <InfoTile label="Check Out" value={fmtTime12(t?.check_out_at)} />
          <InfoTile label="Working For" value={workingFor == null ? '-' : fmtMinutes(workingFor)} />
          <InfoTile label="Overtime" value={workingFor == null ? '-' : fmtMinutes(Math.max(0, workingFor - 480))} />
        </View>
      </Card>

      {officeEmp && t?.check_in_at ? <WorkingHoursCard checkInAt={t.check_in_at} worked={workingFor ?? 0} requiredMin={requiredMin} done={!!t.check_out_at} /> : null}
      <ShortHoursSheet visible={shortSheet} worked={workingFor ?? 0} requiredMin={requiredMin} busy={busy === 'out'}
        blocked={plc.rule.before_required === 'block'} onStay={() => setShortSheet(false)} onConfirm={(reason) => punch('out', reason)} />

      {/* Daily Report: appears only after the employee has checked out for the day */}
      {t?.check_out_at && daily !== undefined ? (
        <Card>
          <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
            <View style={{ flex: 1 }}>
              <Text style={st.cardTitle}>Daily Report for today</Text>
              <Text style={st.caption}>
                {!daily ? 'Not filled yet. Add the work done at each site.'
                  : daily.status === 'Draft' ? 'Draft saved. Open it to finish and submit.'
                  : daily.status === 'Reopened' ? 'Admin / HR reopened it for correction.'
                  : daily.status === 'Reviewed' ? 'Reviewed by Admin / HR.' : 'Submitted.'}
              </Text>
            </View>
            {daily ? <Pill text={daily.status} tone={DR_TONE[daily.status]} /> : null}
          </Row>
          <Button title={!daily ? 'Fill Daily Report' : daily.status === 'Draft' || daily.status === 'Reopened' ? 'Continue Daily Report' : 'View Daily Report'}
            icon="create-outline" style={{ marginTop: 10 }}
            onPress={() => nav.navigate('DailyReport', daily ? { reportId: daily.id } : undefined)} />
        </Card>
      ) : null}

      {/* quick actions, like the design: Attendance, Leave, Travel, More */}
      <View style={st.quick}>
        {([
          ['calendar-outline', 'Attendance', () => nav.navigate(isAdmin ? 'MyAttendance' : 'Attendance')],   // Admin / HR open these as pages, employees as tabs
          ['airplane-outline', 'Leave', () => nav.navigate(isAdmin ? 'MyLeave' : 'Leave')],
          ['walk-outline', profile.site_employee ? 'Site Selfie' : 'Regularization',
            () => nav.navigate(profile.site_employee ? 'SiteSelfie' : 'Regularization')],
          ['grid-outline', 'More', () => nav.navigate('More')],
        ] as const).map(([icon, label, go]) => (
          <Pressable key={label} onPress={go} style={st.qTile}>
            <View style={st.qIcon}><Ionicons name={icon as any} size={22} color={C.blue} /></View>
            <Text style={st.qLabel} numberOfLines={2}>{label}</Text>
            <Ionicons name="chevron-forward" size={16} color={C.muted} />
          </Pressable>
        ))}
      </View>

      <SectionTitle title="This month" note="Live attendance overview" />
      <KpiGrid>
        <Kpi label="Present Days" value={`${m.present} / ${m.working_days}`} icon="people-outline" tone="blue" note="Current month" />
        <Kpi label="Standard Day" value="8 h" icon="time-outline" tone="red" note="More is overtime" />
        <Kpi label="Leave Balance" value={`${dash.leave_balance_total} Days`} icon="airplane-outline" tone="purple" note="All leave types" />
        <Kpi label="Working Hours" value={`${Number(m.hours).toFixed(1)} h`} icon="bar-chart-outline" tone="cyan" note="Recorded this month" />
      </KpiGrid>

      <Card>
        <MonthCalendar year={p.year} month={p.month} days={days} />
      </Card>

      <Card>
        <Row style={{ justifyContent: 'space-between', marginBottom: 4 }}>
          <Text style={st.cardTitle}>Profile</Text>
          <Pill text={profile.site_employee ? 'Site + Selfie' : 'Office'} tone="cyan" />
        </Row>
        <Row style={{ marginBottom: 10 }}>
          <Avatar name={profile.full_name} size={50} />
          <View style={{ flex: 1 }}>
            <Text style={st.name}>{profile.full_name}</Text>
            <Text style={st.caption}>{shownRole(profile)} - {profile.department || 'General'}</Text>
          </View>
        </Row>
        <View style={st.todayGrid}>
          <InfoTile label="Employee ID" value={profile.username} />
        </View>
      </Card>

      <View style={st.footer}>
        <Ionicons name="stats-chart" size={18} color="#8AE9FF" />
        <Text style={st.footerText}>Discipline with Time Builds Extraordinary Teams.</Text>
      </View>
    </Screen>
  );
}

const st = StyleSheet.create({
  quick: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  qTile: { flexGrow: 1, flexBasis: '45%', flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.white, borderRadius: 16, padding: 12, borderWidth: 1, borderColor: '#E4EDF6' },
  qIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#EAF3FF', alignItems: 'center', justifyContent: 'center' },
  qLabel: { flex: 1, fontWeight: '800', color: '#17314D', fontSize: 13.5 },
  caption: { fontSize: 12, color: C.muted },
  clock: { fontSize: 26, fontWeight: '800', color: '#102944', marginTop: 2 },
  todayGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  cardTitle: { fontWeight: '800', color: '#17314D', fontSize: 15 },
  name: { fontWeight: '800', color: '#102A45', fontSize: 16 },
  footer: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#073155', borderRadius: 15, padding: 14, marginTop: 4 },
  footerText: { color: C.white, fontWeight: '700', flex: 1 },
});
