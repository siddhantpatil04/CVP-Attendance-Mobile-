import { useFocusEffect, useNavigation } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { ActivityIndicator, Alert, Text } from 'react-native';
import { DR_TONE, fmtKm, reportNo } from '../../components/DailyReportView';
import { MonthPicker } from '../../components/Pickers';
import { Card, Empty, ListItem, Pill, Screen } from '../../components/ui';
import { api, DailyReport } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { errorText } from '../../lib/supabase';
import { fmtISODate, istDateISO } from '../../lib/time';
import { C } from '../../theme';

/** Employee: my own Daily Reports by month. A Draft or Reopened report opens for editing, the others open read only. */
export default function DailyReportHistoryScreen() {
  const { profile } = useAuth();
  const nav = useNavigation<any>();
  const today = istDateISO();
  const [year, setYear] = useState(Number(today.slice(0, 4)));
  const [month, setMonth] = useState(Number(today.slice(5, 7)));
  const [rows, setRows] = useState<DailyReport[] | null>(null);

  const load = useCallback(async () => {
    if (!profile) return;
    const mm = String(month).padStart(2, '0');
    const to = `${year}-${mm}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}`;
    try { setRows(await api.myDailyReports(profile.id, `${year}-${mm}-01`, to)); }
    catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [profile, year, month]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  return (
    <Screen>
      <MonthPicker year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); setRows(null); }} />
      <Card style={{ paddingVertical: 4 }}>
        {!rows ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : rows.length === 0 ? (
          <Empty icon="document-text-outline" text="No daily reports in this month." />
        ) : rows.map((r) => {
          const names = r.daily_report_sites.map((s) => s.site_name).filter(Boolean).join(', ');
          return (
            <ListItem key={r.id}
              title={`${fmtISODate(r.report_date)}  -  ${reportNo(r.id)}`}
              subtitle={`${r.daily_report_sites.length} site(s)${names ? ': ' + names : ''}${r.gps_km != null ? ' - ' + fmtKm(r.gps_km) : ''}`}
              right={<Pill text={r.status} tone={DR_TONE[r.status]} />}
              onPress={() => nav.navigate('DailyReport', { reportId: r.id })} />
          );
        })}
      </Card>
      <Text style={{ color: C.muted, fontSize: 12, marginTop: 6 }}>
        Tap a report to open it. Draft and Reopened reports can be edited; Submitted and Reviewed reports are read only.
      </Text>
    </Screen>
  );
}
