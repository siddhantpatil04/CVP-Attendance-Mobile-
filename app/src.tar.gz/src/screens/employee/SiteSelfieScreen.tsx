import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import React, { useCallback, useState } from 'react';
import { Alert, Image, Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import {
  Banner, Button, Card, Chips, Empty, Field, InfoTile, ListItem, Loading, Pill, Screen, SectionTitle,
} from '../../components/ui';
import { Dropdown } from '../../components/Pickers';
import { DaySummaryCard } from '../../components/FieldVisitBits';
import PlacePicker from '../../components/PlacePicker';
import ShortHoursSheet from '../../components/ShortHoursSheet';
import WorkingHoursCard from '../../components/WorkingHoursCard';
import { api, CheckoutReportStatus, FieldDayRow, MyDashboard, NearPlace, OpenSite, SelfieRecord, Site } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { currentPosition, distanceM, fmtDistance, isForeignSiteName, nearestWorkSite } from '../../lib/geo';
import { DEFAULT_RANGE_M, DEFAULT_REQUIRED_MIN, hm } from '../../lib/hours';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtDateLong, fmtMinutes, fmtTime12, istDateISO } from '../../lib/time';
import { C } from '../../theme';

export default function SiteSelfieScreen() {
  const { profile } = useAuth();
  const [dash, setDash] = useState<MyDashboard | null>(null);
  const [clockOffset, setClockOffset] = useState(0); // server clock - phone clock
  const [recent, setRecent] = useState<SelfieRecord[]>([]);
  const [site, setSite] = useState('');
  const [sites, setSites] = useState<Site[]>([]);
  const [note, setNote] = useState('');
  const [reason, setReason] = useState('');   // why the check-out is from a foreign location
  // 'Foreign Location' chosen in Select place: the employee then picks the exact work site (foreign_location_place.sql)
  const [fpMode, setFpMode] = useState(false);
  const [fpSiteId, setFpSiteId] = useState(0);
  const nav = useNavigation<any>();
  const [day, setDay] = useState<FieldDayRow | null>(null);   // what the system worked out for today (after the Field Visit trips)
  type Shot = { uri: string; base64: string };
  // One separate selfie for check-in and another for check-out
  const [photos, setPhotos] = useState<{ IN?: Shot; OUT?: Shot }>({});
  const [busy, setBusy] = useState(false);
  // Where the phone is right now (used to decide whether a selfie is allowed)
  const [pos, setPos] = useState<{ lat: number; lng: number; acc?: number | null } | null>(null);
  const [locating, setLocating] = useState(false);
  const [locError, setLocError] = useState(false);
  // Daily Report required before check-out (null = the database update is not installed: nothing is locked)
  const [rule, setRule] = useState<CheckoutReportStatus | null>(null);
  const [askReport, setAskReport] = useState(false);

  // Places (allocated sites + the office) within the Admin range right now, nearest first (the server sends only these)
  const [near, setNear] = useState<NearPlace[]>([]);
  // Admin working-time rules for this employee: range (default 500 m) and required hours (default 8h)
  const [rangeM, setRangeM] = useState(DEFAULT_RANGE_M);
  const [requiredMin, setRequiredMin] = useState(DEFAULT_REQUIRED_MIN);
  const [beforeRule, setBeforeRule] = useState<'reason' | 'block'>('reason');
  const [shortSheet, setShortSheet] = useState(false);
  const [halfToday, setHalfToday] = useState<{ part: 'first' | 'second'; type: string | null } | null>(null);   // approved half-day leave today
  const [nearErr, setNearErr] = useState('');
  const [selId, setSelId] = useState(0);
  const [allocCount, setAllocCount] = useState<number | null>(null);   // how many sites Admin allocated to me
  const [openSite, setOpenSite] = useState<OpenSite | null>(null);     // the site of today's open check-in
  const [, setTick] = useState(0);                                    // re-draws the live working time

  const measure = useCallback(async () => {
    setLocating(true);
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (perm.status !== 'granted') throw new Error('denied');
      const p = await currentPosition();
      const lat = p.coords.latitude, lng = p.coords.longitude;
      setPos({ lat, lng, acc: p.coords.accuracy });
      setLocError(false);
      try {
        // the server sends only the places within the range that this employee may use (allocated sites + the office)
        const list = await api.placesNearMe(lat, lng);
        if (list[0]?.range_m) setRangeM(list[0].range_m);
        setNear(list);
        setNearErr('');
        // keep the employee's choice only while that site is still in range (auto-selection is worked out when drawing)
        setSelId((cur) => (list.some((x) => x.site_id === cur) ? cur : 0));
      } catch (e) {
        setNear([]);
        setNearErr(errorText(e));
      }
    } catch {
      setPos(null);
      setLocError(true);
      setNear([]);
    } finally {
      setLocating(false);
    }
  }, []);
  // GPS and the near-sites list refresh every 30 seconds while this screen is open
  useFocusEffect(useCallback(() => {
    measure();
    const id = setInterval(() => { measure(); setTick((x) => x + 1); }, 30000);
    return () => clearInterval(id);
  }, [measure]));

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      const [d, r, all, mine, open] = await Promise.all([
        api.myDashboard(), api.mySelfies(profile.id), api.sites(), api.employeeSites(profile.id),
        api.myOpenCheckinSite().catch(() => null),
      ]);
      setDash(d);
      setClockOffset(new Date(d.server_time).getTime() - Date.now());
      setRecent(r);
      setSites(all);   // used only by the Foreign Location option; the normal list is the places near me
      api.workingRules().then((rs) => {
        const mine = rs.find((x) => x.kind === (profile.site_employee ? 'site' : 'office'));
        if (mine) { setRangeM(mine.range_m); setRequiredMin(mine.required_minutes); setBeforeRule(mine.before_required); }
        // an approved half-day leave today: half the hours (leave_policy_24.sql)
        api.myRequiredToday().then((r) => { if (r?.required_minutes) setRequiredMin(r.required_minutes); setHalfToday(r?.half_part ? { part: r.half_part, type: r.leave_type } : null); }).catch(() => undefined);
      }).catch(() => undefined);
      setAllocCount(mine.length);
      // check-out uses the site of the check-in; if the database update is missing, find it by name
      const openName = d.attendance?.check_in_at && !d.attendance.check_out_at ? d.attendance.site_name : null;
      const o: OpenSite | null = open ?? (openName ? (() => { const s = all.find((x) => x.name === openName); return s ? { site_id: s.id, name: s.name, lat: s.lat, lng: s.lng, radius_m: s.radius_m, is_office: !!s.is_office } : null; })() : null);
      setOpenSite(o);
      const today = istDateISO();
      let rs = await api.checkoutReportStatus();
      if (!rs && profile.site_employee) {
        // The database update is not installed yet: still show the Daily Report step and keep check-out locked in the app
        const rep = (await api.myDailyReports(profile.id, today, today).catch(() => []))[0];
        const sent = !!rep && (rep.status === 'Submitted' || rep.status === 'Reviewed');
        const inToday = !!d.attendance?.check_in_at;
        rs = { date: today, required: inToday, report_status: rep?.status ?? null, submitted_at: rep?.submitted_at ?? null,
          allowed_by_admin: false, unlocked: !inToday || sent };
      }
      setRule(rs);
      api.myFieldDay(profile.id, today).then(setDay).catch(() => setDay(null));
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [profile]);

  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime(`selfie-${profile?.id}`, [{ table: 'attendance', filter: `user_id=eq.${profile?.id}` }], () => load(), !!profile);

  if (!profile || !dash) return <Loading />;
  if (!profile.site_employee) {
    return (
      <Screen>
        <Banner tone="amber" icon="lock-closed-outline" text="Site selfie attendance is not enabled for your account. Ask HR to enable 'Site Employee' in Access Control." />
      </Screen>
    );
  }

  // Site Selfie = ONE check-in and ONE check-out for the day (site-to-site travel is in the Field Site section)
  const t = dash.attendance;
  const action: 'IN' | 'OUT' | null = !t?.check_in_at ? 'IN' : !t.check_out_at ? 'OUT' : null;
  // The check-out stays locked until today's Daily Report is SUBMITTED (a draft does not unlock it)
  const reportLocked = !!rule?.required && !rule.unlocked;
  const reportDone = !!rule && (rule.report_status === 'Submitted' || rule.report_status === 'Reviewed');
  // Foreign Location place type: the check-out always continues the check-in's Foreign Location site
  // - the latest check-in selfie record of today tells whether it was a Foreign Location one
  const openIn = t?.check_in_at && !t.check_out_at ? recent.find((r) => r.kind === 'IN' && r.attendance_id === t.id) : undefined;
  const fpOpenRec = openIn?.place_type === 'Foreign Location' ? openIn : undefined;
  const fp = !!fpOpenRec || (fpMode && action === 'IN');
  const fpSites = sites.filter((s) => !s.is_office);   // every existing work site can be used; no separate list
  const fpSite = fpOpenRec ? sites.find((s) => s.name === fpOpenRec.site_name) : fpSites.find((s) => s.id === fpSiteId);

  // the allowed distance is the Admin range (default 500 m) for every place, office included
  const asSite = (x: { site_id: number; name: string; lat: number; lng: number; radius_m: number; is_office: boolean }): Site =>
    ({ id: x.site_id, name: x.name, lat: x.lat, lng: x.lng, radius_m: rangeM, active: true, is_office: x.is_office });
  // Check-in: one of my allocated sites that is in range. Check-out: always the site of the check-in (no selection).
  // Auto-select: the one site in range; for check-out the check-in site if it is in range
  // No auto-select: the nearest sites are listed and the employee taps the one he is at
  const effSel = near.some((x) => x.site_id === selId) ? selId : 0;
  const nearPick = near.find((x) => x.site_id === effSel);
  // Admin "Allow once" lets a check-out through away from a site: the check-in site is then used
  const viaOverride = action === 'OUT' && !nearPick && near.length === 0 && !!rule?.allowed_by_admin && !!openSite;
  const normalSite: Site | undefined = nearPick ? asSite(nearPick) : viaOverride ? asSite(openSite!) : undefined;
  const siteName = fp ? (fpSite?.name ?? '') : (normalSite?.name ?? '');

  // Inside / outside the chosen site's allowed radius (the database re-checks this on submit)
  const chosen = fp ? fpSite : normalSite;
  const noAlloc = allocCount === 0;
  // live working time: from check-in until now (or until check-out)
  const workMin = t?.check_in_at ? Math.max(0, Math.round(((t.check_out_at ? new Date(t.check_out_at).getTime() : Date.now() + clockOffset) - new Date(t.check_in_at).getTime()) / 60000)) : null;
  const dist = pos && chosen ? distanceM(pos.lat, pos.lng, chosen.lat, chosen.lng) : null;
  // Wide site: a check-out may be made from a different place than the check-in (still with a selfie)
  const wideOut = !fp && !!profile?.wide_site_access && (action === 'OUT' || action === 'IN');
  const outside = chosen != null && dist != null && dist > chosen.radius_m && !wideOut;
  const atOffice = !fp && !!chosen?.is_office;   // the office location: no selfie, but only inside its area
  // Foreign location: Admin / HR allowed this employee to check out from any place. Away from the site he must give a reason.
  const foreign = wideOut && !atOffice && chosen != null && dist != null && dist > chosen.radius_m;

  const takeSelfie = async (kind: 'IN' | 'OUT') => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Camera permission needed', 'Allow camera access in Settings to submit a site selfie.');
      return;
    }
    const res = await ImagePicker.launchCameraAsync({
      cameraType: ImagePicker.CameraType.front,
      quality: 0.8,
      allowsEditing: false,
      mediaTypes: ['images'],
    });
    if (res.canceled || !res.assets?.[0]) return;
    // Shrink to ~720px wide JPEG to keep uploads fast on site networks
    const ref = await ImageManipulator.manipulate(res.assets[0].uri).resize({ width: 720 }).renderAsync();
    const out = await ref.saveAsync({ compress: 0.6, format: SaveFormat.JPEG, base64: true });
    if (!out.base64) {
      Alert.alert('Could not process photo');
      return;
    }
    setPhotos((p) => ({ ...p, [kind]: { uri: out.uri, base64: out.base64 } }));
  };

  const submit = async (kind: 'IN' | 'OUT', shortReason?: string) => {
    if (action !== kind) return;
    const photo = photos[kind];
    if (!chosen) return Alert.alert(kind === 'IN' ? 'Select your place first.' : 'Select the place you are at now first.');
    // Before the required hours: warning + a reason (saved with the day, Admin sees it)
    if (kind === 'OUT' && !shortReason && workMin != null && workMin < requiredMin) { setShortSheet(true); return; }
    setShortSheet(false);
    setBusy(true);
    let path: string | null = null;
    try {
      // Location is mandatory for site attendance (both check-in and check-out)
      let loc: { lat: number; lng: number };
      try {
        const perm = await Location.requestForegroundPermissionsAsync();
        if (perm.status !== 'granted') throw new Error('denied');
        const p = await currentPosition();
        loc ={ lat: p.coords.latitude, lng: p.coords.longitude };
        setPos({ ...loc, acc: p.coords.accuracy });
      } catch {
        Alert.alert('Location required', 'Allow location access and turn on GPS, then submit again. Site attendance cannot be saved without your location.');
        return;
      }

      if (kind === 'OUT' && shortReason) await api.setShortHoursReason(shortReason);

      // Foreign Location (place type): live selfie + GPS, and only inside the chosen site's allowed radius (the database checks it again)
      if (fp) {
        if (!chosen) { Alert.alert('Select the foreign site / location first.'); return; }
        if (!reason.trim()) { Alert.alert('Reason needed', 'Write the reason for using Foreign Location first.'); return; }
        if (!photo) { Alert.alert(kind === 'IN' ? 'Take your live check-in selfie first.' : 'Take your live check-out selfie first.'); return; }
        path = await api.uploadSelfie(profile.id, photo.base64, kind, istDateISO());
        // "Foreign location" has no radius limit: the distance is recorded from the nearest real work site
        const pickedForeign = isForeignSiteName(chosen.name);
        const target = pickedForeign ? nearestWorkSite(loc.lat, loc.lng, fpSites) : chosen;
        if (!target) { Alert.alert('No work site found', 'There is no work site to measure the distance from. Ask your Admin.'); return; }
        const fo = { ...loc, note: note.trim() || undefined, photoPath: path, reason: pickedForeign ? `Foreign location: ${reason.trim()}` : reason.trim() };
        const fr = kind === 'IN' ? await api.foreignPlaceCheckIn({ ...fo, siteId: target.id }) : await api.foreignPlaceCheckOut(fo);
        const fdm: number | null = (kind === 'IN' ? fr.check_in_dist_m : fr.check_out_dist_m) ?? null;
        setPhotos((x) => ({ ...x, [kind]: undefined }));
        setNote('');
        setReason('');
        setFpMode(false);
        setFpSiteId(0);
        Alert.alert('Submitted', `Foreign Location ${kind === 'IN' ? 'check-in' : 'check-out'} saved at ${target.name}.${pickedForeign ? ` (Foreign location: no radius limit)` : ''}${fdm != null ? ` You were ${fdm} m from the site point.` : ''}`);
        await load();
        return;
      }

      // Re-check with the fresh position: a selfie is only taken and sent from inside the site area
      const wideHere = !!profile?.wide_site_access && !atOffice;
      const isOutside = chosen != null && distanceM(loc.lat, loc.lng, chosen.lat, chosen.lng) > chosen.radius_m && !wideHere;
      const isForeign = wideHere && chosen != null && distanceM(loc.lat, loc.lng, chosen.lat, chosen.lng) > chosen.radius_m;
      if (isForeign && !reason.trim()) {
        Alert.alert('Reason needed', `You are checking ${kind === 'IN' ? 'in' : 'out'} from a foreign location (away from the site). Write the reason first.`);
        return;
      }
      if (atOffice && isOutside) {
        Alert.alert('You are not at the office', `You are ${fmtDistance(distanceM(loc.lat, loc.lng, chosen!.lat, chosen!.lng))} away from ${chosen!.name}. Office check-in / check-out is only possible within ${fmtDistance(chosen!.radius_m)}.`);
        return;
      }
      if (!isOutside && !atOffice) {
        if (!photo) {
          Alert.alert(kind === 'IN' ? 'Take your check-in selfie first.' : 'Take your check-out selfie first.');
          return;
        }
        path = await api.uploadSelfie(profile.id, photo.base64, kind, istDateISO());
      }
      // The place he selected for check-out is saved (the server checks the allocation and the range again)
      if (kind === 'OUT' && !viaOverride && !wideHere) await api.selectCheckoutPlace(chosen.id, loc.lat, loc.lng);
      const opts ={ ...loc, siteName, siteId: chosen?.id, note: note.trim() || undefined, photoPath: path ?? undefined, reason: isForeign ? reason.trim() : undefined };
      let dm: number | null = null;
      let doneMin: number | null = null;
      if (kind === 'IN') { const r = await api.checkIn(opts); dm = r.check_in_dist_m ?? null; }
      else { const r = await api.checkOut(opts); dm = r.check_out_dist_m ?? null; doneMin = r.work_minutes ?? null; }
      setPhotos((p) => ({ ...p, [kind]: undefined }));
      setSelId(0);                                        // the next punch starts with no place selected
      setNote('');
      setReason('');
      const distNote = (dm != null ? ` You were ${dm} m from ${siteName || 'the location'}.` : '')
        + (doneMin != null ? ` Worked ${hm(doneMin)} - ${doneMin >= requiredMin ? 'Full day' : `Short hours (${hm(requiredMin - doneMin)} short)`}.` : '');
      Alert.alert(
        'Submitted',
        (isOutside
          ? 'Saved without a selfie because you are outside the site area. Your admin can see this was done from another location.'
          : atOffice ? 'Office attendance saved. No selfie is needed at the office.' : 'Selfie attendance submitted successfully.') + distNote,
      );
      await load();
    } catch (e) {
      if (path) api.removeSelfie(path).catch(() => {});
      Alert.alert('Submission failed', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <Card>
        <Text style={st.title}>Live Site Selfie</Text>
        <Text style={st.caption}>{fmtDateLong()}{t?.site_name ? ` - Site: ${t.site_name}` : ''}</Text>

        {halfToday ? (
          <Banner tone="blue" icon="time-outline" text={`Today - Half Day (${halfToday.part === 'first' ? 'morning' : 'afternoon'} off). Required today ${hm(requiredMin)}.`} />
        ) : null}
        <View style={st.grid}>
          <InfoTile style={st.tile3} label="Check In" value={t?.check_in_at ? fmtTime12(t.check_in_at) : 'Pending'} />
          <InfoTile style={st.tile3} label="Check Out" value={t?.check_out_at ? fmtTime12(t.check_out_at) : 'Pending'} />
          <InfoTile style={st.tile3} label="Working time" value={workMin != null ? fmtMinutes(workMin) : '-'} />
        </View>

        {t?.check_in_at ? (
          <Text style={st.caption}>Checked in at {fmtTime12(t.check_in_at)} - {t.site_name ?? ''}{t.check_in_dist_m != null ? ` (${t.check_in_dist_m} m from site point)` : ''}</Text>
        ) : null}
        {t?.check_out_at ? (
          <Text style={st.caption}>Checked out at {fmtTime12(t.check_out_at)} - {(t as any).check_out_site_name ?? t.site_name ?? ''}{t.check_out_dist_m != null ? ` (${t.check_out_dist_m} m from site point)` : ''}</Text>
        ) : null}

        {action ? (
          <>
            {fpOpenRec ? (
              <Banner tone="blue" icon="location-outline" text={`Checking out of ${fpOpenRec.site_name} (Foreign Location). Check out at the same site where you checked in.`} />
            ) : fpMode && action === 'IN' ? (
              <Button title="Back to my allocated sites" icon="arrow-back-outline" variant="ghost" small onPress={() => { setFpMode(false); setFpSiteId(0); }} />
            ) : (
              <>
                <Banner tone="blue" icon="time-outline" text={`No time limit - check in or out any time. ${hm(requiredMin)} is counted from your check-in to your check-out.`} />
                {locating && near.length === 0 && !pos ? <Banner tone="blue" icon="locate-outline" text="Finding your location..." />
                  : locError ? <Banner tone="amber" icon="location-outline" text="Location is not available. Allow location access and turn on GPS." />
                  : nearErr ? <Banner tone="red" icon="warning-outline" text={nearErr} />
                  : viaOverride ? (
                    <Banner tone="blue" icon="shield-checkmark-outline" text={`Admin allowed this check-out. It will be saved at ${openSite!.name}.`} />
                  ) : near.length === 0 ? (
                    <Banner tone="amber" icon="navigate-outline" text={`No site or office within ${fmtDistance(rangeM)}. Move closer to your place.`} />
                  ) : (
                    <PlacePicker
                      title={action === 'OUT' ? 'Select check-out place' : 'Select your place'}
                      hint={action === 'OUT' ? 'Not selected automatically - choose where you are now.' : undefined}
                      places={near} selectedId={effSel || null} onSelect={(p) => setSelId(p.site_id === effSel ? 0 : p.site_id)}   // tap again to un-select
                      rangeM={rangeM} loading={locating} error={null} onRefresh={measure} hideRefresh />
                  )}
                <Button title="Refresh my location" icon="locate-outline" variant="ghost" small loading={locating} onPress={measure} style={{ marginTop: 6 }} />
                {action === 'IN' ? <Button title="Foreign Location" icon="earth-outline" variant="ghost" small onPress={() => setFpMode(true)} /> : null}
              </>
            )}
            {fp ? (
              <View style={st.fpBox}>
                <Text style={st.fpTitle}>Foreign Location attendance{action === 'OUT' ? ' - Check-Out' : ''}</Text>
                <Text style={st.fpLabel}>Foreign site / location *</Text>
                {fpOpenRec ? (
                  <InfoTile label="Check-in site" value={fpOpenRec.site_name} />
                ) : (
                  <Dropdown width="100%" value={fpSite ? fpSite.id : -1} onChange={(v) => setFpSiteId(v > 0 ? v : 0)}
                    options={[{ value: -1, label: 'Select foreign location' }, ...fpSites.map((s) => ({ value: s.id, label: s.name }))]} />
                )}
                {fpSite ? (
                  <>
                    <View style={st.fpGrid}>
                      <InfoTile label="Date" value={fmtDateLong()} />
                      <InfoTile label={action === 'OUT' ? 'Check-out time' : 'Check-in time'} value={fmtTime12(new Date(Date.now() + clockOffset).toISOString())} />
                      <InfoTile label="GPS" value={pos ? `${pos.lat.toFixed(4)}, ${pos.lng.toFixed(4)}` : locating ? 'Checking...' : 'Not available'} />
                      {action === 'OUT' && t?.check_in_at
                        ? <InfoTile label="Working time" value={fmtMinutes(Math.max(0, Math.round((Date.now() + clockOffset - new Date(t.check_in_at as string).getTime()) / 60000)))} />
                        : <InfoTile label="Accuracy" value={pos?.acc != null ? `+/-${Math.round(pos.acc)} m` : '-'} />}
                    </View>
                    {locating ? <Banner tone="blue" icon="locate-outline" text="Checking your location..." />
                      : locError ? <Banner tone="amber" icon="location-outline" text="Location is not available. Allow location access and turn on GPS." />
                      : dist != null ? (
                        <Banner tone="blue" icon="location-outline" text={isForeignSiteName(fpSite.name)
                          ? (() => { const nw = pos ? nearestWorkSite(pos.lat, pos.lng, fpSites) : undefined; return nw && pos ? `No distance limit here. Your location is recorded: ${fmtDistance(distanceM(pos.lat, pos.lng, nw.lat, nw.lng))} from the nearest work site (${nw.name}).` : 'No distance limit here. Your location is recorded.'; })()
                          : `Your location is recorded: ${fmtDistance(dist)} from ${fpSite.name}.`} />
                      ) : null}
                    <Field label={`Reason for using Foreign Location (required)`} value={reason} onChangeText={setReason} multiline
                      placeholder="e.g. Working at the client's other premises today" />
                  </>
                ) : (
                  <Text style={st.caption}>Select the exact place where you are working. The list shows all your existing work sites - no separate setup needed.</Text>
                )}
              </View>
            ) : null}            {!fp && chosen ? (
              locating ? <Banner tone="blue" icon="locate-outline" text="Checking your location..." />
                : locError ? <Banner tone="amber" icon="location-outline" text="Location is not available. Allow location access and turn on GPS." />
                : outside && atOffice ? (
                  <Banner tone="red" icon="warning-outline"
                    text={`You are ${fmtDistance(dist!)} away from the office (${chosen.name}). Office check-in / check-out is only possible within ${fmtDistance(chosen.radius_m)}.`} />
                ) : outside ? (
                  <Banner tone="red" icon="warning-outline"
                    text={`You are ${fmtDistance(dist!)} away from ${chosen.name} (allowed ${fmtDistance(chosen.radius_m)}). You can still check in / out, but no selfie is taken and your admin will see it was done from another location.`} />
                ) : foreign ? (
                  <Banner tone="amber" icon="earth-outline"
                    text={`You are ${fmtDistance(dist!)} away from ${chosen.name}. You can ${action === 'IN' ? 'check in' : 'check out'} from this foreign location: write the reason and take a selfie below.`} />
                ) : dist != null ? (
                  <Banner tone="green" icon="checkmark-circle-outline" text={atOffice ? `You are at the office: ${fmtDistance(dist)} from ${chosen.name}. No selfie is needed here.` : `You are at ${chosen.name} (${fmtDistance(dist)} from the site point).`} />
                ) : null
            ) : null}
          </>
        ) : rule?.required ? null : (
          <Banner tone="green" icon="checkmark-done" text="Today's site attendance is complete. Both check-in and check-out are recorded." />
        )}
      </Card>

      {t?.check_in_at ? <WorkingHoursCard checkInAt={t.check_in_at as string} worked={workMin ?? 0} requiredMin={requiredMin} done={!!t.check_out_at} /> : null}

      <ShortHoursSheet visible={shortSheet} worked={workMin ?? 0} requiredMin={requiredMin} busy={busy}
        blocked={beforeRule === 'block'} onStay={() => setShortSheet(false)} onConfirm={(r) => submit('OUT', r)} />

      {wideOut && !atOffice && chosen ? (
        <Card style={foreign ? { borderColor: '#F3C98B', backgroundColor: '#FFF9EE' } : undefined}>
          <View style={st.stepHead}>
            <Text style={st.title}>Foreign location {action === 'IN' ? 'check-in' : 'check-out'}</Text>
            <Pill text={foreign ? 'Foreign location' : 'At the site'} tone={foreign ? 'amber' : 'green'} />
          </View>
          <View style={st.fRow}><Text style={st.fLabel}>Your live location</Text>
            <Text style={st.fVal}>{pos ? `${pos.lat.toFixed(5)}, ${pos.lng.toFixed(5)}` : locating ? 'Checking...' : 'Not available'}</Text></View>
          <View style={st.fRow}><Text style={st.fLabel}>Distance to {chosen.name}</Text>
            <Text style={[st.fVal, foreign && { color: C.red }]}>{dist != null ? `${fmtDistance(dist)} (site area ${fmtDistance(chosen.radius_m)})` : '-'}</Text></View>
          <View style={st.fRow}><Text style={st.fLabel}>Check-out location saved</Text>
            <Text style={st.fVal}>{pos ? `${pos.lat.toFixed(5)}, ${pos.lng.toFixed(5)}` : '-'}</Text></View>
          {foreign ? (
            <Field label={`Reason for ${action === 'IN' ? 'checking in' : 'checking out'} from another location (required)`} value={reason} onChangeText={setReason} multiline
              placeholder={action === 'IN' ? 'e.g. Going straight to the client meeting' : 'e.g. Work finished at the other end of the pipeline'} />
          ) : null}
          <Button title="Refresh my location" icon="locate-outline" variant="ghost" small loading={locating} onPress={measure} />
        </Card>
      ) : null}

      {rule?.required ? (
        <>
          <Card>
            <Text style={st.title}>Today at site</Text>
            <StepRow n={1} state="done" title="Check-in selfie"
              sub={[t?.check_in_at ? fmtTime12(t.check_in_at) : '', t?.site_name ?? '', t?.check_in_dist_m != null ? `${t.check_in_dist_m} m` : ''].filter(Boolean).join(' - ')}
              pill="Done" tone="green" />
            <StepRow n={2} state={reportDone || rule.allowed_by_admin ? 'done' : 'required'} title="Daily Report"
              sub={reportDone ? `Submitted${rule.submitted_at ? ' ' + fmtTime12(rule.submitted_at) : ''}` : rule.allowed_by_admin ? 'Allowed by Admin' : 'Fill before you check out'}
              pill={reportDone ? 'Done' : rule.allowed_by_admin ? 'Allowed' : 'Required'} tone={reportDone ? 'green' : rule.allowed_by_admin ? 'blue' : 'amber'} />
            <StepRow n={3} last state={t?.check_out_at ? 'done' : reportLocked ? 'locked' : 'next'} title="Check-out selfie"
              sub={t?.check_out_at
                ? [fmtTime12(t.check_out_at), t.check_out_dist_m != null ? `${t.check_out_dist_m} m from site` : ''].filter(Boolean).join(' - ')
                : reportLocked ? 'Opens after Daily Report is submitted' : 'Live selfie + GPS'}
              pill={t?.check_out_at ? 'Done' : reportLocked ? 'Locked' : 'Next'} tone={t?.check_out_at ? 'green' : reportLocked ? 'muted' : 'blue'} />
          </Card>

          {reportLocked ? (
            <>
              <View style={st.pending}>
                <Text style={st.pendingTitle}>Daily Report pending</Text>
                <Text style={st.pendingText}>Submit today's report to unlock check-out.</Text>
              </View>
              <Button title="Fill Daily Report" icon="create-outline" onPress={() => nav.navigate('DailyReport')} />
              <Pressable onPress={() => setAskReport(true)} accessibilityRole="button" style={{ marginTop: 10 }}>
                <View pointerEvents="none"><Button title="Submit Check-Out" icon="lock-closed-outline" disabled /></View>
              </Pressable>
            </>
          ) : !t?.check_out_at && t?.check_in_at ? (
            <Banner tone="green" icon="checkmark-circle-outline"
              text={rule.allowed_by_admin && !reportDone ? 'Check-Out is now unlocked (allowed by Admin).'
                : `Report submitted${rule.submitted_at ? ' ' + fmtTime12(rule.submitted_at) : ''} - Check-Out is now unlocked.`} />
          ) : null}

        </>
      ) : null}

      {(['IN', 'OUT'] as const).map((kind) => {
        const done = kind === 'IN' ? !!t?.check_in_at : !!t?.check_out_at;
        const active = action === kind;
        const shot = photos[kind];
        const isIn = kind === 'IN';
        const outLocked = !isIn && reportLocked && !done;   // check-out waits for the submitted Daily Report
        // With the "Today at site" checklist on screen only the active selfie card is shown (done / locked steps are in the checklist)
        if (rule?.required && (!active || outLocked)) return null;
        return (
          <Card key={kind} style={!active && !done ? { opacity: 0.6 } : undefined}>
            <View style={st.stepHead}>
              <Text style={st.title}>{rule?.required ? (isIn ? 'Check In selfie' : 'Check Out selfie') : isIn ? '1. Check In selfie' : '2. Check Out selfie'}</Text>
              <Pill text={done ? 'Done' : outLocked ? 'Locked' : active ? 'Next' : 'Locked'}
                tone={done ? 'green' : outLocked ? 'muted' : active ? 'blue' : 'muted'} />
            </View>
            {done ? (
              <Text style={st.caption}>
                {isIn ? 'Checked in' : 'Checked out'} at {fmtTime12(isIn ? t?.check_in_at : t?.check_out_at)}
              </Text>
            ) : !active ? (
              null
            ) : !isIn && reportLocked ? (
              <>
                <Banner tone="amber" icon="lock-closed-outline" text="Please submit today's Daily Report before checking out. Your check-in stays saved." />
                <Pressable onPress={() => setAskReport(true)} accessibilityRole="button" style={{ marginTop: 10 }}>
                  <View pointerEvents="none"><Button title="Submit Check-Out" icon="lock-closed-outline" disabled /></View>
                </Pressable>
              </>
            ) : (
              <>
                {atOffice || (outside && !fp) ? null : shot ? (
                  <View style={{ alignItems: 'center', marginVertical: 10 }}>
                    <Image source={{ uri: shot.uri }} style={st.preview} />
                    <Button title="Retake" icon="refresh" variant="ghost" small onPress={() => takeSelfie(kind)} />
                  </View>
                ) : (
                  <Button title={isIn ? 'Take check-in selfie' : 'Take check-out selfie'} icon="camera-outline"
                    variant="secondary" onPress={() => takeSelfie(kind)} style={{ marginVertical: 10 }} />
                )}
                <Button
                  title={`${isIn ? 'Submit Check-In' : 'Submit Check-Out'}${outside && !atOffice && !fp ? ' (no selfie)' : ''}`}
                  icon={isIn ? 'log-in-outline' : 'log-out-outline'}
                  variant={isIn ? 'success' : 'primary'}
                  disabled={fp ? (!chosen || !reason.trim() || !shot) : (!chosen || (atOffice ? outside : (!outside && !shot)))}
                  loading={busy}
                  onPress={() => submit(kind)}
                  style={{ marginTop: 10 }}
                />
              </>
            )}
          </Card>
        );
      })}

      {t?.check_out_at ? (
        <>
          {t.check_in_at ? (
            <Banner tone="green" icon="time-outline"
              text={`Working time today: ${fmtMinutes(Math.max(0, Math.round((new Date(t.check_out_at).getTime() - new Date(t.check_in_at).getTime()) / 60000)))}`} />
          ) : null}
          {day && day.check_in_at ? <DaySummaryCard day={day} /> : null}
        </>
      ) : null}

      <Modal visible={askReport} transparent animationType="slide" onRequestClose={() => setAskReport(false)}>
        <Pressable style={st.sheetBackdrop} onPress={() => setAskReport(false)}>
          <Pressable style={st.sheet} onPress={() => {}}>
            <Ionicons name="lock-closed" size={26} color="#C98400" />
            <Text style={st.sheetTitle}>Daily Report required</Text>
            <Text style={st.caption}>Please submit today's Daily Report before checking out. Your check-in is saved and stays as it is.</Text>
            <Button title="Fill Daily Report now" icon="create-outline" style={{ marginTop: 14 }}
              onPress={() => { setAskReport(false); nav.navigate('DailyReport'); }} />
            <Button title="Cancel" variant="secondary" style={{ marginTop: 8 }} onPress={() => setAskReport(false)} />
          </Pressable>
        </Pressable>
      </Modal>

      <SectionTitle title="Recent site records" note="Your latest selfie attendance" />
      <Card>
        {recent.length === 0 ? <Empty text="No selfie attendance records yet." icon="camera-outline" /> : recent.map((r) => (
          <ListItem key={r.id} icon="location-outline" title={r.site_name}
            subtitle={`${fmtDateLong(r.captured_at)} - ${fmtTime12(r.captured_at)}${r.note ? ' - ' + r.note : ''}`}
            right={<View style={st.tags}>{r.place_type === 'Foreign Location' ? <Pill text="Foreign Location" tone="amber" /> : null}<Pill text={r.kind === 'IN' ? 'Check In' : 'Check Out'} tone={r.kind === 'IN' ? 'green' : 'blue'} /></View>} />
        ))}
      </Card>
    </Screen>
  );
}

/** One line of the "Today at site" checklist: numbered circle (green tick when done), title, small text, status pill */
function StepRow({ n, state, title, sub, pill, tone, last }: {
  n: number; state: 'done' | 'required' | 'next' | 'locked'; title: string; sub: string;
  pill: string; tone: 'green' | 'amber' | 'blue' | 'muted'; last?: boolean;
}) {
  const bg = state === 'done' ? C.green : state === 'required' ? '#E59A0C' : state === 'next' ? C.blue : '#B8C4D2';
  return (
    <View style={[st.checkRow, last && { borderBottomWidth: 0 }]}>
      <View style={[st.stepDot, { backgroundColor: bg }]}>
        {state === 'done' ? <Ionicons name="checkmark" size={16} color="#FFFFFF" /> : <Text style={st.stepDotText}>{n}</Text>}
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={st.checkText}>{title}</Text>
        {sub ? <Text style={st.checkSub} numberOfLines={2}>{sub}</Text> : null}
      </View>
      <Pill text={pill} tone={tone} />
    </View>
  );
}

const st = StyleSheet.create({
  label: { fontSize: 12, fontWeight: '800', color: '#4A5A6E', marginBottom: 6, marginTop: 4 },
  nearRow: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderColor: '#DCE7F3', borderRadius: 12, padding: 11, marginBottom: 6, backgroundColor: '#FBFDFF' },
  nearOn: { borderColor: C.blue, backgroundColor: '#EEF6FF' },
  tile3: { flexGrow: 1, flexShrink: 1, flexBasis: 0, minWidth: 0 },
  stepDot: { width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  stepDotText: { color: '#FFFFFF', fontSize: 13, fontWeight: '800' },
  checkSub: { fontSize: 12, color: C.muted, marginTop: 1 },
  pending: { backgroundColor: '#FFF6E5', borderColor: '#F3C98B', borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 10 },
  pendingTitle: { fontSize: 15, fontWeight: '800', color: '#7A4B00' },
  pendingText: { fontSize: 13, color: '#7A4B00', marginTop: 2 },
  fieldLink: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: '#9CC4F5', borderStyle: 'dashed', borderRadius: 14, padding: 14, marginTop: 12, backgroundColor: '#FAFCFF' },
  fieldLinkTitle: { fontSize: 14, fontWeight: '800', color: C.ink },
  fieldLinkSub: { fontSize: 12.5, color: C.muted, marginTop: 1 },
  title: { fontSize: 17, fontWeight: '800', color: C.ink },
  caption: { fontSize: 12.5, color: C.muted, marginTop: 4, lineHeight: 19 },
  km: { backgroundColor: '#E8F7EE', borderRadius: 14, padding: 14, alignItems: 'center' },
  kmLabel: { fontSize: 12, fontWeight: '800', color: '#1B6B3A', textTransform: 'uppercase', textAlign: 'center' },
  kmVal: { fontSize: 32, fontWeight: '800', color: '#102A45', marginTop: 2 },
  grid: { flexDirection: 'row', gap: 8, marginVertical: 12 },
  stepHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  fRow: { backgroundColor: '#F8FBFF', borderRadius: 8, borderWidth: 1, borderColor: '#EDF2F7', paddingVertical: 6, paddingHorizontal: 9, marginBottom: 6 },
  fLabel: { fontSize: 10.5, fontWeight: '800', color: '#8594A6', textTransform: 'uppercase' },
  fVal: { fontSize: 13, fontWeight: '700', color: '#17314D', marginTop: 1 },
  preview: { width: 220, height: 290, borderRadius: 16, backgroundColor: '#EEF2F7' },
  fpBox: { backgroundColor: '#FAF7FF', borderRadius: 14, borderWidth: 1, borderColor: '#D9C9F5', padding: 12, marginTop: 10, gap: 8 },
  fpTitle: { fontSize: 14, fontWeight: '800', color: '#4B2A9B' },
  fpLabel: { fontSize: 12, fontWeight: '800', color: '#4A5A6E' },
  fpGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tags: { flexDirection: 'row', gap: 6, alignItems: 'center' },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  checkText: { flex: 1, fontSize: 14, fontWeight: '700', color: '#102A45' },
  sheetBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(6,37,63,0.35)' },
  sheet: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, paddingBottom: 28 },
  sheetTitle: { fontSize: 18, fontWeight: '800', color: '#102A45', marginTop: 8 },
});



