import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { PickerField } from '../../components/Pickers';
import { Banner, Button, Card, Empty, Field, Loading, Pill, Row, Screen, Segmented } from '../../components/ui';
import { api, Tour } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtISODate, istDateISO } from '../../lib/time';
import { C } from '../../theme';

/** Tour: an employee who works outside the city applies; Admin / HR approve. Approved tour days count as present. */
export default function TourScreen() {
  const { profile } = useAuth();
  const [tab, setTab] = useState<'apply' | 'requests'>('apply');
  const [tours, setTours] = useState<Tour[] | null>(null);
  const today = istDateISO();
  const [city, setCity] = useState('');
  const [from, setFrom] = useState(today);
  const [to, setTo] = useState(today);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    if (!profile) return;
    try { setTours(await api.myTours(profile.id)); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [profile]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime(`tours-${profile?.id}`, [{ table: 'tours', filter: `user_id=eq.${profile?.id}` }], () => load(), !!profile);

  const submit = async () => {
    if (!city.trim()) return Alert.alert('Enter the city you are going to.');
    if (to < from) return Alert.alert('End date cannot be before start date.');
    if (!reason.trim()) return Alert.alert('Enter the purpose of the tour.');
    setBusy(true);
    try {
      await api.applyTour(city.trim(), from, to, reason.trim());
      setCity(''); setReason('');
      Alert.alert('Submitted', 'Tour request submitted to HR.');
      setTab('requests');
      await load();
    } catch (e) {
      Alert.alert('Could not submit', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  const cancel = (t: Tour) =>
    Alert.alert('Cancel this request?', `${t.city} - ${fmtISODate(t.from_day)} to ${fmtISODate(t.to_day)}`, [
      { text: 'Keep', style: 'cancel' },
      { text: 'Cancel request', style: 'destructive', onPress: async () => {
        try { await api.cancelTour(t.id); await load(); } catch (e) { Alert.alert('Error', errorText(e)); }
      } },
    ]);

  if (!tours) return <Loading />;

  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      <Segmented value={tab} onChange={setTab} options={[
        { value: 'apply', label: 'Apply Tour' },
        { value: 'requests', label: `My Tours (${tours.length})` },
      ]} />

      {tab === 'apply' ? (
        <Card>
          <Field label="City / place of tour" placeholder="e.g. Pune" value={city} onChangeText={setCity} />
          <Row>
            <PickerField label="From date" mode="date" value={from} onChange={(v) => { setFrom(v); if (to < v) setTo(v); }} />
            <PickerField label="To date" mode="date" value={to} onChange={setTo} />
          </Row>
          <Field label="Purpose of tour" placeholder="Why are you going on tour..." value={reason} onChangeText={setReason} multiline />
          <Button title="Submit Tour Request" icon="send" loading={busy} onPress={submit} />
        </Card>
      ) : (
        <Card>
          {tours.length === 0 ? <Empty text="No tour requests yet." /> : tours.map((t) => (
            <View key={t.id} style={st.req}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Text style={st.reqTitle}>{t.city}</Text>
                <Pill text={t.status} />
              </Row>
              <Text style={st.reqSub}>{fmtISODate(t.from_day)} to {fmtISODate(t.to_day)}</Text>
              <Text style={st.reqReason}>{t.reason}</Text>
              {t.review_note ? <Text style={st.reqSub}>HR note: {t.review_note}</Text> : null}
              {t.status === 'Pending' ? <Button title="Cancel request" variant="danger" small style={{ marginTop: 8, alignSelf: 'flex-start' }} onPress={() => cancel(t)} /> : null}
            </View>
          ))}
        </Card>
      )}
    </Screen>
  );
}

const st = StyleSheet.create({
  req: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  reqTitle: { fontWeight: '800', color: '#102A45', fontSize: 15 },
  reqSub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  reqReason: { color: '#203951', marginTop: 5 },
});
