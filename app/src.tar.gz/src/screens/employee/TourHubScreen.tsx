﻿import { useRoute } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Segmented } from '../../components/ui';
import TourScreen from './TourScreen';
import TourWorkScreen from './TourWorkScreen';

/** One Tour section: apply for a tour, and the expenses / documents / tasks of a tour */
export default function TourHubScreen() {
  const route = useRoute<any>();
  const [tab, setTab] = useState<'apply' | 'work'>(route.params?.tab === 'work' ? 'work' : 'apply');
  useEffect(() => { if (route.params?.tab) setTab(route.params.tab === 'work' ? 'work' : 'apply'); }, [route.params?.tab]);
  return (
    <View style={{ flex: 1 }}>
      <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
        <Segmented value={tab} onChange={setTab} options={[{ value: 'apply', label: 'Tour' }, { value: 'work', label: 'Tour Expenses' }]} />
      </View>
      <View style={{ flex: 1 }}>{tab === 'apply' ? <TourScreen /> : <TourWorkScreen />}</View>
    </View>
  );
}
