import { useFocusEffect, useRoute } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { Alert, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { MonthCalendar } from '../../components/MonthCalendar';
import { DayPicker, MonthPicker, PickerField } from '../../components/Pickers';
import { Button, Card, Kpi, KpiGrid, Loading, Pill, Screen, SectionTitle, Segmented } from '../../components/ui';
import { api, MonthDay } from '../../lib/api';
import { shareCsv } from '../../lib/csv';
import { useAuth } from '../../lib/auth';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtISODate, hhmmTo12, istDateISO, istParts } from '../../lib/time';
import { C } from '../../theme';

/**
 * Monthly timesheet + calendar + insights.
 * When opened by HR with route.params.userId it shows that employee's month.
 */
export default function AttendanceScreen() {
  const route = useRoute<any>();
  const userId: string | undefined = route.params?.userId;
  const userName: string | undefined = route.params?.name;
  const now = istParts();
  const [year, setYear] = useState(now.year);
  const [month, setMonth] = useState(now.month);
  const [days, setDays] = useState<MonthDay[] | null>(null);
  const [tab, setTab] = useState<'sheet' | 'calendar'>('sheet');
  const [refreshing, setRefreshing] = useState(false);
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [dayFilter, setDayFilter] = useState(0); // drop-down: -1 = list hidden, 0 = all days, otherwise one day

  const load = useCallback(async () => {
    try {
      setDays(await api.monthAttendance(year, month, userId));
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [year, month, userId]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  // Live: a check-in on another device, an approved leave or correction updates this month
  const { profile, isFullAdmin } = useAuth();
  const who = userId ?? profile?.id;
  useRealtime(`month-${who}`, [
    { table: 'attendance', filter: `user_id=eq.${who}` },
    { table: 'leaves', filter: `user_id=eq.${who}` },
    { table: 'regularizations', filter: `user_id=eq.${who}` },
    { table: 'holidays' },
  ], () => load(), !!who);

  if (!days) return <Loading />;
  const p2 = (n: number) => String(n).padStart(2, '0');
  // nothing is chosen yet: the browser date box stays empty (phones need a valid date to open the picker)
  const goDate = dayFilter > 0 ? `${year}-${p2(month)}-${p2(dayFilter)}` : (Platform.OS === 'web' ? '' : istDateISO());
  const count = (st: string[]) => days.filter((d) => st.includes(d.status)).length;
  const worked = days.filter((d) => d.hours != null).map((d) => Number(d.hours));
  const totalHours = worked.reduce((a, b) => a + b, 0);

  const exportCsv = () =>
    shareCsv(`attendance_${userName ? userName.replace(/\s+/g, '_') + '_' : ''}${year}_${String(month).padStart(2, '0')}.csv`,
      days.map((d) => ({
        'Employee Name': userName ?? profile?.full_name ?? '', Date: d.day, Day: d.dow, Status: d.status, 'In Time': d.in_time ?? '', 'Out Time': d.out_time ?? '',
        Hours: d.hours ?? '', Notes: d.notes, Site: d.site_name ?? '',
      })));

  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      {userName ? <Text style={st.forName}>{userName}</Text> : null}
      <MonthPicker year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); setDayFilter(0); setDays(null); }} />

      <KpiGrid>
        <Kpi label="Present" value={count(['Present', 'Checked In'])} icon="checkmark-circle-outline" tone="green" />
        <Kpi label="Absent" value={count(['Absent'])} icon="close-circle-outline" tone="red" />
        <Kpi label="Leave" value={count(['Leave'])} icon="airplane-outline" tone="amber" />
        <Kpi label="Total Hours" value={totalHours.toFixed(1)} icon="time-outline" tone="cyan" />
        <Kpi label="Avg Hours" value={worked.length ? (totalHours / worked.length).toFixed(1) : '-'} icon="bar-chart-outline" tone="blue" />
      </KpiGrid>

      <Segmented value={tab} onChange={setTab} options={[{ value: 'sheet', label: 'Timesheet' }, { value: 'calendar', label: 'Calendar' }]} />

      {tab === 'calendar' ? (
        <Card><MonthCalendar year={year} month={month} days={days} /></Card>
      ) : (
        <>
        <PickerField label="Select a date to see its attendance" mode="date" value={goDate} maximumDate={new Date()}
          onChange={(v) => {
            const y = Number(v.slice(0, 4)), m = Number(v.slice(5, 7)), d = Number(v.slice(8, 10));
            if (y !== year || m !== month) { setYear(y); setMonth(m); setDays(null); }
            setDayFilter(d);
          }} />
        {dayFilter > 0 ? <Card style={{ paddingHorizontal: 10, paddingVertical: 2 }}>
          {days.filter((d) => d.status !== 'Upcoming' && (dayFilter <= 0 || Number(d.day.slice(8, 10)) === dayFilter)).reverse().map((d) => {
            const isOpen = !!open[d.day] || dayFilter > 0;
            return (
              <View key={d.day} style={st.item}>
                <Pressable style={st.row} onPress={() => setOpen((o) => ({ ...o, [d.day]: !o[d.day] }))}>
                  <View style={{ flex: 1 }}>
                    <Text style={st.date}>{fmtISODate(d.day).slice(0, 6)} <Text style={st.dow}>{d.dow}</Text></Text>
                  </View>
                  <Pill text={d.status} />
                  <Ionicons name={isOpen ? 'chevron-up' : 'chevron-down'} size={16} color={C.muted} style={{ marginLeft: 8 }} />
                </Pressable>
                {isOpen ? (
                  <View style={st.detail}>
                    <View style={st.dCell}><Text style={st.dLabel}>In</Text><Text style={st.dVal}>{d.in_time ? hhmmTo12(d.in_time) : '-'}</Text></View>
                    <View style={st.dCell}><Text style={st.dLabel}>Out</Text><Text style={st.dVal}>{d.out_time ? hhmmTo12(d.out_time) : '-'}</Text></View>
                    <View style={st.dCell}><Text style={st.dLabel}>Hours</Text><Text style={st.dVal}>{d.hours != null ? Number(d.hours).toFixed(1) : '-'}</Text></View>
                    {d.notes ? <View style={[st.dCell, { minWidth: '100%' }]}><Text style={st.dLabel}>Note</Text><Text style={st.dVal}>{d.notes}</Text></View> : null}
                    {d.site_name ? <View style={[st.dCell, { minWidth: '100%' }]}><Text style={st.dLabel}>Site</Text><Text style={st.dVal}>{d.site_name}</Text></View> : null}
                  </View>
                ) : null}
              </View>
            );
          })}
          {days.filter((d) => d.status !== 'Upcoming' && (dayFilter <= 0 || Number(d.day.slice(8, 10)) === dayFilter)).length === 0
            ? <Text style={{ padding: 14, color: C.muted }}>No record for this day yet.</Text> : null}
        </Card> : null}
        </>
      )}

      {isFullAdmin ? (
        <>
          <SectionTitle title="Export" />
          <Button title="Download / Share Attendance CSV" icon="download-outline" variant="secondary" onPress={exportCsv} />
        </>
      ) : null}
    </Screen>
  );
}

const st = StyleSheet.create({
  forName: { fontSize: 18, fontWeight: '800', color: C.ink, marginBottom: 8 },
  item: { borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 9 },
  detail: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingBottom: 10 },
  dCell: { flex: 1, minWidth: 70, backgroundColor: '#F8FBFF', borderRadius: 8, borderWidth: 1, borderColor: '#EDF2F7', paddingVertical: 6, paddingHorizontal: 9 },
  dLabel: { fontSize: 10.5, fontWeight: '800', color: '#8594A6', textTransform: 'uppercase' },
  dVal: { fontSize: 13, fontWeight: '700', color: '#17314D', marginTop: 1 },
  head: { paddingVertical: 6 },
  h: { fontSize: 11, fontWeight: '800', color: '#8594A6', textTransform: 'uppercase' },
  c1: { flex: 1.25 },
  c2: { flex: 1.1 },
  c3: { flex: 0.6 },
  c4: { flex: 1.3, alignItems: 'flex-end' },
  date: { fontWeight: '700', color: '#17314D', fontSize: 13 },
  dow: { color: C.muted, fontSize: 11 },
  cell: { fontSize: 12, color: '#203951' },
});
