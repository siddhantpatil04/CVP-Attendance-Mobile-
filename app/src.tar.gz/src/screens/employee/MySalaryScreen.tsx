import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { Banner, Card, Empty, Loading, Row, Screen, SectionTitle } from '../../components/ui';
import { api, MySalaryRow } from '../../lib/api';
import { errorText } from '../../lib/supabase';
import { fmtISODate } from '../../lib/time';
import { C } from '../../theme';
import MySalarySlips from '../../components/MySalarySlips';

const inr = (n: number) => `₹ ${Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;

/** Employee: My Salary (view only). Only the person and the Admin can see it. */
export default function MySalaryScreen() {
  const [rows, setRows] = useState<MySalaryRow[] | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const load = useCallback(async () => {
    try { setRows(await api.mySalary()); } catch (e) { Alert.alert('Could not load', errorText(e)); setRows([]); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  if (!rows) return <Loading />;
  const now = rows[0];                                  // newest change that has started
  const lastRise = rows.find((r) => r.kind === 'Increment');
  const recent = lastRise && Date.now() - new Date(lastRise.effective_date).getTime() < 45 * 86400000;
  const incNo = (i: number) => rows.slice(i).filter((r) => r.kind === 'Increment').length;   // "Increment 3" for the newest of three

  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      <SectionTitle title="SALARY SLIPS" />
      <MySalarySlips />

      {!now ? <Card><Empty text="Your salary has not been set yet. Please ask HR / Admin." icon="cash-outline" /></Card> : (
        <>
          <View style={st.hero}>
            <Text style={st.heroLabel}>CURRENT MONTHLY SALARY</Text>
            <Text style={st.heroAmt}>{inr(now.salary)}</Text>
            <Text style={st.heroSub}>{now.kind === 'Basic' ? 'Since joining' : `Since ${fmtISODate(now.effective_date)}`}</Text>
          </View>

          {recent && lastRise ? (
            <Banner tone="blue" icon="notifications-outline"
              text={`Salary revised to ${inr(lastRise.salary)} from ${fmtISODate(lastRise.effective_date)}. Your payslip uses the new salary.`} />
          ) : null}

          <SectionTitle title="MY SALARY HISTORY" />
          <Card>
            {rows.map((r, i) => (
              <View key={`${r.effective_date}-${i}`} style={st.item}>
                <View style={st.rail}>
                  <View style={[st.dot, i === 0 ? st.dotNow : r.kind === 'Basic' ? st.dotBasic : st.dotDone]} />
                  {i < rows.length - 1 ? <View style={st.line} /> : null}
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={st.itemTitle}>{r.kind === 'Basic' ? 'Basic salary' : `Increment ${incNo(i)}`}</Text>
                  <Text style={st.itemSub}>From {fmtISODate(r.effective_date)}</Text>
                </View>
                <Text style={[st.itemAmt, r.kind === 'Increment' && { color: r.increment >= 0 ? C.blue : C.red }]}>
                  {r.kind === 'Basic' ? inr(r.salary) : `${r.increment >= 0 ? '+' : '-'} ${inr(Math.abs(r.increment))}`}
                </Text>
              </View>
            ))}
          </Card>
          <Row gap={6} style={{ justifyContent: 'center' }}>
            <Ionicons name="lock-closed-outline" size={13} color={C.muted} />
            <Text style={st.note}>View only - only you and Admin can see your salary</Text>
          </Row>
        </>
      )}
    </Screen>
  );
}

const st = StyleSheet.create({
  hero: { backgroundColor: '#06253F', borderRadius: 20, padding: 20, overflow: 'hidden' },
  heroLabel: { color: '#9CC4E6', fontSize: 11, fontWeight: '800', letterSpacing: 1.4 },
  heroAmt: { color: '#fff', fontSize: 34, fontWeight: '800', marginTop: 8 },
  heroSub: { color: '#D3E6F6', fontSize: 13, marginTop: 6 },
  item: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, minHeight: 56 },
  rail: { width: 18, alignItems: 'center', alignSelf: 'stretch' },
  dot: { width: 16, height: 16, borderRadius: 8, borderWidth: 2, marginTop: 2 },
  dotNow: { borderColor: C.blue, backgroundColor: '#fff' },
  dotDone: { borderColor: '#17B26A', backgroundColor: '#17B26A' },
  dotBasic: { borderColor: '#98A2B3', backgroundColor: '#98A2B3' },
  line: { flex: 1, width: 2, backgroundColor: '#DDE6EF', marginVertical: 2 },
  itemTitle: { fontSize: 15, fontWeight: '800', color: '#102A45' },
  itemSub: { fontSize: 12.5, color: C.muted, marginTop: 1, marginBottom: 12 },
  itemAmt: { fontSize: 15, fontWeight: '800', color: '#102A45' },
  note: { fontSize: 12, color: C.muted },
});
