import React, { useState } from 'react';
import DocumentsPanel from '../../components/DocumentsPanel';
import { FromCvpList } from '../../components/SharedDocuments';
import { Banner, Screen, Segmented } from '../../components/ui';
import { useAuth } from '../../lib/auth';

/** Documents: "From CV Patil" (what the company shared with me) and "Sent by me" (my own uploads and the documents Admin / HR sent me) */
export default function DocumentsScreen() {
  const { profile } = useAuth();
  const [tab, setTab] = useState<'from' | 'mine'>('from');
  if (!profile) return null;
  if (!profile.documents_access) {
    return (
      <Screen>
        <Banner tone="amber" icon="lock-closed-outline" text="Documents are not enabled for your account. Ask your Admin to turn on 'Documents'." />
      </Screen>
    );
  }
  return (
    <Screen>
      <Segmented<'from' | 'mine'> value={tab} onChange={setTab} options={[
        { value: 'from', label: 'From CV Patil' },
        { value: 'mine', label: 'Sent by me' },
      ]} />
      {tab === 'from' ? <FromCvpList myId={profile.id} /> : <DocumentsPanel userId={profile.id} admin={false} />}
    </Screen>
  );
}
