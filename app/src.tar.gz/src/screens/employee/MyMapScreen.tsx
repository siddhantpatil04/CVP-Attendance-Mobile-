﻿import { useFocusEffect } from '@react-navigation/native';
import * as Location from 'expo-location';
import React, { useCallback, useState } from 'react';
import { Alert, StyleSheet, Text } from 'react-native';
import LocationMap from '../../components/LocationMap';
import { Banner, Card, Empty, ListItem, Loading, Pill, Screen, SectionTitle } from '../../components/ui';
import { api, Site } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { distanceM, fmtDistance } from '../../lib/geo';
import { errorText } from '../../lib/supabase';
import { C } from '../../theme';

/**
 * Employee map: my own live position + only the work sites I have access to.
 * My position is read on this device while the screen is open and is not sent anywhere or stored.
 */
export default function MyMapScreen() {
  const { profile } = useAuth();
  const [sites, setSites] = useState<Site[] | null>(null);
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [locError, setLocError] = useState('');

  useFocusEffect(useCallback(() => {
    if (!profile) return;
    let alive = true;
    (async () => {
      try {
        const [all, mine] = await Promise.all([api.sites(), api.employeeSites(profile.id)]);
        // Office employees see ONLY the office location; site employees see their own work sites
        const pool = all.filter((s) => (profile.site_employee ? !s.is_office : !!s.is_office));
        if (alive) setSites(mine.length > 0 && profile.site_employee ? pool.filter((s) => mine.includes(s.id)) : pool);
      } catch (e) {
        if (alive) Alert.alert('Could not load sites', errorText(e));
      }
    })();

    let sub: Location.LocationSubscription | null = null;
    (async () => {
      try {
        const perm = await Location.requestForegroundPermissionsAsync();
        if (perm.status !== 'granted') throw new Error('Allow location access to see where you are on the map.');
        sub = await Location.watchPositionAsync(
          { accuracy: Location.Accuracy.Balanced, distanceInterval: 20, timeInterval: 10000 },
          (p) => { if (alive) { setPos({ lat: p.coords.latitude, lng: p.coords.longitude }); setLocError(''); } },
        );
      } catch (e) {
        if (alive) setLocError(e instanceof Error ? e.message : 'Location is not available. Turn on GPS.');
      }
    })();
    return () => { alive = false; sub?.remove(); };
  }, [profile]));

  if (!profile || sites === null) return <Loading />;

  const rows = sites
    .map((s) => ({ s, d: pos ? distanceM(pos.lat, pos.lng, s.lat, s.lng) : null }))
    .sort((a, b) => (a.d ?? 1e12) - (b.d ?? 1e12));
  const inside = rows.find((r) => r.d != null && r.d <= r.s.radius_m);

  return (
    <Screen>
      {locError ? <Banner tone="amber" icon="location-outline" text={locError} /> : null}
      {inside ? <Banner tone="green" icon="checkmark-circle-outline" text={`You are inside ${inside.s.name}.`} /> : null}

      <LocationMap sites={sites} me={pos} height={420} />

      <SectionTitle title={profile.site_employee ? 'My work sites' : 'Office location'} note={sites.length === 0 ? undefined : `${sites.length} site(s)`} />
      <Card style={{ paddingVertical: 4 }}>
        {rows.length === 0 ? (
          <Empty icon="location-outline" text={profile.site_employee ? 'No work sites are assigned to you yet. Ask HR / Admin.' : 'No office location is set yet. Ask HR / Admin.'} />
        ) : rows.map(({ s, d }) => (
          <ListItem key={s.id} icon="location-outline" title={s.name}
            subtitle={`${s.lat.toFixed(5)}, ${s.lng.toFixed(5)} - allowed ${fmtDistance(s.radius_m)}`}
            right={d == null ? <Text style={st.sub}>-</Text>
              : <Pill text={d <= s.radius_m ? 'You are here' : `${fmtDistance(d)} away`} tone={d <= s.radius_m ? 'green' : 'muted'} />} />
        ))}
      </Card>
    </Screen>
  );
}

const st = StyleSheet.create({ sub: { fontSize: 12, color: C.muted } });

