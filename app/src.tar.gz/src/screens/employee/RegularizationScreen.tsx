import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { PickerField } from '../../components/Pickers';
import { Banner, Button, Card, Empty, Field, Pill, Row, Screen, Segmented } from '../../components/ui';
import { api, Regularization } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtISODate, hhmmTo12, istDateISO } from '../../lib/time';
import { C } from '../../theme';

export default function RegularizationScreen() {
  const { profile } = useAuth();
  const [tab, setTab] = useState<'new' | 'history'>('new');
  const [day, setDay] = useState(istDateISO());
  const [inT, setInT] = useState('09:00');
  const [outT, setOutT] = useState('18:00');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [items, setItems] = useState<Regularization[]>([]);

  const load = useCallback(async () => {
    if (!profile) return;
    try { setItems(await api.myRegularizations(profile.id)); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [profile]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime(`reg-${profile?.id}`, [{ table: 'regularizations', filter: `user_id=eq.${profile?.id}` }], () => load(), !!profile);

  const submit = async () => {
    if (outT <= inT) return Alert.alert('Check-out must be after check-in for same-day shifts.');
    if (!reason.trim()) return Alert.alert('Enter a reason.');
    setBusy(true);
    try {
      await api.requestRegularization(day, inT, outT, reason.trim());
      setReason('');
      Alert.alert('Submitted', 'Request sent for HR approval.');
      setTab('history');
      await load();
    } catch (e) {
      Alert.alert('Could not submit', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <Segmented value={tab} onChange={setTab} options={[{ value: 'new', label: 'New Request' }, { value: 'history', label: 'Request History' }]} />
      {tab === 'new' ? (
        <Card>
          <PickerField label="Attendance date" mode="date" value={day} onChange={setDay} maximumDate={new Date()} />
          <Row>
            <PickerField label="Correct check-in" mode="time" value={inT} onChange={setInT} />
            <PickerField label="Correct check-out" mode="time" value={outT} onChange={setOutT} />
          </Row>
          <Field label="Reason for correction" placeholder="Explain why the time needs to be corrected" value={reason} onChangeText={setReason} multiline />
          <Button title="Send for HR Approval" icon="send" loading={busy} onPress={submit} />
        </Card>
      ) : (
        <Card>
          {items.length === 0 ? <Empty text="No regularization requests yet." /> : items.map((r) => (
            <View key={r.id} style={st.item}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Text style={st.title}>{fmtISODate(r.day)}</Text>
                <Pill text={r.status} />
              </Row>
              <Text style={st.sub}>{hhmmTo12(r.requested_in.slice(0, 5))} to {hhmmTo12(r.requested_out.slice(0, 5))}</Text>
              <Text style={st.reason}>{r.reason}</Text>
              {r.review_note ? <Text style={st.sub}>HR note: {r.review_note}</Text> : null}
              {r.status === 'Pending' ? (
                <Button title="Cancel request" variant="danger" small style={{ marginTop: 8, alignSelf: 'flex-start' }}
                  onPress={async () => { try { await api.cancelRegularization(r.id); await load(); } catch (e) { Alert.alert('Error', errorText(e)); } }} />
              ) : null}
            </View>
          ))}
        </Card>
      )}
    </Screen>
  );
}

const st = StyleSheet.create({
  item: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  title: { fontWeight: '800', color: '#102A45', fontSize: 15 },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  reason: { color: '#203951', marginTop: 5 },
});
