import { useFocusEffect, useNavigation } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert, Text } from 'react-native';
import { Dropdown } from '../../components/Pickers';
import TourDetail from '../../components/TourDetail';
import { Banner, Button, Card, Loading, Screen } from '../../components/ui';
import { api, Tour } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { errorText } from '../../lib/supabase';
import { fmtISODate } from '../../lib/time';

/** Tour expenses & report: the employee adds expenses, documents and the tasks completed on an approved tour */
export default function TourWorkScreen() {
  const { profile } = useAuth();
  const nav = useNavigation<any>();
  const [tours, setTours] = useState<Tour[] | null>(null);
  const [pick, setPick] = useState(0);

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      const all = await api.myTours(profile.id);
      setTours(all.filter((t) => t.status === 'Approved'));
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [profile]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  if (!tours) return <Loading />;
  if (tours.length === 0) {
    return (
      <Screen>
        <Banner tone="amber" icon="information-circle-outline"
          text="You have no approved tour. Apply for a tour first; after HR approves it you can add expenses, documents and the tasks you completed." />
        <Card><Button title="Apply for a Tour" icon="bus-outline" onPress={() => nav.navigate('Tour', { tab: 'apply' })} /></Card>
      </Screen>
    );
  }
  const tour = tours[Math.min(pick, tours.length - 1)];

  return (
    <Screen>
      {tours.length > 1 ? (
        <Card>
          <Text style={{ fontWeight: '800', marginBottom: 6 }}>Select tour</Text>
          <Dropdown width="100%" value={pick} onChange={setPick}
            options={tours.map((t, i) => ({ value: i, label: `${t.city} - ${fmtISODate(t.from_day)} to ${fmtISODate(t.to_day)}` }))} />
        </Card>
      ) : null}
      <TourDetail key={tour.id} tour={tour} editable />
    </Screen>
  );
}
