﻿import { useRoute } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Banner, Screen, Segmented } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import DailyReportHistoryScreen from './DailyReportHistoryScreen';
import DailyReportScreen from './DailyReportScreen';

/** One Daily Report section: fill today's report, and the history of the reports by month. Only for employees with site access. */
export default function DailyReportHubScreen() {
  const { profile } = useAuth();
  const route = useRoute<any>();
  const wanted = (): 'fill' | 'history' => (route.params?.tab === 'history' ? 'history' : 'fill');
  const [tab, setTab] = useState<'fill' | 'history'>(wanted());
  useEffect(() => { if (route.params?.tab || route.params?.reportId !== undefined) setTab(wanted()); }, [route.params?.tab, route.params?.reportId]);
  // No site access = no Daily Report (old reports stay saved and visible to Admin / HR)
  if (profile && !profile.site_employee) {
    return <Screen><Banner tone="amber" icon="lock-closed-outline" text="The Daily Report is only for employees with site access." /></Screen>;
  }
  return (
    <View style={{ flex: 1 }}>
      <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
        <Segmented value={tab} onChange={setTab} options={[{ value: 'fill', label: 'Daily Report' }, { value: 'history', label: 'History' }]} />
      </View>
      <View style={{ flex: 1 }}>{tab === 'fill' ? <DailyReportScreen /> : <DailyReportHistoryScreen />}</View>
    </View>
  );
}
