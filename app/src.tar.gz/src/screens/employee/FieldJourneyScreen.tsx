import { useFocusEffect } from '@react-navigation/native';
import { LiveShareNote } from '../../components/LiveTracker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Location from 'expo-location';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Card, Empty, Field, InfoTile, Loading, Pill, Screen, SectionTitle } from '../../components/ui';
import { Dropdown } from '../../components/Pickers';
import LocationMap from '../../components/LocationMap';
import ChangePlanSheet from '../../components/ChangePlanSheet';
import { api, FieldSiteJourney, JourneyPlanChange, JourneyPoint, MapDot, MapLine, MyDashboard, PlanChangeInput, Site } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { distanceM } from '../../lib/geo';
import { flushPlanChanges, readPendingChanges } from '../../lib/journeyPlanQueue';
import { errorText } from '../../lib/supabase';
import { fmtDateLong, fmtMinutes, fmtTime12, istDateISO } from '../../lib/time';
import { C } from '../../theme';

const FOREIGN = -2;   // 'Foreign location' in the Going site list: the employee types the place
const km1 = (n: number | null | undefined) => `${Number(n ?? 0).toFixed(1)} km`;
const trailKey = (id: number) => `fsj_trail_${id}`;
const sentKey = (id: number) => `fsj_sent_${id}`;

/** All the GPS points of a running journey are kept on the phone and sent to the server when the network is there */
async function readTrail(id: number): Promise<{ trail: JourneyPoint[]; sent: number }> {
  try {
    const [a, b] = await Promise.all([AsyncStorage.getItem(trailKey(id)), AsyncStorage.getItem(sentKey(id))]);
    return { trail: a ? JSON.parse(a) : [], sent: b ? Number(b) : 0 };
  } catch { return { trail: [], sent: 0 }; }
}
async function flushTrail(id: number) {
  const { trail, sent } = await readTrail(id);
  if (trail.length <= sent) return;
  await api.addFieldJourneyPoints(id, trail.slice(sent));
  await AsyncStorage.setItem(sentKey(id), String(trail.length));
}

export default function FieldJourneyScreen() {
  const { profile } = useAuth();
  const [dash, setDash] = useState<MyDashboard | null>(null);
  const [sites, setSites] = useState<Site[]>([]);
  const [list, setList] = useState<FieldSiteJourney[]>([]);
  const [fromId, setFromId] = useState(0);
  const [toId, setToId] = useState(0);
  const [foreignName, setForeignName] = useState('');
  const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [trail, setTrail] = useState<JourneyPoint[]>([]);
  const [summary, setSummary] = useState<string | null>(null);
  const startKey = useRef<string>('');
  const [me, setMe] = useState<{ lat: number; lng: number } | null>(null);   // live position shown on the map
  const [allSites, setAllSites] = useState<Site[]>([]);                      // every site (for names in the timeline)
  const [changes, setChanges] = useState<JourneyPlanChange[]>([]);           // plan changes already saved on the server
  const [pending, setPending] = useState<PlanChangeInput[]>([]);             // plan changes waiting on the phone (no internet)
  const [planSheet, setPlanSheet] = useState(false);

  const today = istDateISO();
  // A journey left open from an EARLIER day also blocks a new start on the server, so it is shown here too (with Reached Site)
  const [carry, setCarry] = useState<FieldSiteJourney | null>(null);
  const running = list.find((j) => j.status === 'travelling') ?? carry ?? undefined;
  const reached = list.filter((j) => j.status === 'reached');
  const last = reached[reached.length - 1];
  // Change plan: changes still waiting to be sent are applied on screen already (the server uses the same order)
  const myPending = running ? pending.filter((p) => p.journeyId === running.id) : [];
  const lastPend = myPending[myPending.length - 1];
  const pendingCancel = myPending.some((p) => p.type === 'cancel');
  const effDestId = running
    ? (lastPend && lastPend.type !== 'cancel' ? (lastPend.type === 'back_to_start' ? running.from_site_id : (lastPend.newSite ?? running.to_site_id)) : running.to_site_id)
    : 0;
  const changeCount = (running?.plan_change_count ?? 0) + myPending.length;

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      await flushPlanChanges().catch(() => null);   // changes made with no internet are sent as soon as there is a network
      const [d, all, mine, js] = await Promise.all([
        api.myDashboard(), api.sites(), api.employeeSites(profile.id).catch(() => [] as number[]),
        api.fieldSiteJourneys(today, today, profile.id),
      ]);
      setDash(d);
      setAllSites(all);
      setSites(mine.length > 0 ? all.filter((x) => x.is_office || mine.includes(x.id)) : all);
      setList(js);
      // any journey still travelling from an earlier day (last 31 days)
      const from = istDateISO(Date.now() - 31 * 86400000);
      api.fieldSiteJourneys(from, today, profile.id)
        .then((old) => setCarry(old.find((j) => j.status === 'travelling' && j.journey_date !== today) ?? null))
        .catch(() => setCarry(null));
      setPending(await readPendingChanges());
      api.journeyPlanChanges(js.map((j) => j.id)).then(setChanges).catch(() => {});
    } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [profile, today]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useFocusEffect(useCallback(() => {
    let off = false;
    (async () => {
      try {
        const perm = await Location.requestForegroundPermissionsAsync();
        if (perm.status !== 'granted') return;
        const p = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        if (!off) setMe({ lat: p.coords.latitude, lng: p.coords.longitude });
      } catch { /* no GPS: the map just shows the sites */ }
    })();
    return () => { off = true; };
  }, []));

  // From site: the last reached site; the first journey of the day starts from the attendance check-in site
  const checkInSite = sites.find((s) => s.name === dash?.attendance?.site_name);
  const fromSiteId = last ? last.to_site_id : (fromId || checkInSite?.id || 0);
  const fromSite = sites.find((s) => s.id === fromSiteId);
  const toOptions = sites.filter((s) => s.id !== fromSiteId);

  // ---- GPS while a journey is running: points are saved on the phone first, then synced (offline safe)
  useEffect(() => {
    if (!running) { setTrail([]); return; }
    let sub: Location.LocationSubscription | null = null;
    let stop = false;
    const id = running.id;
    readTrail(id).then((r) => { if (!stop) setTrail(r.trail); });
    (async () => {
      try {
        const perm = await Location.requestForegroundPermissionsAsync();
        if (perm.status !== 'granted') return;
        sub = await Location.watchPositionAsync(
          { accuracy: Location.Accuracy.Balanced, timeInterval: 30000, distanceInterval: 25 },
          async (p) => {
            const pt: JourneyPoint = { lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy != null ? Math.round(p.coords.accuracy) : null, t: new Date(p.timestamp).toISOString() };
            const cur = await readTrail(id);
            const next = [...cur.trail, pt];
            try { await AsyncStorage.setItem(trailKey(id), JSON.stringify(next)); } catch { /* storage full: the point is still shown */ }
            if (!stop) setTrail(next);
            flushTrail(id).catch(() => { /* offline: sent later */ });
          });
      } catch { /* no GPS: the arrival check will say so */ }
    })();
    const tick = setInterval(() => {
      setNow(Date.now()); flushTrail(id).catch(() => {});
      flushPlanChanges().then((r) => { if (r.sent > 0 || r.refused.length > 0) load(); }).catch(() => {});   // waiting plan changes
    }, 30000);
    flushTrail(id).catch(() => {});
    return () => { stop = true; sub?.remove(); clearInterval(tick); };
  }, [running?.id]);

  const getPosition = async () => {
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (perm.status !== 'granted') throw new Error('denied');
      const p = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      return { lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy };
    } catch {
      Alert.alert('GPS is not available', 'Allow location access and turn on GPS, then try again. The journey is not saved without GPS.');
      return null;
    }
  };

  const start = async () => {
    if (busy) return;
    if (!fromSiteId) return Alert.alert('Select the current site (From location).');
    if (!toId) return Alert.alert('Select the going site (To location).');
    if (toId === FOREIGN && !foreignName.trim()) return Alert.alert('Write the name of the place you are going to.');
    if (toId !== FOREIGN && toId === fromSiteId) return Alert.alert('The going site must be different from the current site.');
    setBusy(true);
    try {
      const pos = await getPosition();
      if (!pos) return;
      if (!startKey.current) startKey.current = `${profile!.id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      await api.startFieldJourney({ fromSite: fromSiteId, toSite: toId === FOREIGN ? null : toId, foreignName: toId === FOREIGN ? foreignName.trim() : null, lat: pos.lat, lng: pos.lng, accuracy: pos.acc, key: startKey.current });
      startKey.current = '';
      setSummary(null);
      setToId(0);
      setForeignName('');
      await load();
    } catch (e) { Alert.alert('Could not start', errorText(e)); }
    finally { setBusy(false); }
  };

  const reach = async () => {
    if (!running || busy) return;
    setBusy(true);
    try {
      // a plan change made with no internet must reach the server first (it decides which site you are reaching)
      await flushPlanChanges().catch(() => null);
      if ((await readPendingChanges()).some((p) => p.journeyId === running.id)) {
        setPending(await readPendingChanges());
        Alert.alert('Plan change not sent yet', 'Your change of plan is still waiting for the internet. Connect to the internet, then tap Reached Site again.');
        return;
      }
      const pos = await getPosition();
      if (!pos) return;
      try { await flushTrail(running.id); } catch { /* offline: the server uses the points it already has */ }
      const done = await api.reachFieldJourney(running.id, pos.lat, pos.lng, pos.acc);
      const name = running.to_site_name ?? sites.find((s) => s.id === done.to_site_id)?.name ?? 'the site';
      const msg = `Reached ${name} at ${fmtTime12(done.reached_time)} - ${fmtMinutes(done.duration_minutes ?? 0)} - ${km1(done.distance_km)} saved`;
      setSummary(msg);
      AsyncStorage.multiRemove([trailKey(done.id), sentKey(done.id)]).catch(() => {});
      await load();
    } catch (e) { Alert.alert('Could not mark reached', errorText(e)); }
    finally { setBusy(false); }
  };

  // ---- timeline of today
  const stops = useMemo(() => {
    const out: { name: string; sub: string; leg?: string; lat: number; lng: number }[] = [];
    const valid = list.filter((j) => j.status !== 'cancelled');   // a cancelled visit is not a stop (its distance is still counted below)
    valid.forEach((j, i) => {
      if (i === 0) out.push({ name: j.from_site_name ?? '-', sub: `Checked in ${fmtTime12(dash?.attendance?.check_in_at)} - left ${fmtTime12(j.start_time)}`, lat: j.start_lat, lng: j.start_lng });
      const next = valid[i + 1];
      out.push({
        name: j.to_site_name ?? '-',
        sub: j.reached_time ? `${fmtTime12(j.reached_time)}${next ? ` - ${fmtTime12(next.start_time)}` : ''}` : 'On the way',
        leg: j.reached_time ? `${fmtMinutes(j.duration_minutes ?? 0)} - ${km1(j.distance_km)}` : undefined,
        lat: j.reached_lat ?? j.start_lat, lng: j.reached_lng ?? j.start_lng,
      });
    });
    return out;
  }, [list, dash]);

  // Timeline of every event: Started, Plan changed (old -> new, reason), Reached, Cancelled ...
  const siteName = (id: number | null | undefined, fallback?: string) => (id ? allSites.find((s) => s.id === id)?.name : undefined) ?? fallback ?? '-';
  const events = useMemo(() => {
    type Ev = { t: string; title: string; sub?: string; tone: 'blue' | 'green' | 'amber' | 'red'; waiting?: boolean };
    const out: Ev[] = [];
    list.forEach((j) => {
      out.push({ t: j.start_time, title: `Journey ${j.seq_no} started`, sub: `${j.from_site_name} to ${siteName(j.original_to_site_id ?? j.to_site_id, j.to_site_name)}`, tone: 'blue' });
      if (j.status === 'reached' && j.reached_time) {
        out.push({ t: j.reached_time, title: `Reached ${j.to_site_name}`, sub: `${fmtMinutes(j.duration_minutes ?? 0)} - ${km1(j.distance_km)}`, tone: 'green' });
      }
    });
    changes.forEach((c) => {
      const old = siteName(c.old_destination_site_id);
      const detail = [c.reason, c.remarks, !c.gps_available ? 'GPS not available' : null, c.distance_at_change_km != null ? `${km1(c.distance_at_change_km)} travelled so far` : null]
        .filter(Boolean).join(' - ');
      if (c.change_type === 'cancel') out.push({ t: c.changed_at, title: `Visit cancelled (was going to ${old})`, sub: detail, tone: 'red' });
      else out.push({ t: c.changed_at, title: `Plan changed: ${old} to ${siteName(c.new_destination_site_id)}${c.change_type === 'back_to_start' ? ' (back to start)' : ''}`, sub: detail, tone: 'amber' });
    });
    pending.forEach((p) => {
      out.push({
        t: p.changedAt, tone: 'amber', waiting: true,
        title: p.type === 'cancel' ? 'Visit cancelled' : `Plan changed to ${p.type === 'back_to_start' ? 'the start site' : siteName(p.newSite)}`,
        sub: [p.reason, p.remarks].filter(Boolean).join(' - '),
      });
    });
    return out.sort((a, b) => a.t.localeCompare(b.t));
  }, [list, changes, pending, allSites]);   // eslint-disable-line react-hooks/exhaustive-deps

  const totals = {
    journeys: list.length, sites: reached.length,
    mins: reached.reduce((a, j) => a + (j.duration_minutes ?? 0), 0),
    km: list.filter((j) => j.status !== 'travelling').reduce((a, j) => a + Number(j.distance_km ?? 0), 0),   // reached + cancelled (distance kept)
  };
  const dots: MapDot[] = stops.map((s, i) => ({ key: `s${i}`, lat: s.lat, lng: s.lng, color: i === 0 ? '#16A34A' : '#1677FF', label: `${i + 1}. ${s.name}` }));
  const lines: MapLine[] = stops.length > 1 ? [{ key: 'route', color: '#1677FF', label: '', points: stops.map((s) => [s.lat, s.lng] as [number, number]) }] : [];

  // Map: the site you are leaving (green), the going site with its allowed area (the one chosen, or the running journey's), and you
  const goingSite = running ? (allSites.find((s) => s.id === effDestId) ?? sites.find((s) => s.id === effDestId)) : sites.find((s) => s.id === toId);
  const startFrom = running ? sites.find((s) => s.id === running.from_site_id) : fromSite;
  const livePos = trail.length ? { lat: trail[trail.length - 1].lat, lng: trail[trail.length - 1].lng } : me;
  const mapSites = [startFrom, goingSite].filter((s): s is Site => !!s);
  const planDots: MapDot[] = startFrom ? [{ key: 'from', lat: startFrom.lat, lng: startFrom.lng, color: '#16A34A', label: `From: ${startFrom.name}` }] : [];
  const planLines: MapLine[] = startFrom && goingSite
    ? [{ key: 'plan', color: '#F59E0B', label: `${(distanceM(startFrom.lat, startFrom.lng, goingSite.lat, goingSite.lng) / 1000).toFixed(1)} km`, points: [[startFrom.lat, startFrom.lng], [goingSite.lat, goingSite.lng]] }] : [];

  if (!profile || !dash) return <Loading />;
  if (!profile.site_employee) {
    return <Screen><Banner tone="amber" icon="lock-closed-outline" text="Field Site is for site employees. Ask HR to enable 'Site Employee' in Access Control." /></Screen>;
  }
  const checkedIn = !!dash.attendance?.check_in_at;
  const mins = running ? Math.max(0, Math.round((now - new Date(running.start_time).getTime()) / 60000)) : 0;
  let kmSoFar = 0;
  if (running) {
    let prev = { lat: running.start_lat, lng: running.start_lng };
    for (const p of trail) { kmSoFar += distanceM(prev.lat, prev.lng, p.lat, p.lng) / 1000; prev = p; }
  }

  return (
    <Screen>
      {checkedIn ? (
        <Banner tone="green" icon="checkmark-circle-outline"
          text={`Attendance checked in at ${dash.attendance?.site_name ?? '-'} - ${fmtTime12(dash.attendance?.check_in_at)}. Check-in / check-out stay in Site Selfie; journeys are tracked here.`} />
      ) : (
        <Banner tone="amber" icon="lock-closed-outline" text="Check in to attendance first (Site Selfie). Field Site is available after today's check-in." />
      )}

      <Card>
        <Text style={st.title}>Today's route - {fmtDateLong()}</Text>
        {checkedIn && (mapSites.length > 0 || livePos) ? (
          <View style={{ marginTop: 10 }}>
            <LocationMap height={230} sites={mapSites} dots={planDots} lines={planLines} me={livePos} />
            <Text style={st.caption}>{goingSite ? `Going to ${goingSite.name} (purple circle = its allowed area). Blue dot = you.` : 'Select the going site to see it on the map. Blue dot = you.'}</Text>
          </View>
        ) : null}
        {summary ? <Banner tone="green" icon="checkmark-done" text={summary} /> : null}

        {running && running.journey_date !== today ? (
          <Banner tone="amber" icon="warning-outline" text={`This journey started on ${running.journey_date.split('-').reverse().join('-')} and was never marked as reached. If you are at ${running.to_site_name ?? 'the site'} now, tap Reached Site. Otherwise use Change plan to cancel it.`} />
        ) : null}
        {running ? (
          <View style={st.run}>
            <Text style={st.runTitle}>Journey {running.seq_no} - {running.from_site_name} to {goingSite?.name ?? running.to_site_name}</Text>
            {changeCount > 0 ? <View style={{ flexDirection: 'row', marginTop: 6 }}><Pill text={changeCount === 1 ? 'Plan changed' : `Plan changed ${changeCount}x`} tone="amber" /></View> : null}
            <View style={st.grid}>
              <InfoTile label="Started" value={fmtTime12(running.start_time)} />
              <InfoTile label="Time so far" value={fmtMinutes(mins)} />
              <InfoTile label="Distance so far" value={km1(kmSoFar)} />
            </View>
            {myPending.length > 0 ? (
              <Banner tone="amber" icon="cloud-offline-outline"
                text={pendingCancel ? 'The cancellation is saved on your phone and is sent when the internet is back.'
                  : `${myPending.length} plan change(s) saved on your phone. They are sent when the internet is back.`} />
            ) : null}
            {pendingCancel ? null : (
              <>
                <Button title={`Reached ${goingSite?.name ?? 'Site'}`} icon="location-outline" loading={busy} onPress={reach} />
                <Button title="Change plan" icon="swap-horizontal-outline" variant="secondary" style={{ marginTop: 8 }} onPress={() => setPlanSheet(true)} />
              </>
            )}
            <Text style={st.caption}>Your location is recorded while you travel. With no network the points are kept on the phone and sent later.</Text>
            <LiveShareNote />
          </View>
        ) : checkedIn ? (
          <>
            <Text style={st.label}>Current site (From location) *</Text>
            {last ? (
              <InfoTile label="Last reached site" value={last.to_site_name ?? '-'} />
            ) : (
              <Dropdown width="100%" value={fromSiteId || -1} onChange={(v) => { setFromId(v > 0 ? v : 0); if (v === toId) setToId(0); }}
                options={[{ value: -1, label: 'Select current site' }, ...sites.map((s) => ({ value: s.id, label: s.name }))]} />
            )}
            <Text style={st.label}>Going site (To location) *</Text>
            <Dropdown width="100%" value={toId || -1} onChange={(v) => setToId(v > 0 || v === FOREIGN ? v : 0)}
              options={[{ value: -1, label: 'Select going site' }, { value: FOREIGN, label: 'Foreign location (type the place)' }, ...toOptions.map((s) => ({ value: s.id, label: s.name }))]} />
            {toId === FOREIGN ? (
              <Field label="Name of the place you are going to *" placeholder="e.g. Client office, Shivajinagar" value={foreignName} onChangeText={setForeignName} />
            ) : null}
            <Button title="Start Visit" icon="navigate-outline" variant="success" loading={busy} onPress={start} style={{ marginTop: 12 }} />
            <Text style={st.caption}>Start time and GPS are saved automatically. There is no limit on the number of journeys a day.</Text>
            <LiveShareNote />
          </>
        ) : null}
      </Card>

      <SectionTitle title="My journeys today" note="Sites in visit order with travel time and km between them" />
      <Card>
        {stops.length === 0 ? <Empty icon="navigate-outline" text="No journeys yet today." /> : (
          <>
            {stops.map((s, i) => (
              <View key={i}>
                {s.leg ? <View style={st.legRow}><Pill text={s.leg} tone="blue" /></View> : null}
                <View style={st.stop}>
                  <View style={[st.dot, { backgroundColor: i === 0 ? '#16A34A' : '#1677FF' }]}><Text style={st.dotText}>{i + 1}</Text></View>
                  <View style={{ flex: 1, minWidth: 0 }}>
                    <Text style={st.stopName}>{s.name}</Text>
                    <Text style={st.caption}>{s.sub}</Text>
                  </View>
                </View>
              </View>
            ))}
            <View style={{ marginTop: 10 }}><LocationMap height={220} dots={dots} lines={lines} /></View>
          </>
        )}
      </Card>

      {events.length > 0 ? (
        <>
          <SectionTitle title="Journey timeline" note="Every event of today: started, plan changed, reached, cancelled" />
          <Card>
            {events.map((ev, i) => (
              <View key={i} style={st.stop}>
                <View style={[st.dot, { backgroundColor: ev.tone === 'green' ? '#16A34A' : ev.tone === 'amber' ? '#F59E0B' : ev.tone === 'red' ? '#DC2626' : '#1677FF' }]}>
                  <Text style={st.dotText}>{i + 1}</Text>
                </View>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={st.stopName}>{ev.title}{ev.waiting ? '  (waiting to send)' : ''}</Text>
                  <Text style={st.caption}>{fmtTime12(ev.t)}{ev.sub ? ` - ${ev.sub}` : ''}</Text>
                </View>
              </View>
            ))}
          </Card>
        </>
      ) : null}

      <Card>
        <Text style={st.title}>Today</Text>
        <View style={st.grid}>
          <InfoTile label="Journeys" value={`${totals.journeys}${running ? ' (1 running)' : ''}`} />
          <InfoTile label="Sites reached" value={String(totals.sites)} />
        </View>
        <View style={st.grid}>
          <InfoTile label="Travel time" value={fmtMinutes(totals.mins)} />
          <InfoTile label="Distance" value={km1(totals.km)} />
        </View>
      </Card>

      {running ? (
        <ChangePlanSheet visible={planSheet} onClose={() => setPlanSheet(false)} journey={running}
          startSite={allSites.find((s) => s.id === running.from_site_id)} currentSite={goingSite}
          sites={sites} livePos={livePos}
          onDone={(message, o) => {
            setPlanSheet(false);
            setSummary(message);
            if (o.type === 'cancel' && !o.queued) AsyncStorage.multiRemove([trailKey(running.id), sentKey(running.id)]).catch(() => {});
            load();
          }} />
      ) : null}
    </Screen>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 17, fontWeight: '800', color: C.ink },
  label: { fontSize: 12, fontWeight: '800', color: '#4A5A6E', marginTop: 12, marginBottom: 6 },
  caption: { fontSize: 12.5, color: C.muted, marginTop: 4, lineHeight: 19 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginVertical: 8 },
  run: { backgroundColor: '#EEF6FF', borderRadius: 14, borderWidth: 1, borderColor: '#BFD8F5', padding: 12, marginTop: 10 },
  runTitle: { fontSize: 15, fontWeight: '800', color: C.ink },
  stop: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6 },
  dot: { width: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  dotText: { color: '#fff', fontSize: 12, fontWeight: '800' },
  stopName: { fontSize: 14.5, fontWeight: '800', color: C.ink },
  legRow: { marginLeft: 34, paddingVertical: 2 },
});
