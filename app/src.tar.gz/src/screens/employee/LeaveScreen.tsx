import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { PickerField } from '../../components/Pickers';
import {
  Banner, Button, Card, Empty, Field, Loading, Pill, Row, Screen, Segmented,
} from '../../components/ui';
import { api, LeaveLedgerRow, LeavePreviewV2Day, LeaveRequest, LeaveSummary } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { useIsDesktop } from '../../lib/layout';
import { pickFile } from '../../lib/pickFile';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtISODate, isoToLocalDate, istDateISO } from '../../lib/time';
import { C } from '../../theme';

// Leave type buttons: label -> the type name stored in the database
const TYPES = [
  { label: 'Earned Leave', value: 'Earned Leave' },
  { label: 'Casual Leave', value: 'Casual Leave' },
  { label: 'Sick Leave', value: 'Sick Leave' },
  { label: 'Unpaid Leave (LOP)', value: 'Loss of Pay' },
];
const PERSONAL = ['Bank / office', 'Family', 'Doctor', 'Other'];
const OLD_TYPES = ['Annual Leave', 'Compensatory Off', 'Monthly Paid Leave'];
const BUCKET_LABEL: Record<string, string> = { EL: 'EL', CL: 'CL', SL: 'SL', LOP: 'Unpaid' };
const BUCKET_TYPE: Record<string, string> = { EL: 'Earned Leave', CL: 'Casual Leave', SL: 'Sick Leave', LOP: 'Unpaid' };
const KIND_LABEL: Record<string, string> = { credit: 'Credit', used: 'Used', lapse: 'Lapsed', encash: 'Encashed', adjust: 'Adjusted', opening: 'Opening' };
const n1 = (x: number | null | undefined) => String(Math.round(Number(x ?? 0) * 10) / 10);

export default function LeaveScreen() {
  const { profile } = useAuth();
  const desktop = useIsDesktop();
  const [tab, setTab] = useState<'apply' | 'requests' | 'balance'>('apply');
  const [sum, setSum] = useState<LeaveSummary | null>(null);
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [ledger, setLedger] = useState<LeaveLedgerRow[]>([]);
  const today = istDateISO();
  const [type, setType] = useState('Casual Leave');
  const [half, setHalf] = useState<'first' | 'second' | null>(null);        // null = full day(s)
  const [from, setFrom] = useState(today);
  const [to, setTo] = useState(today);
  const [personal, setPersonal] = useState('Bank / office');
  const [reason, setReason] = useState('');
  const [cert, setCert] = useState<{ path: string; name: string } | null>(null);
  const [preview, setPreview] = useState<LeavePreviewV2Day[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const isPersonal = type === 'Half Day - Personal work';
  const effHalf = isPersonal ? (half ?? 'first') : half;                       // the quick option is always one half
  const pol = sum?.policy;

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      const [s, r] = await Promise.all([api.leaveSummary(), api.myLeaves(profile.id)]);
      setSum(s);
      setRequests(r);
      api.leaveLedger().then(setLedger).catch(() => {});
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [profile]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime(`leaves-${profile?.id}`, [{ table: 'leaves', filter: `user_id=eq.${profile?.id}` }], () => load(), !!profile);

  // the earliest date for each type (the server checks it again)
  const minDate = useMemo(() => {
    if (!pol) return today;
    if (type === 'Earned Leave') return istDateISO(Date.now() + pol.el_notice_days * 86400000);
    if (type === 'Sick Leave') return istDateISO(Date.now() - pol.sl_apply_within * 86400000);
    return today;
  }, [type, pol, today]);
  // keep the dates valid when the type changes
  useEffect(() => { if (from < minDate) { setFrom(minDate); setTo(minDate); } }, [minDate]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (effHalf || isPersonal) setTo(from); }, [effHalf, isPersonal, from]);

  // day-by-day preview from the server (EL / CL / SL / Unpaid for each date)
  useEffect(() => {
    if (tab !== 'apply' || !from || to < from) { setPreview(null); return; }
    let off = false;
    const h = setTimeout(() => {
      api.leavePreviewV2(type, from, effHalf ? from : to, effHalf).then((d) => { if (!off) setPreview(d); }).catch(() => { if (!off) setPreview(null); });
    }, 250);
    return () => { off = true; clearTimeout(h); };
  }, [type, from, to, effHalf, tab]);

  const units = (preview ?? []).reduce((a, d) => a + (d.bucket ? Number(d.units) : 0), 0);
  const by = (b: string) => (preview ?? []).filter((d) => d.bucket === b).reduce((a, d) => a + Number(d.units), 0);
  const lopUnits = by('LOP');
  const deduct = Math.round((preview ?? []).filter((d) => d.bucket === 'LOP').reduce((a, d) => a + Number(d.units) * Number(d.per_day), 0));

  // rule messages shown BEFORE sending (send is disabled while one applies)
  const problem = (() => {
    if (!sum || !pol) return null;
    if (type === 'Earned Leave' && from < istDateISO(Date.now() + pol.el_notice_days * 86400000)) return `Earned Leave needs ${pol.el_notice_days} days notice. Choose later dates, or use Casual Leave.`;
    if (type === 'Casual Leave' && units > pol.cl_max_request) return `Casual Leave: maximum ${pol.cl_max_request} days at a time.`;
    if (type === 'Sick Leave' && units > pol.sl_cert_after && !cert) return 'Upload medical certificate';
    if (preview && preview.length > 0 && units === 0) return 'No working days in these dates (weekly off / holiday only).';
    return null;
  })();

  const chooseCert = () => {
    if (!profile) return;
    pickFile(false).then(async (f) => {
      if (!f) return;
      try { setCert({ path: await api.uploadLeaveCert(profile.id, f.bytes, f.name, f.mime), name: f.name }); }
      catch (e) { Alert.alert('Could not upload', errorText(e)); }
    }).catch((e) => Alert.alert('Could not pick the file', errorText(e)));
  };

  const submit = async () => {
    if (problem) return Alert.alert('Cannot send yet', problem);
    if (!reason.trim()) return Alert.alert('Enter a reason.');
    setBusy(true);
    try {
      await api.applyLeaveV2({
        type, from, to: effHalf ? from : to, reason: reason.trim(), half: effHalf,
        personal: isPersonal ? personal : null, certificate: cert?.path ?? null,
      });
      setReason(''); setCert(null);
      Alert.alert('Sent', 'Your request was sent to Admin / HR for approval. The balance changes only after it is approved.');
      setTab('requests');
      await load();
    } catch (e) {
      Alert.alert('Could not send', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  const cancel = (r: LeaveRequest) =>
    Alert.alert('Cancel this request?', `${r.leave_type} - ${fmtISODate(r.from_day)} to ${fmtISODate(r.to_day)}`, [
      { text: 'Keep', style: 'cancel' },
      { text: 'Cancel request', style: 'destructive', onPress: async () => {
        try { await api.cancelLeave(r.id); await load(); } catch (e) { Alert.alert('Error', errorText(e)); }
      } },
    ]);

  if (!sum || !pol) return <Loading />;
  const el = sum.el, cl = sum.cl, sl = sum.sl;
  const pct = (v: number, max: number) => `${Math.max(0, Math.min(100, Math.round((100 * v) / Math.max(max, 1))))}%` as const;
  const addedParts = [sum.el.added_this_month ? `EL +${n1(sum.el.added_this_month)}` : '', sum.cl.added_this_month ? `CL +${n1(sum.cl.added_this_month)}` : '',
    sum.sl.added_this_month ? `SL +${n1(sum.sl.added_this_month)}` : ''].filter(Boolean).join(', ');
  const personalBalanceNote = isPersonal && preview ? (() => {
    const used = (['CL', 'EL'] as const).find((b) => by(b) > 0);
    if (lopUnits > 0 && !used) return null;
    if (!used) return null;
    const b = used === 'CL' ? cl.balance : el.balance;
    return `${n1(by(used))} day from ${BUCKET_TYPE[used]} - balance ${n1(b)} -> ${n1(b - by(used))} after approval. Required working hours that day: half of the usual.`;
  })() : null;

  const cardsRow = (
    <View style={st.cards}>
      <View style={[st.balCard, { backgroundColor: '#FFFFFF' }]}>
        <Text style={st.balName}>Earned Leave (EL)</Text>
        <Text style={st.balValue}>{n1(el.balance)} days</Text>
        <Text style={st.balSub}>Balance - can save up to {n1(el.cap)} days</Text>
        <View style={st.bar}><View style={[st.barFill, { width: pct(el.balance, el.cap), backgroundColor: C.blue }]} /></View>
        <Text style={st.balRule}>12 / year - 1 a month. Apply {pol.el_notice_days} days in advance. Unused EL is saved - up to {n1(el.cap)} days.</Text>
      </View>
      <View style={[st.balCard, { backgroundColor: '#FFFFFF' }]}>
        <Text style={st.balName}>Casual Leave (CL)</Text>
        <Text style={st.balValue}>{n1(cl.balance)} / {n1(cl.yearly)}</Text>
        <Text style={st.balSub}>Days available this year</Text>
        <View style={st.bar}><View style={[st.barFill, { width: pct(cl.balance, cl.yearly), backgroundColor: C.green }]} /></View>
        <Text style={st.balRule}>6 / year - 0.5 a month. Short notice OK. Max {n1(pol.cl_max_request)} days at a time. Lapses {pol.lapse_day} Dec.</Text>
      </View>
      <View style={[st.balCard, { backgroundColor: '#FFFFFF' }]}>
        <Text style={st.balName}>Sick Leave (SL)</Text>
        <Text style={st.balValue}>{n1(sl.balance)} / {n1(sl.yearly)}</Text>
        <Text style={st.balSub}>Days available this year</Text>
        <View style={st.bar}><View style={[st.barFill, { width: pct(sl.balance, sl.yearly), backgroundColor: C.red }]} /></View>
        <Text style={st.balRule}>6 / year - 0.5 a month. More than {n1(pol.sl_cert_after)} days needs a medical certificate. Lapses {pol.lapse_day} Dec.</Text>
      </View>
      <View style={[st.balCard, { backgroundColor: '#FFF8EA', borderColor: '#F3DFB5' }]}>
        <Text style={st.balName}>Unpaid Leave (LOP)</Text>
        <Text style={st.balValue}>{n1(sum.lop_year)}</Text>
        <Text style={st.balSub}>Days taken this year</Text>
        <Text style={[st.balRule, { marginTop: 14 }]}>Used when no paid balance, or before {sum.months_total} months. Salary is deducted.</Text>
      </View>
    </View>
  );

  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      {!sum.eligible ? (
        <Banner tone="amber" icon="time-outline"
          text={sum.eligible_from
            ? `Paid leaves start after ${sum.months_total} months - ${sum.months_done ?? 0} of ${sum.months_total} months done - starts ${fmtISODate(sum.eligible_from)}. Any leave you apply for now is Unpaid (LOP) and still needs Admin / HR approval.`
            : 'Your joining date is missing, so paid leaves cannot start yet. Ask Admin / HR to enter it. Any leave you apply for now is Unpaid (LOP).'} />
      ) : (
        <Banner tone="green" icon="checkmark-circle-outline"
          text={`You completed ${sum.months_total} months${sum.eligible_from ? ` on ${fmtISODate(sum.eligible_from)}` : ''}. You get 24 paid leaves a year: Earned 12 + Casual 6 + Sick 6 (credited monthly).`} />
      )}
      {sum.eligible ? (
        <View style={st.summary}>
          <Text style={st.sumText}>
            Paid leave available: <Text style={st.sumB}>{n1(sum.paid_available)} days</Text>
            {addedParts ? ` - added this month: ${addedParts}` : ''}
            {` - EL saved from earlier months: ${n1(el.saved_before)}`}
          </Text>
        </View>
      ) : null}

      {cardsRow}

      {!desktop ? (
        <Row style={{ marginBottom: 12 }}>
          <Button title="Apply leave" icon="add" style={{ flex: 1 }} onPress={() => { setTab('apply'); if (isPersonal) { setType('Casual Leave'); setHalf(null); } }} />
          <Button title="Half Day" icon="time-outline" variant="success" style={{ flex: 1 }} onPress={() => { setTab('apply'); setType('Half Day - Personal work'); setHalf((h) => h ?? 'first'); }} />
        </Row>
      ) : null}

      <Segmented value={tab} onChange={setTab} options={[
        { value: 'apply', label: 'Apply Leave' },
        { value: 'requests', label: 'My Requests' },
        { value: 'balance', label: 'All Balances' },
      ]} />

      {tab === 'apply' ? (
        <Card>
          <Text style={st.label}>Leave type</Text>
          <View style={st.typeRow}>
            {TYPES.map((t) => (
              <Pressable key={t.value} onPress={() => { setType(t.value); if (t.value === 'Half Day - Personal work') setHalf((h) => h ?? 'first'); else if (isPersonal) setHalf(null); }}
                style={[st.typeBtn, type === t.value && st.typeOn]} accessibilityRole="button">
                <Text style={[st.typeText, type === t.value && { color: C.white }]}>{t.label}</Text>
              </Pressable>
            ))}
          </View>

          {!isPersonal ? (
            <>
              <Text style={st.label}>Duration</Text>
              <Segmented<'full' | 'half'> value={half ? 'half' : 'full'} onChange={(v) => setHalf(v === 'half' ? 'first' : null)}
                options={[{ value: 'full', label: 'Full day(s)' }, { value: 'half', label: 'Half day' }]} />
            </>
          ) : null}

          {effHalf ? (
            <>
              <Text style={[st.label, { marginTop: 10 }]}>Which half? *</Text>
              <View style={st.halfRow}>
                {([['first', 'sunny-outline', 'First half - Morning', 'Off in the morning, work in the afternoon'],
                  ['second', 'moon-outline', 'Second half - Afternoon', 'Work in the morning, leave after lunch']] as const).map(([v, icon, title, sub]) => (
                  <Pressable key={v} onPress={() => setHalf(v)} style={[st.halfCard, effHalf === v && st.halfOn]} accessibilityRole="radio">
                    <View style={[st.halfIcon, effHalf === v && { backgroundColor: C.blue }]}><Ionicons name={icon} size={20} color={effHalf === v ? C.white : C.muted} /></View>
                    <View style={{ flex: 1, minWidth: 0 }}>
                      <Text style={st.halfTitle}>{title}</Text>
                      <Text style={st.halfSub}>{sub}</Text>
                    </View>
                  </Pressable>
                ))}
              </View>
            </>
          ) : null}

          <Row style={{ marginTop: 10 }}>
            <PickerField label={effHalf ? 'Date * (any day - even today)' : 'From date'} mode="date" value={from} minimumDate={isoToLocalDate(minDate)}
              onChange={(v) => { setFrom(v); if (effHalf || to < v) setTo(v); }} />
            {effHalf ? null : <PickerField label="To date" mode="date" value={to} onChange={setTo} minimumDate={isoToLocalDate(from)} />}
          </Row>

          {isPersonal ? (
            <>
              <Text style={st.label}>Personal work *</Text>
              <View style={st.typeRow}>
                {PERSONAL.map((p) => (
                  <Pressable key={p} onPress={() => setPersonal(p)} style={[st.typeBtn, personal === p && st.typeOn]} accessibilityRole="button">
                    <Text style={[st.typeText, personal === p && { color: C.white }]}>{p}</Text>
                  </Pressable>
                ))}
              </View>
            </>
          ) : null}

          <Field label="Reason *" placeholder={isPersonal ? 'e.g. Bank loan document signing' : 'Enter reason for leave...'} value={reason} onChangeText={setReason} multiline={!isPersonal} />

          {type === 'Sick Leave' && units > pol.sl_cert_after ? (
            <View style={{ marginBottom: 10 }}>
              <Banner tone="amber" icon="medkit-outline" text={`More than ${n1(pol.sl_cert_after)} days of Sick Leave needs a medical certificate (photo or PDF).`} />
              <Button title={cert ? `Certificate: ${cert.name}` : 'Upload medical certificate'} icon={cert ? 'checkmark-circle-outline' : 'cloud-upload-outline'}
                variant={cert ? 'success' : 'secondary'} onPress={chooseCert} />
            </View>
          ) : null}

          {preview && preview.length > 0 ? (
            <View style={{ marginBottom: 10 }}>
              <Text style={st.label}>How these days are counted</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                {preview.slice(0, 62).map((d, i) => {
                  const dt = new Date(`${d.day}T12:00:00`);
                  const tone = d.bucket && d.bucket !== 'LOP' ? ['#E6F0FF', C.blue] : d.bucket === 'LOP' ? ['#FDE8EA', '#B42330'] : ['#EEF2F7', '#62738A'];
                  return (
                    <View key={`${d.day}-${i}`} style={{ backgroundColor: tone[0], borderRadius: 10, paddingVertical: 6, paddingHorizontal: 10, alignItems: 'center', minWidth: 84 }}>
                      <Text style={{ fontSize: 12, fontWeight: '800', color: tone[1] }}>{dt.getDate()} {dt.toLocaleDateString('en-GB', { weekday: 'short' })}</Text>
                      <Text style={{ fontSize: 10.5, fontWeight: '700', color: tone[1] }}>
                        {d.bucket ? `${BUCKET_LABEL[d.bucket]} ${n1(d.units)}` : d.status}
                      </Text>
                    </View>
                  );
                })}
              </View>
              {(() => {
                const parts = (['EL', 'CL', 'SL', 'LOP'] as const).filter((b) => by(b) > 0).map((b) => `${n1(by(b))} ${b === 'LOP' ? 'Unpaid' : BUCKET_TYPE[b].replace(' Leave', '')}`);
                return parts.length ? (
                  <Banner tone="blue" icon="information-circle-outline"
                    text={`${n1(units)} leave day(s): ${parts.join(' + ')}. Weekly offs and holidays are not counted.`} />
                ) : null;
              })()}
              {personalBalanceNote ? <Banner tone="green" icon="walk-outline" text={personalBalanceNote} /> : null}
              {isPersonal && lopUnits > 0 && !personalBalanceNote ? (
                <Banner tone="red" icon="warning-outline" text={`No Casual or Earned Leave left. This half day will be UNPAID (0.5 day salary deducted).`} />
              ) : null}
              {effHalf ? <Banner tone="blue" icon="time-outline" text="On that day you work the other half and check in / out as usual - required working hours that day are half of the usual." /> : null}
            </View>
          ) : null}

          {problem ? <Banner tone="red" icon="warning-outline" text={problem} /> : null}
          <Button title="Send to Admin / HR for approval" icon="send" loading={busy} disabled={!!problem} onPress={submit} />
        </Card>
      ) : null}

      {tab === 'requests' ? (
        <Card>
          {requests.length === 0 ? <Empty text="No leave requests yet." /> : requests.map((r) => {
            const old = !r.policy_v2 && OLD_TYPES.includes(r.leave_type);
            const u = r.units ?? r.days;
            return (
              <View key={r.id} style={st.req}>
                <Row style={{ justifyContent: 'space-between' }}>
                  <Text style={st.reqTitle}>
                    {r.leave_type === 'Loss of Pay' ? 'Unpaid Leave (LOP)' : r.leave_type}
                    {r.half_part ? ` (${r.half_part === 'first' ? 'Morning' : 'Afternoon'})` : ''}
                  </Text>
                  <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
                    {old ? <Pill text="Old type" tone="muted" /> : null}
                    <Pill text={r.status === 'Pending' ? 'Waiting' : r.status} />
                  </View>
                </Row>
                <Text style={st.reqSub}>{fmtISODate(r.from_day)}{r.to_day !== r.from_day ? ` to ${fmtISODate(r.to_day)}` : ''} - {n1(u)} day(s){r.personal_work ? ` - ${r.personal_work}` : ''}</Text>
                <Text style={st.reqReason}>{r.reason}</Text>
                <Text style={st.reqSub}>
                  {r.status === 'Pending' ? 'Waiting for Admin / HR' : r.status === 'Approved' ? 'Approved - balance updated' : r.status === 'Rejected' ? `Rejected${r.review_note ? `: ${r.review_note}` : ''}` : r.status}
                </Text>
                {r.status === 'Pending' ? <Button title="Cancel request" variant="danger" small style={{ marginTop: 8, alignSelf: 'flex-start' }} onPress={() => cancel(r)} /> : null}
              </View>
            );
          })}
        </Card>
      ) : null}

      {tab === 'balance' ? (
        <Card>
          <Text style={st.label}>Balance now: Earned {n1(el.balance)} - Casual {n1(cl.balance)} - Sick {n1(sl.balance)}</Text>
          <View style={[st.tRow, { borderBottomWidth: 1, borderBottomColor: C.line }]}>
            <Text style={[st.tC1, st.tH]}>Month / type</Text><Text style={[st.tC, st.tH]}>Change</Text><Text style={[st.tC, st.tH]}>Balance</Text>
          </View>
          {ledger.length === 0 ? <Empty text="No leave entries yet. Credits start when your paid leaves start." /> : ledger.map((l, i) => {
            const delta = Number(l.credited) + Number(l.adjusted) - Number(l.used) - Number(l.lapsed) - Number(l.encashed);
            return (
              <View key={`${l.created_at}-${i}`} style={st.tRow}>
                <View style={st.tC1}>
                  <Text style={{ color: '#17314D', fontWeight: '700' }}>{l.leave_type.replace(' Leave', '')} - {KIND_LABEL[l.kind] ?? l.kind}</Text>
                  <Text style={st.reqSub}>{l.month.slice(0, 7)}{l.reason ? ` - ${l.reason}` : ''}</Text>
                </View>
                <Text style={[st.tC, { color: delta >= 0 ? '#157A4B' : '#B42330', fontWeight: '800' }]}>{delta >= 0 ? '+' : ''}{n1(delta)}</Text>
                <Text style={[st.tC, { fontWeight: '800' }]}>{n1(l.balance_after)}</Text>
              </View>
            );
          })}
        </Card>
      ) : null}
    </Screen>
  );
}

const st = StyleSheet.create({
  summary: { backgroundColor: '#E8F8EF', borderWidth: 1, borderColor: '#BFE8D0', borderRadius: 14, padding: 12, marginBottom: 12 },
  sumText: { color: '#3C7A57', fontSize: 13, lineHeight: 19, fontWeight: '600' },
  sumB: { color: '#0E6B3B', fontWeight: '800' },
  cards: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 12 },
  balCard: { flexGrow: 1, flexBasis: 180, minWidth: 150, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: '#E7EDF5' },
  balName: { fontSize: 12, fontWeight: '800', color: '#1E3D5B' },
  balValue: { fontSize: 24, fontWeight: '800', color: '#102944', marginTop: 4 },
  balSub: { fontSize: 11.5, color: '#78899D', fontWeight: '600' },
  balRule: { fontSize: 11.5, color: '#62738A', marginTop: 8, lineHeight: 16, fontWeight: '600' },
  bar: { height: 6, backgroundColor: '#DFE9F2', borderRadius: 999, marginTop: 8, overflow: 'hidden' },
  barFill: { height: '100%', borderRadius: 999 },
  label: { fontSize: 12, fontWeight: '700', color: '#3A5068', marginBottom: 8 },
  typeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  typeBtn: { paddingVertical: 10, paddingHorizontal: 14, borderRadius: 14, borderWidth: 1, borderColor: '#E1E9F2', backgroundColor: '#FFFFFF' },
  typeOn: { backgroundColor: C.blue, borderColor: C.blue },
  typeText: { fontSize: 14, fontWeight: '700', color: '#102A45' },
  halfRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  halfCard: { flexGrow: 1, flexBasis: 240, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 2, borderColor: '#E1E9F2', borderRadius: 16, padding: 12, backgroundColor: '#FFFFFF' },
  halfOn: { borderColor: C.blue, backgroundColor: '#F1F7FF' },
  halfIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#EEF2F7', alignItems: 'center', justifyContent: 'center' },
  halfTitle: { fontSize: 15, fontWeight: '800', color: '#102A45' },
  halfSub: { fontSize: 12.5, color: '#78899D', marginTop: 2, fontWeight: '600' },
  req: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  reqTitle: { fontWeight: '800', color: '#102A45', fontSize: 15, flexShrink: 1 },
  reqSub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  reqReason: { color: '#203951', marginTop: 5 },
  tRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10 },
  tH: { fontSize: 11, fontWeight: '800', color: '#8594A6', textTransform: 'uppercase' },
  tC1: { flex: 2.4, color: '#17314D', fontWeight: '600' },
  tC: { flex: 1, textAlign: 'right', color: '#17314D' },
});
