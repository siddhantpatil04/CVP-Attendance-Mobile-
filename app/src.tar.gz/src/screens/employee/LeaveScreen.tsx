import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { PickerField } from '../../components/Pickers';
import {
  Banner, Button, Card, Empty, Field, Loading, Pill, Row, Screen, Segmented,
} from '../../components/ui';
import { api, LeaveCancelOption, LeaveLedgerRow, LeavePreviewV2Day, LeaveRequest, LeaveSummary } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { pickFile } from '../../lib/pickFile';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtISODate, isoToLocalDate, istDateISO } from '../../lib/time';
import { C } from '../../theme';

// Leave type buttons: label -> the type name stored in the database
const TYPES = [
  { label: 'Earned Leave', value: 'Earned Leave', paid: true },
  { label: 'Casual Leave (unpaid)', value: 'Casual Leave', paid: false },
  { label: 'Sick Leave (unpaid)', value: 'Sick Leave', paid: false },
  { label: 'Unpaid Leave (LOP)', value: 'Loss of Pay', paid: false },
];
const OLD_TYPES = ['Annual Leave', 'Compensatory Off', 'Monthly Paid Leave'];
const BUCKET_LABEL: Record<string, string> = { EL: 'EL', CL: 'CL', SL: 'SL', LOP: 'LOP' };
const BUCKET_TYPE: Record<string, string> = { EL: 'Earned Leave', CL: 'Casual Leave', SL: 'Sick Leave', LOP: 'Unpaid' };
const KIND_LABEL: Record<string, string> = { credit: 'Credit', used: 'Used', lapse: 'Lapsed', encash: 'Encashed', adjust: 'Adjusted', opening: 'Opening' };
// whole days only: never a decimal point on this screen
const wn = (x: number | null | undefined) => Math.round(Number(x ?? 0));
const days = (x: number) => `${wn(x)} ${wn(x) === 1 ? 'day' : 'days'}`;
const when = (iso: string | null) => (iso
  ? new Date(iso).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'Asia/Kolkata' })
  : '');

export default function LeaveScreen() {
  const { profile } = useAuth();
  const [tab, setTab] = useState<'apply' | 'requests' | 'balance'>('apply');
  const [sum, setSum] = useState<LeaveSummary | null>(null);
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [ledger, setLedger] = useState<LeaveLedgerRow[]>([]);
  const today = istDateISO();
  const [type, setType] = useState('Casual Leave');
  const [from, setFrom] = useState(today);
  const [to, setTo] = useState(today);
  const [reason, setReason] = useState('');
  const [cert, setCert] = useState<{ path: string; name: string } | null>(null);
  const [preview, setPreview] = useState<LeavePreviewV2Day[] | null>(null);
  const [serverMsg, setServerMsg] = useState<{ error: string | null } | null>(null);   // null = the server check is not available yet
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  // cancel of an approved leave: which button each leave gets (empty until leave_cancel_approved.sql is run) + the reason popup
  const [opts, setOpts] = useState<Record<number, LeaveCancelOption>>({});
  const [cancelling, setCancelling] = useState<LeaveRequest | null>(null);
  const [cancelWhy, setCancelWhy] = useState('');

  const pol = sum?.policy;
  const rules = sum?.rules;
  const elNotice = rules?.EL.notice_days ?? pol?.el_notice_days ?? 7;
  const clMax = rules?.CL.max_in_a_row ?? pol?.cl_max_request ?? 3;
  const slCert = rules?.SL.certificate_after_days ?? pol?.sl_cert_after ?? 2;
  const savedNotice = rules?.saved_notice_days ?? 5;

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      const [s, r] = await Promise.all([api.leaveSummary(), api.myLeaves(profile.id)]);
      setSum(s);
      setRequests(r);
      api.leaveLedger().then(setLedger).catch(() => {});
      api.leaveCancelOptions().then((l) => setOpts(Object.fromEntries(l.map((o) => [o.leave_id, o])))).catch(() => setOpts({}));
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [profile]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime(`leaves-${profile?.id}`, [{ table: 'leaves', filter: `user_id=eq.${profile?.id}` }], () => load(), !!profile);

  // only Earned Leave is paid; before the paid leaves start it cannot be chosen
  useEffect(() => { if (sum && !sum.eligible && type === 'Earned Leave') setType('Loss of Pay'); }, [sum, type]);

  // the earliest date for each type (the server checks it again)
  const minDate = useMemo(() => {
    if (!pol) return today;
    if (type === 'Earned Leave') return istDateISO(Date.now() + elNotice * 86400000);
    if (type === 'Sick Leave') return istDateISO(Date.now() - pol.sl_apply_within * 86400000);
    return today;
  }, [type, pol, today, elNotice]);
  // keep the dates valid when the type changes
  useEffect(() => { if (from < minDate) { setFrom(minDate); setTo(minDate); } }, [minDate]);   // eslint-disable-line react-hooks/exhaustive-deps

  // day-by-day preview + the server's apply rules (EL / CL / SL / Unpaid, this month / saved, for each date)
  useEffect(() => {
    if (tab !== 'apply' || !from || to < from) { setPreview(null); setServerMsg(null); return; }
    let off = false;
    const h = setTimeout(() => {
      api.leaveDayChips(type, from, to).then((d) => { if (!off) setPreview(d); }).catch(() => { if (!off) setPreview(null); });
      api.leaveCheck(type, from, to, cert?.path).then((c) => { if (!off) setServerMsg(c); }).catch(() => { if (!off) setServerMsg(null); });
    }, 250);
    return () => { off = true; clearTimeout(h); };
  }, [type, from, to, tab, cert]);

  const units = (preview ?? []).reduce((a, d) => a + (d.bucket ? 1 : 0), 0);
  const by = (b: string) => (preview ?? []).filter((d) => d.bucket === b).length;

  // rule messages shown BEFORE sending (send is disabled while one applies); the server's text wins
  const problem = (() => {
    if (!sum || !pol) return null;
    if (serverMsg) return serverMsg.error;
    if (type === 'Earned Leave' && from < istDateISO(Date.now() + elNotice * 86400000)) return `Earned Leave needs ${elNotice} days notice. Choose later dates, or use Casual Leave.`;
    if (type === 'Casual Leave' && units > clMax) return `Casual Leave: maximum ${clMax} days in a row.`;
    if (type === 'Sick Leave' && units > slCert && !cert) return 'Upload medical certificate';
    if (preview && preview.length > 0 && units === 0) return 'No working days in these dates (weekly off / holiday only).';
    return null;
  })();
  const needsCert = type === 'Sick Leave' && units > slCert;

  const chooseCert = () => {
    if (!profile) return;
    pickFile(false).then(async (f) => {
      if (!f) return;
      try { setCert({ path: await api.uploadLeaveCert(profile.id, f.bytes, f.name, f.mime), name: f.name }); }
      catch (e) { Alert.alert('Could not upload', errorText(e)); }
    }).catch((e) => Alert.alert('Could not pick the file', errorText(e)));
  };

  const submit = async () => {
    if (problem) return Alert.alert('Cannot send yet', problem);
    if (!reason.trim()) return Alert.alert('Enter a reason.');
    setBusy(true);
    try {
      await api.applyLeaveV2({ type, from, to, reason: reason.trim(), certificate: cert?.path ?? null });
      setReason(''); setCert(null);
      Alert.alert('Sent', 'Your request was sent to HR / Admin for approval (one approval is enough). The balance changes only after it is approved.');
      setTab('requests');
      await load();
    } catch (e) {
      Alert.alert('Could not send', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  const cancel = (r: LeaveRequest) =>
    Alert.alert('Cancel this request?', `${r.leave_type} - ${fmtISODate(r.from_day)} to ${fmtISODate(r.to_day)}`, [
      { text: 'Keep', style: 'cancel' },
      { text: 'Cancel request', style: 'destructive', onPress: async () => {
        try { await api.cancelLeave(r.id); await load(); } catch (e) { Alert.alert('Error', errorText(e)); }
      } },
    ]);

  // Approved leave: "Request cancellation" (reason required). The leave stays Approved until Admin / HR decide.
  const confirmCancel = async () => {
    const r = cancelling; const why = cancelWhy.trim();
    if (!r || !why || busy) return;
    setBusy(true);
    try {
      await api.requestLeaveCancel(r.id, why);
      setCancelling(null); setCancelWhy('');
      await load();
      Alert.alert('Sent to Admin', 'Your leave stays approved (balance, attendance and salary do not change) until Admin / HR decide.');
    } catch (e) {
      Alert.alert('Could not send', errorText(e));
    } finally {
      setBusy(false);
    }
  };
  const cancelDate = (iso: string | null | undefined) => (iso ? fmtISODate(istDateISO(new Date(iso).getTime())) : '');
  // Leave approved -> Cancel requested <date> -> Admin -> Cancelled
  const steps = (r: LeaveRequest) => {
    const s = r.cancel_status;
    const items: { t: string; on: boolean }[] = [
      { t: 'Leave approved', on: true },
      { t: `Cancel requested ${cancelDate(r.cancel_requested_at)}`.trim(), on: true },
      { t: s === 'kept' ? 'Admin: leave kept' : 'Admin', on: s === 'approved' || s === 'kept' },
      { t: s === 'kept' ? 'Approved' : 'Cancelled', on: s === 'approved' || s === 'kept' },
    ];
    return (
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 4, marginTop: 6 }}>
        {items.map((it, i) => (
          <React.Fragment key={i}>
            {i > 0 ? <Text style={{ color: C.muted, fontSize: 12 }}>→</Text> : null}
            <Text style={{ fontSize: 11.5, fontWeight: '800', color: it.on ? '#157A4B' : '#9A6200', backgroundColor: it.on ? '#E8F8EF' : '#FFF3D6', borderRadius: 8, paddingVertical: 3, paddingHorizontal: 7, overflow: 'hidden' }}>
              {it.on ? '✓ ' : '… '}{it.t}
            </Text>
          </React.Fragment>
        ))}
      </View>
    );
  };

  if (!sum || !pol) return <Loading />;
  const el = sum.el, cl = sum.cl, sl = sum.sl;

  // this month / saved / total, whole numbers (from the server buckets; derived from the old keys until leave_rules_v3.sql is run)
  const split = (code: 'EL' | 'CL' | 'SL', bal: number, added: number) => {
    const b = sum.buckets?.[code];
    if (b) return { total: wn(b.total), thisMonth: wn(b.this_month), saved: wn(b.saved) };
    const total = wn(bal); const thisMonth = Math.min(total, wn(added));
    return { total, thisMonth, saved: total - thisMonth };
  };
  const sEL = split('EL', el.balance, el.added_this_month);
  // Earned Leave is the only paid leave
  const totalAll = sEL.total;
  const totalSaved = sEL.saved;

  // credited this month: from the rule table when there is one (EL +1, CL +1 or SL +1)
  const mi = Number(today.slice(5, 7)) - 1;
  const added = (code: 'EL' | 'CL' | 'SL', old: number) => (rules ? Number(rules.monthly[code][mi] ?? 0) : wn(old));
  const addedParts = (() => { const n = added('EL', el.added_this_month); return n > 0 ? `EL +${n}` : ''; })();

  const card = (name: string, s: { total: number; thisMonth: number; saved: number }, rule: string, tint?: { bg: string; border: string }) => (
    <View style={[st.balCard, { backgroundColor: tint?.bg ?? '#FFFFFF', borderColor: tint?.border ?? '#E7EDF5' }]}>
      <Text style={st.balName}>{name}</Text>
      <Text style={st.balValue}>{s.total}</Text>
      <Text style={st.balSub}>This month {s.thisMonth} · Saved {s.saved}</Text>
    </View>
  );

  const infoCard = (name: string, _rule?: string) => (
    <View style={[st.balCard, { backgroundColor: '#FFF8EA', borderColor: '#F3DFB5' }]}>
      <Text style={st.balName}>{name}</Text>
      <Text style={[st.balValue, { fontSize: 22, marginTop: 10 }]}>Unpaid</Text>
      <Text style={st.balSub}>Not a paid leave - salary is deducted</Text>
    </View>
  );

  const cardsRow = (
    <View style={st.cards}>
      {card('Earned Leave (EL / PL) - paid', sEL, '', { bg: '#F1F7FF', border: '#CFE0FA' })}
      {infoCard('Casual Leave (CL)', '')}
      {infoCard('Sick Leave (SL)', '')}
    </View>
  );

  const monthsDone = Math.min(sum.months_done ?? 0, sum.months_total);
  const waitDate = sum.credit_from ?? sum.eligible_from;

  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      {!sum.eligible ? (
        <View style={st.wait}>
          <Text style={st.waitTitle}>
            {waitDate
              ? `${sum.months_total} months on ${fmtISODate(waitDate)} - only Unpaid leave (LOP) now`
              : 'Your joining date is missing - only Unpaid leave (LOP) now. Ask Admin / HR to enter it.'}
          </Text>
          <View style={st.waitBar}><View style={[st.waitFill, { width: `${Math.round((100 * monthsDone) / Math.max(sum.months_total, 1))}%` }]} /></View>
          <Text style={st.waitSub}>{monthsDone} of {sum.months_total} months done. Any leave you apply for now is Unpaid (LOP) and needs HR or Admin approval.</Text>
        </View>
      ) : (
        <View style={st.summary}>
          <Text style={st.sumText}>
            Paid leave available: <Text style={st.sumB}>{days(totalAll)}</Text>
            {addedParts ? ` · added this month: ${addedParts}` : ''}
            {` · saved from earlier months: ${totalSaved}`}
          </Text>
        </View>
      )}

      {cardsRow}
      <Text style={st.lop}>
        Unpaid days (LOP, Casual, Sick) taken this year: <Text style={st.sumB}>{days(sum.lop_year)}</Text> - also used when there is no Earned Leave balance, or before {sum.months_total} months. Salary is deducted.
      </Text>

      <Segmented value={tab} onChange={setTab} options={[
        { value: 'apply', label: 'Apply Leave' },
        { value: 'requests', label: 'My Requests' },
        { value: 'balance', label: 'All Balances' },
      ]} />

      {tab === 'apply' ? (
        <Card>
          <Text style={st.label}>Leave type</Text>
          <View style={st.typeRow}>
            {TYPES.map((t) => {
              const off = t.paid && !sum.eligible;
              return (
                <Pressable key={t.value} disabled={off} onPress={() => setType(t.value)}
                  style={[st.typeBtn, type === t.value && st.typeOn, off && { opacity: 0.45 }]} accessibilityRole="button">
                  <Text style={[st.typeText, type === t.value && { color: C.white }]}>{t.label}</Text>
                </Pressable>
              );
            })}
          </View>

          <Row style={{ marginTop: 4 }}>
            <PickerField label="From date" mode="date" value={from} minimumDate={isoToLocalDate(minDate)}
              onChange={(v) => { setFrom(v); if (to < v) setTo(v); }} />
            <PickerField label="To date" mode="date" value={to} onChange={setTo} minimumDate={isoToLocalDate(from)} />
          </Row>

          <Field label="Reason *" placeholder="Enter reason for leave..." value={reason} onChangeText={setReason} multiline />

          {needsCert ? (
            <View style={{ marginBottom: 10 }}>
              <Banner tone="amber" icon="medkit-outline" text={`More than ${slCert} days of Sick Leave needs a medical certificate (photo or PDF).`} />
              <Button title={cert ? `Certificate: ${cert.name}` : 'Upload medical certificate'} icon={cert ? 'checkmark-circle-outline' : 'cloud-upload-outline'}
                variant={cert ? 'success' : 'secondary'} onPress={chooseCert} />
            </View>
          ) : null}

          {preview && preview.length > 0 ? (
            <View style={{ marginBottom: 10 }}>
              <Text style={st.label}>How these days are counted</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                {preview.slice(0, 62).map((d, i) => {
                  const dt = new Date(`${d.day}T12:00:00`);
                  // this month = blue, saved = purple, LOP = amber, weekly off / holiday = grey
                  const tone = d.bucket === 'LOP' ? ['#FFF3D6', '#9A6200']
                    : d.bucket && d.source === 'saved' ? ['#EFE7FF', '#6B3FC4']
                    : d.bucket ? ['#E6F0FF', C.blue] : ['#EEF2F7', '#62738A'];
                  const sub = d.bucket
                    ? `${BUCKET_LABEL[d.bucket]}${d.bucket === 'LOP' ? '' : d.source === 'saved' ? ' · saved' : d.source === 'this_month' ? ' · this month' : ''}`
                    : d.status;
                  return (
                    <View key={`${d.day}-${i}`} style={{ backgroundColor: tone[0], borderRadius: 10, paddingVertical: 6, paddingHorizontal: 10, alignItems: 'center', minWidth: 96 }}>
                      <Text style={{ fontSize: 12, fontWeight: '800', color: tone[1] }}>{dt.getDate()} {dt.toLocaleDateString('en-GB', { weekday: 'short' })}</Text>
                      <Text style={{ fontSize: 10.5, fontWeight: '700', color: tone[1] }}>{sub}</Text>
                    </View>
                  );
                })}
              </View>
              {(() => {
                const parts = (['EL', 'CL', 'SL', 'LOP'] as const).filter((b) => by(b) > 0).map((b) => `${by(b)} ${b === 'LOP' ? 'Unpaid' : BUCKET_TYPE[b].replace(' Leave', '')}`);
                return parts.length ? (
                  <Banner tone="blue" icon="information-circle-outline"
                    text={`${units} leave ${units === 1 ? 'day' : 'days'}: ${parts.join(' + ')}. Weekly offs and holidays are not counted.`} />
                ) : null;
              })()}
            </View>
          ) : null}

          {problem ? <Banner tone="red" icon="warning-outline" text={problem} /> : null}
          <Button title="Send to HR / Admin for approval" icon="send" loading={busy} disabled={!!problem} onPress={submit} />
        </Card>
      ) : null}

      {tab === 'requests' ? (
        <Card>
          {requests.length === 0 ? <Empty text="No leave requests yet." /> : requests.map((r) => {
            const old = !r.policy_v2 && OLD_TYPES.includes(r.leave_type);
            const u = r.units ?? r.days;
            const role = r.reviewed_by_role ?? r.reviewer?.role ?? 'Admin';
            const who = `${role === 'HR' ? 'HR' : 'Admin'}${r.reviewer?.full_name ? ` (${r.reviewer.full_name}${r.reviewed_at ? `, ${when(r.reviewed_at)}` : ''})` : r.reviewed_at ? ` (${when(r.reviewed_at)})` : ''}`;
            return (
              <View key={r.id} style={st.req}>
                <Row style={{ justifyContent: 'space-between' }}>
                  <Text style={st.reqTitle}>{r.leave_type === 'Loss of Pay' ? 'Unpaid Leave (LOP)' : r.leave_type}</Text>
                  <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
                    {old ? <Pill text="Old type" tone="muted" /> : null}
                    <Pill text={r.status === 'Pending' ? 'Waiting' : r.status === 'Approved' && r.cancel_status === 'requested' ? 'Cancellation requested' : r.status}
                      tone={r.status === 'Approved' && r.cancel_status === 'requested' ? 'amber' : r.status === 'Cancelled' ? 'muted' : undefined} />
                  </View>
                </Row>
                <Text style={st.reqSub}>{fmtISODate(r.from_day)}{r.to_day !== r.from_day ? ` to ${fmtISODate(r.to_day)}` : ''} - {days(u)}</Text>
                <Text style={st.reqReason}>{r.reason}</Text>
                <Text style={st.reqSub}>
                  {r.status === 'Pending' ? 'Waiting for approval (HR or Admin)'
                    : r.status === 'Approved' ? `Approved by ${who}`
                    : r.status === 'Rejected' ? `Rejected by ${who}${r.review_note ? ` - ${r.review_note}` : ''}`
                    : r.status === 'Cancelled' && r.cancel_status === 'approved'
                      ? `Cancelled · Cancellation approved by ${r.canceller?.full_name ?? 'Admin'}${r.cancel_reviewed_at ? ` (${when(r.cancel_reviewed_at)})` : ''}${Number(r.cancel_returned) > 0 ? ` · ${wn(r.cancel_returned)} ${r.leave_type} returned to your balance` : ''}`
                      : r.status}
                </Text>
                {r.cancel_reason && r.cancel_status ? <Text style={st.reqSub}>Your reason to cancel: {r.cancel_reason}</Text> : null}
                {r.status === 'Approved' && r.cancel_status === 'kept' ? <Text style={[st.reqSub, { color: '#B42330', fontWeight: '700' }]}>Cancellation not approved by {r.canceller?.full_name ?? 'Admin'}{r.cancel_reviewed_at ? ` (${when(r.cancel_reviewed_at)})` : ''}{r.cancel_review_note ? ` - ${r.cancel_review_note}` : ''}</Text> : null}
                {r.cancel_status ? steps(r) : null}
                {r.status === 'Pending' ? <Button title="Cancel request" variant="danger" small style={{ marginTop: 8, alignSelf: 'flex-start' }} onPress={() => cancel(r)} /> : null}
                {r.status === 'Approved' && opts[r.id]?.mode === 'request'
                  ? <Button title="Request cancellation" variant="danger" small style={{ marginTop: 8, alignSelf: 'flex-start' }} onPress={() => { setCancelWhy(''); setCancelling(r); }} /> : null}
                {r.status === 'Approved' && opts[r.id]?.mode === 'finalized' ? <Text style={[st.reqSub, { marginTop: 8, fontWeight: '700' }]}>Cannot cancel - salary finalized</Text> : null}
              </View>
            );
          })}
        </Card>
      ) : null}

      <Modal visible={!!cancelling} transparent animationType="fade" onRequestClose={() => setCancelling(null)}>
        <Pressable style={st.backdrop} onPress={() => setCancelling(null)}>
          <Pressable style={st.box} onPress={() => {}}>
            <Text style={st.boxTitle}>Request cancellation</Text>
            {cancelling ? (
              <>
                <Text style={st.reqSub}>{cancelling.leave_type === 'Loss of Pay' ? 'Unpaid Leave (LOP)' : cancelling.leave_type} - {fmtISODate(cancelling.from_day)}{cancelling.to_day !== cancelling.from_day ? ` to ${fmtISODate(cancelling.to_day)}` : ''}</Text>
                <Banner tone="blue" icon="information-circle-outline"
                  text="Admin / HR will decide. Your leave stays approved until then; your balance, attendance and salary do not change." />
              </>
            ) : null}
            <TextInput value={cancelWhy} onChangeText={setCancelWhy} multiline autoFocus placeholder="Reason *" placeholderTextColor={C.muted} style={st.input} />
            <Row style={{ marginTop: 10 }}>
              <Button title="Back" variant="secondary" small style={{ flex: 1 }} onPress={() => setCancelling(null)} />
              <Button title="Send to Admin" icon="send" small style={{ flex: 1 }}
                loading={busy} disabled={!cancelWhy.trim() || busy} onPress={confirmCancel} />
            </Row>
          </Pressable>
        </Pressable>
      </Modal>

      {tab === 'balance' ? (
        <Card>
          <Text style={st.label}>Earned Leave balance now: {sEL.total} (this month {sEL.thisMonth} · saved {sEL.saved})</Text>
          <View style={[st.tRow, { borderBottomWidth: 1, borderBottomColor: C.line }]}>
            <Text style={[st.tC1, st.tH]}>Month / type</Text><Text style={[st.tC, st.tH]}>Change</Text><Text style={[st.tC, st.tH]}>Balance</Text>
          </View>
          {ledger.length === 0 ? <Empty text="No leave entries yet. Credits start when your paid leaves start." /> : ledger.map((l, i) => {
            const delta = wn(Number(l.credited) + Number(l.adjusted) - Number(l.used) - Number(l.lapsed) - Number(l.encashed));
            return (
              <View key={`${l.created_at}-${i}`} style={st.tRow}>
                <View style={st.tC1}>
                  <Text style={{ color: '#17314D', fontWeight: '700' }}>{l.leave_type.replace(' Leave', '')} - {l.kind === 'used' && Number(l.used) < 0 ? 'Returned' : (KIND_LABEL[l.kind] ?? l.kind)}</Text>
                  <Text style={st.reqSub}>{l.month.slice(0, 7)}{l.reason ? ` - ${l.reason}` : ''}</Text>
                </View>
                <Text style={[st.tC, { color: delta >= 0 ? '#157A4B' : '#B42330', fontWeight: '800' }]}>{delta >= 0 ? '+' : ''}{delta}</Text>
                <Text style={[st.tC, { fontWeight: '800' }]}>{wn(l.balance_after)}</Text>
              </View>
            );
          })}
        </Card>
      ) : null}
    </Screen>
  );
}

const st = StyleSheet.create({
  summary: { backgroundColor: '#E8F8EF', borderWidth: 1, borderColor: '#BFE8D0', borderRadius: 14, padding: 12, marginBottom: 12 },
  sumText: { color: '#3C7A57', fontSize: 13, lineHeight: 19, fontWeight: '600' },
  sumB: { color: '#0E6B3B', fontWeight: '800' },
  wait: { backgroundColor: '#FFF8E1', borderWidth: 1, borderColor: '#F3DFA0', borderRadius: 14, padding: 12, marginBottom: 12 },
  waitTitle: { color: '#8A5A00', fontSize: 14, fontWeight: '800', lineHeight: 20 },
  waitSub: { color: '#8A6A2A', fontSize: 12, marginTop: 6, lineHeight: 17, fontWeight: '600' },
  waitBar: { height: 8, backgroundColor: '#F3E6BD', borderRadius: 999, marginTop: 8, overflow: 'hidden' },
  waitFill: { height: '100%', borderRadius: 999, backgroundColor: '#E8A400' },
  cards: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 8 },
  balCard: { flexGrow: 1, flexBasis: 200, minWidth: 150, borderRadius: 14, padding: 12, borderWidth: 1 },
  balName: { fontSize: 12, fontWeight: '800', color: '#1E3D5B' },
  balValue: { fontSize: 30, fontWeight: '800', color: '#102944', marginTop: 4 },
  balSub: { fontSize: 12, color: '#52667D', fontWeight: '700' },
  dash: { borderTopWidth: 1, borderTopColor: '#C9D6E4', borderStyle: 'dashed', marginTop: 10 },
  balRule: { fontSize: 11.5, color: '#62738A', marginTop: 8, lineHeight: 16, fontWeight: '600' },
  lop: { fontSize: 12, color: '#6A5A33', lineHeight: 17, fontWeight: '600', marginBottom: 12 },
  label: { fontSize: 12, fontWeight: '700', color: '#3A5068', marginBottom: 8 },
  typeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  typeBtn: { paddingVertical: 10, paddingHorizontal: 14, borderRadius: 14, borderWidth: 1, borderColor: '#E1E9F2', backgroundColor: '#FFFFFF' },
  typeOn: { backgroundColor: C.blue, borderColor: C.blue },
  typeText: { fontSize: 14, fontWeight: '700', color: '#102A45' },
  req: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  reqTitle: { fontWeight: '800', color: '#102A45', fontSize: 15, flexShrink: 1 },
  reqSub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  reqReason: { color: '#203951', marginTop: 5 },
  backdrop: { flex: 1, justifyContent: 'center', padding: 16, backgroundColor: 'rgba(6,37,63,0.35)' },
  box: { backgroundColor: C.white, borderRadius: 14, padding: 16, width: '100%', maxWidth: 420, alignSelf: 'center' },
  boxTitle: { fontWeight: '800', color: C.ink, fontSize: 16, marginBottom: 2 },
  input: { marginTop: 10, minHeight: 80, borderWidth: 1, borderColor: '#D8E3EF', borderRadius: 10, padding: 10, color: C.ink, fontSize: 14, textAlignVertical: 'top' },
  tRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10 },
  tH: { fontSize: 11, fontWeight: '800', color: '#8594A6', textTransform: 'uppercase' },
  tC1: { flex: 2.4, color: '#17314D', fontWeight: '600' },
  tC: { flex: 1, textAlign: 'right', color: '#17314D' },
});
