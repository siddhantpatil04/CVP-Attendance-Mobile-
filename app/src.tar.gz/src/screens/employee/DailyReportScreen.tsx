import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert, Platform, StyleSheet, Text, View } from 'react-native';
import { SiteBlocks, VisitSequence, DR_TONE, reportNo } from '../../components/DailyReportView';
import { Dropdown } from '../../components/Pickers';
import { PreviewField } from '../../components/PreviewField';
import ReportPhotos from '../../components/ReportPhotos';
import { pickFile } from '../../lib/pickFile';
import { Banner, Button, Card, Field, InfoTile, Loading, Pill, Row, Screen } from '../../components/ui';
import { api, DailyReport, DailyReportContext, DailySiteInput, Site } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { errorText } from '../../lib/supabase';
import { fmtISODate, fmtTime12 } from '../../lib/time';
import { C } from '../../theme';

// cc = how many "Comment to contractor" boxes are shown (1 to 3); the "Add contractor comment" button shows the next one
type Entry = DailySiteInput & { other: boolean; cc: number };
const OTHER = -1;
const MAX_CC = 3;
const blank = (): Entry => ({
  site_id: null, other: false, cc: 1, site_name: '', sub_work: '', work_going_on: '', work_description: '',
  comment_1: '', comment_2: '', comment_3: '', remarks: '',
});

const toEntry = (s: { site_id: number | null; site_name: string } & Partial<Record<keyof DailySiteInput, string | number | null>>, sites: Site[]): Entry => ({
  ...blank(),
  site_id: s.site_id ?? null,
  site_name: s.site_name ?? '',
  other: s.site_id == null && !!s.site_name && !sites.some((x) => x.name.toLowerCase() === s.site_name.toLowerCase()),
  sub_work: String(s.sub_work ?? ''), work_going_on: String(s.work_going_on ?? ''), work_description: String(s.work_description ?? ''),
  comment_1: String(s.comment_1 ?? ''), comment_2: String(s.comment_2 ?? ''), comment_3: String(s.comment_3 ?? ''), remarks: String(s.remarks ?? ''),
  cc: s.comment_3 ? 3 : s.comment_2 ? 2 : 1,   // show every comment that is already filled
});

const UNSENT_KEY = 'cvp_unsent_daily_report_';
const TRANSLATE_KEY = 'cvp_pending_report_translation';
async function queueTranslate(id: number) {
  try { const cur: number[] = JSON.parse((await AsyncStorage.getItem(TRANSLATE_KEY)) ?? '[]'); if (!cur.includes(id)) await AsyncStorage.setItem(TRANSLATE_KEY, JSON.stringify([...cur, id])); } catch { /* ignore */ }
}
async function retryTranslations() {
  try {
    const cur: number[] = JSON.parse((await AsyncStorage.getItem(TRANSLATE_KEY)) ?? '[]');
    const left: number[] = [];
    for (const id of cur) { try { await api.translateReport(id); } catch { left.push(id); } }
    await AsyncStorage.setItem(TRANSLATE_KEY, JSON.stringify(left));
  } catch { /* ignore */ }
}
const isNetworkError = (msg: string) => /No internet|network is too slow|Failed to fetch|Network request failed/i.test(msg);

/** Employee: the Daily Report of today (after check-in; it unlocks the site check-out), or a draft / reopened report from the history */
export default function DailyReportScreen() {
  const { profile } = useAuth();
  const nav = useNavigation<any>();
  const route = useRoute<any>();
  const reportId: number | undefined = route.params?.reportId;

  const [ctx, setCtx] = useState<DailyReportContext | null>(null);
  const [report, setReport] = useState<DailyReport | null>(null);
  const [sites, setSites] = useState<Site[]>([]);
  const [entries, setEntries] = useState<Entry[]>([blank()]);
  const [errors, setErrors] = useState<Record<number, string[]>>({});
  const [busy, setBusy] = useState<'draft' | 'submit' | null>(null);
  const [ready, setReady] = useState(false);
  const [checkIn, setCheckIn] = useState<{ site: string | null; at: string } | null>(null);   // today's check-in (site + time)
  // OPTIONAL photo of the report: photos already saved with the report, and photos just uploaded (attached when the report is saved / submitted)
  const [saved, setSaved] = useState<{ id: number; file_path: string; file_name: string | null }[]>([]);
  const [pending, setPending] = useState<{ path: string; name: string }[]>([]);
  const [done, setDone] = useState<{ id: number; date: string; sites: number; comments: number; km: number | null } | null>(null);

  const load = useCallback(async () => {
    if (!profile) return;
    retryTranslations();
    try {
      const today = (await api.dailyReportContext());
      const dash = !reportId ? await api.myDashboard().catch(() => null) : null;
      setCheckIn(dash?.attendance?.check_in_at ? { site: dash.attendance.site_name ?? null, at: dash.attendance.check_in_at } : null);
      const [all, mine] = await Promise.all([api.sites(), api.employeeSites(profile.id)]);
      const allowed = mine.length ? all.filter((s) => mine.includes(s.id)) : all;
      const r = reportId
        ? await api.dailyReport(reportId)
        : (await api.myDailyReports(profile.id, today.date, today.date))[0] ?? null;
      setCtx(today);
      setSites(allowed);
      setReport(r);
      setSaved(r ? await api.dailyReportPhotos(r.id).catch(() => []) : []);
      // a report that could not be sent (no internet) is kept on the phone until it is sent
      const kept = !reportId && !r ? await AsyncStorage.getItem(`${UNSENT_KEY}${today.date}`).catch(() => null) : null;
      if (r && r.daily_report_sites.length) {
        setEntries(r.daily_report_sites.map((s) => toEntry(s, allowed)));
      } else if (kept) {
        try { setEntries((JSON.parse(kept) as Entry[]).map((e) => ({ ...blank(), ...e }))); } catch { setEntries([blank()]); }
      } else if (today.visits.length) {
        // one entry per visited site (taken from the recorded visits: nothing is invented)
        setEntries(today.visits.map((v) => toEntry({ site_id: v.site_id, site_name: v.site_name }, allowed)));
      } else {
        // the site of today's check-in is filled in; the employee can add more sites
        const checkedInSite = !reportId && !r ? dash?.attendance?.site_name : null;
        const match = checkedInSite ? allowed.find((s) => s.name.toLowerCase() === checkedInSite.toLowerCase()) : null;
        setEntries([checkedInSite ? toEntry({ site_id: match?.id ?? null, site_name: match?.name ?? checkedInSite }, allowed) : blank()]);
      }
      setErrors({});
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    } finally {
      setReady(true);
    }
  }, [profile, reportId]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  if (!profile || !ready || !ctx) return <Loading />;

  const date = report?.report_date ?? ctx.date;
  const isToday = date === ctx.date;
  const locked = !!report && (report.status === 'Submitted' || report.status === 'Reviewed');
  const blocked = !report && !(ctx.checked_in ?? ctx.checked_out);      // today's report starts after check-in
  const visits = isToday ? ctx.visits : (report?.daily_report_sites ?? []).filter((s) => s.arrived_at).map((s) => ({ site_name: s.site_name, arrived_at: s.arrived_at, departed_at: s.departed_at }));
  const km = isToday ? ctx.gps_km : report?.gps_km ?? null;
  const hasGps = isToday ? ctx.has_gps : !!report?.has_gps;

  const set = (i: number, patch: Partial<Entry>) => setEntries((list) => list.map((e, k) => (k === i ? { ...e, ...patch } : e)));
  const photoCount = saved.length + pending.length;
  const isBlank = (e: Entry) => ![e.site_name, e.sub_work, e.work_description, e.comment_1, e.comment_2, e.comment_3, e.remarks].some((x) => (x ?? '').trim());
  // with a photo the form is optional: blank site entries are simply not sent
  const payload = (): DailySiteInput[] => entries.filter((e) => !(photoCount > 0 && isBlank(e))).map(({ other, cc, ...e }) => ({ ...e, site_name: e.site_name.trim() }));

  const addPhoto = async (camera: boolean) => {
    try {
      const f = await pickFile(camera);
      if (!f) return;
      const path = await api.uploadDailyReportPhoto(profile.id, f.bytes, f.name, f.mime);
      setPending((l) => [...l, { path, name: f.name }]);
    } catch (e) { Alert.alert('Could not add the photo', errorText(e)); }
  };
  const dropPending = (p: { path: string; name: string }) => { api.removeDailyReportFile(p.path).catch(() => {}); setPending((l) => l.filter((x) => x.path !== p.path)); };
  const dropSaved = (p: { id: number }) =>
    api.removeDailyReportPhoto(p.id).then(() => setSaved((l) => l.filter((x) => x.id !== p.id))).catch((e) => Alert.alert('Could not remove', errorText(e)));
  // photos uploaded in this session are attached to the report (the report is saved first when it does not exist yet)
  const attachPhotos = async (): Promise<number | null> => {
    if (pending.length === 0) return report?.id ?? null;
    const rep = await api.saveDailyReportDraft(report?.id ?? null, payload());
    for (const p of pending) await api.addDailyReportPhoto(rep.id, p.path, p.name);
    setPending([]);
    return rep.id;
  };
  const finish = (id: number, status: string) => {
    if (status === 'Submitted') {
      setDone({
        id, date, sites: entries.length, km,
        comments: entries.reduce((n, e) => n + [e.comment_1, e.comment_2, e.comment_3].filter((c) => c.trim()).length, 0),
      });
    }
  };

  const saveDraft = async () => {
    setBusy('draft');
    try {
      const rid = await attachPhotos();
      const res = await api.saveDailyReportDraft(rid ?? report?.id ?? null, payload());
      Alert.alert('Draft saved', 'You can come back and edit it any time before you submit. A draft does not unlock check-out: submit the report to check out.');
      await load();
      return res;
    } catch (e) {
      const msg = errorText(e);
      if (isNetworkError(msg)) await keepOnPhone();
      Alert.alert(isNetworkError(msg) ? 'Report not sent' : 'Could not save', isNetworkError(msg) ? 'Report not sent - check-out stays locked. Your entries are kept on this phone; connect to the internet and submit again.' : msg);
    }
    finally { setBusy(null); }
  };

  const keepOnPhone = async () => {
    if (report) return;   // an existing server report is the master copy
    await AsyncStorage.setItem(`${UNSENT_KEY}${ctx.date}`, JSON.stringify(entries)).catch(() => {});
  };

  const submit = async () => {
    const errs: Record<number, string[]> = {};
    // a photo of the report replaces the typed fields; without a photo the fields are required as before
    if (photoCount === 0) entries.forEach((e, i) => {
      const m: string[] = [];
      if (!e.site_name.trim()) m.push('Choose the site location (or enter it under Other).');
      if (!e.sub_work.trim()) m.push('Enter the sub work (subcontract details).');
      if (!e.work_description.trim()) m.push('Enter the work description (work completed today).');
      if (m.length) errs[i] = m;
    });
    setErrors(errs);
    if (Object.keys(errs).length) return Alert.alert('Report not complete', 'Fill the required fields marked in red for every site, then submit again.');
    setBusy('submit');
    try {
      const rid = await attachPhotos();
      const res = await api.submitDailyReport(rid ?? report?.id ?? null, payload());
      await AsyncStorage.removeItem(`${UNSENT_KEY}${ctx.date}`).catch(() => {});
      // the English for Admin is made on the server now; if that fails (no internet) it is retried the next time this screen opens
      api.translateReport(res.id).catch(() => queueTranslate(res.id));
      finish(res.id, res.status);
    } catch (e) {
      const msg = errorText(e);
      if (isNetworkError(msg)) await keepOnPhone();
      Alert.alert(isNetworkError(msg) ? 'Report not sent' : 'Could not submit', isNetworkError(msg) ? 'Report not sent - check-out stays locked. Your entries are kept on this phone; connect to the internet and submit again.' : msg);
    }
    finally { setBusy(null); }
  };

  // ---------------------------------------------------------------- success screen
  if (done) {
    return (
      <Screen>
        <Card>
          <Banner tone="green" icon="checkmark-circle"
            text={ctx.checked_out ? 'Daily report submitted. Thank you!' : 'Report submitted - Check-Out is now unlocked.'} />
          {!ctx.checked_out && (ctx.checked_in ?? false) ? (
            <Button title="Go to Check-Out" icon="log-out-outline" style={{ marginTop: 8 }}
              onPress={() => (profile.role === 'Employee' ? nav.navigate('Tabs', { screen: 'Selfie' }) : nav.navigate('SiteSelfie'))} />
          ) : null}
          <Row style={{ flexWrap: 'wrap', marginTop: 6 }}>
            <InfoTile label="Report number" value={reportNo(done.id)} />
            <InfoTile label="Date" value={fmtISODate(done.date)} />
            <InfoTile label="Sites" value={String(done.sites)} />
            <InfoTile label="Comments" value={String(done.comments)} />
            <InfoTile label="GPS distance" value={done.km != null ? `${done.km} km` : 'GPS not available'} />
          </Row>
          <Button title="View Daily Report History" icon="time-outline" variant="secondary" style={{ marginTop: 12 }} onPress={() => nav.setParams({ tab: 'history' })} />
          <Button title="Back to Home" icon="home-outline" style={{ marginTop: 8 }}
            onPress={() => nav.navigate('Tabs', { screen: profile.role === 'Employee' ? 'Home' : 'CheckIn' })} />
        </Card>
      </Screen>
    );
  }

  if (blocked) {
    return (
      <Screen>
        <Banner tone="amber" icon="lock-closed-outline" text="Check in first, then fill the Daily Report. It must be submitted before you can check out." />
      </Screen>
    );
  }

  const siteOptions = [
    { value: 0, label: 'Select site' },
    ...sites.map((s) => ({ value: s.id, label: s.name })),
    { value: OTHER, label: 'Other (type the site name)' },
  ];

  return (
    <Screen>
      <Card>
        <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={st.title}>{"Daily Report"}</Text>
          {report ? <Pill text={report.status} tone={DR_TONE[report.status]} /> : <Pill text={"New"} tone="blue" />}
        </Row>
        <Row style={{ flexWrap: 'wrap', marginTop: 8 }}>
          <InfoTile label={"Employee"} value={profile.full_name} />
          <InfoTile label={"Employee ID"} value={profile.username} />
          <InfoTile label={"Report date"} value={fmtISODate(date)} />
          {report ? <InfoTile label={"Report no."} value={reportNo(report.id)} /> : null}
        </Row>
        {report?.status === 'Reopened' && report.review_note ? (
          <Banner tone="amber" icon="refresh-outline" text={`Reopened for correction: ${report.review_note}`} />
        ) : report?.status === 'Reopened' ? (
          <Banner tone="amber" icon="refresh-outline" text="Admin / HR reopened this report for correction. Update it and submit again." />
        ) : null}
        {report?.status === 'Reviewed' && report.review_note ? <Banner tone="green" text={`Review note: ${report.review_note}`} /> : null}
        {isToday && !locked && checkIn?.site ? (
          <Banner tone="green" icon="location-outline" text={`Site from today's check-in: ${checkIn.site} (${fmtTime12(checkIn.at)})`} />
        ) : null}
      </Card>

      <Card>
        <Text style={st.sec}>Site visits and GPS distance (recorded automatically)</Text>
        <VisitSequence visits={visits} km={km} hasGps={hasGps} />
      </Card>

      {locked ? (
        <Card>
          <Banner tone="blue" icon="lock-closed-outline" text="This report is submitted and cannot be edited. Ask Admin / HR to reopen it if a correction is needed." />
          <SiteBlocks sites={report!.daily_report_sites} />
          <ReportPhotos reportId={report!.id} />
        </Card>
      ) : (
        <>
          <Card>
            <Text style={st.sec}>Photo of the report (optional)</Text>
            <Text style={st.lbl}>Upload a photo of your report. With a photo you do not have to fill the form below - or fill it as well. A photo is not compulsory.</Text>
            <Row style={{ flexWrap: 'wrap' }}>
              <Button title="Add photo" icon="image-outline" variant="secondary" small onPress={() => addPhoto(false)} />
              {Platform.OS !== 'web' ? <Button title="Take photo" icon="camera-outline" variant="secondary" small onPress={() => addPhoto(true)} /> : null}
            </Row>
            {saved.map((p, i) => (
              <Row key={p.id} style={{ justifyContent: 'space-between', marginTop: 6 }}>
                <Text style={st.lbl}>Photo {i + 1}{p.file_name ? ` - ${p.file_name}` : ''} (saved)</Text>
                <Button title="Remove" icon="trash-outline" variant="danger" small onPress={() => dropSaved(p)} />
              </Row>
            ))}
            {pending.map((p) => (
              <Row key={p.path} style={{ justifyContent: 'space-between', marginTop: 6 }}>
                <Text style={st.lbl}>{p.name} (added)</Text>
                <Button title="Remove" icon="trash-outline" variant="danger" small onPress={() => dropPending(p)} />
              </Row>
            ))}
          </Card>

          {entries.map((e, i) => {
            const err = errors[i] ?? [];
            const bad = (cond: boolean) => (err.length && cond ? st.bad : undefined);
            return (
              <Card key={i}>
                <Row style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                  <Text style={st.sec}>Site {i + 1}</Text>
                  {entries.length > 1 ? (
                    <Button title="Remove" icon="trash-outline" variant="danger" small
                      onPress={() => { setEntries((l) => l.filter((_, k) => k !== i)); setErrors({}); }} />
                  ) : null}
                </Row>
                <Text style={st.lbl}>{"Site location / name *"}</Text>
                <View style={{ marginBottom: 8 }}>
                  <Dropdown width="100%" value={e.other ? OTHER : e.site_id ?? 0} options={siteOptions}
                    onChange={(v) => {
                      if (v === OTHER) set(i, { other: true, site_id: null, site_name: '' });
                      else if (v === 0) set(i, { other: false, site_id: null, site_name: '' });
                      else set(i, { other: false, site_id: v, site_name: sites.find((s) => s.id === v)?.name ?? '' });
                    }} />
                </View>
                {e.other ? (
                  <Field placeholder="Type the site name" value={e.site_name} onChangeText={(v) => set(i, { site_name: v })}
                    style={bad(!e.site_name.trim())} />
                ) : null}
                <PreviewField fieldKey="sub_work" label={"Sub work (subcontract details) *"} value={e.sub_work} onChangeText={(v) => set(i, { sub_work: v })} style={bad(!e.sub_work.trim())} />
                <PreviewField fieldKey="work_description" label={"Work description (work completed today) *"} multiline value={e.work_description} onChangeText={(v) => set(i, { work_description: v })} style={bad(!e.work_description.trim())} />
                {([1, 2, 3] as const).filter((k) => k <= e.cc).map((k) => {
                  const key = `comment_${k}` as 'comment_1' | 'comment_2' | 'comment_3';
                  return (
                    <View key={k}>
                      <PreviewField fieldKey={key} label={`Comment to contractor ${k}`} value={e[key]} onChangeText={(v) => set(i, { [key]: v } as Partial<Entry>)} />
                      {k === e.cc && k > 1 ? (
                        <Button title={`Remove contractor ${k}`} icon="close-circle-outline" variant="ghost" small
                          onPress={() => set(i, { [key]: '', cc: k - 1 } as Partial<Entry>)} style={{ alignSelf: 'flex-start', marginBottom: 6 }} />
                      ) : null}
                    </View>
                  );
                })}
                {e.cc < MAX_CC ? (
                  <Button title={"+ Add contractor"} icon="person-add-outline" variant="secondary" small
                    onPress={() => set(i, { cc: e.cc + 1 })} style={{ alignSelf: 'flex-start', marginBottom: 8 }} />
                ) : null}
                <PreviewField fieldKey="remarks" label={"Remarks (issues, delays, pending work)"} multiline value={e.remarks} onChangeText={(v) => set(i, { remarks: v })} />
                {err.map((m) => <Text key={m} style={st.err}>{m}</Text>)}
              </Card>
            );
          })}

          <Button title={"+ Add Another Site"} icon="add" variant="secondary" onPress={() => setEntries((l) => [...l, blank()])} style={{ marginBottom: 8 }} />
          <Row>
            <Button title={"Save as Draft"} icon="save-outline" variant="secondary" style={{ flex: 1 }} loading={busy === 'draft'} disabled={!!busy} onPress={saveDraft} />
            <Button title={"Submit Report"} icon="send" style={{ flex: 1 }} loading={busy === 'submit'} disabled={!!busy} onPress={submit} />
          </Row>
          <Text style={st.draftNote}>{"A draft does not unlock check-out."}</Text>
        </>
      )}
    </Screen>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 18, fontWeight: '800', color: '#102A45' },
  sec: { fontSize: 14, fontWeight: '800', color: '#102A45', marginBottom: 8 },
  lbl: { fontSize: 12, fontWeight: '700', color: '#3A5068', marginBottom: 6 },
  err: { color: C.red, fontSize: 12.5, marginTop: 2 },
  draftNote: { textAlign: 'center', color: C.muted, fontSize: 12.5, marginTop: 8 },
  bad: { borderColor: C.red },
});
