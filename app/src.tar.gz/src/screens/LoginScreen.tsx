import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useEffect, useState } from 'react';
import {
  Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import EmployeeRegistration from '../components/EmployeeRegistration';
import { Banner, Button, Field, Segmented } from '../components/ui';
import { COMPANY_ADDRESS, COMPANY_NAME, isConfigured } from '../config';
import { Portal, useAuth } from '../lib/auth';
import { appVersionText } from '../lib/otaUpdate';
import { UPDATE_NOTICE_KEY } from '../lib/release';
import { useIsDesktop } from '../lib/layout';
import { errorText } from '../lib/supabase';
import { useTicker } from '../lib/realtime';
import { fmtDateLong, fmtTime12 } from '../lib/time';
import { C, shadow } from '../theme';

const TITLE: Record<Portal, string> = { employee: 'Employee', hr: 'HR', admin: 'Admin' };
const NOTE: Record<Portal, string> = {
  employee: 'For employees to mark attendance, use site selfie attendance, apply leave and view personal records.',
  hr: 'For HR to manage employees, approvals, reports, holidays and site selfie review.',
  admin: 'For Admin to manage everything: HR and employee accounts, roles, work sites, reports and the audit trail.',
};

export default function LoginScreen() {
  const { signIn } = useAuth();
  const [portal, setPortal] = useState<Portal>('employee');
  const [mode, setMode] = useState<'employee' | 'staff' | 'choose' | 'register' | 'status'>('choose');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [updated, setUpdated] = useState<string | null>(null);
  const now = useTicker(1000);

  // shown once after the Admin published an update and everyone was signed out
  useEffect(() => {
    AsyncStorage.getItem(UPDATE_NOTICE_KEY).then((v) => { if (v) { setUpdated(v); AsyncStorage.removeItem(UPDATE_NOTICE_KEY).catch(() => {}); } }).catch(() => {});
  }, []);
  const desktop = useIsDesktop();

  // Asked every time the login page opens (so after every sign-out too). Never shown once signed in.
  const choose = (m: 'employee' | 'staff') => {
    setMode(m);
    setPortal(m === 'staff' ? 'admin' : 'employee');
    setError(''); setUsername(''); setPassword(''); setShow(false);
  };

  const switchPortal = (p: Portal) => { setPortal(p); setMode(p === 'employee' ? 'employee' : 'staff'); setError(''); setUsername(''); setPassword(''); setShow(false); };

  const submit = async () => {
    setError('');
    setBusy(true);
    try {
      await signIn(username, password, portal);
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.navy }}>
      <SafeAreaView style={{ flex: 1 }}>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <ScrollView
            contentContainerStyle={desktop ? st.deskScroll : { flexGrow: 1, padding: 18 }}
            keyboardShouldPersistTaps="handled"
          >
           <View style={desktop ? st.deskRow : undefined}>
            <View style={desktop ? st.deskLeft : undefined}>
            {desktop ? (<>
            <View style={st.brand}>
              <Image source={require('../../assets/cvp_logo.png')} style={st.logo} />
              <View style={{ flex: 1 }}>
                <Text style={st.company}>{COMPANY_NAME}</Text>
                <Text style={st.address}>{COMPANY_ADDRESS}</Text>
              </View>
            </View>

            <View style={st.message}>
              <Text style={[st.title, desktop && st.deskTitle]}>Work smarter.{'\n'}<Text style={{ color: '#49D7F4' }}>Track time beautifully.</Text></Text>
            </View>
            </>) : (
              <View style={st.hero}>
                <Image source={require('../../assets/cvp_logo.png')} style={st.heroLogo} />
                <Text style={st.heroName}>CVP <Text style={{ fontWeight: '500' }}>Attendance</Text></Text>
                <Text style={st.heroTag}>Track  ·  Work  ·  Grow</Text>
                <Text style={st.heroCompany}>{COMPANY_NAME}</Text>
              </View>
            )}
            {desktop ? (
              <View style={{ gap: 12 }}>
                {[
                  ['pulse-outline', 'Live dashboard: check-ins appear on every screen within a second'],
                  ['phone-portrait-outline', 'Same account on phone and desktop, always in sync'],
                  ['shield-checkmark-outline', 'Server time (IST) and audit trail for every action'],
                ].map(([icon, text]) => (
                  <View key={text} style={st.feature}>
                    <View style={st.featureIcon}><Ionicons name={icon as any} size={18} color="#49D7F4" /></View>
                    <Text style={st.featureText}>{text}</Text>
                  </View>
                ))}
              </View>
            ) : null}
            </View>

            <View style={[st.card, desktop && st.deskCard]}>
              <View style={st.timeRow}>
                <Text style={st.timeSmall}>India Time - {fmtDateLong(now)}</Text>
                <Text style={st.timeBig}>{fmtTime12(now)}</Text>
              </View>
              <Text style={st.cardTitle}>{mode === 'register' ? 'Register' : mode === 'status' ? 'Create login' : mode === 'choose' ? 'Welcome to CVP Attendance' : 'Welcome Back!'}</Text>
              <Text style={st.cardCopy}>
                {mode === 'register' ? 'New employee registration.'
                  : mode === 'status' ? 'Check your registration status or create your login.'
                  : mode === 'choose' ? 'Who is signing in? Choose to continue.'
                  : 'Sign in to continue'}
              </Text>

              {mode === 'choose' ? (
                <View style={{ gap: 12, marginTop: 4 }}>
                  <Pressable onPress={() => choose('employee')} accessibilityRole="button" style={[st.chooseBtn, { backgroundColor: C.blue, borderColor: C.blue }]}>
                    <Ionicons name="person-outline" size={22} color="#FFFFFF" />
                    <Text style={[st.chooseText, { color: '#FFFFFF' }]}>I am an Employee</Text>
                  </Pressable>
                  <Pressable onPress={() => choose('staff')} accessibilityRole="button" style={st.chooseBtn}>
                    <Ionicons name="shield-checkmark-outline" size={22} color={C.ink} />
                    <Text style={st.chooseText}>I am Admin</Text>
                  </Pressable>
                </View>
              ) : null}

              {mode === 'register' || mode === 'status' ? <EmployeeRegistration key={mode} flow={mode} onBack={() => setMode('employee')} /> : null}
              {mode === 'employee' || mode === 'staff' ? (<>

              {updated ? (
                <Banner tone="blue" icon="cloud-download-outline" text={updated === 'update' ? 'The app was updated. Please sign in again.' : `The app was updated (${updated}). Please sign in again.`} />
              ) : null}

              {!isConfigured ? (
                <Banner tone="red" icon="warning" text={Platform.OS === 'web' ? 'App not configured: add EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY to the .env file.' : 'The app is not available right now. Please contact HR / Admin.'} />
              ) : null}

              <Pressable onPress={() => { setMode('choose'); setError(''); setUsername(''); setPassword(''); }} accessibilityRole="button" style={st.whoRow}>
                <Text style={st.whoText}>Signing in as {portal === 'employee' ? 'Employee' : 'Admin'}</Text>
                <Text style={st.serverLink}>Change</Text>
              </Pressable>

              <View style={st.pwRow}>
                <Ionicons name="person-outline" size={19} color="#7F93AA" style={{ marginLeft: 14 }} />
                <TextInput
                  style={st.pwInput}
                  placeholder={portal === 'employee' ? 'Username / Employee ID' : `${TITLE[portal]} username`}
                  placeholderTextColor="#9AA8B8"
                  value={username}
                  onChangeText={setUsername}
                  key={`user-${portal}`}
                  autoCapitalize="none"
                  autoCorrect={false}
                  autoComplete="off"
                  importantForAutofill="no"
                  textContentType="none"
                  returnKeyType="next"
                />
              </View>
              <View>
                <View style={st.pwRow}>
                  <Ionicons name="lock-closed-outline" size={19} color="#7F93AA" style={{ marginLeft: 14 }} />
                  <TextInput
                    style={st.pwInput}
                    placeholder="Enter password"
                    placeholderTextColor="#9AA8B8"
                    secureTextEntry={!show}
                    value={password}
                    onChangeText={setPassword}
                    key={`pw-${portal}`}
                    autoComplete="new-password"
                    importantForAutofill="no"
                    textContentType="oneTimeCode"
                    onSubmitEditing={submit}
                    returnKeyType="go"
                  />
                  <Pressable onPress={() => setShow(!show)} hitSlop={10} style={{ padding: 10 }}>
                    <Ionicons name={show ? 'eye-off-outline' : 'eye-outline'} size={20} color={C.muted} />
                  </Pressable>
                </View>
              </View>

              {error ? <Banner tone="red" icon="alert-circle" text={error} /> : null}

              <Button
                title="Login"
                loading={busy}
                onPress={submit}
                style={{ marginTop: 4 }}
              />
              <Pressable onPress={() => Alert.alert('Forgot password?', 'Ask HR / Admin to reset your password.')} style={{ alignSelf: 'center', marginTop: 12 }}>
                <Text style={st.serverLink}>Forgot Password?</Text>
              </Pressable>
              <Pressable onPress={() => { setError(''); setMode('register'); }} style={{ alignSelf: 'center', marginTop: 12 }}>
                <Text style={st.serverLink}>New employee? Register</Text>
              </Pressable>
              <Pressable onPress={() => { setError(''); setMode('status'); }} style={{ alignSelf: 'center', marginTop: 8 }}>
                <Text style={st.serverLink}>Check status / Create login</Text>
              </Pressable>
              <View style={st.secure}>
                <Ionicons name="shield-checkmark-outline" size={14} color={C.muted} />
                <Text style={st.footer2}>Secure  |  Simple  |  Reliable</Text>
              </View>
              </>) : null}
            </View>
           </View>
           {Platform.OS !== 'web' ? <Text style={{ textAlign: 'center', color: '#8FA3BA', fontSize: 11, marginTop: 14, marginBottom: 8 }}>{appVersionText()}</Text> : null}
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const st = StyleSheet.create({
  chooseBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, height: 56, borderRadius: 16, borderWidth: 1.5, borderColor: '#DCE7F3', backgroundColor: '#FFFFFF' },
  chooseText: { fontSize: 17, fontWeight: '800', color: '#0B2B4D' },
  whoRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  whoText: { fontSize: 14, fontWeight: '800', color: '#0B2B4D' },
  hero: { alignItems: 'center', paddingTop: 28, paddingBottom: 26 },
  heroLogo: { width: 96, height: 96, borderRadius: 26, backgroundColor: C.white },
  heroName: { color: C.white, fontSize: 30, fontWeight: '800', marginTop: 14, letterSpacing: 0.3 },
  heroTag: { color: '#9CC8E6', fontSize: 13, marginTop: 6, letterSpacing: 1 },
  heroCompany: { color: '#6F9DBF', fontSize: 11.5, marginTop: 4 },
  secure: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 16 },
  footer2: { color: C.muted, fontSize: 11.5 },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 6 },
  logo: { width: 58, height: 58, borderRadius: 16, backgroundColor: C.white },
  company: { color: C.white, fontWeight: '800', fontSize: 15, letterSpacing: 0.3 },
  address: { color: '#A9CADD', fontSize: 11, marginTop: 3, lineHeight: 15 },
  message: { marginTop: 26, marginBottom: 18 },
  kicker: { color: '#78D9FF', fontSize: 11, fontWeight: '800', letterSpacing: 1.5 },
  title: { color: C.white, fontSize: 30, fontWeight: '800', marginTop: 8, letterSpacing: -0.8, lineHeight: 34 },
  card: { backgroundColor: C.white, borderRadius: 24, padding: 20, ...shadow },
  timeRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  timeSmall: { fontSize: 11, color: '#71839A' },
  timeBig: { fontSize: 14, fontWeight: '800', color: C.blue },
  cardTitle: { fontSize: 22, fontWeight: '800', color: '#102944', letterSpacing: -0.5 },
  cardCopy: { fontSize: 13, color: '#728299', marginTop: 4, marginBottom: 14 },
  note: { fontSize: 12, color: '#74879C', backgroundColor: '#F7FBFF', borderWidth: 1, borderColor: '#E4EDF6', borderRadius: 11, padding: 10, marginBottom: 12 },
  label: { fontSize: 12, fontWeight: '700', color: '#3A5068', marginBottom: 6 },
  pwRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FBFDFF', borderWidth: 1, borderColor: '#DFE8F2', borderRadius: 12, marginBottom: 14 },
  pwInput: { flex: 1, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: C.ink },
  deskScroll: { flexGrow: 1, padding: 40, alignItems: 'center', justifyContent: 'center' },
  deskRow: { flexDirection: 'row', alignItems: 'center', gap: 56, width: '100%', maxWidth: 1080 },
  deskLeft: { flex: 1 },
  deskTitle: { fontSize: 44, lineHeight: 50 },
  deskCard: { width: 440, padding: 28 },
  feature: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  featureIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: 'rgba(73,215,244,0.12)', alignItems: 'center', justifyContent: 'center' },
  featureText: { color: '#CFE2EE', fontSize: 14, flex: 1 },
  footer: { textAlign: 'center', color: C.muted, fontSize: 12, marginTop: 14 },
  serverLink: { color: C.blue, fontSize: 12, fontWeight: '700' },
  serverBox: { marginTop: 10, padding: 12, borderRadius: 12, backgroundColor: '#F7FBFF', borderWidth: 1, borderColor: '#E4EDF6' },
  serverNow: { fontSize: 11.5, color: C.muted, marginBottom: 8 },
});

