import { useRoute } from '@react-navigation/native';
import React, { useEffect, useMemo, useState } from 'react';
import { Alert } from 'react-native';
import { AccessControlCard } from '../../components/AccessControlCard';
import EmployeeDetailsForm from '../../components/EmployeeDetailsForm';
import { Avatar, Card, Loading, Pill, Row, Screen } from '../../components/ui';
import { Text, View } from 'react-native';
import { api, Profile } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { errorText } from '../../lib/supabase';
import { C } from '../../theme';
import { shownRole } from '../../navigation/menu';

/** One employee's Employee Form + documents (opened by Admin / HR from "Employee Forms") */
export default function EmployeeFormScreen() {
  const route = useRoute<any>();
  const { profile: me } = useAuth();
  const userId: string = route.params.userId;
  const [p, setP] = useState<Profile | null>(null);
  const reload = () => api.profile(userId).then(setP).catch((e) => Alert.alert('Could not load', errorText(e)));
  useEffect(() => { reload(); }, [userId]);
  const fallback = useMemo(() => ({ name: p?.full_name ?? '', phone: p?.phone ?? '', joining: p?.joining_date ?? '', department: p?.department ?? '', designation: p?.designation ?? '', role: p?.role ?? '', siteEmployee: !!p?.site_employee }), [p?.full_name, p?.phone, p?.joining_date, p?.department, p?.designation, p?.role, p?.site_employee]);
  if (!p || !me) return <Loading />;
  return (
    <Screen>
      <Card>
        <Row>
          <Avatar name={p.full_name} size={46} />
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '800', fontSize: 16, color: C.ink }}>{p.full_name}</Text>
            <Text style={{ color: C.muted, fontSize: 12.5, marginTop: 2 }}>{p.username} - {p.designation || p.department || 'General'}</Text>
          </View>
          <Pill text={shownRole(p)} tone="purple" />
        </Row>
      </Card>
      <EmployeeDetailsForm userId={p.id} admin={p.id !== me.id} fallback={fallback} />
      {p.id !== me.id ? <AccessControlCard key={p.id} p={p} canManage={me.role === 'Admin' || me.role === 'HR' || p.role === 'Employee'} onSaved={reload} /> : null}
    </Screen>
  );
}
