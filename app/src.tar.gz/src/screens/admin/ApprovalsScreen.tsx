import { notificationsApi } from '../../lib/notifications';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert, Linking, Modal, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Avatar, Banner, Button, Card, Empty, LiveDot, Loading, Pill, Row, Screen, Segmented } from '../../components/ui';
import { api, LeaveBalance, LeaveRequest, LeaveReviewInfo, RegistrationRequest } from '../../lib/api';
import { useIsDesktop } from '../../lib/layout';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtISODate, fmtTime12, istParts, MONTHS } from '../../lib/time';
import { C } from '../../theme';

// ---------------------------------------------------------------- leave card helpers (display only)
const mon = (m: number) => MONTHS[m - 1].slice(0, 3);
const ymd = (iso: string) => iso.slice(0, 10).split('-').map(Number) as [number, number, number];
const plural = (n: number, w: string) => `${n} ${w}${n === 1 ? '' : 's'}`;
/** "18 - 19 Nov 2026", "24 Nov 2026", "28 Nov - 2 Dec 2026", "30 Dec 2026 - 2 Jan 2027" */
function fmtRange(from: string, to: string) {
  const [fy, fm, fd] = ymd(from); const [ty, tm, td] = ymd(to);
  if (from.slice(0, 10) === to.slice(0, 10)) return `${fd} ${mon(fm)} ${fy}`;
  if (fy !== ty) return `${fd} ${mon(fm)} ${fy} - ${td} ${mon(tm)} ${ty}`;
  if (fm !== tm) return `${fd} ${mon(fm)} - ${td} ${mon(tm)} ${ty}`;
  return `${fd} - ${td} ${mon(tm)} ${ty}`;
}
const abbr = (t: string) => t.split(/\s+/).map((w) => w[0]?.toUpperCase() ?? '').join('');   // "Casual Leave" -> "CL"

type Split = { paid: number; unpaid: number };
const typeLabel = (l: LeaveRequest) => (l.leave_type === 'Loss of Pay' ? 'Unpaid (LOP)' : l.leave_type);
const daysOf = (l: LeaveRequest) => Number(l.units ?? l.days) || 0;
const halfWord = (l: LeaveRequest) => (l.half_part ? (l.half_part === 'first' ? 'Morning' : 'Afternoon') : '');

/** Paid / unpaid days of a request: from the 24-day policy numbers when present, else from the old preview split */
/** Display only: show whole days (0.5 -> 1), the unpaid part is whatever is left of the request's total */
const whole = (s: Split): Split => {
  const total = s.paid + s.unpaid;
  const paid = Math.min(Math.round(s.paid), Math.ceil(total));
  return { paid, unpaid: Math.max(0, Math.ceil(total) - paid) };
};
function paidUnpaid(l: LeaveRequest, info?: LeaveReviewInfo, split?: Split): Split | null {
  if (l.policy_v2) return info ? whole({ paid: info.uses.EL + info.uses.CL + info.uses.SL, unpaid: info.uses.LOP }) : null;
  return split ? whole(split) : null;
}
function tagOf(s: Split | null) {
  if (!s) return null;
  if (s.unpaid === 0) return { text: 'Paid', tone: 'green' as const };
  if (s.paid === 0) return { text: 'Unpaid', tone: 'amber' as const };
  return { text: `${s.paid} Paid + ${s.unpaid} Unpaid`, tone: 'purple' as const };
}
function payLine(l: LeaveRequest, info?: LeaveReviewInfo, s?: Split | null) {
  if (!s) return 'Loading...';
  if (l.policy_v2 && info) {
    let left = s.paid;                                   // whole paid days, handed out EL -> CL -> SL
    const parts = (['EL', 'CL', 'SL'] as const).filter((k) => info.uses[k] > 0).map((k) => {
      const n = Math.min(left, Math.max(1, Math.round(info.uses[k]))); left -= n; return { n, k };
    }).filter((p) => p.n > 0);
    if (s.unpaid === 0) return parts.length === 1 ? `${plural(parts[0].n, 'day')} from ${parts[0].k}` : parts.map((p) => `${plural(p.n, 'day')} ${p.k}`).join(' + ');
    if (parts.length === 0) return `${plural(s.unpaid, 'day')} unpaid${info.under_eligibility ? ' (under 6 months)' : ''}`;
    return `${parts.map((p) => `${plural(p.n, 'day')} ${p.k}`).join(' + ')} + ${plural(s.unpaid, 'day')} unpaid`;
  }
  if (s.unpaid === 0) return `${plural(s.paid, 'day')} paid`;
  if (s.paid === 0) return `${plural(s.unpaid, 'day')} unpaid`;
  return `${plural(s.paid, 'day')} paid + ${plural(s.unpaid, 'day')} unpaid`;
}
function appliedText(l: LeaveRequest, info?: LeaveReviewInfo) {
  const c = istParts(l.created_at);
  let ahead = info?.days_ahead;
  if (ahead === undefined) {
    const [fy, fm, fd] = ymd(l.from_day);
    ahead = Math.round((Date.UTC(fy, fm - 1, fd) - Date.UTC(c.year, c.month - 1, c.day)) / 86400000);
  }
  return `${c.day} ${mon(c.month)}, ${ahead <= 0 ? 'same day' : `${plural(ahead, 'day')} before`}`;
}

function LeaveCard({ l, info, split, busy, onApprove, onReject }: {
  l: LeaveRequest; info?: LeaveReviewInfo; split?: Split; busy?: 'a' | 'r' | null;
  onApprove?: () => void; onReject?: () => void;      // no handlers = already approved / rejected
}) {
  const desktop = useIsDesktop();
  const [open, setOpen] = useState(false);            // details are closed by default and again after a reload
  const [bal, setBal] = useState<LeaveBalance[] | null>(null);
  const s = paidUnpaid(l, info, split);
  const tag = tagOf(s);

  const toggle = () => {
    const next = !open;
    setOpen(next);
    if (next && !l.policy_v2 && bal === null) api.leaveBalance(Number(l.from_day.slice(0, 4)), l.user_id).then(setBal).catch(() => setBal([]));
  };
  const balText = l.policy_v2
    ? (info ? `EL ${Math.round(info.before.EL)} · CL ${Math.round(info.before.CL)} · SL ${Math.round(info.before.SL)}` : 'Loading...')
    : bal === null ? 'Loading...' : bal.filter((b) => b.counts_balance).map((b) => `${abbr(b.leave_type)} ${b.balance}`).join(' · ') || '-';
  const n = daysOf(l);
  const half = halfWord(l);

  return (
    <Card>
      <Row>
        <Avatar name={l.employee?.full_name} size={38} />
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.name} numberOfLines={1}>{l.employee?.full_name}</Text>
          <Text style={st.sub} numberOfLines={1}>{(l.employee?.department || 'General').toUpperCase()}</Text>
        </View>
        {l.status === 'Pending' && tag ? <Pill text={tag.text} tone={tag.tone} /> : null}
        {l.status !== 'Pending' && tag ? <Pill text={tag.text} tone={tag.tone} /> : null}
      </Row>
      <Row style={{ marginTop: 10, gap: 6 }}>
        <Ionicons name="calendar-outline" size={15} color={C.muted} />
        <Text style={[st.dates, { flex: 1 }]}>
          {fmtRange(l.from_day, l.to_day)}{half ? ` (${half})` : ''}
          <Text style={st.datesMeta}>  · {n === 0.5 ? '0.5 day' : plural(n, 'day')} · {typeLabel(l)}</Text>
        </Text>
      </Row>
      <Text style={st.reason}><Text style={{ fontWeight: '800' }}>Reason: </Text>{l.reason}{l.personal_work ? ` - ${l.personal_work}` : ''}</Text>

      <Pressable onPress={toggle} style={st.link} accessibilityRole="button" accessibilityState={{ expanded: open }}>
        <Text style={st.linkText}>{open ? '▾ Hide details' : '▸ Show details'}</Text>
      </Pressable>
      {open ? (
        <View style={st.details}>
          <View style={st.dRow}><Text style={st.dLabel}>Leave balance</Text><Text style={st.dVal}>{balText}</Text></View>
          <View style={st.dRow}><Text style={st.dLabel}>Paid / unpaid</Text><Text style={st.dVal}>{payLine(l, info, s)}</Text></View>
          <View style={st.dRow}><Text style={st.dLabel}>Applied</Text><Text style={st.dVal}>{appliedText(l, info)}</Text></View>
          {half ? <View style={st.dRow}><Text style={st.dLabel}>Half day</Text><Text style={st.dVal}>{l.half_part === 'first' ? 'First half (Morning)' : 'Second half (Afternoon)'}</Text></View> : null}
          {info?.certificate_path ? (
            <View style={st.dRow}><Text style={st.dLabel}>Medical certificate</Text>
              <Pressable onPress={() => api.leaveCertUrl(info.certificate_path!).then((url) => Linking.openURL(url)).catch((e) => Alert.alert('Could not open', errorText(e)))}>
                <Text style={st.linkText}>View</Text>
              </Pressable>
            </View>
          ) : null}
        </View>
      ) : null}

      {onApprove && onReject ? (
        <Row style={{ marginTop: 10 }}>
          {/* phone: two half-width buttons; desktop: compact buttons side by side */}
          <Button title="Approve" icon="checkmark" variant="success" small style={desktop ? { minWidth: 110 } : { flex: 1 }}
            loading={busy === 'a'} disabled={!!busy} onPress={onApprove} />
          <Button title="Reject" icon="close" variant="danger" small style={desktop ? { minWidth: 110 } : { flex: 1 }}
            loading={busy === 'r'} disabled={!!busy} onPress={onReject} />
        </Row>
      ) : (
        <View style={{ marginTop: 10, alignSelf: 'flex-start' }}>
          <Pill tone={l.status === 'Approved' ? 'green' : 'red'}
            text={`${l.status === 'Approved' ? '✓ Approved' : '✕ Rejected'}${l.reviewer?.full_name ? ' by ' + l.reviewer.full_name : ''}${l.reviewed_at ? ` · ${istParts(l.reviewed_at).day} ${mon(istParts(l.reviewed_at).month)}, ${fmtTime12(l.reviewed_at)}` : ''}`} />
          {l.status === 'Rejected' && l.review_note ? <Text style={[st.sub, { marginTop: 4 }]}>Reason: {l.review_note}</Text> : null}
        </View>
      )}
    </Card>
  );
}

/** An approved leave the employee asks to cancel: ONE approval by Admin or HR (approve = Cancelled + days returned, Keep leave = stays Approved) */
function CancelCard({ l, busy, onApprove, onReject }: { l: LeaveRequest; busy?: 'a' | 'r' | null; onApprove: () => void; onReject: () => void }) {
  const desktop = useIsDesktop();
  const n = daysOf(l);
  return (
    <Card>
      <Row>
        <Avatar name={l.employee?.full_name} size={38} />
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.name} numberOfLines={1}>{l.employee?.full_name}</Text>
          <Text style={st.sub} numberOfLines={1}>{(l.employee?.department || 'General').toUpperCase()}</Text>
        </View>
        <Pill text="Cancellation requested" tone="amber" />
      </Row>
      <Row style={{ marginTop: 10, gap: 6 }}>
        <Ionicons name="calendar-outline" size={15} color={C.muted} />
        <Text style={[st.dates, { flex: 1 }]}>
          {fmtRange(l.from_day, l.to_day)}
          <Text style={st.datesMeta}>  · {n === 0.5 ? '0.5 day' : plural(n, 'day')} · {typeLabel(l)}</Text>
        </Text>
      </Row>
      <Text style={st.sub}>
        Approved earlier by {l.reviewer?.full_name ?? 'Admin'}{l.reviewed_at ? `, ${istParts(l.reviewed_at).day} ${mon(istParts(l.reviewed_at).month)} ${fmtTime12(l.reviewed_at)}` : ''}
      </Text>
      <Text style={st.reason}><Text style={{ fontWeight: '800' }}>Leave reason: </Text>{l.reason}</Text>
      <Text style={st.reason}><Text style={{ fontWeight: '800' }}>Reason to cancel: </Text>{l.cancel_reason}</Text>
      <Text style={st.sub}>Asked {l.cancel_requested_at ? `${istParts(l.cancel_requested_at).day} ${mon(istParts(l.cancel_requested_at).month)}, ${fmtTime12(l.cancel_requested_at)}` : ''}. Approve = the leave is cancelled and the days go back to the same leave type. Keep leave = it stays approved.</Text>
      <Row style={{ marginTop: 10 }}>
        <Button title="Approve cancellation" icon="checkmark" variant="success" small style={desktop ? { minWidth: 170 } : { flex: 1 }}
          loading={busy === 'a'} disabled={!!busy} onPress={onApprove} />
        <Button title="Keep leave" icon="shield-checkmark-outline" variant="secondary" small style={desktop ? { minWidth: 120 } : { flex: 1 }}
          loading={busy === 'r'} disabled={!!busy} onPress={onReject} />
      </Row>
    </Card>
  );
}

export default function ApprovalsScreen() {
  const [leaves, setLeaves] = useState<LeaveRequest[] | null>(null);
  const [cancels, setCancels] = useState<LeaveRequest[]>([]);            // cancel requests of approved leave (leave_cancel_approved.sql)
  const [regs, setRegs] = useState<RegistrationRequest[]>([]);
  const [split, setSplit] = useState<Record<number, { paid: number; unpaid: number }>>({});   // paid / unpaid days of each pending request
  const [info, setInfo] = useState<Record<number, LeaveReviewInfo>>({});   // 24-day policy: balance now -> after, days ahead, certificate
  const [busyId, setBusyId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [view, setView] = useState<'Waiting' | 'Cancel' | 'Approved' | 'Rejected'>('Waiting');
  const [reviewed, setReviewed] = useState<LeaveRequest[] | null>(null);
  const [rejecting, setRejecting] = useState<LeaveRequest | null>(null);   // leave waiting for its (required) rejection reason
  const [rejNote, setRejNote] = useState('');

  const load = useCallback(async () => {
    try {
      const list = [...(await api.pendingLeaves())].sort((a, b) => b.id - a.id);   // newest first
      setLeaves(list);
      Promise.all(list.filter((l) => l.policy_v2).map((l) => api.leaveReviewInfo(l.id).then((i) => [l.id, i] as const).catch(() => null)))
        .then((r) => setInfo(Object.fromEntries(r.filter((e): e is NonNullable<typeof e> => !!e))));
      const entries = await Promise.all(list.filter((l) => !l.policy_v2).map(async (l) => {
        try {
          const d = await api.leavePreview(l.leave_type, l.from_day, l.to_day, l.user_id);
          return [l.id, { paid: d.filter((x) => x.status === 'Paid').length, unpaid: d.filter((x) => x.status === 'Unpaid').length }] as const;
        } catch { return null; }
      }));
      setSplit(Object.fromEntries(entries.filter((e): e is NonNullable<typeof e> => !!e)));
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
    setCancels(await api.pendingLeaveCancels().catch(() => []));       // empty until leave_cancel_approved.sql is run
    // the login approvals need employee_registration.sql; without it the list stays empty
    setRegs(await api.pendingRegistrations().catch(() => []));
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  const live = useRealtime('approvals', [{ table: 'leaves' }, { table: 'employee_registrations' }], () => load());

  // Approved / Rejected lists are fetched when that tab is opened
  const switchView = async (v: 'Waiting' | 'Cancel' | 'Approved' | 'Rejected') => {
    setView(v);
    if (v === 'Waiting' || v === 'Cancel') return;
    setReviewed(null);
    try { setReviewed(await api.reviewedLeaves(v)); } catch (e) { setReviewed([]); Alert.alert('Could not load', errorText(e)); }
  };

  // after Approve / Reject: tell the reviewer whether the employee has a phone that gets the notification
  const [notice, setNotice] = useState('');
  const tell = async (userId: string, name: string) => {
    const n = await notificationsApi.deviceCount(userId);
    setNotice(n > 0 ? `Notification sent to ${name} (${n} device${n === 1 ? '' : 's'}).` : `${name} has no phone with notifications yet.`);
    setTimeout(() => setNotice(''), 8000);
  };
  const act = async (key: string, fn: () => Promise<unknown>, who?: { id: string; name: string }) => {
    if (busyId) return;                                  // no double click while saving
    setBusyId(key);
    try { await fn(); await load(); if (who) void tell(who.id, who.name); } catch (e) { Alert.alert('Could not update', errorText(e)); } finally { setBusyId(null); }
  };

  // used by the login approvals (the optional reason stays as it was)
  const reject = (key: string, fn: (note?: string) => Promise<unknown>) => {
    if (Platform.OS === 'web') {
      // the browser prompt: Cancel = do not reject; OK = reject with the optional reason
      const note = window.prompt('Reject this request? Type a reason for the employee (optional) and press OK.');
      if (note !== null) void act(key, () => fn(note.trim() || undefined));
    } else if (Platform.OS === 'ios') {
      // iOS: allow an optional note
      Alert.prompt('Reject request', 'Optional note for the employee', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Reject', style: 'destructive', onPress: (note?: string) => act(key, () => fn(note)) },
      ]);
    } else {
      Alert.alert('Reject this request?', '', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Reject', style: 'destructive', onPress: () => act(key, () => fn()) },
      ]);
    }
  };

  const confirmReject = () => {
    const l = rejecting; const note = rejNote.trim();
    if (!l || !note) return;
    setRejecting(null); setRejNote('');
    void act(`lr${l.id}`, () => api.reviewLeave(l.id, false, note), { id: l.user_id, name: l.employee?.full_name ?? 'The employee' });
  };

  if (!leaves) return <Loading />;

  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      {regs.length > 0 ? <Text style={st.head}>Pending Login Approvals ({regs.length})</Text> : null}
      {regs.map((r) => (
        <Card key={`reg${r.id}`}>
          <Row>
            <Avatar name={r.full_name} size={32} />
            <View style={{ flex: 1 }}>
              <Text style={st.name}>{r.full_name}</Text>
              <Text style={st.sub}>{r.department || 'General'}{r.designation ? ` - ${r.designation}` : ''}</Text>
            </View>
          </Row>
          <Text style={st.dates}>{r.channel === 'mobile' ? `Mobile ${r.mobile ?? ''} (verified)` : `E-mail ${r.email ?? ''} (verified)`}</Text>
          <Text style={st.reason}>Requested {r.submitted_at ? fmtISODate(r.submitted_at.slice(0, 10)) : ''} - waiting to create a username and password.</Text>
          <Row style={{ marginTop: 8 }}>
            <Button title="Approve" icon="checkmark" variant="success" small loading={busyId === `ga${r.id}`}
              onPress={() => act(`ga${r.id}`, () => api.reviewRegistration(r.id, true))} />
            <Button title="Reject" icon="close" variant="danger" small loading={busyId === `gr${r.id}`}
              onPress={() => reject(`gr${r.id}`, (n) => api.reviewRegistration(r.id, false, n))} />
          </Row>
        </Card>
      ))}

      {notice ? <Banner tone="green" icon="notifications" text={notice} /> : null}
      <Text style={[st.head, { marginTop: 14, marginBottom: 6 }]}>Leave requests</Text>
      <View style={st.list}>
        <Segmented value={view} onChange={switchView} options={[
          { value: 'Waiting', label: `Waiting (${leaves.length})` },
          { value: 'Cancel', label: `Cancellation requests (${cancels.length})` },
          { value: 'Approved', label: 'Approved' },
          { value: 'Rejected', label: 'Rejected' },
        ]} />
        {view === 'Waiting' ? (
          leaves.length === 0 ? <Card><Empty text="No pending leave requests." icon="checkmark-done-outline" /></Card> : leaves.map((l) => (
            <LeaveCard key={l.id} l={l} info={info[l.id]} split={split[l.id]}
              busy={busyId === `la${l.id}` ? 'a' : busyId === `lr${l.id}` ? 'r' : null}
              onApprove={() => act(`la${l.id}`, () => api.reviewLeave(l.id, true), { id: l.user_id, name: l.employee?.full_name ?? 'The employee' })}
              onReject={() => { setRejNote(''); setRejecting(l); }} />
          ))
        ) : view === 'Cancel' ? (
          cancels.length === 0 ? <Card><Empty text="No cancellation requests." icon="checkmark-done-outline" /></Card> : cancels.map((l) => (
            <CancelCard key={l.id} l={l}
              busy={busyId === `ca${l.id}` ? 'a' : busyId === `cr${l.id}` ? 'r' : null}
              onApprove={() => act(`ca${l.id}`, () => api.reviewLeaveCancel(l.id, true), { id: l.user_id, name: l.employee?.full_name ?? 'The employee' })}
              onReject={() => act(`cr${l.id}`, () => api.reviewLeaveCancel(l.id, false), { id: l.user_id, name: l.employee?.full_name ?? 'The employee' })} />
          ))
        ) : reviewed === null ? <Loading /> : reviewed.length === 0
          ? <Card><Empty text={`No ${view.toLowerCase()} leave requests.`} icon="document-text-outline" /></Card>
          : reviewed.map((l) => <LeaveCard key={l.id} l={l} />)}
      </View>

      <Modal visible={!!rejecting} transparent animationType="fade" onRequestClose={() => setRejecting(null)}>
        <Pressable style={st.backdrop} onPress={() => setRejecting(null)}>
          <Pressable style={st.box} onPress={() => {}}>
            <Text style={st.boxTitle}>Reason for rejecting *</Text>
            <Text style={st.sub}>{rejecting?.employee?.full_name}</Text>
            <Text style={st.sub}>{rejecting ? `${fmtRange(rejecting.from_day, rejecting.to_day)} · ${daysOf(rejecting) === 0.5 ? '0.5 day' : plural(daysOf(rejecting), 'day')} · ${typeLabel(rejecting)}` : ''}</Text>
            <TextInput value={rejNote} onChangeText={setRejNote} multiline autoFocus placeholder="Tell the employee why"
              placeholderTextColor={C.muted} style={st.input} />
            <Row style={{ marginTop: 10 }}>
              <Button title="Cancel" variant="secondary" small style={{ flex: 1 }} onPress={() => setRejecting(null)} />
              <Button title="Reject leave" icon="close" variant="danger" small style={{ flex: 1 }}
                disabled={!rejNote.trim() || !!busyId} onPress={confirmReject} />
            </Row>
          </Pressable>
        </Pressable>
      </Modal>
    </Screen>
  );
}

const st = StyleSheet.create({
  head: { fontWeight: '800', color: C.ink, fontSize: 14 },
  name: { fontWeight: '800', color: '#102A45', fontSize: 14 },
  sub: { color: C.muted, fontSize: 12, marginTop: 1 },
  dates: { marginTop: 6, fontWeight: '700', color: '#17314D', fontSize: 13 },
  datesMeta: { fontWeight: '600', color: C.muted, fontSize: 12 },
  reason: { marginTop: 4, color: '#203951', fontSize: 13 },
  list: { width: '100%', maxWidth: 900, alignSelf: 'flex-start' },
  link: { alignSelf: 'flex-start', paddingVertical: 8 },
  linkText: { color: C.blue, fontWeight: '800', fontSize: 13 },
  details: { backgroundColor: '#F3F6FA', borderRadius: 10, padding: 10, gap: 6 },
  dRow: { flexDirection: 'row', gap: 8 },
  dLabel: { width: 124, color: C.muted, fontSize: 12, fontWeight: '700' },
  dVal: { flex: 1, color: '#17314D', fontSize: 13, fontWeight: '700' },
  backdrop: { flex: 1, justifyContent: 'center', padding: 16, backgroundColor: 'rgba(6,37,63,0.35)' },
  box: { backgroundColor: C.white, borderRadius: 14, padding: 16, width: '100%', maxWidth: 420, alignSelf: 'center' },
  boxTitle: { fontWeight: '800', color: C.ink, fontSize: 16, marginBottom: 2 },
  input: { marginTop: 10, minHeight: 80, borderWidth: 1, borderColor: '#D8E3EF', borderRadius: 10, padding: 10, color: C.ink, fontSize: 14, textAlignVertical: 'top' },
});
