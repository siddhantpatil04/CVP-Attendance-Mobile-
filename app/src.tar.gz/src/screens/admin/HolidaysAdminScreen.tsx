import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import LeavePolicyCard from '../../components/LeavePolicyCard';
import { holidayMonths } from '../../lib/holidayMonths';
import { Dropdown, PickerField } from '../../components/Pickers';
import { Banner, Button, Card, Chips, Col, Empty, Field, ListItem, Pill, Row, Screen, SectionTitle, Segmented } from '../../components/ui';
import { api, EmployeeHoliday, Holiday, Profile } from '../../lib/api';
import { useIsDesktop } from '../../lib/layout';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtISODate, istDateISO } from '../../lib/time';
import { C } from '../../theme';

type Cat = 'Site' | 'Office';
const CAT_LABEL: Record<Cat, string> = { Site: 'Site Employees', Office: 'Office Employees' };
const inCat = (p: Profile, c: Cat) => (c === 'Site' ? !!p.site_employee : !p.site_employee);

/** One line of the holiday table: an old company-wide holiday or a Site / Office holiday */
interface Line { key: string; day: string; name: string; category: string; type: 'Paid' | 'Unpaid'; selected: string; legacy?: Holiday; e?: EmployeeHoliday }

/**
 * Holiday Setup (Admin / HR).
 *  - Holiday List : every holiday in one table (date, name, employee category, type, selected employees, edit / delete)
 *  - Add Holiday  : category (Site / Office), date, name, Paid / Unpaid, all employees of the category or selected employees
 *  - All Employees: the original company-wide holiday (applies to everybody, paid)
 */
export default function HolidaysAdminScreen() {
  const desktop = useIsDesktop();
  const [tab, setTab] = useState<'list' | 'new' | 'company'>('list');
  const [rows, setRows] = useState<Holiday[]>([]);
  const [special, setSpecial] = useState<EmployeeHoliday[]>([]);
  const [people, setPeople] = useState<Profile[]>([]);
  const [month, setMonth] = useState(-1); // -1 = list hidden, 0 = all holidays, n = the n-th month
  const [emp, setEmp] = useState(0);        // 0 = all employees, n = only the holidays of the n-th employee

  // company-wide form (as before)
  const [day, setDay] = useState(istDateISO());
  const [name, setName] = useState('');
  const [kind, setKind] = useState<'General' | 'Restricted'>('General');
  const [busy, setBusy] = useState(false);

  // Site / Office holiday form
  const [editId, setEditId] = useState<number | null>(null);
  const [cat, setCat] = useState<Cat>('Site');
  const [hDay, setHDay] = useState(istDateISO());
  const [hName, setHName] = useState('');
  const [hType, setHType] = useState<'Paid' | 'Unpaid'>('Paid');
  const [pick, setPick] = useState(0);                 // 0 = all employees of the category, 1 = selected employees
  const [chosen, setChosen] = useState<string[]>([]);
  const [q, setQ] = useState('');
  const [setup, setSetup] = useState(false);

  const load = useCallback(async () => {
    try {
      const [h, e, p] = await Promise.all([api.allHolidays(), api.employeeHolidays(), api.allProfiles()]);
      setRows(h); setSpecial(e); setPeople(p.filter((x) => x.active && x.role !== 'Admin'));
      setSetup(false);
    } catch (err) { Alert.alert('Could not load', errorText(err)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('holidays-admin', [{ table: 'holidays' }, { table: 'employee_holidays' }, { table: 'employee_holiday_users' }], () => load());

  const nameOf = useMemo(() => new Map(people.map((p) => [p.id, p.full_name])), [people]);
  const catPeople = useMemo(() => people.filter((p) => inCat(p, cat)), [people, cat]);
  const shownPeople = catPeople.filter((p) => !q.trim() || `${p.full_name} ${p.username}`.toLowerCase().includes(q.trim().toLowerCase()));

  const lines: Line[] = useMemo(() => {
    const old: Line[] = rows.map((h) => ({ key: `c${h.day}`, day: h.day, name: h.name, category: 'All Employees', type: 'Paid', selected: 'All employees (company holiday)', legacy: h }));
    const neu: Line[] = special.map((e) => {
      const n = people.filter((p) => inCat(p, e.category)).length;
      const names = e.user_ids.map((id) => nameOf.get(id) ?? 'Former employee');
      return {
        key: `e${e.id}`, day: e.day, name: e.name, category: CAT_LABEL[e.category], type: e.holiday_type, e,
        selected: e.all_employees ? `All ${CAT_LABEL[e.category].toLowerCase()} (${n})`
          : `${names.slice(0, 3).join(', ')}${names.length > 3 ? ` +${names.length - 3} more` : ''} (${names.length})`,
      };
    });
    return [...old, ...neu].sort((a, b) => b.day.localeCompare(a.day));
  }, [rows, special, people, nameOf]);
  const months = holidayMonths(lines);
  const empPerson = emp > 0 ? people[emp - 1] : undefined;
  // a holiday applies to the chosen employee: company holiday, his whole category, or he is in the selected list
  const appliesTo = (l: Line, p: Profile) => !l.e || (l.e.all_employees ? inCat(p, l.e.category) : l.e.user_ids.includes(p.id));
  const byMonth = month > 0 ? lines.filter((l) => l.day.startsWith(months[month - 1]?.key ?? '')) : lines;
  const shownLines = empPerson ? byMonth.filter((l) => appliesTo(l, empPerson)) : byMonth;
  // ---- company-wide holiday (as before)
  const save = async () => {
    if (!name.trim()) return Alert.alert('Enter holiday name.');
    setBusy(true);
    try {
      const exists = rows.some((r) => r.day === day);
      await api.saveHoliday({ day, name: name.trim(), kind });
      Alert.alert(exists ? 'Holiday updated' : 'Holiday created');
      setName(''); setTab('list'); await load();
    } catch (e) { Alert.alert('Could not save', errorText(e)); } finally { setBusy(false); }
  };
  const removeCompany = (h: Holiday) => Alert.alert('Delete holiday?', `${h.name} - ${fmtISODate(h.day)}`, [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Delete', style: 'destructive', onPress: async () => {
      try { await api.deleteHoliday(h.day); setName(''); setTab('list'); await load(); } catch (e) { Alert.alert('Error', errorText(e)); }
    } },
  ]);

  // ---- Site / Office holiday
  const resetForm = () => { setEditId(null); setCat('Site'); setHDay(istDateISO()); setHName(''); setHType('Paid'); setPick(0); setChosen([]); setQ(''); };
  const openNew = () => { resetForm(); setTab('new'); };
  // quick: give a Paid / Unpaid holiday to the employee chosen in the list
  const openNewFor = (p: Profile) => { resetForm(); setCat(p.site_employee ? 'Site' : 'Office'); setPick(1); setChosen([p.id]); setTab('new'); };  const openEdit = (e: EmployeeHoliday) => {
    setEditId(e.id); setCat(e.category); setHDay(e.day); setHName(e.name); setHType(e.holiday_type);
    setPick(e.all_employees ? 0 : 1); setChosen(e.user_ids); setQ(''); setTab('new');
  };
  const saveSpecial = async () => {
    if (!hName.trim()) return Alert.alert('Enter the holiday name.');
    if (pick === 1 && chosen.length === 0) return Alert.alert('Select at least one employee, or choose all employees.');
    setBusy(true);
    try {
      await api.saveEmployeeHoliday({ id: editId ?? undefined, day: hDay, name: hName.trim(), category: cat, type: hType, all: pick === 0, userIds: chosen });
      Alert.alert(editId ? 'Holiday updated' : 'Holiday created', 'It is applied to attendance and payroll of the selected employees.');
      resetForm(); setTab('list'); await load();
    } catch (e) { Alert.alert('Could not save', errorText(e)); } finally { setBusy(false); }
  };
  const removeSpecial = (e: EmployeeHoliday) => Alert.alert('Delete holiday?', `${e.name} - ${fmtISODate(e.day)}`, [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Delete', style: 'destructive', onPress: async () => {
      try { await api.deleteEmployeeHoliday(e.id); resetForm(); setTab('list'); await load(); } catch (err) { Alert.alert('Error', errorText(err)); }
    } },
  ]);
  const toggle = (id: string) => setChosen((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id]));

  const editLine = (l: Line) => { if (l.e) openEdit(l.e); else if (l.legacy) { setDay(l.legacy.day); setName(l.legacy.name); setKind(l.legacy.kind); setTab('company'); } };
  const deleteLine = (l: Line) => { if (l.e) removeSpecial(l.e); else if (l.legacy) removeCompany(l.legacy); };

  return (
    <Screen>
      <Segmented value={tab} onChange={(t) => { if (t === 'new' && tab !== 'new') resetForm(); setTab(t); }} options={[
        { value: 'list', label: 'Holiday List' }, { value: 'new', label: 'Add Holiday' },
      ]} />

      {tab === 'new' ? (
        <Card>
          <Text style={st.title}>{editId ? 'Edit holiday' : 'Add holiday'}</Text>
          {setup ? <Banner tone="amber" text="Run supabase/holiday_setup.sql in the Supabase SQL Editor first." /> : null}
          <Text style={st.label}>Employee category</Text>
          <Dropdown width="100%" value={cat === 'Site' ? 0 : 1} onChange={(v) => { setCat(v === 0 ? 'Site' : 'Office'); setChosen([]); }}
            options={[{ value: 0, label: 'Site Employees' }, { value: 1, label: 'Office Employees' }]} />
          <Row style={{ alignItems: 'flex-start', marginTop: 10 }}>
            <Col><PickerField label="Holiday date" mode="date" value={hDay} onChange={setHDay} /></Col>
            <Col><Field label="Holiday name" value={hName} onChangeText={setHName} placeholder="e.g. Site shutdown day" /></Col>
          </Row>
          <Text style={st.label}>Holiday type</Text>
          <Dropdown width="100%" value={hType === 'Paid' ? 0 : 1} onChange={(v) => setHType(v === 0 ? 'Paid' : 'Unpaid')}
            options={[{ value: 0, label: 'Paid' }, { value: 1, label: 'Unpaid' }]} />
          <Text style={st.hint}>{hType === 'Paid' ? 'Paid: a normal holiday. No absence and no salary deduction.' : 'Unpaid: no absence mark, but the salary of that day is deducted in payroll.'}</Text>
          <Text style={st.label}>Employee selection</Text>
          <Dropdown width="100%" value={pick} onChange={setPick}
            options={[{ value: 0, label: `All ${CAT_LABEL[cat]} (${catPeople.length})` }, { value: 1, label: 'Select employees' }]} />
          {pick === 1 ? (
            <View style={{ marginTop: 8 }}>
              <Field placeholder={`Search ${CAT_LABEL[cat].toLowerCase()}`} value={q} onChangeText={setQ} />
              <Row style={{ marginBottom: 6 }} gap={8}>
                <Button title="Select all shown" variant="secondary" small onPress={() => setChosen(Array.from(new Set([...chosen, ...shownPeople.map((p) => p.id)])))} />
                <Button title="Clear" variant="secondary" small onPress={() => setChosen([])} />
                <Text style={st.hint}>{chosen.length} selected</Text>
              </Row>
              <View style={st.pickBox}>
                {shownPeople.length === 0 ? <Empty text={`No ${CAT_LABEL[cat].toLowerCase()} found.`} icon="people-outline" /> : shownPeople.map((p) => {
                  const on = chosen.includes(p.id);
                  return (
                    <Pressable key={p.id} onPress={() => toggle(p.id)} style={st.pickRow}>
                      <Ionicons name={on ? 'checkbox' : 'square-outline'} size={20} color={on ? C.blue : '#8A9BB0'} />
                      <View style={{ flex: 1 }}>
                        <Text style={st.pickName}>{p.full_name}</Text>
                        <Text style={st.hint}>{p.username}{p.department ? ` - ${p.department}` : ''}</Text>
                      </View>
                    </Pressable>
                  );
                })}
              </View>
            </View>
          ) : null}
          <Button title={editId ? 'Update Holiday' : 'Save Holiday'} icon="save-outline" loading={busy} onPress={saveSpecial} style={{ marginTop: 12 }} />
          {editId ? (
            <Button title="Delete Holiday" icon="trash-outline" variant="danger" style={{ marginTop: 8 }}
              onPress={() => { const e = special.find((x) => x.id === editId); if (e) removeSpecial(e); }} />
          ) : null}
          <Button title="Cancel" variant="ghost" style={{ marginTop: 4 }} onPress={() => { resetForm(); setTab('list'); }} />
        </Card>
      ) : tab === 'company' ? (
        <Card>
          <Text style={st.title}>Holiday for all employees</Text>
          <Text style={st.hint}>A company holiday: it applies to every employee and is always paid. For Site or Office employees, or for selected employees, use Add Holiday.</Text>
          <Row style={{ alignItems: 'flex-start', marginTop: 8 }}>
            <Col><PickerField label="Holiday date" mode="date" value={day} onChange={setDay} /></Col>
            <Col><Field label="Holiday name" value={name} onChangeText={setName} placeholder="e.g. Diwali" /></Col>
          </Row>
          <Chips<'General' | 'Restricted'> options={['General', 'Restricted']} value={kind} onChange={setKind} />
          <Button title="Save Holiday" icon="save-outline" loading={busy} onPress={save} />
          {rows.some((r) => r.day === day) ? (
            <Button title="Delete Holiday" icon="trash-outline" variant="danger" style={{ marginTop: 8 }}
              onPress={() => removeCompany(rows.find((r) => r.day === day)!)} />
          ) : null}
        </Card>
      ) : (
        <>
          <Row style={{ justifyContent: 'space-between', flexWrap: 'wrap' }}>
            <View style={{ flex: 1, minWidth: 180 }}><SectionTitle title={`${lines.length} published`} note="Add, edit or delete holidays. They apply only to the employees shown." /></View>
            <Button title="Add Holiday" icon="add-circle-outline" small onPress={openNew} />
          </Row>
          {lines.length > 0 ? (
            <View style={{ marginBottom: 10, gap: 8 }}>
              <Dropdown width="100%" value={month} onChange={setMonth}
                options={[{ value: -1, label: 'Select month' }, { value: 0, label: `All (${lines.length})` },
                  ...months.map((m, i) => ({ value: i + 1, label: m.label }))]} />
              <Dropdown width="100%" value={emp} onChange={setEmp}
                options={[{ value: 0, label: `All employees (${people.length})` },
                  ...people.map((p, i) => ({ value: i + 1, label: `${p.full_name} - ${p.site_employee ? 'Site' : 'Office'}` }))]} />
              {empPerson ? (
                <Row gap={8} style={{ alignItems: 'center', flexWrap: 'wrap' }}>
                  <Text style={st.hint}>Holidays of {empPerson.full_name}: {shownLines.length}</Text>
                  <Button title={`Give Paid / Unpaid holiday to ${empPerson.full_name.split(' ')[0]}`} icon="add-circle-outline" variant="secondary" small onPress={() => openNewFor(empPerson)} />
                </Row>
              ) : null}
            </View>
          ) : null}
          <Card style={{ padding: 0, overflow: 'hidden', display: month < 0 && emp === 0 && lines.length > 0 ? 'none' : 'flex' }}>
            {desktop && shownLines.length > 0 ? (
              <View style={st.hd}>
                {[['HOLIDAY DATE', 1.2], ['HOLIDAY NAME', 1.8], ['EMPLOYEE CATEGORY', 1.4], ['HOLIDAY TYPE', 1], ['SELECTED EMPLOYEES', 2.4], ['ACTIONS', 1.4]].map(([t, f]) => (
                  <Text key={String(t)} style={[st.hdText, { flex: Number(f) }]}>{t}</Text>))}
              </View>
            ) : null}
            {lines.length === 0 ? <Empty text="No holidays have been published yet." icon="calendar-outline" /> : shownLines.map((l) => desktop ? (
              <View key={l.key} style={st.tr}>
                <Text style={[st.cell, { flex: 1.2 }]}>{fmtISODate(l.day)}</Text>
                <Text style={[st.name, { flex: 1.8 }]}>{l.name}</Text>
                <Text style={[st.cell, { flex: 1.4 }]}>{l.category}</Text>
                <View style={{ flex: 1, alignItems: 'flex-start' }}><Pill text={l.type} tone={l.type === 'Paid' ? 'green' : 'amber'} /></View>
                <Text style={[st.cell, { flex: 2.4 }]}>{l.selected}</Text>
                <Row style={{ flex: 1.4, justifyContent: 'flex-end' }} gap={6}>
                  <Button title="Edit" icon="create-outline" variant="secondary" small onPress={() => editLine(l)} />
                  <Button title="Delete" icon="trash-outline" variant="danger" small onPress={() => deleteLine(l)} />
                </Row>
              </View>
            ) : (
              <View key={l.key} style={st.trM}>
                <ListItem icon="calendar-outline" title={l.name} subtitle={`${fmtISODate(l.day)} - ${l.category}\n${l.selected}`}
                  right={<Pill text={l.type} tone={l.type === 'Paid' ? 'green' : 'amber'} />} onPress={() => editLine(l)} />
                <Row gap={6} style={{ paddingHorizontal: 12, paddingBottom: 8 }}>
                  <Button title="Edit" icon="create-outline" variant="secondary" small onPress={() => editLine(l)} />
                  <Button title="Delete" icon="trash-outline" variant="danger" small onPress={() => deleteLine(l)} />
                </Row>
              </View>
            ))}
          </Card>
        </>
      )}

      <LeavePolicyCard />
    </Screen>
  );
}

const st = StyleSheet.create({
  title: { fontWeight: '800', fontSize: 16, color: C.ink, marginBottom: 6 },
  label: { fontSize: 12, fontWeight: '800', color: '#6B7C93', marginTop: 10, marginBottom: 4 },
  hint: { fontSize: 12, color: C.muted, marginTop: 4 },
  hd: { flexDirection: 'row', paddingHorizontal: 14, paddingVertical: 10, backgroundColor: '#FAFCFE', borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  hdText: { fontSize: 11, fontWeight: '800', color: '#8594A6', letterSpacing: 0.4 },
  tr: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  trM: { borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  name: { fontWeight: '800', color: '#102944', fontSize: 13 },
  cell: { fontWeight: '700', color: '#203951', fontSize: 12.5 },
  pickBox: { maxHeight: 260, borderWidth: 1, borderColor: '#E4EDF6', borderRadius: 10, overflow: 'hidden' },
  pickRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 10, paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  pickName: { fontWeight: '700', color: '#17314D', fontSize: 13 },
});
