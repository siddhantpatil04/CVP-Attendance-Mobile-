﻿import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert } from 'react-native';
import { Banner, Loading, LiveDot, Row, Screen, SectionTitle } from '../../components/ui';
import { TeamAttendance } from '../../components/TeamAttendance';
import { api, BoardRow } from '../../lib/api';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtDateLong } from '../../lib/time';

/** Admin / HR page (More section): today's team attendance, live */
export default function TeamAttendanceScreen() {
  const [board, setBoard] = useState<BoardRow[] | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try { setBoard(await api.board()); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  const live = useRealtime('team-attendance', [
    { table: 'attendance' }, { table: 'leaves' }, { table: 'profiles' },
  ], () => load());

  if (!board) return <Loading />;
  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      <Row style={{ justifyContent: 'space-between', marginBottom: 4 }}>
        <SectionTitle title="Today's team attendance" note={`${fmtDateLong()} - updates instantly when anyone checks in or out`} />
        <LiveDot live={live} />
      </Row>
      <TeamAttendance board={board} />
    </Screen>
  );
}

