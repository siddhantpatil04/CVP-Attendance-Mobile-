import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { PickerField } from '../../components/Pickers';
import { Banner, Button, Card, Dropdown, Field, Loading } from '../../components/ui';
import { checkAll, FormulaItem, RESERVED_CODES, STARTING_ITEMS } from '../../lib/salaryEngine';
import { clearFormulaCache, formulasForMonth, salaryFormulasApi } from '../../lib/salaryFormulas';
import { errorText } from '../../lib/supabase';
import { istParts, MONTHS } from '../../lib/time';
import { C } from '../../theme';

const monthLabel = (iso: string) => `${MONTHS[Number(iso.slice(5, 7)) - 1]} ${iso.slice(0, 4)}`;
const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;
const firstOf = (y: number, m: number) => `${y}-${String(m).padStart(2, '0')}-01`;
const inr = (v: number) => `Rs ${Number(v).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
const confirmBox = (title: string, msg: string, yes: string, onYes: () => void) => {
  if (Platform.OS === 'web') { if (typeof window !== 'undefined' && window.confirm(`${title}\n\n${msg}`)) onYes(); }
  else Alert.alert(title, msg, [{ text: 'Back', style: 'cancel' }, { text: yes, onPress: onYes }]);
};
const codeFor = (name: string, used: string[]): string => {
  let c = name.toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 16) || 'ADDED';
  if (c.length < 2 || RESERVED_CODES.has(c)) c = `X_${c}`.slice(0, 18);
  const base = c; let k = 2;
  while (used.includes(c)) c = `${base.slice(0, 14)}_${k++}`;
  return c;
};

/** Salary Management > Salary Formulas (Admin): one row per salary item with its formula, and "Apply from" + Save. */
export default function SalaryFormulasTab() {
  const now = istParts();
  const [base, setBase] = useState<FormulaItem[] | null>(null);      // the formulas in use now
  const [fromDb, setFromDb] = useState(true);
  const [items, setItems] = useState<FormulaItem[]>(STARTING_ITEMS.map((x) => ({ ...x })));
  const [lastFin, setLastFin] = useState<{ year: number; month: number } | null | undefined>(undefined);
  const [from, setFrom] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    formulasForMonth(now.year, now.month).then((m) => { setBase(m.items); setItems(m.items.map((x) => ({ ...x }))); setFromDb(m.fromDatabase); });
    salaryFormulasApi.lastFinalized().then(setLastFin).catch(() => setLastFin(null));
  }, []);   // eslint-disable-line react-hooks/exhaustive-deps

  // "Apply from": a calendar date. Whatever day is picked becomes the 1st of that month, and it must be after the last finalized month.
  const minFrom = useMemo(() => {
    if (!lastFin) return firstOf(now.year, now.month);
    return lastFin.month === 12 ? firstOf(lastFin.year + 1, 1) : firstOf(lastFin.year, lastFin.month + 1);
  }, [lastFin, now.year, now.month]);
  useEffect(() => {
    if (from || lastFin === undefined) return;
    const next = now.month === 12 ? firstOf(now.year + 1, 1) : firstOf(now.year, now.month + 1);
    setFrom(next < minFrom ? minFrom : next);   // default: next month
  }, [lastFin, minFrom, from]);   // eslint-disable-line react-hooks/exhaustive-deps
  const pickFrom = (iso: string) => {
    const first = `${iso.slice(0, 8)}01`;
    if (first < minFrom) { Alert.alert('Choose a later month', `${monthLabel(minFrom)} or later: months up to the last finalized month cannot change.`); return; }
    setFrom(first);
  };
  const errors = useMemo(() => checkAll(items), [items]);
  const nameErrs = items.map((f) => (f.type !== 'builtin' && !f.name.trim() ? 'Enter the name' : null));
  const invalid = errors.some(Boolean) || nameErrs.some(Boolean);
  const changedAt = (f: FormulaItem) => !base || base.find((b) => b.code === f.code)?.formula !== f.formula;
  const anyChange = !!base && (items.length !== base.length || items.some(changedAt));

  const setFormula = (i: number, v: string) => setItems((l) => l.map((x, j) => (j === i ? { ...x, formula: v } : x)));
  const addRow = () => setItems((l) => [...l, { code: codeFor(`NEW ${l.length - 5}`, l.map((x) => x.code)), name: '', type: 'earning', formula: '' }]);
  const rename = (i: number, name: string) => setItems((l) => l.map((x, j) => {
    if (j !== i) return x;
    const code = codeFor(name || 'NEW', l.filter((_, k) => k !== i).map((y) => y.code));
    return { ...x, name, code: name.trim() ? code : x.code };
  }));

  const save = () => {
    if (!from) return Alert.alert('Choose the Apply from month');
    if (invalid) return Alert.alert('Check the formulas', 'A formula is wrong (red box).');
    if (!anyChange) return Alert.alert('Nothing changed', 'Change a formula first.');
    confirmBox('Save the new formulas?', `From the ${monthLabel(from)} salary (${dmy(from)}), all employees' salary, slips, wage register and bank report will use the new formulas. Older months stay as they are.`, 'Yes, save', async () => {
      setSaving(true);
      try {
        await salaryFormulasApi.save(from, items.map((f) => ({ ...f, name: f.name.trim() || f.name, formula: f.formula.trim() })));
        clearFormulaCache();
        Alert.alert('Saved', `The new formulas apply from ${monthLabel(from)}.`);
        const m = await formulasForMonth(now.year, now.month); setBase(m.items); setFromDb(m.fromDatabase);
      } catch (e) { Alert.alert('Could not save', errorText(e)); } finally { setSaving(false); }
    });
  };

  if (!base) return <Loading />;
  return (
    <View style={{ gap: 12 }}>
      {!fromDb ? <Banner tone="amber" text="Showing today's formulas. To save changes, run supabase/salary_formulas.sql in the Supabase SQL Editor, then: notify pgrst, 'reload schema';" /> : null}

      <Card>
        <View style={st.between}>
          <Text style={st.h}>Salary formulas</Text>
          <Button title="+ Add formula" variant="secondary" small onPress={addRow} />
        </View>
        {items.map((f, i) => {
          const err = errors[i] || nameErrs[i];
          const edited = changedAt(f);
          const added = f.type !== 'builtin';
          return (
            <View key={f.code} style={st.row}>
              <View style={st.nameCol}>
                {added ? (
                  <>
                    <Field label="Name" value={f.name} onChangeText={(v) => rename(i, v)} placeholder="e.g. Conveyance allowance" />
                    <Dropdown<string> options={['Earning (adds to salary)', 'Deduction (cuts from salary)']} value={f.type === 'earning' ? 'Earning (adds to salary)' : 'Deduction (cuts from salary)'}
                      onChange={(v) => setItems((l) => l.map((x, j) => (j === i ? { ...x, type: v.startsWith('Earning') ? 'earning' : 'deduction' } : x)))} />
                    <Text style={st.code}>use as {f.code}</Text>
                  </>
                ) : <Text style={st.name}>{f.name}</Text>}
              </View>
              <View style={{ flex: 1, minWidth: 260 }}>
                <Field value={f.formula} onChangeText={(v) => setFormula(i, v)} autoCapitalize="characters" multiline
                  placeholder="e.g. ROUND(1600 * PAID_DAYS / MONTH_DAYS)"
                  style={[{ minHeight: added ? 96 : 44, fontFamily: Platform.OS === 'web' ? 'monospace' : undefined }, edited && { borderColor: '#E8A400', backgroundColor: '#FFF8E6' }, err ? { borderColor: '#D14343', backgroundColor: '#FFF1F1' } : null]} />
                {err ? <Text style={st.err}>{err}</Text> : edited && base.find((b) => b.code === f.code) ? <Text style={st.was}>was {base.find((b) => b.code === f.code)!.formula}</Text> : null}
              </View>
              {added ? <Button title="Remove" variant="danger" small onPress={() => setItems((l) => l.filter((_, j) => j !== i))} /> : null}
            </View>
          );
        })}

        <View style={st.save}>
          <View style={{ width: 170 }}>
            <PickerField flat compact label="Apply from *" mode="date" value={from || minFrom} minimumDate={new Date(`${minFrom}T12:00:00`)} onChange={pickFrom} />
          </View>
          <Button title="Save" icon="save-outline" small loading={saving} disabled={invalid || !anyChange || !fromDb} onPress={save} style={{ minWidth: 100 }} />
        </View>
      </Card>

    </View>
  );
}
const st = StyleSheet.create({
  h: { fontSize: 16, fontWeight: '800', color: C.ink },
  sub: { fontSize: 12.5, color: C.muted, marginTop: 4, marginBottom: 6 },
  between: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, flexWrap: 'wrap', paddingVertical: 6, borderTopWidth: 1, borderTopColor: '#EEF3F8' },
  nameCol: { width: 170 },
  name: { fontWeight: '800', color: '#102A45', fontSize: 14 },
  code: { fontSize: 11.5, color: C.muted, fontWeight: '700' },
  err: { color: '#D14343', fontWeight: '700', fontSize: 12.5, marginTop: -2 },
  was: { color: '#9A5B00', fontWeight: '700', fontSize: 11.5, marginTop: -2 },
  lbl: { fontSize: 11.5, fontWeight: '800', color: '#5A6F86', letterSpacing: 0.4, marginBottom: 6 },
  save: { flexDirection: 'row', alignItems: 'flex-end', gap: 12, flexWrap: 'wrap', borderTopWidth: 1, borderTopColor: '#EEF3F8', paddingTop: 12, marginTop: 6 },
});
