import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import LocationMap from '../../components/GoogleLiveMap';
import MapFilterDropdown, { DDGroup, DDRow } from '../../components/MapFilterDropdown';
import { siteArea } from '../../components/SiteDropdown';
import { CTRL_H, PickerField } from '../../components/Pickers';
import { Avatar, Banner, Button, LiveDot, Screen } from '../../components/ui';
import { api, BoardRow, LiveLocation, MapDot, MapLine, MapPoint, MapSite, Site } from '../../lib/api';
import { distanceM, fmtDistance } from '../../lib/geo';
import { useIsDesktop } from '../../lib/layout';
import { useRealtime, useTicker } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtMinutes, fmtTime12, istDateISO } from '../../lib/time';
import { C } from '../../theme';

const GREEN = '#16A34A', PURPLE = '#7C3AED', BLUE = '#2563EB', RED = '#DC2626', AMBER = '#F59E0B', GREY = '#94A3B8';

type Key = 'date' | 'kind' | 'site' | 'semp' | 'office' | 'oemp';
interface Saved { kindSel?: 'site' | 'office' | null; date?: string; siteSel?: number; semp?: string | null; officeSel?: number; oemp?: string | null }
const STORE = 'cvp.livemap.filters.v1';
const readSaved = (): Saved => { try { const s = (globalThis as any).localStorage?.getItem(STORE); return s ? JSON.parse(s) : {}; } catch { return {}; } };

const initials = (n: string) => n.split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]?.toUpperCase()).join('');
const lc = (s: string | null | undefined) => (s ?? '').trim().toLowerCase();

/** Live Map: Date | Work site | Site employees | Office location | Office employees (Admin / HR) */
export default function LiveMapScreen() {
  const desktop = useIsDesktop();
  const today = istDateISO();
  // an older saved selection without the new Site / Office step is ignored (only the date is kept)
  const saved = useMemo<Saved>(() => { const s = readSaved(); return s.kindSel ? s : { date: s.date }; }, []);
  const [date, setDate] = useState(saved.date ?? today);
  const [kindSel, setKindSel] = useState<'site' | 'office' | null>(saved.kindSel ?? null);   // 1st step: Site employees or Office employees
  const [siteSel, setSiteSel] = useState(saved.siteSel ?? 0);          // 0 = all sites, else a work site id
  const [semp, setSemp] = useState<string | null>(saved.semp ?? null);  // a site employee (user id)
  const [officeSel, setOfficeSel] = useState(saved.officeSel ?? 0);    // 0 = all office locations, else an office id
  const [oemp, setOemp] = useState<string | null>(saved.oemp ?? null); // an office employee (user id)
  const [openKey, setOpenKey] = useState<Key | null>(null);

  const [points, setPoints] = useState<MapPoint[] | null>(null);
  const [sites, setSites] = useState<Site[]>([]);
  const [board, setBoard] = useState<BoardRow[]>([]);
  const [liveRows, setLive] = useState<LiveLocation[]>([]);
  const [tracks, setTracks] = useState<Record<string, [number, number][]>>({});
  const [access, setAccess] = useState<{ user_id: string; site_id: number }[]>([]);
  const [ranges, setRanges] = useState({ site: 500, office: 500 });
  const [liveReady, setLiveReady] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // the selected filters stay when the page is refreshed
  useEffect(() => {
    try { (globalThis as any).localStorage?.setItem(STORE, JSON.stringify({ kindSel, date, siteSel, semp, officeSel, oemp } as Saved)); } catch { /* ignore */ }
  }, [kindSel, date, siteSel, semp, officeSel, oemp]);

  const load = useCallback(async () => {
    try {
      let liveOk = true;
      const [p, s, b, a, ll] = await Promise.all([
        api.mapPoints(date, date), api.sites(false), api.board(date),
        api.siteAccess().catch(() => []),
        api.liveLocations().catch(() => { liveOk = false; return [] as LiveLocation[]; }),
      ]);
      setLiveReady(liveOk);
      setLive(ll);
      setTracks(await api.liveTracks(ll.map((l) => l.user_id)).catch(() => ({})));
      setPoints(p); setSites(s); setBoard(b); setAccess(a);
      api.workingRules().then((rs) => setRanges({
        site: rs.find((r) => r.kind === 'site')?.range_m ?? 500, office: rs.find((r) => r.kind === 'office')?.range_m ?? 500,
      })).catch(() => undefined);
    } catch (e) {
      Alert.alert('Could not load map', errorText(e));
    }
  }, [date]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  const live = useRealtime('livemap', [{ table: 'attendance' }, { table: 'sites' }, { table: 'live_locations' }], () => load());
  const tickNow = useTicker(30000);
  // live pins refresh by themselves every 45 seconds (today only)
  useEffect(() => {
    if (date !== today) return;
    const id = setInterval(() => { load(); }, 45000);
    return () => clearInterval(id);
  }, [date, today, load]);

  const refresh = async () => { if (refreshing) return; setRefreshing(true); try { await load(); } finally { setRefreshing(false); } };

  // ------------------------------------------------------------------ data
  const liveOn = date === today;
  const liveMap = useMemo(() => new Map((liveOn ? liveRows : []).map((l) => [l.user_id, l])), [liveRows, liveOn]);
  const siteList = useMemo(() => sites.filter((s) => s.active && !s.is_office), [sites]);
  const officeList = useMemo(() => sites.filter((s) => s.active && s.is_office), [sites]);
  const byName = useMemo(() => new Map(sites.map((s) => [lc(s.name), s])), [sites]);
  const place = (r: BoardRow) => lc(r.site_name);
  const countAt = (name: string) => board.filter((r) => r.check_in_at && place(r) === lc(name)).length;
  const assigned = (uid: string, siteId: number) => access.some((a) => a.user_id === uid && a.site_id === siteId);
  const siteEmps = useMemo(() => board.filter((r) => r.site_employee), [board]);
  const officeEmps = useMemo(() => board.filter((r) => !r.site_employee && r.role !== 'Admin'), [board]);
  const siteObj = siteSel > 0 ? sites.find((s) => s.id === siteSel) ?? null : null;
  const officeFilter = officeSel > 0 ? sites.find((s) => s.id === officeSel) ?? null : null;
  const sEmpRow = semp ? board.find((r) => r.user_id === semp) ?? null : null;
  const oEmpRow = oemp ? board.find((r) => r.user_id === oemp) ?? null : null;

  const siteTag = (r: BoardRow) =>
    r.leave_type ? { text: 'On leave', color: AMBER }
      : !r.check_in_at ? { text: 'Not in', color: GREY }
        : r.check_out_at ? { text: 'Checked out', color: BLUE }
          : liveMap.has(r.user_id) ? { text: 'Moving', color: BLUE } : { text: 'At site', color: GREEN };
  const siteRow = (r: BoardRow): DDRow => ({
    id: r.user_id, title: r.full_name, initials: initials(r.full_name), tag: siteTag(r),
    sub: `${r.username}${r.check_in_at ? ` - In ${fmtTime12(r.check_in_at)}` : ''}`,
  });
  const officeRow = (r: BoardRow): DDRow => ({
    id: r.user_id, title: r.full_name, initials: initials(r.full_name),
    sub: r.check_in_at ? `In ${fmtTime12(r.check_in_at)}${r.check_out_at ? ` - Out ${fmtTime12(r.check_out_at)}` : ''}` : r.username,
    tag: r.check_out_at ? { text: 'OUT', color: RED } : r.check_in_at ? { text: 'IN', color: GREEN } : r.leave_type ? { text: 'On leave', color: AMBER } : undefined,
  });

  // Work site: grouped A-Z by area, with the employee count today
  const siteGroups = useMemo<DDGroup[]>(() => {
    const m = new Map<string, Site[]>();
    for (const s of [...siteList].sort((a, b) => a.name.localeCompare(b.name))) m.set(siteArea(s.name), [...(m.get(siteArea(s.name)) ?? []), s]);
    return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]))
      .map(([area, l]) => ({ key: area, title: area, rows: l.map((s) => ({ id: String(s.id), title: s.name, count: countAt(s.name) })) }));
  }, [siteList, board]);   // eslint-disable-line react-hooks/exhaustive-deps

  // Site employees: grouped by today's site, "Not checked in" last; only the selected Work site's employees when one is chosen
  const siteEmpBase = useMemo(() => siteEmps.filter((r) => !siteObj || place(r) === lc(siteObj.name) || (!r.check_in_at && assigned(r.user_id, siteObj.id))), [siteEmps, siteObj, access]);   // eslint-disable-line react-hooks/exhaustive-deps
  const siteEmpGroups = useMemo<DDGroup[]>(() => {
    const m = new Map<string, BoardRow[]>();
    const none: BoardRow[] = [];
    for (const r of siteEmpBase) {
      if (!r.check_in_at) { none.push(r); continue; }
      const k = (r.site_name ?? 'Other').trim() || 'Other';
      m.set(k, [...(m.get(k) ?? []), r]);
    }
    const g: DDGroup[] = [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]))
      .map(([k, rows]) => ({ key: k, title: k.toUpperCase(), rows: rows.sort((a, b) => a.full_name.localeCompare(b.full_name)).map(siteRow) }));
    if (none.length) g.push({ key: '_none', title: 'NOT CHECKED IN', rows: none.sort((a, b) => a.full_name.localeCompare(b.full_name)).map(siteRow) });
    return g;
  }, [siteEmpBase, liveMap]);   // eslint-disable-line react-hooks/exhaustive-deps

  // Office location: each office with the number of people there today
  const officeGroups = useMemo<DDGroup[]>(() => [{
    key: 'offices', title: 'OFFICE LOCATIONS',
    rows: [...officeList].sort((a, b) => a.name.localeCompare(b.name)).map((s) => ({ id: String(s.id), title: s.name, count: countAt(s.name) })),
  }], [officeList, board]);   // eslint-disable-line react-hooks/exhaustive-deps

  // Office employees: "In office now" and "Not checked in"; only the selected office's employees when one is chosen
  const officeEmpBase = useMemo(() => officeEmps.filter((r) => !officeFilter || place(r) === lc(officeFilter.name) || (!r.check_in_at && assigned(r.user_id, officeFilter.id))), [officeEmps, officeFilter, access]);   // eslint-disable-line react-hooks/exhaustive-deps
  const officeEmpGroups = useMemo<DDGroup[]>(() => {
    const inn = officeEmpBase.filter((r) => r.check_in_at).sort((a, b) => a.full_name.localeCompare(b.full_name));
    const out = officeEmpBase.filter((r) => !r.check_in_at).sort((a, b) => a.full_name.localeCompare(b.full_name));
    const g: DDGroup[] = [];
    if (inn.length) g.push({ key: 'in', title: 'IN OFFICE NOW', rows: inn.map(officeRow) });
    if (out.length) g.push({ key: 'out', title: 'NOT CHECKED IN', rows: out.map(officeRow) });
    return g;
  }, [officeEmpBase]);

  // Employees dropdown (after the place): CHECK-IN / CHECK-OUT employees and FIELD SITE employees (on a visit or travelling now)
  const kindGroups = useMemo<DDGroup[]>(() => [{
    key: 'kind', title: 'EMPLOYEE TYPE',
    rows: [
      { id: 'site', title: 'Site employees', sub: `${siteEmps.length} employee(s)` },
      { id: 'office', title: 'Office employees', sub: `${officeEmps.length} employee(s)` },
    ],
  }], [siteEmps, officeEmps]);
  const empGroups = useMemo<DDGroup[]>(() => {
    if (!kindSel) return [];
    const base = kindSel === 'site' ? siteEmpBase : officeEmpBase;
    const mk = kindSel === 'site' ? siteRow : officeRow;
    const cio = base.filter((r) => r.check_in_at).sort((a, b) => a.full_name.localeCompare(b.full_name)).map(mk);
    const field = (kindSel === 'site' ? siteEmps : officeEmps).filter((r) => liveMap.has(r.user_id))
      .sort((a, b) => a.full_name.localeCompare(b.full_name))
      .map((r): DDRow => ({ id: r.user_id, title: r.full_name, initials: initials(r.full_name), sub: `${r.username} - live ${fmtTime12(liveMap.get(r.user_id)!.updated_at)}`, tag: { text: 'Field visit', color: BLUE } }));
    const g: DDGroup[] = [];
    g.push({ key: 'cio', title: 'CHECK-IN / CHECK-OUT EMPLOYEES', rows: cio });
    if (field.length) g.push({ key: 'field', title: 'FIELD SITE EMPLOYEES', rows: field });
    return g;
  }, [kindSel, siteEmpBase, officeEmpBase, siteEmps, officeEmps, liveMap]);   // eslint-disable-line react-hooks/exhaustive-deps
  // ------------------------------------------------------------------ choosing (one employee at a time)
  const pickSite = (v: number) => { setSiteSel(v); setSemp(null); };
  const pickSemp = (id: string | null) => {
    setSemp(id); setOemp(null);
    if (id) { const r = board.find((x) => x.user_id === id); const s = r ? byName.get(place(r)) : undefined; if (s && !s.is_office) setSiteSel(s.id); }
  };
  const pickOffice = (v: number) => { setOfficeSel(v); setOemp(null); };
  const pickOemp = (id: string | null) => {
    setOemp(id); setSemp(null);
    if (id) { const r = board.find((x) => x.user_id === id); const s = r ? byName.get(place(r)) : undefined; if (s?.is_office) setOfficeSel(s.id); }
  };
  // 1st dropdown: Site or Office employees. The other side's choices are cleared.
  const pickKind = (k: 'site' | 'office' | null) => {
    setKindSel(k); setSemp(null); setOemp(null);
    if (k !== 'site') setSiteSel(0);
    if (k !== 'office') setOfficeSel(0);
  };
  const toggle = (k: Key) => setOpenKey((c) => (c === k ? null : k));

  // ------------------------------------------------------------------ the map
  const ago = (iso: string) => {
    const m = Math.max(0, Math.round((tickNow - new Date(iso).getTime()) / 60000));
    return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : `${Math.floor(m / 60)} h ${m % 60} min ago`;
  };
  const workedOf = (r: BoardRow) => !r.check_in_at ? '-'
    : r.check_out_at ? fmtMinutes(Math.max(0, Math.round((new Date(r.check_out_at).getTime() - new Date(r.check_in_at).getTime()) / 60000)))
      : liveOn ? fmtMinutes(Math.max(0, Math.round((tickNow - new Date(r.check_in_at).getTime()) / 60000))) : '-';
  const pt = (uid: string, kind: 'IN' | 'OUT') => (points ?? []).find((p) => p.userId === uid && p.kind === kind);

  type Card = { title: string; sub: string; tiles?: [string, string][]; note?: { text: string; tone: 'green' | 'blue' }; list?: { name: string; in: string; tag: string }[] };
  const view = useMemo(() => {
    const mapSites: MapSite[] = [];
    const dots: MapDot[] = [];
    const lines: MapLine[] = [];
    let legend: { color: string; label: string }[] = [];
    let card: Card | null = null;
    const first = (n: string) => n.split(/\s+/)[0] ?? n;

    if (sEmpRow) {
      // ONE site employee: check-in pin, live pin and the route, check-out pin
      const r = sEmpRow;
      const pin = pt(r.user_id, 'IN'), pout = pt(r.user_id, 'OUT'), lv = liveMap.get(r.user_id);
      const home = byName.get(place(r));
      if (siteObj) mapSites.push({ ...siteObj, radius_m: ranges.site, color: GREEN, circle: true, label: siteObj.name });
      if (officeFilter) mapSites.push({ ...officeFilter, radius_m: ranges.office, color: PURPLE, circle: true, label: officeFilter.name });
      if (pin) dots.push({ key: 'in', lat: pin.lat, lng: pin.lng, color: GREEN, permanent: true, label: `IN ${fmtTime12(pin.at)} - ${pin.siteName ?? r.site_name ?? ''}` });
      if (pout) dots.push({ key: 'out', lat: pout.lat, lng: pout.lng, color: PURPLE, permanent: true, label: `OUT ${fmtTime12(pout.at)}${pout.siteName ? ` - ${pout.siteName}` : ''}` });
      if (lv) dots.push({ key: 'live', lat: lv.lat, lng: lv.lng, color: BLUE, permanent: true, label: `Now ${fmtTime12(lv.updated_at)}` });
      const track = tracks[r.user_id];
      if (lv && track && track.length >= 2) lines.push({ key: 'route', color: BLUE, label: `${r.full_name} - route today`, points: track });
      else if (lv && pin) lines.push({ key: 'route', color: BLUE, label: `${r.full_name} - check-in to now`, points: [[pin.lat, pin.lng], [lv.lat, lv.lng]], dashed: true });
      legend = [{ color: GREEN, label: 'Check-in' }, { color: PURPLE, label: 'Check-out' }, { color: BLUE, label: 'Live now' }];
      card = {
        title: r.full_name, sub: `Site employee${r.site_name ? ` - ${r.site_name}` : ''}`,
        tiles: [['CHECK IN', r.check_in_at ? fmtTime12(r.check_in_at) : '-'], ['CHECK OUT', r.check_out_at ? fmtTime12(r.check_out_at) : 'Pending'], ['WORKING', workedOf(r)]],
        note: lv
          ? { tone: 'green', text: `Live location updated ${ago(lv.updated_at)}${home ? ` - ${fmtDistance(distanceM(lv.lat, lv.lng, home.lat, home.lng))} from ${home.name}` : ''}` }
          : liveOn && !r.check_out_at && r.check_in_at ? { tone: 'blue', text: 'No live location right now. It is shared only while the employee is on a field visit or travelling.' } : undefined,
      };
    } else if (oEmpRow) {
      // ONE office employee: his office check-in and check-out inside the office range circle
      const r = oEmpRow;
      const off = officeFilter ?? byName.get(place(r)) ?? null;
      const pin = pt(r.user_id, 'IN'), pout = pt(r.user_id, 'OUT');
      const dIn = off && pin ? Math.round(distanceM(pin.lat, pin.lng, off.lat, off.lng)) : null;
      const dOut = off && pout ? Math.round(distanceM(pout.lat, pout.lng, off.lat, off.lng)) : null;
      if (off) mapSites.push({ ...off, radius_m: ranges.office, color: PURPLE, circle: true, label: off.name });
      if (siteObj) mapSites.push({ ...siteObj, radius_m: ranges.site, color: GREEN, circle: true, label: siteObj.name });
      if (pin) dots.push({ key: 'in', lat: pin.lat, lng: pin.lng, color: GREEN, permanent: true, label: `IN ${fmtTime12(pin.at)}${dIn != null ? ` - ${dIn} m from office` : ''}` });
      if (pout) dots.push({ key: 'out', lat: pout.lat, lng: pout.lng, color: RED, permanent: true, label: `OUT ${fmtTime12(pout.at)}${dOut != null ? ` - ${dOut} m from office` : ''}` });
      legend = [{ color: PURPLE, label: 'Office location' }, { color: GREEN, label: 'Check-in' }, { color: RED, label: 'Check-out' }];
      const inside = (d: number | null) => d != null && d <= ranges.office;
      card = {
        title: r.full_name, sub: `Office employee${off ? ` - ${off.name}` : ''}`,
        tiles: [['CHECK IN', r.check_in_at ? fmtTime12(r.check_in_at) : '-'], ['CHECK OUT', r.check_out_at ? fmtTime12(r.check_out_at) : 'Pending'], ['WORKING', workedOf(r)]],
        note: { tone: 'blue', text: `Purple circle = office range (${ranges.office} m). ${dIn == null && dOut == null ? 'No check-in location was saved for this day.' : (dIn == null || inside(dIn)) && (dOut == null || inside(dOut)) ? (dOut != null ? 'Both check-in and check-out were inside it.' : 'The check-in was inside it.') : 'A punch was outside it.'}` },
      };
    } else if (officeFilter || siteObj) {
      // a Work site and / or an Office location chosen: the range circle(s) and EVERY employee inside them
      const places: { s: Site; rng: number; color: string; kind: string }[] = [];
      if (siteObj) places.push({ s: siteObj, rng: ranges.site, color: GREEN, kind: 'site' });
      if (officeFilter) places.push({ s: officeFilter, rng: ranges.office, color: PURPLE, kind: 'office' });
      const inside: { r: BoardRow; lat: number; lng: number; at: string; isLive: boolean; where: string }[] = [];
      const seen = new Set<string>();
      for (const r of board) {
        for (const pl of places) {
          if (seen.has(r.user_id)) break;
          const lv = liveMap.get(r.user_id), pin = pt(r.user_id, 'IN'), pout = pt(r.user_id, 'OUT');
          const near = (la: number, ln: number) => distanceM(la, ln, pl.s.lat, pl.s.lng) <= pl.rng;
          let pos: { lat: number; lng: number; at: string; isLive: boolean } | null = null;
          if (lv && near(lv.lat, lv.lng)) pos = { lat: lv.lat, lng: lv.lng, at: lv.updated_at, isLive: true };
          else if (pin && (near(pin.lat, pin.lng) || (r.check_in_at && place(r) === lc(pl.s.name)))) pos = { lat: pin.lat, lng: pin.lng, at: pin.at, isLive: false };
          else if (pout && near(pout.lat, pout.lng)) pos = { lat: pout.lat, lng: pout.lng, at: pout.at, isLive: false };
          if (pos) { inside.push({ r, ...pos, where: pl.s.name }); seen.add(r.user_id); }
        }
      }
      for (const pl of places) {
        const n = inside.filter((x) => x.where === pl.s.name).length;
        mapSites.push({ ...pl.s, radius_m: pl.rng, color: pl.color, circle: true, label: `${pl.s.name} (${n})` });
      }
      for (const x of inside) {
        dots.push({ key: `e-${x.r.user_id}`, lat: x.lat, lng: x.lng, color: BLUE, permanent: inside.length <= 8,
          label: `${first(x.r.full_name)} - ${x.isLive ? `Now ${fmtTime12(x.at)}` : `IN ${fmtTime12(x.at)}`}` });
      }
      legend = [...(siteObj ? [{ color: GREEN, label: `Site (${ranges.site} m range)` }] : []), ...(officeFilter ? [{ color: PURPLE, label: `Office (${ranges.office} m range)` }] : []), { color: BLUE, label: 'Employee' }];
      // (no side card for a site / office: the employees are the blue pins and the counts are in the circle labels)
    } else {
      // nothing selected: every site (green, with the count), every office (purple, with its range circle), people on the move (blue)
      for (const s of siteList) mapSites.push({ ...s, color: GREEN, circle: false, label: `${s.name} (${countAt(s.name)})` });
      for (const s of officeList) mapSites.push({ ...s, radius_m: ranges.office, color: PURPLE, circle: true, label: `${s.name} (${countAt(s.name)})` });
      for (const l of liveMap.values()) {
        dots.push({ key: `live-${l.user_id}`, lat: l.lat, lng: l.lng, color: BLUE, label: `${l.employee?.full_name ?? 'Employee'} - on the move - updated ${ago(l.updated_at)}` });
        const tr = tracks[l.user_id];
        if (tr && tr.length >= 2) lines.push({ key: `line-${l.user_id}`, color: BLUE, label: `${l.employee?.full_name ?? 'Employee'} - route today`, points: tr });
      }
      legend = [{ color: GREEN, label: 'Site' }, { color: PURPLE, label: 'Office' }, { color: BLUE, label: 'On the move' }];
    }
    return { mapSites, dots, lines, legend, card };
  }, [sEmpRow, oEmpRow, officeFilter, siteObj, board, points, sites, liveMap, tracks, ranges, tickNow, date]);   // eslint-disable-line react-hooks/exhaustive-deps

  // ------------------------------------------------------------------ filter bar
  const valueSite = siteSel > 0 ? siteObj?.name ?? 'Work site' : 'All sites';
  const valueSemp = sEmpRow ? sEmpRow.full_name : siteObj ? `All (${siteEmpBase.length} at this site)` : 'All site employees';
  const valueOffice = officeFilter ? officeFilter.name : 'All office locations';
  const valueOemp = oEmpRow ? oEmpRow.full_name : 'All office employees';
  const dateBox = (
    <View style={[st.dateCell, openKey === 'date' && { zIndex: 3000 }]}>
      <PickerField flat label="DATE" mode="date" value={date} onChange={(v) => { setDate(v); setOpenKey(null); }} />
    </View>
  );
  const empId = kindSel === 'site' ? semp : oemp;
  const empCount = empGroups.reduce((n, g) => n + g.rows.length, 0);
  const valueKind = kindSel === 'site' ? 'Site employees' : kindSel === 'office' ? 'Office employees' : 'Select site / office';
  const valueEmp = (kindSel === 'site' ? sEmpRow : oEmpRow)?.full_name ?? 'All employees';
  const bar = (
    <View style={[st.bar, desktop ? st.barRow : st.barGrid]}>
      {dateBox}
      <MapFilterDropdown label="SELECT SITE / OFFICE" valueText={valueKind} open={openKey === 'kind'} onToggle={() => toggle('kind')} onClose={() => setOpenKey(null)}
        allLabel="Show everything" allCount={siteEmps.length + officeEmps.length} allSelected={!kindSel} groups={kindGroups}
        selectedId={kindSel} onSelectAll={() => pickKind(null)} onSelect={(id) => pickKind(id as 'site' | 'office')}
        searchPlaceholder="Search..." active={!!kindSel} />
      {kindSel === 'site' ? (
        <MapFilterDropdown label="WORK SITE" valueText={valueSite} open={openKey === 'site'} onToggle={() => toggle('site')} onClose={() => setOpenKey(null)}
          allLabel={`All sites (${siteList.length})`} allCount={siteList.length} allSelected={siteSel === 0} groups={siteGroups}
          selectedId={siteSel > 0 ? String(siteSel) : null} onSelectAll={() => pickSite(0)} onSelect={(id) => pickSite(Number(id))}
          searchPlaceholder="Search site or area..." active={siteSel > 0} />
      ) : null}
      {kindSel === 'office' ? (
        <MapFilterDropdown label="OFFICE LOCATION" valueText={valueOffice} open={openKey === 'office'} onToggle={() => toggle('office')} onClose={() => setOpenKey(null)}
          allLabel="All office locations" allCount={officeList.length} allSelected={officeSel === 0} groups={officeGroups}
          selectedId={officeSel > 0 ? String(officeSel) : null} onSelectAll={() => pickOffice(0)} onSelect={(id) => pickOffice(Number(id))}
          searchPlaceholder="Search office..." active={officeSel > 0} />
      ) : null}
      {kindSel ? (
        <MapFilterDropdown label="EMPLOYEES" valueText={valueEmp} open={openKey === 'semp'} onToggle={() => toggle('semp')} onClose={() => setOpenKey(null)}
          allLabel="All employees" allCount={empCount} allSelected={!empId} groups={empGroups}
          selectedId={empId} onSelectAll={() => (kindSel === 'site' ? pickSemp(null) : pickOemp(null))}
          onSelect={(id) => (kindSel === 'site' ? pickSemp(id) : pickOemp(id))}
          searchPlaceholder="Search employee..." active={!!empId} />
      ) : null}
      <View style={[st.btnRow, !desktop && { width: '100%', flexBasis: '100%' as any }]}>
        <Button title="Today" variant="secondary" onPress={() => setDate(today)} style={{ height: CTRL_H, flex: desktop ? undefined : 1 }} />
        <Button title="Refresh" icon="refresh" loading={refreshing} onPress={refresh} style={{ height: CTRL_H, flex: desktop ? undefined : 1 }} />
      </View>
    </View>
  );
  const card = view.card;
  const cardView = card ? (
    <View style={[st.card, desktop ? st.cardFloat : st.cardBelow]}>
      <View style={st.cardHead}>
        <Avatar name={card.title} size={40} />
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.cardTitle} numberOfLines={1}>{card.title}</Text>
          <Text style={st.cardSub} numberOfLines={1}>{card.sub}</Text>
        </View>
      </View>
      {card.tiles ? (
        <View style={st.tiles}>
          {card.tiles.map(([k, v]) => (<View key={k} style={st.tile}><Text style={st.tileK}>{k}</Text><Text style={st.tileV} numberOfLines={1}>{v}</Text></View>))}
        </View>
      ) : null}
      {card.note ? (
        <View style={[st.note, { backgroundColor: card.note.tone === 'green' ? '#E8F7EE' : '#E8F2FF' }]}>
          <Text style={[st.noteText, { color: card.note.tone === 'green' ? '#157A4B' : '#0B5FC4' }]}>{card.note.text}</Text>
        </View>
      ) : null}
      {card.list ? (card.list.length === 0 ? <Text style={st.cardSub}>Nobody has checked in here on this date.</Text> : card.list.map((x, i) => (
        <View key={i} style={st.listRow}>
          <Avatar name={x.name} size={30} />
          <View style={{ flex: 1, minWidth: 0 }}><Text style={st.rowName} numberOfLines={1}>{x.name}</Text><Text style={st.cardSub}>{x.in}</Text></View>
          <Text style={st.rowTag}>{x.tag}</Text>
        </View>
      ))) : null}
    </View>
  ) : null;

  const pins = view.mapSites.length + view.dots.length;
  return (
    <Screen>
      <View style={st.top}>
        <Text style={st.head}>{pins} location pin(s)</Text>
        <LiveDot live={live && liveOn} />
      </View>
      {!liveReady ? (
        <Banner tone="amber" icon="warning-outline"
          text="Live tracking is not set up on this server yet, so the live (blue) pins are off. Ask the Admin to run the latest database update (supabase/update_live_location.sql)." />
      ) : null}
      {bar}
      <View style={st.mapWrap}>
        <LocationMap sites={view.mapSites} dots={view.dots} lines={view.lines} height={desktop ? 620 : 400} />
        <View style={st.legend} pointerEvents="none">
          {view.legend.map((l) => (<View key={l.label} style={st.legendItem}><View style={[st.legendDot, { backgroundColor: l.color }]} /><Text style={st.legendText}>{l.label}</Text></View>))}
        </View>
        {/* the employee / office info card (name, check-in, check-out, working, live-location note) is not shown on the map */}
      </View>
    </Screen>
  );
}

const st = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  head: { fontWeight: '800', color: C.ink, fontSize: 15 },
  bar: { position: 'relative', zIndex: 2000, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: '#E3ECF6', padding: 14, marginBottom: 12 },
  barRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 12 },
  barGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  dateCell: { flexGrow: 1, flexBasis: 150, minWidth: 140, position: 'relative' },
  btnRow: { flexDirection: 'row', gap: 10, alignItems: 'flex-end', flexGrow: 0, flexBasis: 'auto' as any },
  mapWrap: { position: 'relative', zIndex: 0, width: '100%' },
  legend: { position: 'absolute', left: 12, bottom: 12, flexDirection: 'row', flexWrap: 'wrap', gap: 6, backgroundColor: '#FFFFFF', borderRadius: 14, padding: 8, zIndex: 500 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderColor: '#E3ECF6', borderRadius: 16, paddingVertical: 5, paddingHorizontal: 10 },
  legendDot: { width: 10, height: 10, borderRadius: 5 },
  legendText: { fontSize: 12.5, fontWeight: '800', color: '#102A45' },
  card: { backgroundColor: '#FFFFFF', borderRadius: 14, padding: 14, shadowColor: '#0B2B4D', shadowOpacity: 0.16, shadowRadius: 14, shadowOffset: { width: 0, height: 6 }, elevation: 6 },
  cardFloat: { position: 'absolute', top: 12, right: 12, width: 340, zIndex: 500 },
  cardBelow: { marginTop: 12 },
  cardHead: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  cardTitle: { fontSize: 16, fontWeight: '800', color: '#102A45' },
  cardSub: { fontSize: 12.5, color: '#77889D', fontWeight: '600', marginTop: 1 },
  tiles: { flexDirection: 'row', gap: 8 },
  tile: { flex: 1, minWidth: 0, backgroundColor: '#F3F7FB', borderRadius: 10, paddingVertical: 8, paddingHorizontal: 10 },
  tileK: { fontSize: 10, fontWeight: '800', letterSpacing: 0.4, color: '#77889D' },
  tileV: { fontSize: 14, fontWeight: '800', color: '#102A45', marginTop: 2 },
  note: { borderRadius: 10, padding: 10, marginTop: 10 },
  noteText: { fontSize: 13, fontWeight: '700', lineHeight: 18 },
  listRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 7, borderTopWidth: 1, borderTopColor: '#EEF3F8' },
  rowName: { fontSize: 14, fontWeight: '800', color: '#102A45' },
  rowTag: { fontSize: 12.5, fontWeight: '800', color: '#102A45' },
});
