import { useFocusEffect, useNavigation } from '@react-navigation/native';
import React, { useCallback, useRef, useState } from 'react';
import { Alert, Animated, StyleSheet, Text, View } from 'react-native';
import {
  Banner, Button, Card, Hero, Kpi, KpiGrid, LiveDot, Loading, Row, Screen, SectionTitle,
} from '../../components/ui';
import { TeamAttendance } from '../../components/TeamAttendance';
import { AdminStats, api, AttendanceRow, BoardRow } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtDateLong, fmtTime12 } from '../../lib/time';
import { C } from '../../theme';

export default function LiveDashboardScreen() {
  const { profile, isFullAdmin } = useAuth();
  const nav = useNavigation<any>();
  const [board, setBoard] = useState<BoardRow[] | null>(null);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [event, setEvent] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const flash = useRef(new Animated.Value(0)).current;
  const boardRef = useRef<BoardRow[]>([]);

  const load = useCallback(async () => {
    try {
      const [b, s] = await Promise.all([api.board(), api.stats()]);
      setBoard(b);
      boardRef.current = b;
      setStats(s);
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  // ---- REAL-TIME: any check-in / check-out / request on any phone updates this screen
  const live = useRealtime('admin-live', [
    { table: 'attendance' },
    { table: 'leaves' },
    { table: 'regularizations' },
    { table: 'profiles' },
  ], (payload) => {
    if (payload.table === 'attendance' && payload.new && 'user_id' in payload.new) {
      const a = payload.new as unknown as AttendanceRow;
      const who = boardRef.current.find((r) => r.user_id === a.user_id)?.full_name ?? 'An employee';
      const msg = a.check_out_at
        ? `${who} checked out at ${fmtTime12(a.check_out_at)}`
        : `${who} checked in at ${fmtTime12(a.check_in_at)}${a.source === 'site' ? ' - site selfie' : ''}`;
      setEvent(msg);
      flash.setValue(1);
      Animated.timing(flash, { toValue: 0, duration: 2500, useNativeDriver: false }).start();
    }
    load();
  });

  if (!board || !stats) return <Loading />;

  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      <Hero
        kicker={`${(profile?.role ?? 'HR').toUpperCase()} CONTROL CENTER - ${profile?.full_name ?? ''}`}
        title="Live Attendance"
        subtitle={`Signed in as ${profile?.full_name ?? ''} (${profile?.role ?? 'HR'}) - ${fmtDateLong()}`}
        right={<LiveDot live={live} />} />

      {event ? (
        <Animated.View style={{ transform: [{ scale: flash.interpolate({ inputRange: [0, 1], outputRange: [1, 1.03] }) }] }}>
          <Banner tone="green" icon="flash-outline" text={event} />
        </Animated.View>
      ) : null}
      {stats.is_holiday ? <Banner tone="blue" icon="sunny-outline" text={`Holiday today: ${stats.is_holiday}`} /> : null}

      <KpiGrid>
        <Kpi label="Present Today" value={`${stats.present_today} / ${stats.active_employees}`} icon="checkmark-circle-outline" tone="green" note="Checked in" />
        <Kpi label="Still Working" value={stats.still_working} icon="briefcase-outline" tone="purple" note="Not checked out" />
        <Kpi label="Not Checked In" value={stats.not_checked_in} icon="close-circle-outline" tone="red" note="No punch yet" />
        <Kpi label="On Leave" value={stats.on_leave} icon="airplane-outline" tone="blue" note="Approved leave" />
        <Kpi label="Approvals" value={stats.pending_leaves + stats.pending_regularizations} icon="hourglass-outline" tone="cyan" note="Pending requests" />
      </KpiGrid>

      <SectionTitle title="Today's team attendance" note="Updates instantly when anyone checks in or out" />
      <TeamAttendance board={board} />
      <Row style={{ justifyContent: 'center', marginTop: 4 }}>
        <Text style={st.foot}>Pull down to refresh manually - real-time updates are automatic</Text>
      </Row>
    </Screen>
  );
}

const st = StyleSheet.create({
  salTitle: { fontWeight: '800', color: C.ink, fontSize: 15 },
  foot: { color: C.muted, fontSize: 11.5 },
});
