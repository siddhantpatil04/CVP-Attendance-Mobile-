import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Dropdown } from '../../components/Pickers';
import { PhotoAvatar } from '../../components/PhotoAvatar';
import { Button, Card, Empty, Field, Loading, Pill, Row, Screen } from '../../components/ui';
import { api, DETAIL_FILE_KINDS, LoginOverviewRow, Profile } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { useIsDesktop } from '../../lib/layout';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { C } from '../../theme';
import { AddEmployeeForm } from './AddEmployeeScreen';
import { shownRole } from '../../navigation/menu';

type Overview = Awaited<ReturnType<typeof api.detailsOverview>>;
const REQUIRED = DETAIL_FILE_KINDS.filter((d) => d.required).map((d) => d.kind);
const PAGE = 10;
const ROLE_OPTIONS = [{ value: 0, label: 'All roles' }, { value: 1, label: 'Employee' }, { value: 2, label: 'HR' }];

/**
 * Admin / HR: Employee Management. Search, filter, add and open every employee in one place.
 * Add Employee opens as a panel on the right. View = the Employee Form and documents, Edit = access, leaves, profile and shift.
 */
export default function EmployeeFormsScreen() {
  const nav = useNavigation<any>();
  const desktop = useIsDesktop();
  const { isFullAdmin } = useAuth();
  const [rows, setRows] = useState<Profile[] | null>(null);
  const [ov, setOv] = useState<Overview | null>(null);
  const [logins, setLogins] = useState<Map<string, LoginOverviewRow>>(new Map());
  const [q, setQ] = useState('');
  const [dept, setDept] = useState(0);
  const [role, setRole] = useState(0);
  const [page, setPage] = useState(0);
  const [adding, setAdding] = useState(false);

  const load = useCallback(async () => {
    try {
      const [p, o] = await Promise.all([api.allProfiles(), api.detailsOverview()]);
      setRows(p); setOv(o);
      // login status needs employee_registration.sql; without it every account just shows "Active"
      setLogins(new Map((await api.loginOverview().catch(() => [])).map((l) => [l.user_id, l])));
    } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('employee-forms', [{ table: 'employee_details' }, { table: 'employee_detail_files' }, { table: 'profiles' }], () => load());

  const people = useMemo(
    () => (rows ?? []).filter((x) => x.active && (isFullAdmin ? x.role !== 'Admin' : shownRole(x) === 'Employee')),
    [rows, isFullAdmin],
  );
  const depts = useMemo(
    () => Array.from(new Set(people.map((x) => (x.department ?? '').trim()).filter(Boolean))).sort((a, b) => a.localeCompare(b)),
    [people],
  );
  const deptOptions = [{ value: 0, label: 'All departments' }, ...depts.map((d, i) => ({ value: i + 1, label: d }))];

  const shown = useMemo(() => {
    const t = q.trim().toLowerCase();
    const digits = t.replace(/\D/g, '');
    return people
      .filter((x) => !t || `${x.full_name} ${x.username}`.toLowerCase().includes(t) || (digits.length > 2 && (x.phone ?? '').replace(/\D/g, '').includes(digits)))
      .filter((x) => dept === 0 || (x.department ?? '').trim() === depts[dept - 1])
      .filter((x) => role === 0 || shownRole(x) === ROLE_OPTIONS[role].label)
      .sort((a, b) => a.full_name.localeCompare(b.full_name));
  }, [people, q, dept, role, depts]);

  if (!rows || !ov) return <Loading />;
  const pages = Math.max(1, Math.ceil(shown.length / PAGE));
  const cur = Math.min(page, pages - 1);
  const slice = shown.slice(cur * PAGE, cur * PAGE + PAGE);
  const isComplete = (id: string) => ov.filled.has(id) && REQUIRED.every((k) => ov.docs.get(id)?.has(k));
  const docPill = (id: string) => {
    const filled = ov.filled.has(id);
    const done = isComplete(id);
    return <Pill text={done ? 'Complete' : filled ? 'Documents missing' : 'Form not filled'} tone={done ? 'green' : filled ? 'amber' : 'red'} />;
  };
  // account status: Pending Verification / Pending Approval / Approved - Create Login / Active / Rejected (never the password)
  const loginPill = (x: Profile) => {
    const l = logins.get(x.id);
    const s = l?.reg_status;
    if (!l || l.login_claimed || s === 'Active') return <Pill text="Active" tone="green" />;
    if (s === 'Approved') return <Pill text="Approved - Create Login" tone="blue" />;
    if (s === 'Rejected') return <Pill text="Rejected" tone="red" />;
    if (s) return <Pill text={s} tone="amber" />;
    return <Pill text="Waiting for registration" tone="amber" />;
  };
  const loginInfo = (x: Profile) => {
    const l = logins.get(x.id);
    if (!l) return '';
    const made = l.account_created_at ? ` - created ${l.account_created_at.slice(0, 10).split('-').reverse().join('-')}` : '';
    const ver = l.email_verified || l.phone_verified ? ' - verified' : '';
    return `${l.username ? `Username: ${l.username}` : 'No username yet'}${ver}${made}`;
  };
  const typeText = (x: Profile) => (x.site_employee ? 'Site\n(9:00 - 6:00)' : 'Office\n(8:30 - 5:30)');
  const edit = (x: Profile) => nav.navigate('EmployeeDetail', { userId: x.id });

  const actions = (x: Profile) => (
    <Row gap={6}>
      <Pressable onPress={() => edit(x)} style={st.act}><Ionicons name="create-outline" size={14} color={C.blue} /><Text style={st.actText}>Edit</Text></Pressable>
    </Row>
  );

  return (
    <Screen>
      <Row style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.title}>Employee Management</Text>
          <Text style={st.subtitle}>View, add, and manage employees in one place</Text>
        </View>
        <Button title="Add Employee" icon="add" onPress={() => setAdding(true)} />
      </Row>

      <Row style={{ alignItems: 'flex-start', flexWrap: 'wrap' }} gap={10}>
        <View style={{ flexGrow: 2, flexBasis: 240, minWidth: 200 }}>
          <Field value={q} onChangeText={(v) => { setQ(v); setPage(0); }} placeholder="Search by name or mobile" autoCapitalize="none" />
        </View>
        <View style={{ flexGrow: 1, flexBasis: 170, minWidth: 150, marginBottom: 8 }}>
          <Dropdown width="100%" value={dept} onChange={(v) => { setDept(v); setPage(0); }} options={deptOptions} />
        </View>
        <View style={{ flexGrow: 1, flexBasis: 150, minWidth: 130, marginBottom: 8 }}>
          <Dropdown width="100%" value={role} onChange={(v) => { setRole(v); setPage(0); }} options={isFullAdmin ? ROLE_OPTIONS : ROLE_OPTIONS.slice(0, 2)} />
        </View>
      </Row>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        {desktop ? (
          <View style={st.head}>
            <Text style={[st.th, { flex: 2.4 }]}>Employee</Text>
            <Text style={[st.th, st.mid, { flex: 1.3 }]}>Department</Text>
            <Text style={[st.th, st.mid, { flex: 1.3 }]}>Designation</Text>
            <Text style={[st.th, st.mid, { flex: 0.9 }]}>Role</Text>
            <Text style={[st.th, st.mid, { flex: 1.1 }]}>Employee Type</Text>
            <Text style={[st.th, { flex: 1.5 }]}>Status</Text>
            <Text style={[st.th, { flex: 1.4 }]}>Actions</Text>
          </View>
        ) : null}
        {slice.length === 0 ? <Empty icon="people-outline" text="No employees found." /> : slice.map((x) => {
          const photo = ov.docs.get(x.id)?.get('photo')?.path ?? null;
          const who = (
            <Row style={{ flex: desktop ? 2.4 : undefined, minWidth: 0 }}>
              <PhotoAvatar name={x.full_name} size={40} path={photo} />
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={st.name} numberOfLines={1}>{x.full_name}</Text>
                <Text style={st.sub} numberOfLines={1}>{x.phone ? `+91 ${x.phone.replace(/\D/g, '').slice(-10)}` : x.username}</Text>
              </View>
            </Row>
          );
          if (desktop) {
            return (
              <View key={x.id} style={st.tr}>
                {who}
                <Text style={[st.td, st.mid, { flex: 1.3 }]} numberOfLines={2}>{x.department || '-'}</Text>
                <Text style={[st.td, st.mid, { flex: 1.3 }]} numberOfLines={2}>{x.designation || '-'}</Text>
                <Text style={[st.td, st.mid, { flex: 0.9 }]}>{shownRole(x)}</Text>
                <Text style={[st.td, st.mid, { flex: 1.1 }]}>{typeText(x)}</Text>
                <View style={{ flex: 1.5, alignItems: 'flex-start', gap: 4 }}>{loginPill(x)}{docPill(x.id)}<Text style={st.sub}>{loginInfo(x)}</Text></View>
                <View style={{ flex: 1.4 }}>{actions(x)}</View>
              </View>
            );
          }
          return (
            <View key={x.id} style={[st.tr, { flexDirection: 'column', alignItems: 'stretch', gap: 8 }]}>
              {who}
              <Text style={st.sub}>{[x.department, x.designation, shownRole(x), x.site_employee ? 'Site' : 'Office'].filter(Boolean).join(' - ')}</Text>
              <Row gap={6} style={{ flexWrap: 'wrap' }}>{loginPill(x)}{docPill(x.id)}</Row>
              <Text style={st.sub}>{loginInfo(x)}</Text>
              {actions(x)}
            </View>
          );
        })}
        <View style={st.foot}>
          <Text style={st.sub}>{shown.length === 0 ? 'Showing 0 employees' : `Showing ${cur * PAGE + 1} - ${cur * PAGE + slice.length} of ${shown.length} employees`}</Text>
          <Row gap={6}>
            <Pressable disabled={cur === 0} onPress={() => setPage(cur - 1)} style={[st.pg, cur === 0 && { opacity: 0.4 }]}><Ionicons name="chevron-back" size={14} color={C.ink} /></Pressable>
            <View style={[st.pg, { backgroundColor: C.blue, borderColor: C.blue }]}><Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{cur + 1}</Text></View>
            <Pressable disabled={cur >= pages - 1} onPress={() => setPage(cur + 1)} style={[st.pg, cur >= pages - 1 && { opacity: 0.4 }]}><Ionicons name="chevron-forward" size={14} color={C.ink} /></Pressable>
          </Row>
        </View>
      </Card>

      <Modal visible={adding} transparent animationType="fade" onRequestClose={() => setAdding(false)}>
        <View style={st.overlay}>
          <Pressable style={{ flex: 1 }} onPress={() => setAdding(false)} />
          <View style={[st.panel, !desktop && { width: '100%' }]}>
            <Row style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <Text style={st.title}>Add Employee</Text>
              <Pressable onPress={() => setAdding(false)} hitSlop={10}><Ionicons name="close" size={24} color={C.muted} /></Pressable>
            </Row>
            <ScrollView keyboardShouldPersistTaps="handled">
              <AddEmployeeForm embedded onCreated={() => { setAdding(false); load(); }} />
              <Button title="Cancel" variant="secondary" onPress={() => setAdding(false)} style={{ marginTop: 8, marginBottom: 20 }} />
            </ScrollView>
          </View>
        </View>
      </Modal>
    </Screen>
  );
}

const st = StyleSheet.create({
  title: { fontSize: 22, fontWeight: '800', color: '#0B2B4D' },
  subtitle: { color: C.muted, fontSize: 13, marginTop: 2 },
  head: { flexDirection: 'row', backgroundColor: '#F1F6FC', paddingVertical: 12, paddingHorizontal: 16, gap: 8 },
  th: { fontWeight: '800', color: '#3A5068', fontSize: 12 },
  mid: { textAlign: 'center', paddingHorizontal: 8 },   // Department / Designation / Role / Type: centred, with room so a long designation never touches the next column
  tr: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 16, gap: 8, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  td: { color: '#203951', fontSize: 12.5 },
  name: { fontWeight: '800', color: '#102A45', fontSize: 14 },
  sub: { color: C.muted, fontSize: 12, marginTop: 1 },
  act: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 6, paddingHorizontal: 10, borderRadius: 8, borderWidth: 1, borderColor: '#B9D4FF', backgroundColor: '#F2F8FF' },
  actText: { color: C.blue, fontWeight: '800', fontSize: 12 },
  foot: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14 },
  pg: { minWidth: 28, height: 28, borderRadius: 8, borderWidth: 1, borderColor: '#DFE8F2', alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' },
  overlay: { flex: 1, flexDirection: 'row', backgroundColor: 'rgba(8,24,46,0.45)' },
  panel: { width: 440, maxWidth: '100%', backgroundColor: '#fff', padding: 20 },
});
