import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Dropdown, MonthPicker } from '../../components/Pickers';
import { Card, Empty, Kpi, KpiGrid, Pill, Row, Screen, SectionTitle } from '../../components/ui';
import { api, TravelReportRow } from '../../lib/api';
import { errorText } from '../../lib/supabase';
import { fmtDateLong, hhmmTo12, istParts } from '../../lib/time';
import { C } from '../../theme';

/**
 * Admin / HR travel report for one month: stops, trips, km, and how many times each site was visited.
 * Pick the month, then an employee (or everyone).
 */
export default function TravelReportScreen() {
  const now = istParts();
  const [year, setYear] = useState(now.year);
  const [month, setMonth] = useState(now.month);
  const [rows, setRows] = useState<TravelReportRow[] | null>(null);
  const [who, setWho] = useState(-1); // -1 = hidden, 0 = all employees, n = the n-th employee who travelled
  const [open, setOpen] = useState<Record<string, boolean>>({});

  const mm = String(month).padStart(2, '0');
  const from = `${year}-${mm}-01`;
  const to = `${year}-${mm}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}`;

  const load = useCallback(async () => {
    try { setRows(await api.travelReport(from, to)); }
    catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [from, to]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const people = useMemo(() => {
    const m = new Map<string, { id: string; name: string; days: number; trips: number; km: number }>();
    for (const r of rows ?? []) {
      const p = m.get(r.user_id) ?? { id: r.user_id, name: r.full_name, days: 0, trips: 0, km: 0 };
      p.days += 1; p.trips += r.trips; p.km += Number(r.km ?? 0);
      m.set(r.user_id, p);
    }
    return [...m.values()].sort((a, b) => a.name.localeCompare(b.name));
  }, [rows]);

  const shown = useMemo(
    () => (who > 0 ? (rows ?? []).filter((r) => r.user_id === people[who - 1]?.id) : rows ?? []),
    [rows, people, who],
  );
  const totals = useMemo(() => ({
    km: shown.reduce((s, r) => s + Number(r.km ?? 0), 0),
    trips: shown.reduce((s, r) => s + r.trips, 0),
    stops: shown.reduce((s, r) => s + r.stops, 0),
  }), [shown]);

  // How many times each work site was visited (one visit = one stop at that site)
  const visits = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of shown) for (const l of r.legs ?? []) m.set(l.site ?? 'Unnamed stop', (m.get(l.site ?? 'Unnamed stop') ?? 0) + 1);
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  }, [shown]);

  const t = (v: string | null) => (v ? hhmmTo12(v) : '-');
  const key = (r: TravelReportRow) => `${r.user_id}-${r.work_date}`;

  return (
    <Screen>
      <MonthPicker year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); setRows(null); setWho(-1); }} />
      <Text style={st.label}>Employee</Text>
      <View style={{ marginBottom: 12 }}>
        <Dropdown width="100%" value={who} onChange={setWho}
          options={[{ value: -1, label: 'Select employee' },
            { value: 0, label: `All employees (${people.length})` },
            ...people.map((p, i) => ({ value: i + 1, label: `${p.name} (${p.km.toFixed(1)} km)` }))]} />
      </View>

      {who >= 0 ? (
        <>
          <KpiGrid>
            <Kpi label="Travel days" value={shown.length} icon="walk-outline" tone="blue" note="In this month" />
            <Kpi label="Trips" value={totals.trips} icon="swap-horizontal-outline" tone="purple" note="Site to site moves" />
            <Kpi label="Total distance" value={`${totals.km.toFixed(1)} km`} icon="navigate-outline" tone="cyan" note="Real route (live GPS)" />
            <Kpi label="Site visits" value={totals.stops} icon="location-outline" tone="green" note="Stops at sites" />
          </KpiGrid>

          <SectionTitle title="Visits per site" note="How many times each site was visited" />
          <Card style={{ paddingVertical: 4 }}>
            {visits.length === 0 ? <Empty icon="location-outline" text="No site visits in this selection." /> : visits.map(([site, n]) => (
              <View key={site} style={st.visit}>
                <Ionicons name="location-outline" size={18} color={C.blue} />
                <Text style={st.name} numberOfLines={1}>{site}</Text>
                <Pill text={`${n} visit${n === 1 ? '' : 's'}`} tone="blue" />
              </View>
            ))}
          </Card>

          <SectionTitle title="Day by day" note="Tap a day for the stops and the km of each trip" />
          <Card style={{ paddingVertical: 4 }}>
            {!rows ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : shown.length === 0 ? (
              <Empty icon="walk-outline" text="No travel records for this selection. Switch on Travel Access for an employee in Employees." />
            ) : shown.map((r) => {
              const isOpen = !!open[key(r)];
              return (
                <View key={key(r)} style={st.rec}>
                  <Pressable onPress={() => setOpen((o) => ({ ...o, [key(r)]: !o[key(r)] }))}>
                    <Row style={{ justifyContent: 'space-between' }}>
                      <View style={{ flex: 1 }}>
                        <Text style={st.name} numberOfLines={1}>{r.full_name}</Text>
                        <Text style={st.sub}>{fmtDateLong(r.work_date)} - {r.stops} stop(s), {r.trips} trip(s)</Text>
                        {r.route ? <Text style={st.route} numberOfLines={2}>{r.route}</Text> : null}
                      </View>
                      <Pill text={`${Number(r.km).toFixed(1)} km`} tone="green" />
                      <Ionicons name={isOpen ? 'chevron-up' : 'chevron-down'} size={16} color={C.muted} style={{ marginLeft: 8 }} />
                    </Row>
                  </Pressable>
                  {isOpen ? (r.legs ?? []).map((l) => (
                    <View key={l.leg} style={st.stop}>
                      <Text style={st.sub}>Stop {l.leg}{l.site ? ` - ${l.site}` : ''}: in {t(l.in)}, out {t(l.out)}</Text>
                      {l.trip_km != null ? (
                        <Text style={st.trip}>Trip {l.leg - 1} to {l.leg}: {l.trip_km} km ({l.source === 'gps' ? 'live GPS route' : 'straight line, no GPS'})</Text>
                      ) : null}
                    </View>
                  )) : null}
                </View>
              );
            })}
          </Card>
        </>
      ) : null}
    </Screen>
  );
}

const st = StyleSheet.create({
  label: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  visit: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  rec: { paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#EEF3F8', gap: 3 },
  name: { flex: 1, fontSize: 14, fontWeight: '800', color: '#102A45' },
  sub: { fontSize: 12, color: C.muted },
  route: { fontSize: 12.5, fontWeight: '700', color: '#17314D', marginTop: 2 },
  stop: { marginLeft: 6, paddingTop: 6 },
  trip: { fontSize: 12, fontWeight: '700', color: '#1B6B3A', marginTop: 1 },
});

