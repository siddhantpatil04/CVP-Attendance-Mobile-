import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Dropdown } from '../../components/Pickers';
import { Avatar, Card, Chips, Empty, Field, Loading, Pill, Row, Screen } from '../../components/ui';
import { api, Profile } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { C } from '../../theme';
import { shownRole } from '../../navigation/menu';

type F = 'Employees' | 'All';
const ORD = ['', '1st', '2nd', '3rd', '4th'];

/** Admin / HR: decide, for every employee, which Saturdays (1st to 4th) are a holiday. Taps save immediately. */
export default function SaturdaysAdminScreen() {
  const { profile: me, isFullAdmin } = useAuth();
  const [rows, setRows] = useState<Profile[] | null>(null);
  const [q, setQ] = useState('');
  const [f, setF] = useState<F>('Employees');
  const [saving, setSaving] = useState<string | null>(null);

  const load = useCallback(async () => {
    try { setRows((await api.allProfiles()).filter((p) => p.active)); }
    catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('saturdays-admin', [{ table: 'profiles' }], () => load());

  // Letter drop-down: -1 = list hidden, 0 = everyone, 1..26 = employees whose FIRST name starts with A..Z
  // (first name only: not the middle name and not the surname)
  const [letter, setLetter] = useState(-1);
  const firstLetter = (p: Profile) => (p.full_name.trim().split(/\s+/)[0] ?? '').charAt(0).toUpperCase();

  const scope = useMemo(() => {
    let r = rows ?? [];
    if (f === 'Employees') r = r.filter((p) => p.role === 'Employee' || p.role === 'HR'); // HR are company employees too
    return r;
  }, [rows, f]);
  const letterCounts = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of scope) m.set(firstLetter(p), (m.get(firstLetter(p)) ?? 0) + 1);
    return m;
  }, [scope]);

  const shown = useMemo(() => {
    let r = scope;
    if (letter > 0) r = r.filter((p) => firstLetter(p) === String.fromCharCode(64 + letter));
    const k = q.trim().toLowerCase();
    return k ? r.filter((p) => `${p.full_name} ${p.username} ${p.department}`.toLowerCase().includes(k)) : r;
  }, [scope, q, letter]);

  const toggle = async (p: Profile, n: number) => {
    const current = (p.saturday_off ?? []).filter((x) => x <= 4);
    const next = current.includes(n) ? current.filter((x) => x !== n) : [...current, n].sort();
    setSaving(p.id);
    setRows((all) => (all ?? []).map((x) => (x.id === p.id ? { ...x, saturday_off: next } : x))); // show the change at once
    try { await api.setSaturdays(p.id, next); }
    catch (e) { Alert.alert('Could not save', errorText(e)); await load(); }
    finally { setSaving(null); }
  };

  if (!rows) return <Loading />;
  return (
    <Screen>
      <Field placeholder="Search name, username or department" value={q} onChangeText={setQ} autoCapitalize="none" />
      <Chips<F> options={['Employees', 'All']} value={f} onChange={setF} />
      <View style={{ marginBottom: 10 }}>
        <Dropdown width="100%" value={letter} onChange={setLetter}
          options={[
            { value: -1, label: 'Select letter' },
            { value: 0, label: `All employees (${scope.length})` },
            ...Array.from({ length: 26 }, (_, i) => ({ l: String.fromCharCode(65 + i), v: i + 1 }))
              .filter((x) => letterCounts.has(x.l))
              .map((x) => ({ value: x.v, label: `${x.l} (${letterCounts.get(x.l)})` })),
          ]} />
      </View>
      <Card style={{ paddingVertical: 4, display: letter < 0 ? 'none' : 'flex' }}>
        {shown.length === 0 ? <Empty text="No employees found." /> : shown.map((p) => {
          const off = (p.saturday_off ?? []).filter((x) => x <= 4);
          // HR can change employees (and themselves); only an Admin can change HR / Admin accounts
          const canEdit = isFullAdmin || p.role === 'Employee' || p.id === me?.id; // (isFullAdmin = Admin or HR)
          return (
            <View key={p.id} style={st.item}>
              <Row>
                <Avatar name={p.full_name} size={36} />
                <View style={{ flex: 1 }}>
                  <Text style={st.name} numberOfLines={1}>{p.full_name}</Text>
                  <Text style={st.sub} numberOfLines={1}>{p.department || 'General'}</Text>
                </View>
                {shownRole(p) !== 'Employee' ? <Pill text={shownRole(p)} tone="purple" /> : null}
                {saving === p.id ? <Pill text="Saving..." tone="blue" /> : null}
              </Row>
              <View style={st.chips}>
                {[1, 2, 3, 4].map((n) => {
                  const on = off.includes(n);
                  return (
                    <Pressable key={n} disabled={!canEdit} onPress={() => toggle(p, n)}
                      style={[st.chip, on && st.chipOn, !canEdit && { opacity: 0.45 }]}>
                      <Text style={[st.chipText, on && st.chipTextOn]}>{ORD[n]} Sat - {on ? 'Off' : 'Working'}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>
          );
        })}
      </Card>
    </Screen>
  );
}

const st = StyleSheet.create({
  item: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  name: { fontWeight: '800', color: '#102A45', fontSize: 14.5 },
  sub: { color: C.muted, fontSize: 12, marginTop: 1 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 10 },
  chip: { paddingVertical: 8, paddingHorizontal: 11, borderRadius: 999, borderWidth: 1, borderColor: '#DFE8F2', backgroundColor: '#FBFDFF' },
  chipOn: { backgroundColor: '#E6F4EA', borderColor: '#34A853' },
  chipText: { fontSize: 12, fontWeight: '700', color: '#5A6B7F' },
  chipTextOn: { color: '#1E7A3C' },
});
