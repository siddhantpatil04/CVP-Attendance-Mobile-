import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { MonthYearDropdowns } from '../../components/Pickers';
import { Banner, Button, Card, Loading, Screen } from '../../components/ui';
import { api, MonthSummaryRow } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { periodLabel, ReportDef, REPORTS } from '../../lib/reports';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { sharePdf } from '../../lib/pdf';
import { shareXlsx } from '../../lib/xlsx';
import { istParts } from '../../lib/time';
import { C } from '../../theme';

const GROUPS: ReportDef['group'][] = ['Salary & Bank', 'Attendance', 'Leave', 'Field & Site', 'Employees & Company'];

export default function ReportsScreen() {
  const { isFullAdmin } = useAuth();
  const now = istParts();
  const [year, setYear] = useState(now.year);
  const [month, setMonth] = useState(now.month);
  const [rows, setRows] = useState<MonthSummaryRow[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    try { setRows(await api.monthSummary(year, month)); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [year, month]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('reports', [{ table: 'attendance' }, { table: 'leaves' }, { table: 'holidays' }], () => load());

  // the Detailed Day-wise Report and the Leave Register are now under Employees -> the employee -> Reports
  const list = useMemo(() => REPORTS.filter((r) => !r.perEmployee), []);

  const download = async (def: ReportDef, kind: 'xlsx' | 'pdf' = 'xlsx') => {
    if (!rows) return;
    setBusy(`${def.id}:${kind}`);
    try {
      const res = await def.build({ year, month, summary: rows });
      if (res.rows.length === 0 && !res.aoa?.length) return Alert.alert('No data', `There are no records for "${def.title}" in this period.`);
      if (kind === 'pdf' && res.custom?.pdf) {
        await res.custom.pdf(res.file.replace(/\.xlsx$/, '.pdf'));
      } else if (kind === 'xlsx' && res.custom?.xlsx) {
        await res.custom.xlsx(res.file);
      } else if (kind === 'pdf') {
        await sharePdf(res.file.replace(/\.xlsx$/, '.pdf'), {
          title: def.title, subtitle: periodLabel(def, { year, month }), rows: res.rows, aoa: res.aoa, merges: res.merges, grid: res.grid, company: true,
        });
      } else {
        const subtitle = periodLabel(def, { year, month });
        await shareXlsx(res.file, [
          { name: def.title, title: def.title, subtitle, rows: res.rows, aoa: res.aoa, merges: res.merges, calc: res.calc, company: true },
          ...(res.grid ? [{ name: 'Day-wise Attendance', title: `${def.title} - day-wise attendance`, subtitle, rows: [], aoa: res.grid.aoa, merges: res.grid.merges, calc: res.gridCalc, company: true }] : []),
        ]);
      }
    } catch (e) {
      Alert.alert('Download failed', errorText(e));
    } finally {
      setBusy(null);
    }
  };

  if (!isFullAdmin) return <Screen><Banner tone="amber" text="Reports are available to the Admin only." /></Screen>;
  if (!rows) return <Loading />;
  const sum = (k: keyof MonthSummaryRow) => rows.reduce((a, r) => a + Number(r[k] || 0), 0);

  return (
    <Screen>
      <MonthYearDropdowns year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); setRows(null); }} />
      <View style={st.strip}>
        <Text style={[st.stripItem, { color: C.green }]}>Present {sum('present')}</Text>
        <Text style={[st.stripItem, { color: C.red }]}>Absent {sum('absent')}</Text>
        <Text style={[st.stripItem, { color: '#C98400' }]}>Leave {sum('on_leave')}</Text>
        <Text style={st.stripItem}>Hours {sum('hours').toFixed(0)}</Text>
      </View>

      {GROUPS.map((g) => {
        const items = list.filter((r) => r.group === g);
        if (!items.length) return null;
        return (
          <View key={g}>
            <Text style={st.group}>{g}</Text>
            <Card style={{ paddingVertical: 2, paddingHorizontal: 10 }}>
              {items.map((def, i) => (
                <View key={def.id} style={[st.row, i < items.length - 1 && st.rowLine]}>
                  <Ionicons name={def.icon as any} size={16} color={C.blue} />
                  <Text style={st.title} numberOfLines={2}>{def.title}</Text>
                  <Button title="Excel" icon="download-outline" small loading={busy === `${def.id}:xlsx`} disabled={!!busy && busy !== `${def.id}:xlsx`}
                    onPress={() => download(def, 'xlsx')} />
                  <Button title="PDF" icon="document-text-outline" variant="secondary" small loading={busy === `${def.id}:pdf`} disabled={!!busy && busy !== `${def.id}:pdf`}
                    onPress={() => download(def, 'pdf')} />
                </View>
              ))}
            </Card>
          </View>
        );
      })}
    </Screen>
  );
}
const st = StyleSheet.create({
  strip: { flexDirection: 'row', flexWrap: 'wrap', gap: 14, paddingHorizontal: 4, marginBottom: 8 },
  stripItem: { fontSize: 13, fontWeight: '800', color: '#17314D' },
  group: { fontSize: 13, fontWeight: '800', color: '#3A5068', marginTop: 4, marginBottom: 6, marginLeft: 2 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 7 },
  rowLine: { borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  title: { flex: 1, fontWeight: '700', color: '#102A45', fontSize: 13.5 },
});