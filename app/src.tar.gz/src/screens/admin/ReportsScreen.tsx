import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Dropdown, MonthYearDropdowns } from '../../components/Pickers';
import { Banner, Button, Card, Loading, Screen } from '../../components/ui';
import { api, MonthSummaryRow } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { periodLabel, ReportDef, REPORTS } from '../../lib/reports';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { sharePdf } from '../../lib/pdf';
import { shareXlsx } from '../../lib/xlsx';
import { istParts } from '../../lib/time';
import { C } from '../../theme';
import { CompanyFilter } from '../../components/CompanyFilter';
import PfReportsPanel from '../../components/PfReportsPanel';
import { headingOf, setReportCompany, useCompanies, useCompanyChoice } from '../../lib/companies';

const GROUPS: ReportDef['group'][] = ['Salary & Bank', 'Provident Fund (PF)', 'Attendance', 'Leave', 'Field & Site', 'Employees & Company'];

export default function ReportsScreen() {
  const { isFullAdmin } = useAuth();
  const now = istParts();
  const [year, setYear] = useState(now.year);
  const [month, setMonth] = useState(now.month);
  const [rows, setRows] = useState<MonthSummaryRow[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const co = useCompanies();
  const [coSel, setCoSel] = useCompanyChoice();
  const [pfSel, setPfSel] = useState(0);   // 0 everybody, 1 PF members, 2 non-PF
  const [empSel, setEmpSel] = useState('');   // '' = every employee (salary and PF reports)
  const [coOf, setCoOf] = useState<Map<string, number | null>>(new Map());
  React.useEffect(() => { api.allProfiles().then((l) => setCoOf(new Map(l.map((p) => [p.id, p.company_id ?? null])))).catch(() => undefined); }, []);
  const allow = React.useCallback((uid: string, date: string) => !coSel || co.companyAt(uid, date, coOf.get(uid)) === coSel, [coSel, co.history, coOf]);   // eslint-disable-line react-hooks/exhaustive-deps
  const mEnd = `${year}-${String(month).padStart(2, '0')}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}`;
  // the Company choice only applies to the downloaded reports; the numbers on screen are everybody
  const rowsC = useMemo(() => (rows && coSel ? rows.filter((r) => allow(r.user_id, mEnd)) : rows), [rows, allow, mEnd, coSel]);

  const load = useCallback(async () => {
    try { setRows(await api.monthSummary(year, month)); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [year, month]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('reports', [{ table: 'attendance' }, { table: 'leaves' }, { table: 'holidays' }], () => load());

  // the Detailed Day-wise Report and the Leave Register are now under Employees -> the employee -> Reports
  const pfOnly = pfSel === 1 ? 'on' as const : pfSel === 2 ? 'off' as const : undefined;
  // company + employee choice of the salary and PF downloads
  const salaryAllow = React.useCallback((uid: string, date: string) => (!empSel || uid === empSel) && allow(uid, date), [empSel, allow]);
  const names = useMemo(() => [...(rowsC ?? [])].sort((a, b) => a.full_name.localeCompare(b.full_name)), [rowsC]);
  const list = useMemo(() => REPORTS.filter((r) => !r.perEmployee && !r.variantOf), []);
  // the "Muster Roll cum Wages Register - Form II" row is ONE dropdown: Form II, PF Report, PF ECR file, ESIC Report, PT Report (the last choice is remembered on this device)
  const [variant, setVariant] = useState('wages_register');
  React.useEffect(() => { AsyncStorage.getItem('cvp.statutoryReport').then((v) => { if (v && REPORTS.some((r) => r.id === v)) setVariant(v); }).catch(() => undefined); }, []);
  const pickVariant = (id: string) => { setVariant(id); AsyncStorage.setItem('cvp.statutoryReport', id).catch(() => undefined); };

  const download = async (def: ReportDef, kind: 'xlsx' | 'pdf' | 'txt' = 'xlsx') => {
    if (!rowsC || !rows) return;
    const sal = def.group === 'Salary & Bank' || def.group === 'Provident Fund (PF)';   // only these follow the company and PF choice
    setBusy(`${def.id}:${kind}`);
    try {
      setReportCompany(sal ? headingOf(co.companies, coSel) : null);
      const res = await def.build({ year, month, summary: sal ? rowsC : rows, allow: sal && (coSel || empSel) ? salaryAllow : undefined, pf: sal ? pfOnly : undefined });
      if (res.rows.length === 0 && !res.aoa?.length) return Alert.alert('No data', `There are no records for "${def.title}" in this period.`);
      if (kind === 'txt' && res.custom?.txt) {
        await res.custom.txt(res.file);
      } else if (kind === 'pdf' && res.custom?.pdf) {
        await res.custom.pdf(res.file.replace(/\.xlsx$/, '.pdf'));
      } else if (kind === 'xlsx' && res.custom?.xlsx) {
        await res.custom.xlsx(res.file);
      } else if (kind === 'pdf') {
        await sharePdf(res.file.replace(/\.xlsx$/, '.pdf'), {
          title: def.title, subtitle: periodLabel(def, { year, month }), rows: res.rows, aoa: res.aoa, merges: res.merges, grid: res.grid, company: true,
        });
      } else {
        const subtitle = periodLabel(def, { year, month });
        await shareXlsx(res.file, [
          { name: def.title, title: def.title, subtitle, rows: res.rows, aoa: res.aoa, merges: res.merges, calc: res.calc, company: true },
          ...(res.grid ? [{ name: 'Day-wise Attendance', title: `${def.title} - day-wise attendance`, subtitle, rows: [], aoa: res.grid.aoa, merges: res.grid.merges, calc: res.gridCalc, company: true }] : []),
        ]);
      }
      if ((await Promise.resolve(res.notice))) Alert.alert('Please check', res.notice as string);
    } catch (e) {
      Alert.alert('Download failed', errorText(e));
    } finally {
      setBusy(null);
    }
  };

  if (!isFullAdmin) return <Screen><Banner tone="amber" text="Reports are available to the Admin only." /></Screen>;
  if (!rows) return <Loading />;
  const sum = (k: keyof MonthSummaryRow) => rows.reduce((a, r) => a + Number(r[k] || 0), 0);

  return (
    <Screen>
      <MonthYearDropdowns year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); setRows(null); }} />
      <View style={st.strip}>
        <Text style={[st.stripItem, { color: C.green }]}>Present {sum('present')}</Text>
        <Text style={[st.stripItem, { color: C.red }]}>Absent {sum('absent')}</Text>
        <Text style={[st.stripItem, { color: '#C98400' }]}>Leave {sum('on_leave')}</Text>
        <Text style={st.stripItem}>Hours {sum('hours').toFixed(0)}</Text>
      </View>

      {GROUPS.map((g) => {
        const items = list.filter((r) => r.group === g);
        if (!items.length) return null;
        return (
          <View key={g}>
            <Text style={st.group}>{g}</Text>
            {g === 'Salary & Bank' ? <View style={{ maxWidth: 420, marginBottom: 8 }}><CompanyFilter companies={co.companies} value={coSel} onChange={setCoSel} />
              <Dropdown width="100%" value={pfSel} onChange={setPfSel} options={[{ value: 0, label: 'PF: All employees (ON + OFF)' }, { value: 1, label: 'PF: PF members only' }, { value: 2, label: 'PF: Non-PF only' }]} />
              <Dropdown width="100%" value={Math.max(0, names.findIndex((r) => r.user_id === empSel) + 1)} onChange={(i) => setEmpSel(i ? names[i - 1].user_id : '')}
                options={[{ value: 0, label: 'Employee: All' }, ...names.map((r, i) => ({ value: i + 1, label: r.full_name }))]} /></View> : null}
            {g === 'Salary & Bank' ? <PfReportsPanel year={year} month={month} allow={coSel || empSel ? salaryAllow : undefined} pf={pfOnly} /> : null}
            <Card style={{ paddingVertical: 2, paddingHorizontal: 10 }}>
              {items.map((row, i) => {
                const choices = row.id === 'wages_register' ? REPORTS.filter((r) => r.id === 'wages_register' || r.variantOf === 'wages_register') : [];
                const def = choices.find((r) => r.id === variant) ?? row;
                return (
                  <View key={row.id} style={[st.row, i < items.length - 1 && st.rowLine, choices.length ? { flexWrap: 'wrap' } : null]}>
                    <Ionicons name={row.icon as any} size={16} color={C.blue} />
                    {choices.length ? (
                      <View style={{ flex: 1, minWidth: 240 }}>
                        <Dropdown width="100%" value={Math.max(0, choices.findIndex((r) => r.id === def.id))} onChange={(k) => pickVariant(choices[k].id)}
                          options={choices.map((r, k) => ({ value: k, label: r.title }))} />
                      </View>
                    ) : <Text style={st.title} numberOfLines={2}>{def.title}</Text>}
                    {def.textOnly ? (
                      <Button title="Download ECR (.txt)" icon="download-outline" small loading={busy === `${def.id}:txt`} disabled={!!busy && busy !== `${def.id}:txt`} onPress={() => download(def, 'txt')} />
                    ) : def.pdfOnly ? (
                      <Button title="PDF" icon="document-text-outline" small loading={busy === `${def.id}:pdf`} disabled={!!busy && busy !== `${def.id}:pdf`}
                        onPress={() => download(def, 'pdf')} />
                    ) : (
                      <>
                        <Button title="PDF" icon="document-text-outline" small loading={busy === `${def.id}:pdf`} disabled={!!busy && busy !== `${def.id}:pdf`}
                          onPress={() => download(def, 'pdf')} />
                        <Button title="Excel" icon="download-outline" variant="secondary" small loading={busy === `${def.id}:xlsx`} disabled={!!busy && busy !== `${def.id}:xlsx`}
                          onPress={() => download(def, 'xlsx')} />
                      </>
                    )}
                  </View>
                );
              })}
            </Card>
          </View>
        );
      })}
    </Screen>
  );
}
const st = StyleSheet.create({
  strip: { flexDirection: 'row', flexWrap: 'wrap', gap: 14, paddingHorizontal: 4, marginBottom: 8 },
  stripItem: { fontSize: 13, fontWeight: '800', color: '#17314D' },
  group: { fontSize: 13, fontWeight: '800', color: '#3A5068', marginTop: 4, marginBottom: 6, marginLeft: 2 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 7 },
  rowLine: { borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  title: { flex: 1, fontWeight: '700', color: '#102A45', fontSize: 13.5 },
});