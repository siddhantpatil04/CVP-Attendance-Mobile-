import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Image, Linking, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, useWindowDimensions, View } from 'react-native';
import { Dropdown, MonthPicker, PickerField } from '../../components/Pickers';
import { Avatar, Button, Card, Empty, LiveDot, Pill, Row, Screen, Segmented } from '../../components/ui';
import { api, Profile, SelfieRecord, Site } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { distanceM, fmtDistance, isForeignSiteName } from '../../lib/geo';
import { shareCsv } from '../../lib/csv';
import { imageDataUrl } from '../../lib/imageData';
import { selfieAllXlsx, selfieForeignXlsx, selfieReportXlsx } from '../../lib/selfieXlsx';
import { ForeignRow, SelfieReportInfo, SelfieRow, selfieAllPdf, selfieForeignPdf, selfieReportPdf } from '../../lib/wagesRegisterPdf';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtDateLong, fmtTime12, istDateISO } from '../../lib/time';
import { C } from '../../theme';

type Kind = 'All' | 'IN' | 'OUT' | 'Outside';
const KINDS: { kind: Kind; label: string }[] = [
  { kind: 'All', label: 'All records (check in and check out)' },
  { kind: 'IN', label: 'Check in only' },
  { kind: 'OUT', label: 'Check out only' },
  { kind: 'Outside', label: 'Outside site area' },
];

type Place = 'All' | 'Site' | 'Foreign Location';
const PLACES: { place: Place; label: string }[] = [
  { place: 'All', label: 'All places' },
  { place: 'Site', label: 'Sites' },
  { place: 'Foreign Location', label: 'Foreign Location' },
];
const isForeignPlace = (g: { inn?: SelfieRecord; out?: SelfieRecord }) => (g.inn?.place_type ?? g.out?.place_type) === 'Foreign Location';
/** A foreign-location punch however it was saved: the Foreign Location place type, the old "foreign_loc" flag, or the work site called "Foreign location" */
const isForeignGroup = (g: { inn?: SelfieRecord; out?: SelfieRecord }) =>
  isForeignPlace(g) || !!(g.inn?.foreign_loc || g.out?.foreign_loc) || isForeignSiteName(g.inn?.site_name) || isForeignSiteName(g.out?.site_name);

/** One employee on one day: the check-in and the check-out selfie records together */
interface Group {
  key: string; user_id: string; name: string; dept: string | null; day: string;
  inn?: SelfieRecord; out?: SelfieRecord; last: number;
}

/** check-in + check-out of every employee and day, newest first */
function groupRecords(recs: SelfieRecord[]): Group[] {
  const map = new Map<string, Group>();
  for (const r of recs) {
    const day = istDateISO(r.captured_at);
    const key = r.attendance_id != null ? `a${r.attendance_id}` : `${r.user_id}_${day}`;
    const g = map.get(key) ?? { key, user_id: r.user_id, name: r.employee?.full_name ?? 'Employee', dept: r.employee?.department ?? null, day, last: 0 };
    if (r.kind === 'IN') { g.inn ??= r; } else { g.out = r; }
    g.last = Math.max(g.last, new Date(r.captured_at).getTime());
    map.set(key, g);
  }
  return [...map.values()].sort((a, b) => b.last - a.last);
}

/** Small selfie preview shown at the left of each record (a red pin when no selfie was taken) */
function Thumb({ path, size = 46, radius = 12 }: { path: string | null; size?: number; radius?: number }) {
  const [uri, setUri] = useState<string | null>(null);
  useEffect(() => {
    if (!path) return;
    let alive = true;
    api.selfieUrl(path).then((u) => { if (alive) setUri(u); }).catch(() => {});
    return () => { alive = false; };
  }, [path]);
  const box = { width: size, height: size, borderRadius: radius };
  if (!path) {
    return (
      <View style={[st.thumb, box, { backgroundColor: '#FDECEC' }]}>
        <Ionicons name="location-outline" size={Math.round(size / 2.2)} color={C.red} />
      </View>
    );
  }
  return (
    <View style={[st.thumb, box]}>
      {uri ? <Image source={{ uri }} style={st.thumbImg} /> : <ActivityIndicator size="small" color={C.blue} />}
    </View>
  );
}

const away = (m: number | null) => (m == null ? '' : m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(1)} km`);
const coords = (lat: number | null, lng: number | null) =>
  lat != null && lng != null ? `${lat.toFixed(4)}, ${lng.toFixed(4)}` : 'Not captured';
const worked = (a: string, b: string) => {
  const mins = Math.max(0, Math.round((new Date(b).getTime() - new Date(a).getTime()) / 60000));
  return mins < 60 ? `${mins}m` : `${Math.floor(mins / 60)}h ${String(mins % 60).padStart(2, '0')}m`;
};

/** Tile of the expanded record: small caps label, bold value, one note line */
function Tile({ icon, label, value, note, tone }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string; note?: string; tone?: 'green' | 'red' | 'amber' }) {
  return (
    <View style={st.tile}>
      <View style={st.tileHead}>
        <Ionicons name={icon} size={12} color="#8594A6" />
        <Text style={st.tileLabel}>{label}</Text>
      </View>
      <Text style={st.tileVal} numberOfLines={2}>{value}</Text>
      {note ? <Text style={[st.tileNote, tone === 'green' && { color: C.green }, tone === 'red' && { color: C.red }, tone === 'amber' && { color: '#C98400' }]} numberOfLines={2}>{note}</Text> : null}
    </View>
  );
}

/** Employee drop-down with a search box, the department and the number of records of each employee */
function EmployeePicker({ people, counts, total, value, onChange }: {
  people: { id: string; name: string; dept: string | null }[]; counts: Map<string, number>; total: number;
  value: string | undefined; onChange: (id: string | undefined) => void;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const shown = useMemo(() => {
    const k = q.trim().toLowerCase();
    return k ? people.filter((p) => `${p.name} ${p.dept ?? ''}`.toLowerCase().includes(k)) : people;
  }, [people, q]);
  const current = people.find((p) => p.id === value);
  const pick = (id: string | undefined) => { onChange(id); setOpen(false); setQ(''); };
  return (
    <View>
      <Pressable style={st.field} onPress={() => setOpen((o) => !o)}>
        <Ionicons name="search-outline" size={15} color={C.muted} />
        <Text style={st.fieldText} numberOfLines={1}>{current?.name ?? 'All employees'}</Text>
        <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={14} color={C.muted} />
      </Pressable>
      {open ? (
        <View style={st.pop}>
          <View style={st.searchBox}>
            <Ionicons name="search-outline" size={15} color={C.blue} />
            <TextInput value={q} onChangeText={setQ} placeholder="Search employee" placeholderTextColor="#9AA9BA" autoFocus style={[st.searchInput, { outlineStyle: 'none' } as any]} />
          </View>
          <ScrollView style={{ maxHeight: 260 }} keyboardShouldPersistTaps="handled">
            {!q.trim() ? (
              <Pressable style={[st.opt, !value && st.optOn]} onPress={() => pick(undefined)}>
                <View style={st.allIcon}><Text style={st.allIconText}>All</Text></View>
                <Text style={st.optName}>All employees</Text>
                <Text style={st.optMeta}>{total} records</Text>
              </Pressable>
            ) : null}
            {shown.map((p) => (
              <Pressable key={p.id} style={[st.opt, value === p.id && st.optOn]} onPress={() => pick(p.id)}>
                <Avatar name={p.name} size={28} />
                <Text style={st.optName} numberOfLines={1}>{p.name}</Text>
                <Text style={st.optMeta} numberOfLines={1}>{p.dept ? `${p.dept} - ` : ''}{counts.get(p.id) ?? 0}</Text>
              </Pressable>
            ))}
            {shown.length === 0 ? <Text style={[st.optMeta, { padding: 12 }]}>No employee matches "{q}".</Text> : null}
          </ScrollView>
          <Text style={st.popFoot}>{shown.length} of {people.length} employees match</Text>
        </View>
      ) : null}
    </View>
  );
}


// ---------------------------------------------------------------- new filter bar pieces
const RECORDS = ['All records', 'Checked out', 'Not checked out', 'Short day', 'Far (>200 m)'];
const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const NAVY = '#0B2A4A';

/** Date / month box (browser input), 44 px high like the other filter fields */
function DateInput({ type, value, onChange, max }: { type: 'date' | 'month'; value: string; onChange: (v: string) => void; max?: string }) {
  return React.createElement('input', {
    type, value, max,
    onChange: (e: any) => { if (e.target.value) onChange(e.target.value); },
    style: { width: '100%', height: 44, boxSizing: 'border-box', borderRadius: 12, border: '1px solid #C9DDF3', background: '#EAF2FC', color: '#0F2A47', fontFamily: 'inherit', fontSize: 14, fontWeight: 700, padding: '0 10px', outline: 'none', minWidth: 0 },
  });
}

/** ‹ / › button next to the date or month */
function StepBtn({ dir, disabled, onPress }: { dir: -1 | 1; disabled?: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} disabled={disabled} accessibilityRole="button" accessibilityLabel={dir < 0 ? 'Previous' : 'Next'}
      style={{ width: 38, height: 44, borderRadius: 12, flexShrink: 0, borderWidth: 1, borderColor: '#C9DDF3', backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.4 : 1 }}>
      <Ionicons name={dir < 0 ? 'chevron-back' : 'chevron-forward'} size={18} color="#1366D6" />
    </Pressable>
  );
}

/** PDF (blue, filled) / Excel (green outline) */
function ExportBtn({ title, kind, loading, disabled, onPress, grow }: { title: string; kind: 'pdf' | 'xlsx' | 'csv'; loading: boolean; disabled: boolean; onPress: () => void; grow?: boolean }) {
  const pdf = kind === 'pdf';
  const col = pdf ? '#FFFFFF' : '#0E7A4A';
  return (
    <Pressable onPress={onPress} disabled={disabled} accessibilityRole="button"
      style={[{ height: 44, minWidth: 92, paddingHorizontal: 18, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1.5, borderColor: pdf ? '#1366D6' : '#0E7A4A', backgroundColor: pdf ? '#1366D6' : '#FFFFFF', opacity: disabled && !loading ? 0.55 : 1 }, grow ? { flex: 1 } : null]}>
      {loading ? <ActivityIndicator size="small" color={col} /> : <Ionicons name="download-outline" size={16} color={col} />}
      <Text style={{ fontWeight: '800', fontSize: 14, color: col }}>{title}</Text>
    </Pressable>
  );
}

/** Small summary card; tapping it sets the RECORDS filter */
function SumCard({ label, value, color, active, onPress }: { label: string; value: string | number; color: string; active?: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button"
      style={{ flexGrow: 1, flexBasis: 0, minWidth: 96, backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: active ? 2 : 1, borderColor: active ? '#1366D6' : '#E3ECF6', paddingVertical: 12, paddingHorizontal: 14 }}>
      <Text style={{ fontSize: 24, fontWeight: '800', color }} numberOfLines={1}>{value}</Text>
      <Text style={{ fontSize: 12, fontWeight: '700', color: '#64748B', marginTop: 2 }} numberOfLines={1}>{label}</Text>
    </Pressable>
  );
}

function FChip({ text, orange }: { text: string; orange?: boolean }) {
  return <View style={{ backgroundColor: orange ? '#FFF1DC' : '#EAF2FC', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5 }}><Text style={{ fontSize: 12, fontWeight: '700', color: orange ? '#B45309' : '#1B4F9C' }}>{text}</Text></View>;
}

/**
 * PLACE filter: ONE highlighted "Foreign Location" at the top (with the number of foreign punches), then "All places",
 * then the work sites A-Z. (The work site row that is called "Foreign location" is hidden here, not deleted.)
 * value: 0 = Foreign Location, 1 = All places, 2+ = a work site (sites[value - 2])
 */
function PlacePicker({ sites, value, onChange, foreignBadge }: { sites: string[]; value: number; onChange: (i: number) => void; foreignBadge: string }) {
  const [open, setOpen] = useState(false);
  const pick = (i: number) => { onChange(i); setOpen(false); };
  const label = value === 0 ? 'Foreign Location' : value === 1 ? 'All places' : (sites[value - 2] ?? 'All places');
  return (
    <View>
      <Pressable style={[st.field, value === 0 && { backgroundColor: '#FFF3E3', borderColor: '#F3C98B' }]} onPress={() => setOpen((o) => !o)} accessibilityRole="button">
        <Ionicons name={value === 0 ? 'earth-outline' : 'location-outline'} size={15} color={value === 0 ? '#B45309' : C.muted} />
        <Text style={st.fieldText} numberOfLines={1}>{label}</Text>
        <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={14} color={C.muted} />
      </Pressable>
      {open ? (
        <View style={st.pop}>
          <ScrollView style={{ maxHeight: 320 }} keyboardShouldPersistTaps="handled">
            <Pressable onPress={() => pick(0)} style={[st.opt, { backgroundColor: '#FFF1DC', borderWidth: 1, borderColor: '#F3C98B', marginBottom: 2 }]}>
              <Ionicons name="earth-outline" size={16} color="#B45309" />
              <Text style={[st.optName, { color: '#7C2D12' }]}>Foreign Location</Text>
              <View style={{ backgroundColor: '#C2410C', borderRadius: 999, paddingHorizontal: 9, paddingVertical: 2 }}><Text style={{ color: '#FFFFFF', fontSize: 11, fontWeight: '800' }}>{foreignBadge}</Text></View>
            </Pressable>
            <Pressable onPress={() => pick(1)} style={[st.opt, value === 1 && st.optOn]}><Text style={st.optName}>All places</Text></Pressable>
            <Text style={{ fontSize: 10.5, fontWeight: '700', color: '#94A3B8', letterSpacing: 0.6, paddingHorizontal: 8, paddingTop: 8, paddingBottom: 2 }}>WORK SITES (A-Z)</Text>
            {sites.map((s, i) => (
              <Pressable key={s} onPress={() => pick(i + 2)} style={[st.opt, value === i + 2 && st.optOn]}><Text style={st.optName} numberOfLines={1}>{s}</Text></Pressable>
            ))}
          </ScrollView>
        </View>
      ) : null}
    </View>
  );
}

export default function SelfieRecordsScreen() {
  const { isFullAdmin, profile } = useAuth();
  const route = useRoute<any>();
  const nav = useNavigation<any>();
  const { width } = useWindowDimensions();
  const wide = width >= 760;
  const bar = width >= 1000;   // the filter bar fits on ONE row
  // The employee filter starts on the employee the page was opened for (if any); the drop-down can change it
  const [userId, setUserId] = useState<string | undefined>(route.params?.userId);
  const [team, setTeam] = useState<Profile[]>([]);
  // Only site employees take selfies, so only they are listed
  useEffect(() => { api.team().then((l) => setTeam(l.filter((p) => p.site_employee))).catch(() => {}); }, []);
  // history = opened from one employee's page (Selfie Records): every day and month of that employee (old layout, unchanged).
  // Otherwise the new screen: one filter bar with Day / Month.
  const history = !!route.params?.history;
  const name: string | undefined = team.find((e) => e.id === userId)?.full_name ?? (userId === route.params?.userId ? route.params?.name : undefined);
  const today = istDateISO();
  // history page: From / To
  const [from, setFrom] = useState(route.params?.history ? today.slice(0, 8) + '01' : today);
  const [to, setTo] = useState(today);
  const [recView, setRecView] = useState(0);
  const kind = KINDS[recView].kind;
  const [placeView, setPlaceView] = useState(0);   // All / Sites / Foreign Location (history page)
  const place = PLACES[placeView].place;
  // new filter bar
  const [mode, setMode] = useState<'day' | 'month'>('day');
  const [dayVal, setDayVal] = useState(today);
  const [ym, setYm] = useState(() => ({ y: Number(today.slice(0, 4)), m: Number(today.slice(5, 7)) }));
  const [recIdx, setRecIdx] = useState(0);     // RECORDS filter
  const [placeIdx, setPlaceIdx] = useState(1); // PLACE filter: 0 = Foreign Location, 1 = All places, 2+ = one work site (see PlacePicker)
  const [siteAccess, setSiteAccess] = useState<{ user_id: string; site_id: number }[]>([]);   // who is allotted to which site (nearest allotted site)
  useEffect(() => { if (!history) api.siteAccess().then(setSiteAccess).catch(() => {}); }, [history]);
  const mm = String(ym.m).padStart(2, '0');
  const mFrom = `${ym.y}-${mm}-01`;
  const mLast = `${ym.y}-${mm}-${String(new Date(ym.y, ym.m, 0).getDate()).padStart(2, '0')}`;
  const mTo = mLast > today ? today : mLast;
  const rFrom = history ? from : mode === 'day' ? dayVal : mFrom;
  const rTo = history ? to : mode === 'day' ? dayVal : mTo;
  const [data, setData] = useState<SelfieRecord[] | null>(null);  const [open, setOpen] = useState<SelfieRecord | null>(null);
  const [url, setUrl] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [allSites, setAllSites] = useState<Site[]>([]);
  useEffect(() => { api.sites(false).then(setAllSites).catch(() => {}); }, []);
  // work sites A-Z for the PLACE filter; the work site row called "Foreign location" is hidden here (not deleted)
  const siteNames = useMemo(() => [...new Set(allSites.filter((s) => !isForeignSiteName(s.name)).map((s) => s.name))].sort((a, b) => a.localeCompare(b)), [allSites]);
  const placeOptions = useMemo(() => ['Foreign Location', 'All places', ...siteNames], [siteNames]);
  const foreignMode = !history && placeIdx === 0;

  const load = useCallback(async () => {
    if (rTo < rFrom) return Alert.alert('To date must be on or after From date.');
    try {
      // the main page loads everybody (the drop-down shows each employee's count); a single employee's history loads only theirs
      setData(await api.allSelfieRecords({ from: rFrom, to: rTo, userId: history ? userId : undefined }));
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [rFrom, rTo, userId, history]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  const live = useRealtime('selfies', [{ table: 'selfie_records' }], () => load());

  // check-in + check-out of every employee and day, newest first
  const groups = useMemo(() => groupRecords(data ?? []), [data]);

  const counts = useMemo(() => {
    const m = new Map<string, number>();
    groups.forEach((g) => m.set(g.user_id, (m.get(g.user_id) ?? 0) + 1));
    return m;
  }, [groups]);
  const people = useMemo(() => {
    const m = new Map<string, { id: string; name: string; dept: string | null }>();
    team.forEach((p) => m.set(p.id, { id: p.id, name: p.full_name, dept: p.department }));
    groups.forEach((g) => { if (!m.has(g.user_id)) m.set(g.user_id, { id: g.user_id, name: g.name, dept: g.dept }); });
    return [...m.values()].sort((a, b) => a.name.localeCompare(b.name));
  }, [team, groups]);

  const minsOf = (g: Group) => (g.inn && g.out ? Math.max(0, Math.round((new Date(g.out.captured_at).getTime() - new Date(g.inn.captured_at).getTime()) / 60000)) : null);
  const isShort = (g: Group) => { const m = minsOf(g); return m != null && m < 480; };
  const isFar = (g: Group) => (g.inn?.distance_m ?? 0) > 200 || (g.out?.distance_m ?? 0) > 200;
  const placeOk = (g: Group) => {
    if (placeIdx === 1) return true;
    if (placeIdx === 0) return isForeignGroup(g);   // every foreign punch, however it was saved
    const s = placeOptions[placeIdx];
    return g.inn?.site_name === s || g.out?.site_name === s;
  };
  const recOk = (g: Group) => (recIdx === 0 ? true : recIdx === 1 ? !!g.out : recIdx === 2 ? !!g.inn && !g.out : recIdx === 3 ? isShort(g) : isFar(g));
  const keep = (g: Group) => {
    if (userId && g.user_id !== userId) return false;
    if (!history) return placeOk(g) && recOk(g);
    if (kind === 'IN') return !!g.inn;
    if (kind === 'OUT') return !!g.out;
    if (place === 'Foreign Location' && !isForeignPlace(g)) return false;
    if (place === 'Site' && isForeignPlace(g)) return false;
    if (kind === 'Outside') return !!(g.inn?.outside || g.out?.outside);
    return true;
  };
  const shown = useMemo(() => groups.filter(keep), [groups, userId, kind, place, recIdx, placeIdx, history, placeOptions]);   // eslint-disable-line react-hooks/exhaustive-deps
  // the summary cards count by Employee and Place only (the RECORDS filter is what they set)
  const base = useMemo(() => groups.filter((g) => (!userId || g.user_id === userId) && placeOk(g)), [groups, userId, placeIdx, placeOptions]);   // eslint-disable-line react-hooks/exhaustive-deps
  const stats = {
    inn: base.filter((g) => g.inn).length, out: base.filter((g) => g.out).length, still: base.filter((g) => g.inn && !g.out).length,
    short: base.filter(isShort).length, far: base.filter(isFar).length,
    emps: new Set(base.map((g) => g.user_id)).size, mins: base.reduce((a, g) => a + (minsOf(g) ?? 0), 0),
  };
  // day list: A-Z by name; one employee over a month: by date
  const listRows = useMemo(() => [...shown].sort(mode === 'month' && userId
    ? (a, b) => a.day.localeCompare(b.day)
    : (a, b) => a.name.localeCompare(b.name) || a.day.localeCompare(b.day)), [shown, mode, userId]);
  // month list (all employees): one row per employee
  const monthRows = useMemo(() => {
    const m = new Map<string, { id: string; name: string; empId: string; inn: number; out: number; noOut: number; mins: number }>();
    for (const g of shown) {
      const e = m.get(g.user_id) ?? { id: g.user_id, name: g.name, empId: (g.inn ?? g.out)?.employee?.username ?? '', inn: 0, out: 0, noOut: 0, mins: 0 };
      if (g.inn) e.inn += 1;
      if (g.out) e.out += 1;
      if (g.inn && !g.out) e.noOut += 1;
      e.mins += minsOf(g) ?? 0;
      m.set(g.user_id, e);
    }
    return [...m.values()].sort((a, b) => a.name.localeCompare(b.name));
  }, [shown]);   // eslint-disable-line react-hooks/exhaustive-deps
  const hm = (mins: number) => `${Math.floor(mins / 60)}h ${String(mins % 60).padStart(2, '0')}m`;
  const resetFilters = () => { setUserId(undefined); setPlaceIdx(1); setRecIdx(0); };

  // ---- Foreign Location details (from what is stored: place note, GPS, reason, selfies, allotted sites)
  const foreignCount = groups.filter(isForeignGroup).length;
  const foreignBadge = `${foreignCount} ${mode === 'month' ? 'this month' : dayVal === today ? 'today' : 'that day'}`;
  const foreignPlace = (g: Group) => {
    const r = (g.inn ?? g.out)!;
    const note = (g.inn?.note ?? g.out?.note ?? '').trim();
    return note || (isForeignSiteName(r.site_name) ? 'Foreign location' : r.site_name);
  };
  const foreignReason = (g: Group) => ((g.inn?.reason ?? g.out?.reason) ?? '').trim();
  const foreignGps = (g: Group) => { const r = (g.inn ?? g.out)!; return r.lat != null && r.lng != null ? `${r.lat.toFixed(5)}, ${r.lng.toFixed(5)}` : ''; };
  const kmAway = (m: number) => (m < 1000 ? `${Math.round(m)} m away` : `${(m / 1000).toFixed(1)} km away`);
  // nearest site that is allotted to this employee (else the nearest work site) and how far the foreign punch was from it
  const nearestAllotted = (g: Group): { name: string; m: number } | null => {
    const r = (g.inn ?? g.out)!;
    if (r.lat == null || r.lng == null) return null;
    const real = allSites.filter((s) => !s.is_office && !isForeignSiteName(s.name));
    const mine = new Set(siteAccess.filter((a) => a.user_id === g.user_id).map((a) => a.site_id));
    let pool = real.filter((s) => mine.has(s.id));
    if (pool.length === 0) pool = real;
    let best: { name: string; m: number } | null = null;
    for (const s of pool) { const m = distanceM(r.lat, r.lng, s.lat, s.lng); if (!best || m < best.m) best = { name: s.name, m }; }
    return best;
  };
  const shiftDay = (d: number) => { const t = new Date(`${dayVal}T00:00:00Z`); t.setUTCDate(t.getUTCDate() + d); const v = t.toISOString().slice(0, 10); if (v <= today) setDayVal(v); };
  const shiftMonth = (d: number) => {
    let m = ym.m + d; let y = ym.y;
    if (m < 1) { m = 12; y -= 1; } if (m > 12) { m = 1; y += 1; }
    if (`${y}-${String(m).padStart(2, '0')}` <= today.slice(0, 7)) setYm({ y, m });
  };
  const nextDisabled = mode === 'day' ? dayVal >= today : `${ym.y}-${mm}` >= today.slice(0, 7);

  const removePhoto = (r: SelfieRecord) =>
    Alert.alert('Delete this photo?', 'The selfie is removed for good. The check-in record (time and location) is kept.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        try { await api.deleteSelfiePhoto(r.id); setOpen(null); setUrl(null); await load(); }
        catch (e) { Alert.alert('Could not delete', errorText(e)); }
      } },
    ]);
  const view = async (r: SelfieRecord) => {
    setOpen(r);
    setUrl(null);
    if (!r.photo_path) return; // outside the site area: no selfie was accepted
    try { setUrl(await api.selfieUrl(r.photo_path)); } catch (e) { Alert.alert('Photo unavailable', errorText(e)); setOpen(null); }
  };

  // PDF / Excel: exactly what the filters show (Day or Month, all employees or one, Place and Records applied).
  // Selfies are fetched through short-lived signed URLs and shrunk to small JPEGs; one that cannot load never stops the report.
  const [pdfBusy, setPdfBusy] = useState<'' | 'pdf' | 'xlsx' | 'csv'>('');
  const [progress, setProgress] = useState('');
  // `monthly`: the whole month (employee by employee, day by day); otherwise the day on screen (by time)
  const buildReport = async (source: Group[], monthly?: { from: string; to: string }) => {
    const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;
    const t0 = (g: Group) => (g.inn ?? g.out!).captured_at;
    // All employees: A-Z by name, then by date (the grouped report). One employee / one day: as before.
    const list = [...source].sort(monthly || !userId
      ? (a, b) => a.name.localeCompare(b.name) || a.day.localeCompare(b.day) || t0(a).localeCompare(t0(b))
      : (a, b) => a.day.localeCompare(b.day) || t0(a).localeCompare(t0(b)));
    const paths = [...new Set(list.flatMap((g) => [g.inn?.photo_path, g.out?.photo_path]).filter((p): p is string => !!p))];
    const imgs = new Map<string, string | null>();
    let done = 0;
    setProgress(`Preparing... 0 of ${paths.length} photos`);
    for (let i = 0; i < paths.length; i += 6) {
      await Promise.all(paths.slice(i, i + 6).map(async (p) => {
        try { imgs.set(p, await imageDataUrl(await api.selfieUrl(p))); } catch { imgs.set(p, null); }
        done += 1; setProgress(`Preparing... ${done} of ${paths.length} photos`);
      }));
    }
    const rows: SelfieRow[] = list.map((g) => {
      const main = (g.inn ?? g.out)!;
      const mins = g.inn && g.out ? Math.max(0, Math.round((new Date(g.out.captured_at).getTime() - new Date(g.inn.captured_at).getTime()) / 60000)) : null;
      const still = !g.out;
      return {
        name: g.name, empId: main.employee?.username ?? '', date: dmy(g.day),
        // a foreign-location punch is never empty: the place + the reason in the Check-in Site column
        inSite: isForeignGroup(g) ? `Foreign - ${foreignPlace(g)}${foreignReason(g) ? ` (reason: ${foreignReason(g)})` : ''}` : (g.inn?.site_name ?? ''),
        inTime: g.inn ? fmtTime12(g.inn.captured_at) : '', inDist: g.inn?.distance_m != null ? away(g.inn.distance_m) : '',
        inImg: g.inn?.photo_path ? imgs.get(g.inn.photo_path) ?? null : null, inHas: !!g.inn?.photo_path,
        outSite: g.out?.site_name ?? '', outTime: g.out ? fmtTime12(g.out.captured_at) : '', outDist: g.out?.distance_m != null ? away(g.out.distance_m) : '',
        outImg: g.out?.photo_path ? imgs.get(g.out.photo_path) ?? null : null, outHas: !!g.out?.photo_path,
        mins, inDistM: g.inn?.distance_m ?? null, outDistM: g.out?.distance_m ?? null,
        worked: mins != null ? `${worked(g.inn!.captured_at, g.out!.captured_at)}${mins < 480 ? ' (Short)' : ''}` : 'No check-out',
        workedTone: mins != null ? (mins < 480 ? 'short' : 'ok') : 'none',
      } as SelfieRow;
    });
    const days = monthly ? [monthly.from, monthly.to] : [...new Set(list.map((g) => g.day))].sort();
    const period = days.length === 1 ? fmtDateLong(`${days[0]}T12:00:00+05:30`) : `${dmy(days[0])} to ${dmy(days[days.length - 1])}`;
    const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const month = `${MONTHS[Number(days[0].slice(5, 7)) - 1]} ${days[0].slice(0, 4)}.`;
    const empName = userId ? (name ?? list[0].name) : undefined;
    const empId = userId ? (list[0].inn ?? list[0].out)?.employee?.username : undefined;
    const info: SelfieReportInfo = {
      period, month, showDate: !!monthly || days.length > 1 || !!userId, employee: empName ? `${empName}${empId ? ` (${empId})` : ''}` : undefined,
      // plain ASCII: the browser's own date text has a narrow no-break space that the PDF font cannot print (this made the PDF fail)
      generated: `${dmy(istDateISO())} ${fmtTime12(new Date())}`,
      by: profile?.full_name,
    };
    const file = `cvp_selfie_attendance_${empName ? empName.trim().replace(/\s+/g, '_') + '_' : 'all_'}${days[0]}_to_${days[days.length - 1]}`;
    return { rows, info, file };
  };
  // Place = Foreign Location: the Foreign Location register (PDF / Excel / CSV) with place, nearest allotted site, reason and both selfies
  const exportForeign = async (kind: 'pdf' | 'xlsx' | 'csv') => {
    const monthly = mode === 'month' ? { from: mFrom, to: mLast } : undefined;
    const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;
    const t0 = (g: Group) => (g.inn ?? g.out!).captured_at;
    const list = [...shown].sort((a, b) => a.name.localeCompare(b.name) || a.day.localeCompare(b.day) || t0(a).localeCompare(t0(b)));
    setPdfBusy(kind);
    try {
      if (list.length === 0) { Alert.alert('Nothing to export', 'No foreign location records for these filters.'); return; }
      const imgs = new Map<string, string | null>();
      if (kind !== 'csv') {
        const paths = [...new Set(list.flatMap((g) => [g.inn?.photo_path, g.out?.photo_path]).filter((p): p is string => !!p))];
        let done = 0; setProgress(`Preparing... 0 of ${paths.length} photos`);
        for (let i = 0; i < paths.length; i += 6) {
          await Promise.all(paths.slice(i, i + 6).map(async (p) => {
            try { imgs.set(p, await imageDataUrl(await api.selfieUrl(p))); } catch { imgs.set(p, null); }
            done += 1; setProgress(`Preparing... ${done} of ${paths.length} photos`);
          }));
        }
      }
      const rows: ForeignRow[] = list.map((g) => {
        const main = (g.inn ?? g.out)!;
        const mins = minsOf(g); const na = nearestAllotted(g);
        return {
          name: g.name, empId: main.employee?.username ?? '', date: dmy(g.day),
          place: foreignPlace(g), gps: foreignGps(g),
          nearSite: na?.name ?? '', nearDist: na ? kmAway(na.m) : '', reason: foreignReason(g),
          inTime: g.inn ? fmtTime12(g.inn.captured_at) : '', inImg: g.inn?.photo_path ? imgs.get(g.inn.photo_path) ?? null : null, inHas: !!g.inn?.photo_path,
          outTime: g.out ? fmtTime12(g.out.captured_at) : '', outImg: g.out?.photo_path ? imgs.get(g.out.photo_path) ?? null : null, outHas: !!g.out?.photo_path,
          worked: mins != null ? `${worked(g.inn!.captured_at, g.out!.captured_at)}${mins < 480 ? ' (Short)' : ''}` : (g.day === today ? 'Working' : 'No check-out'),
          workedTone: mins != null ? (mins < 480 ? 'short' : 'ok') : (g.day === today ? 'still' : 'none'),
        };
      });
      const days = monthly ? [monthly.from, monthly.to] : [...new Set(list.map((g) => g.day))].sort();
      const period = days.length === 1 ? fmtDateLong(`${days[0]}T12:00:00+05:30`) : `${dmy(days[0])} to ${dmy(days[days.length - 1])}`;
      const month = `${MONTH_NAMES[Number(days[0].slice(5, 7)) - 1]} ${days[0].slice(0, 4)}.`;
      const grouped = !!monthly || !!userId;
      const info: SelfieReportInfo = { period, month, showDate: !!monthly || days.length > 1 || !!userId, generated: `${dmy(istDateISO())} ${fmtTime12(new Date())}`, by: profile?.full_name };
      const file = `cvp_selfie_foreign_location_${days[0]}_to_${days[days.length - 1]}`;
      if (kind === 'csv') {
        await shareCsv(`${file}.csv`, rows.map((r, i) => ({
          'Sr. No.': i + 1, 'Name of the Employee': r.name, 'Emp ID': r.empId, Date: r.date,
          'Foreign Place (entered)': r.place, 'GPS (lat, lng)': r.gps, 'Nearest Allotted Site': r.nearSite, 'Distance from Nearest Site': r.nearDist,
          'Reason for Foreign Location': r.reason || 'No reason given',
          'Check-in Time': r.inTime, 'Check-in Selfie': r.inHas ? 'selfie available' : '-',
          'Check-out Time': r.outTime, 'Check-out Selfie': r.outHas ? 'selfie available' : '-', 'Worked Hours': r.worked,
        })));
        return;
      }
      setProgress(kind === 'pdf' ? 'Creating the PDF...' : 'Creating the Excel file...');
      if (kind === 'pdf') await selfieForeignPdf(`${file}.pdf`, info, rows, grouped);
      else await selfieForeignXlsx(`${file}.xlsx`, info, rows, grouped);
    } catch (e) {
      Alert.alert('Export failed', errorText(e));
    } finally {
      setPdfBusy(''); setProgress('');
    }
  };
  const exportReport = async (kind: 'pdf' | 'xlsx') => {
    if (foreignMode) return exportForeign(kind);
    const monthly = !history && mode === 'month' ? { from: mFrom, to: mLast } : undefined;
    const source = shown;   // the month (or day) is already loaded and filtered
    setPdfBusy(kind);
    try {
      if (source.length === 0) { Alert.alert('Nothing to export', 'No selfie attendance records for these filters.'); return; }
      const photos = source.reduce((n, g) => n + (g.inn?.photo_path ? 1 : 0) + (g.out?.photo_path ? 1 : 0), 0);
      if (monthly && photos > 300) {
        const msg = `This report has ${source.length} rows and ${photos} selfies. Preparing it can take a few minutes. Continue?`;
        const ok = Platform.OS === 'web' ? window.confirm(msg)
          : await new Promise<boolean>((res) => Alert.alert('Large report', msg, [{ text: 'Cancel', style: 'cancel', onPress: () => res(false) }, { text: 'Continue', onPress: () => res(true) }]));
        if (!ok) return;
      }
      const { rows, info, file } = await buildReport(source, monthly);
      setProgress(kind === 'pdf' ? 'Creating the PDF...' : 'Creating the Excel file...');
      if (userId) {
        if (kind === 'pdf') await selfieReportPdf(`${file}.pdf`, info, rows);
        else await selfieReportXlsx(`${file}.xlsx`, info, rows);
      } else if (kind === 'pdf') await selfieAllPdf(`${file}.pdf`, info, rows);   // all employees: A-Z, grouped by employee
      else await selfieAllXlsx(`${file}.xlsx`, info, rows);
    } catch (e) {
      Alert.alert('Export failed', errorText(e));
    } finally {
      setPdfBusy(''); setProgress('');
    }
  };
  const exportPdf = () => exportReport('pdf');
  const exportXlsx = () => exportReport('xlsx');

  // Travel between two sites: for a Check In, the employee's previous Check Out on the same day at ANOTHER site
  // gives the distance between the two places and the time spent on the way.
  const travelFrom = (g: Group) => {
    const r = g.inn;
    if (!r || r.lat == null || r.lng == null) return null;
    const t = new Date(r.captured_at).getTime();
    const prev = (data ?? [])
      .filter((x) => x.user_id === r.user_id && x.kind === 'OUT' && x.lat != null && x.lng != null
        && istDateISO(x.captured_at) === g.day && new Date(x.captured_at).getTime() < t)
      .sort((a, b) => new Date(b.captured_at).getTime() - new Date(a.captured_at).getTime())[0];
    if (!prev || prev.site_name === r.site_name) return null;
    const mins = Math.max(0, Math.round((t - new Date(prev.captured_at).getTime()) / 60000));
    const time = mins < 60 ? `${mins} min` : `${Math.floor(mins / 60)} hr ${mins % 60} min`;
    return { from: prev.site_name, outAt: prev.captured_at, km: fmtDistance(distanceM(prev.lat!, prev.lng!, r.lat, r.lng)), time };
  };

  const renderGroup = (g: Group, bodyOnly = false) => {
    const isOpen = !!expanded[g.key];
    const main = g.inn ?? g.out!;
    const outside = !!(g.inn?.outside || g.out?.outside);
    const noSelfie = outside && !(g.inn?.photo_path || g.out?.photo_path);
    const when = g.out ? `Check-out ${fmtTime12(g.out.captured_at)}` : `Check-in ${fmtTime12(g.inn!.captured_at)}`;
    const thumb = g.inn?.photo_path ?? g.out?.photo_path ?? null;
    const site = allSites.find((s) => s.name === main.site_name) ?? null;
    const dist = g.inn && site && g.inn.lat != null && g.inn.lng != null ? distanceM(g.inn.lat, g.inn.lng, site.lat, site.lng) : (g.inn?.distance_m ?? null);
    const tr = isOpen ? travelFrom(g) : null;
    const foreignIn = g.inn?.foreign_loc ? g.inn : null;
    const foreignOut = g.out?.foreign_loc ? g.out : null;
    const foreign = foreignIn ?? foreignOut;
    const foreignPill = foreignIn && foreignOut ? 'In & Out - Foreign' : foreignIn ? 'In - Foreign' : 'Out - Foreign';
    return (
      <View key={g.key} style={bodyOnly ? undefined : st.rec}>
        {bodyOnly ? null : (<Pressable style={[st.recHead, !wide && st.recHeadM]} onPress={() => setExpanded((e) => ({ ...e, [g.key]: !e[g.key] }))}>
          <Thumb path={thumb} />
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={st.recName} numberOfLines={2}>{g.name}</Text>
            <View style={st.metaRow}>
              <Ionicons name="calendar-outline" size={12} color={C.muted} /><Text style={st.recSub}>{fmtDateLong(main.captured_at)}</Text>
              <Ionicons name={g.out ? 'log-out-outline' : 'log-in-outline'} size={12} color={C.muted} /><Text style={st.recSub}>{when}</Text>
              <Ionicons name="location-outline" size={12} color={C.muted} /><Text style={st.recSub} numberOfLines={1}>{main.site_name}</Text>
            </View>
          </View>
          <View style={[st.pills, !wide && st.pillsM]}>
            {isForeignPlace(g) ? <Pill text="Foreign Location" tone="amber" /> : null}
            {outside ? (
              <>
                <Pill text={noSelfie ? 'Outside area - no selfie' : 'Outside area'} tone="red" />
                <Pill text="Needs review" tone="amber" />
              </>
            ) : foreign ? (
              <Pill text={foreignPill} tone="amber" />
            ) : g.out ? (
              <>
                <Pill text="Check Out" tone="blue" />
                <Pill text="Present" tone="green" />
              </>
            ) : (
              <>
                <Pill text="Check In" tone="green" />
                <Pill text={g.day === today ? 'Still working' : 'No check-out'} tone="amber" />
              </>
            )}
          </View>
          <View style={[st.chev, isOpen && st.chevOn, !wide && st.chevM]}>
            <Ionicons name={isOpen ? 'chevron-up' : 'chevron-down'} size={20} color={isOpen ? C.white : C.blue} />
          </View>
        </Pressable>)}
        {isOpen ? (
          <View style={[st.recBody, wide && { flexDirection: 'row', alignItems: 'flex-start' }]}>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              {[g.inn, g.out].map((x, i) => (
                <View key={i} style={{ alignItems: 'center', gap: 4 }}>
                  <Pressable onPress={() => (x?.photo_path ? view(x) : null)}>
                    <Thumb path={x?.photo_path ?? null} size={wide ? 120 : 96} radius={14} />
                  </Pressable>
                  <Text style={st.dLabel}>{i === 0 ? 'Check-in selfie' : 'Check-out selfie'}</Text>
                </View>
              ))}
            </View>
            <View style={{ flex: 1, minWidth: 0, gap: 8 }}>
              <View style={st.tiles}>
                <Tile icon="business-outline" label="Site name" value={main.site_name} note={isForeignPlace(g) ? 'Foreign Location (chosen site)' : 'Assigned work site'} />
                <Tile icon="locate-outline" label="GPS location" value={coords(main.lat, main.lng)} note={main.lat != null ? 'Captured with the selfie' : undefined} />
                <Tile icon="navigate-outline" label="Distance from site" value={dist != null ? away(dist) : '-'}
                  note={dist == null ? undefined : outside ? 'Outside site area' : foreignIn ? 'Foreign location (nearest site)' : `Inside site area${site ? ` (radius ${site.radius_m} m)` : ''}`} tone={outside ? 'red' : foreignIn ? 'amber' : 'green'} />
                <Tile icon="log-in-outline" label="Check-in" value={g.inn ? fmtTime12(g.inn.captured_at) : '-'} note={g.inn ? (g.inn.photo_path ? 'Selfie captured' : 'No selfie') : 'Not recorded'} />
                <Tile icon="log-out-outline" label="Check-out" value={g.out ? fmtTime12(g.out.captured_at) : '-'} note={g.out ? (g.out.photo_path ? 'Selfie captured' : 'No selfie') : 'Not checked out'} />
                <Tile icon="time-outline" label="Worked" value={g.inn && g.out ? worked(g.inn.captured_at, g.out.captured_at) : '-'}
                  note={g.out?.note || g.inn?.note ? `Note: ${g.out?.note || g.inn?.note}` : undefined} />
              </View>
              {tr ? (
                <View style={[st.dCell, { borderColor: '#BFD8F5', backgroundColor: '#EEF6FF' }]}>
                  <Text style={st.dLabel}>Travel from previous site</Text>
                  <Text style={st.dVal}>From {tr.from} (checked out {fmtTime12(tr.outAt)}) - {tr.km} straight line - {tr.time} on the way</Text>
                </View>
              ) : null}
              {g.out && !foreignOut ? (
                <View style={[st.dCell, { borderColor: '#BFE3CC', backgroundColor: '#F2FBF5' }]}>
                  <Text style={st.dLabel}>Check-out location - at {fmtTime12(g.out.captured_at)}</Text>
                  <Text style={st.dVal}>Site: {g.out.site_name || main.site_name}</Text>
                  <Text style={st.dVal}>Place: {coords(g.out.lat, g.out.lng)}{g.out.distance_m != null ? ` - ${away(g.out.distance_m)} from the site point` : ''}</Text>
                  {g.out.lat != null && g.out.lng != null ? (
                    <Pressable onPress={() => Linking.openURL(`https://maps.google.com/?q=${g.out!.lat},${g.out!.lng}`)}>
                      <Text style={[st.dVal, { color: C.blue, fontWeight: '800' }]}>Open the check-out location in Google Maps</Text>
                    </Pressable>
                  ) : null}
                </View>
              ) : null}
              {[foreignIn, foreignOut].filter((x): x is SelfieRecord => !!x).map((f) => (
                <View key={f.kind} style={[st.dCell, { borderColor: '#F3C98B', backgroundColor: '#FFF9EE' }]}>
                  <Text style={st.dLabel}>Foreign location - {f.kind === 'IN' ? 'check-in' : 'check-out'} at {fmtTime12(f.captured_at)}</Text>
                  <Text style={st.dVal}>Place: {coords(f.lat, f.lng)} - {away(f.distance_m) || '-'} from the nearest site</Text>
                  <Text style={st.dVal}>Reason: {f.reason || '-'}</Text>
                  {f.lat != null && f.lng != null ? (
                    <Pressable onPress={() => Linking.openURL(`https://maps.google.com/?q=${f.lat},${f.lng}`)}>
                      <Text style={[st.dVal, { color: C.blue, fontWeight: '800' }]}>Open this location in Google Maps</Text>
                    </Pressable>
                  ) : null}
                </View>
              ))}
              {[g.inn, g.out].filter((x): x is SelfieRecord => !!x && x.place_type === 'Foreign Location').map((f) => (
                <View key={`fp-${f.kind}`} style={[st.dCell, { borderColor: '#D9C9F5', backgroundColor: '#FAF7FF' }]}>
                  <Text style={st.dLabel}>Foreign Location attendance - {f.kind === 'IN' ? 'check-in' : 'check-out'} at {fmtTime12(f.captured_at)}</Text>
                  <Text style={st.dVal}>Site: {f.site_name} - {f.distance_m != null ? `${away(f.distance_m)} from the site point` : 'distance not recorded'}</Text>
                  <Text style={st.dVal}>Reason: {f.reason || '-'}</Text>
                </View>
              ))}
              <Row style={{ flexWrap: 'wrap' }}>
                {g.inn?.photo_path ? <Button title={g.out?.photo_path ? 'Check-in photo' : 'Open full photo'} icon="image-outline" variant="secondary" small onPress={() => view(g.inn!)} /> : null}
                {g.out?.photo_path ? <Button title="Check-out photo" icon="image-outline" variant="secondary" small onPress={() => view(g.out!)} /> : null}
                <Button title="Employee attendance" icon="calendar-outline" variant="secondary" small onPress={() => nav.navigate('EmployeeDetail', { userId: g.user_id })} />
                <Button title="View on Live Map" icon="map-outline" variant="secondary" small onPress={() => nav.navigate('LiveMap')} />
              </Row>
            </View>
          </View>
        ) : null}
      </View>
    );
  };

  // ---------------------------------------------------------------- new list
  const dmyOf = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;
  const workedPill = (g: Group) => {
    const m = minsOf(g);
    if (m != null) return <Pill text={m < 480 ? `${hm(m)} (Short)` : hm(m)} tone={m < 480 ? 'red' : 'green'} />;
    return <Pill text={g.day === today ? 'Working' : 'No check-out'} tone={g.day === today ? 'amber' : 'red'} />;
  };
  const showDateCol = mode === 'month';   // one employee over a month: a Date column
  const dayHead = () => (wide ? (
    <View style={st.tHead}>
      {showDateCol ? <Text style={[st.th, { flex: 1.1 }]}>DATE</Text> : null}
      <Text style={[st.th, { flex: 2.4 }]}>EMPLOYEE</Text>
      <Text style={[st.th, { flex: 2 }]}>CHECK-IN SITE</Text>
      <Text style={[st.th, { flex: 1.6 }]}>CHECK-IN · DISTANCE</Text>
      <Text style={[st.th, { flex: 2 }]}>CHECK-OUT SITE</Text>
      <Text style={[st.th, { flex: 1.6 }]}>CHECK-OUT · DISTANCE</Text>
      <Text style={[st.th, { flex: 1.5 }]}>WORKED</Text>
    </View>
  ) : null);
  const dayRow = (g: Group) => {
    const main = g.inn ?? g.out!;
    const diff = !!(g.inn && g.out && g.out.site_name !== g.inn.site_name);
    const thumb = g.inn?.photo_path ?? g.out?.photo_path ?? null;
    const toggle = () => setExpanded((e) => ({ ...e, [g.key]: !e[g.key] }));
    if (!wide) {
      return (
        <View key={g.key} style={st.rec}>
          <Pressable onPress={toggle} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, paddingHorizontal: 6 }}>
            <Thumb path={thumb} size={48} radius={12} />
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={st.recName} numberOfLines={1}>{g.name}</Text>
              <Text style={st.recSub} numberOfLines={1}>{showDateCol ? `${dmyOf(g.day)} · ` : ''}{main.site_name}</Text>
              <Text style={{ fontSize: 12.5, fontWeight: '700', color: NAVY, marginTop: 2 }}>In {g.inn ? fmtTime12(g.inn.captured_at) : '-'} · Out {g.out ? fmtTime12(g.out.captured_at) : '-'}</Text>
            </View>
            {workedPill(g)}
          </Pressable>
          {renderGroup(g, true)}
        </View>
      );
    }
    return (
      <View key={g.key} style={st.rec}>
        <Pressable onPress={toggle} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 6 }}>
          {showDateCol ? <Text style={[st.td, { flex: 1.1 }]}>{dmyOf(g.day)}</Text> : null}
          <View style={{ flex: 2.4, flexDirection: 'row', alignItems: 'center', gap: 10, minWidth: 0, paddingRight: 8 }}>
            <Thumb path={thumb} size={36} radius={10} />
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={st.recName} numberOfLines={1}>{g.name}</Text>
              <Text style={st.recSub} numberOfLines={1}>{main.employee?.username ?? ''}</Text>
            </View>
          </View>
          <Text style={[st.td, { flex: 2 }]} numberOfLines={2}>{g.inn?.site_name ?? '-'}</Text>
          <Text style={[st.td, { flex: 1.6 }]}>{g.inn ? fmtTime12(g.inn.captured_at) : '-'}
            {g.inn?.distance_m != null ? <Text style={{ color: g.inn.distance_m > 200 ? '#C00000' : '#64748B', fontWeight: g.inn.distance_m > 200 ? '800' : '600' }}> · {away(g.inn.distance_m)}</Text> : null}</Text>
          <Text style={[st.td, { flex: 2 }, diff ? { color: '#1F4E9E', fontWeight: '800' } : null]} numberOfLines={2}>{g.out?.site_name ?? '-'}</Text>
          <Text style={[st.td, { flex: 1.6 }]}>{g.out ? fmtTime12(g.out.captured_at) : '-'}
            {g.out?.distance_m != null ? <Text style={{ color: g.out.distance_m > 200 ? '#C00000' : '#64748B', fontWeight: g.out.distance_m > 200 ? '800' : '600' }}> · {away(g.out.distance_m)}</Text> : null}</Text>
          <View style={{ flex: 1.5, alignItems: 'flex-start' }}>{workedPill(g)}</View>
        </Pressable>
        {renderGroup(g, true)}
      </View>
    );
  };
  const monthHead = () => (wide ? (
    <View style={st.tHead}>
      <Text style={[st.th, { flex: 3 }]}>EMPLOYEE</Text>
      <Text style={[st.th, { flex: 1.3 }]}>DAYS CHECKED IN</Text>
      <Text style={[st.th, { flex: 1.3 }]}>CHECKED OUT</Text>
      <Text style={[st.th, { flex: 1.3 }]}>NO CHECK-OUT</Text>
      <Text style={[st.th, { flex: 1.5 }]}>TOTAL WORKED</Text>
      <Text style={[st.th, { flex: 1.6 }]}>STATUS</Text>
    </View>
  ) : null);
  const monthRow = (e: { id: string; name: string; empId: string; inn: number; out: number; noOut: number; mins: number }) => {
    const pill = <Pill text={e.noOut > 0 ? `${e.noOut} no check-out` : 'On track'} tone={e.noOut > 0 ? 'red' : 'green'} />;
    return (
      <Pressable key={e.id} onPress={() => setUserId(e.id)} accessibilityRole="button" style={[st.rec, { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 6 }]}>
        {wide ? (
          <>
            <View style={{ flex: 3, flexDirection: 'row', alignItems: 'center', gap: 10, minWidth: 0, paddingRight: 8 }}>
              <Avatar name={e.name} size={34} />
              <Text style={st.recName} numberOfLines={1}>{e.name} <Text style={{ fontWeight: '600', color: '#64748B' }}>{e.empId}</Text></Text>
            </View>
            <Text style={[st.td, { flex: 1.3 }]}>{e.inn}</Text>
            <Text style={[st.td, { flex: 1.3 }]}>{e.out}</Text>
            <Text style={[st.td, { flex: 1.3 }]}>{e.noOut}</Text>
            <Text style={[st.td, { flex: 1.5, fontWeight: '800', color: NAVY }]}>{hm(e.mins)}</Text>
            <View style={{ flex: 1.6, alignItems: 'flex-start' }}>{pill}</View>
          </>
        ) : (
          <>
            <Avatar name={e.name} size={44} />
            <View style={{ flex: 1, minWidth: 0, marginLeft: 12 }}>
              <Text style={st.recName} numberOfLines={1}>{e.name}</Text>
              <Text style={st.recSub} numberOfLines={1}>{e.inn} days · {e.out} out · {e.noOut} no check-out</Text>
              <Text style={{ fontSize: 12.5, fontWeight: '800', color: NAVY, marginTop: 2 }}>{hm(e.mins)}</Text>
            </View>
            {pill}
          </>
        )}
      </Pressable>
    );
  };

  const monthLabel = `${MONTH_NAMES[ym.m - 1]} ${ym.y}`;
  const monthChip = mTo < mLast ? `${monthLabel} (1 - ${Number(mTo.slice(8))} ${MONTH_NAMES[ym.m - 1].slice(0, 3)})` : monthLabel;
  const dayLabel = fmtDateLong(`${dayVal}T12:00:00+05:30`);
  const cards = mode === 'day' ? [
    { label: 'Checked in', value: stats.inn, color: NAVY, rec: 0 },
    { label: 'Checked out', value: stats.out, color: '#0E7A4A', rec: 1 },
    { label: 'Still working', value: stats.still, color: '#A86400', rec: 2 },
    { label: 'Short day', value: stats.short, color: '#C00000', rec: 3 },
    { label: 'Far (>200 m)', value: stats.far, color: '#C00000', rec: 4 },
  ] : [
    { label: 'Employees', value: stats.emps, color: NAVY, rec: 0 },
    { label: 'Days checked in', value: stats.inn, color: NAVY, rec: 0 },
    { label: 'Checked out', value: stats.out, color: '#0E7A4A', rec: 1 },
    { label: 'No check-out', value: stats.still, color: '#C00000', rec: 2 },
    { label: 'Total worked', value: `${Math.floor(stats.mins / 60).toLocaleString('en-IN')}h`, color: '#1366D6', rec: 0 },
  ];
  const cardsShown = wide ? cards : mode === 'day' ? [cards[0], cards[1], cards[2]] : [cards[0], cards[1], cards[3]];
  const listTitle = mode === 'day' ? `${dayLabel} · ${shown.length} records · A-Z`
    : userId ? `${monthLabel} · ${name ?? 'Employee'} · ${shown.length} days` : `${monthLabel} · ${monthRows.length} employees · A-Z`;

  // ---- Foreign Location view: who, where, why + both selfies
  const foreignList = [...shown].sort((a, b) => a.name.localeCompare(b.name) || a.day.localeCompare(b.day) || (a.inn ?? a.out!).captured_at.localeCompare((b.inn ?? b.out!).captured_at));
  const fStats = {
    emps: new Set(shown.map((g) => g.user_id)).size, out: shown.filter((g) => g.out).length, still: shown.filter((g) => g.inn && !g.out).length,
  };
  const reasonBox = (g: Group) => {
    const r = foreignReason(g);
    return r
      ? <View style={{ backgroundColor: '#FFF7ED', borderLeftWidth: 3, borderLeftColor: '#EA580C', borderRadius: 6, padding: 8 }}><Text style={{ fontSize: 12.5, fontWeight: '600', color: '#6E3200' }}>{r}</Text></View>
      : <Text style={{ fontSize: 12.5, fontStyle: 'italic', color: '#94A3B8' }}>No reason given</Text>;
  };
  const selfieBox = (rec: SelfieRecord | undefined, label: string, size: number) => (
    <View style={{ alignItems: 'center', gap: 4 }}>
      {rec?.photo_path ? (
        <Pressable onPress={() => view(rec)} accessibilityRole="button"><Thumb path={rec.photo_path} size={size} radius={12} /></Pressable>
      ) : (
        <View style={{ width: size, height: size, borderRadius: 12, borderWidth: 1, borderStyle: 'dashed', borderColor: '#B8C4D2', alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 10, color: '#94A3B8', textAlign: 'center' }}>{rec ? 'No selfie' : 'Not out'}</Text>
        </View>
      )}
      <Text style={st.recSub}>{label} {rec ? fmtTime12(rec.captured_at) : '-'}</Text>
    </View>
  );
  const foreignHead = () => (wide ? (
    <View style={st.tHead}>
      <Text style={[st.th, { flex: 2.2 }]}>EMPLOYEE</Text>
      <Text style={[st.th, { flex: 2.4 }]}>FOREIGN PLACE (ENTERED + GPS)</Text>
      <Text style={[st.th, { flex: 1.8 }]}>NEAREST ALLOTTED SITE</Text>
      <Text style={[st.th, { flex: 2.6 }]}>REASON</Text>
      <Text style={[st.th, { flex: 1.2 }]}>CHECK-IN SELFIE</Text>
      <Text style={[st.th, { flex: 1.2 }]}>CHECK-OUT SELFIE</Text>
      <Text style={[st.th, { flex: 1.2 }]}>WORKED</Text>
    </View>
  ) : null);
  const foreignRow = (g: Group) => {
    const main = (g.inn ?? g.out)!;
    const na = nearestAllotted(g); const gps = foreignGps(g);
    const dateTag = mode === 'month' ? `${dmyOf(g.day)} · ` : '';
    if (!wide) {
      return (
        <View key={g.key} style={[st.rec, { padding: 12, gap: 8 }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Thumb path={g.inn?.photo_path ?? g.out?.photo_path ?? null} size={44} radius={12} />
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={st.recName} numberOfLines={1}>{g.name}</Text>
              <Text style={st.recSub} numberOfLines={1}>{dateTag}{main.employee?.username ?? ''}</Text>
            </View>
            {workedPill(g)}
          </View>
          <Text style={{ fontSize: 14, fontWeight: '800', color: '#C25A00' }}>{foreignPlace(g)}</Text>
          {gps ? <Text style={st.recSub}>📍 {gps}{na ? ` · ${na.name}, ` : ''}{na ? <Text style={{ color: '#C00000', fontWeight: '800' }}>{kmAway(na.m)}</Text> : null}</Text> : null}
          {reasonBox(g)}
          <View style={{ flexDirection: 'row', gap: 16 }}>{selfieBox(g.inn, 'In', 84)}{selfieBox(g.out, 'Out', 84)}</View>
        </View>
      );
    }
    return (
      <View key={g.key} style={[st.rec, { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 6 }]}>
        <View style={{ flex: 2.2, flexDirection: 'row', alignItems: 'center', gap: 10, minWidth: 0, paddingRight: 8 }}>
          <Avatar name={g.name} size={34} />
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={st.recName} numberOfLines={2}>{g.name}</Text>
            <Text style={st.recSub} numberOfLines={1}>{dateTag}{main.employee?.username ?? ''}</Text>
          </View>
        </View>
        <View style={{ flex: 2.4, paddingRight: 10 }}>
          <Text style={{ fontSize: 13.5, fontWeight: '800', color: '#C25A00' }}>{foreignPlace(g)}</Text>
          {gps ? <Text style={st.recSub}>📍 {gps}</Text> : null}
        </View>
        <View style={{ flex: 1.8, paddingRight: 10 }}>
          <Text style={st.td} numberOfLines={2}>{na?.name ?? '-'}</Text>
          {na ? <Text style={{ fontSize: 12.5, fontWeight: '800', color: '#C00000' }}>{kmAway(na.m)}</Text> : null}
        </View>
        <View style={{ flex: 2.6, paddingRight: 10 }}>{reasonBox(g)}</View>
        <View style={{ flex: 1.2 }}>{selfieBox(g.inn, 'In', 64)}</View>
        <View style={{ flex: 1.2 }}>{selfieBox(g.out, 'Out', 64)}</View>
        <View style={{ flex: 1.2, alignItems: 'flex-start' }}>{workedPill(g)}</View>
      </View>
    );
  };

  const placeField = (
    <View style={{ flex: 1, minWidth: 0, zIndex: 5 }}>
      <Text style={st.flabel}>Place</Text>
      <PlacePicker sites={siteNames} value={placeIdx} onChange={setPlaceIdx} foreignBadge={foreignBadge} />
    </View>
  );
  const recField = (
    <View style={{ flex: 1, minWidth: 0 }}>
      <Text style={st.flabel}>Records</Text>
      <Dropdown width="100%" value={recIdx} onChange={setRecIdx} options={RECORDS.map((l, i) => ({ value: i, label: l }))} />
    </View>
  );

  const modern = (
    <View style={{ width: '100%', maxWidth: 1180, alignSelf: 'center' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.title}>Selfie Attendance</Text>
          <Text style={st.subtitle}>Site selfies with GPS and distance</Text>
        </View>
        <LiveDot live={live} />
      </View>

      <Card style={{ zIndex: 5 }}>
        <View style={{ flexDirection: bar ? 'row' : 'column', gap: 12, alignItems: bar ? 'flex-start' : 'stretch', zIndex: 5 }}>
          <View style={{ width: bar ? 168 : '100%' }}>
            <Text style={st.flabel}>Report</Text>
            <Segmented value={mode} onChange={setMode} options={[{ value: 'day', label: 'Day' }, { value: 'month', label: 'Month' }]} />
          </View>
          <View style={{ flex: bar ? 1.25 : undefined, minWidth: bar ? 250 : 0 }}>
            <Text style={st.flabel}>{mode === 'day' ? 'Date' : 'Month'}</Text>
            <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
              {Platform.OS === 'web' ? (
                <>
                  <StepBtn dir={-1} onPress={() => (mode === 'day' ? shiftDay(-1) : shiftMonth(-1))} />
                  <View style={{ flex: 1, minWidth: 0 }}>
                    <DateInput type={mode === 'day' ? 'date' : 'month'} value={mode === 'day' ? dayVal : `${ym.y}-${mm}`} max={mode === 'day' ? today : today.slice(0, 7)}
                      onChange={(v) => { if (mode === 'day') setDayVal(v > today ? today : v); else setYm({ y: Number(v.slice(0, 4)), m: Number(v.slice(5, 7)) }); }} />
                  </View>
                  <StepBtn dir={1} disabled={nextDisabled} onPress={() => (mode === 'day' ? shiftDay(1) : shiftMonth(1))} />
                </>
              ) : mode === 'day' ? (
                <>
                  <StepBtn dir={-1} onPress={() => shiftDay(-1)} />
                  <View style={{ flex: 1, minWidth: 0, marginTop: -6 }}>
                    <PickerField flat label="" mode="date" value={dayVal} maximumDate={new Date(`${today}T00:00:00`)} onChange={(v) => setDayVal(v > today ? today : v)} />
                  </View>
                  <StepBtn dir={1} disabled={nextDisabled} onPress={() => shiftDay(1)} />
                </>
              ) : (
                <View style={{ flex: 1, minWidth: 0 }}>
                  <MonthPicker year={ym.y} month={ym.m} onChange={(y, m) => { if (`${y}-${String(m).padStart(2, '0')}` <= today.slice(0, 7)) setYm({ y, m }); }} />
                </View>
              )}
            </View>
          </View>
          <View style={{ flex: bar ? 1.4 : undefined, minWidth: 0, zIndex: 6 }}>
            <Text style={st.flabel}>Employee</Text>
            <EmployeePicker people={people} counts={counts} total={groups.length} value={userId} onChange={(id) => setUserId(id)} />
          </View>
          {bar ? <>{placeField}{recField}</> : <View style={{ flexDirection: 'row', gap: 12 }}>{placeField}{recField}</View>}
          {isFullAdmin ? (
            <View style={{ flexDirection: 'row', gap: 10, marginTop: bar ? 22 : 0 }}>
              <ExportBtn kind="pdf" title="PDF" grow={!bar} loading={pdfBusy === 'pdf'} disabled={!!pdfBusy} onPress={exportPdf} />
              <ExportBtn kind="xlsx" title="Excel" grow={!bar} loading={pdfBusy === 'xlsx'} disabled={!!pdfBusy} onPress={exportXlsx} />
              {foreignMode ? <ExportBtn kind="csv" title="CSV" grow={!bar} loading={pdfBusy === 'csv'} disabled={!!pdfBusy} onPress={() => exportForeign('csv')} /> : null}
            </View>
          ) : null}
        </View>
        <View style={{ marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#DCE7F3', borderStyle: 'dashed', flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 8 }}>
          <Text style={{ fontSize: 12.5, fontWeight: '700', color: '#64748B' }}>Showing:</Text>
          <FChip text={mode === 'day' ? dayLabel : monthChip} />
          <FChip text={userId ? (name ?? 'Selected employee') : 'All employees'} />
          <FChip text={placeOptions[placeIdx] ?? 'All places'} orange={foreignMode} />
          {recIdx ? <FChip text={RECORDS[recIdx]} /> : null}
          <View style={{ flex: 1, minWidth: 8 }} />
          <Text style={{ fontSize: 12, fontWeight: '600', color: '#64748B' }}>Downloads use these filters · </Text>
          <Pressable onPress={resetFilters} accessibilityRole="button"><Text style={{ fontSize: 12, fontWeight: '800', color: '#1366D6' }}>Reset filters</Text></Pressable>
        </View>
        {pdfBusy ? <Text style={{ marginTop: 8, fontSize: 12.5, fontWeight: '700', color: '#1366D6' }}>{progress || 'Preparing...'}</Text> : null}
      </Card>

      {foreignMode ? (
        <View style={{ marginTop: 14, backgroundColor: '#FFF7ED', borderWidth: 1, borderColor: '#F3C98B', borderRadius: 14, padding: 14, flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Ionicons name="earth-outline" size={18} color="#9A3412" />
            <Text style={{ fontSize: 15, fontWeight: '800', color: '#7C2D12' }}>Foreign Location · {mode === 'day' ? dayLabel : monthLabel}</Text>
          </View>
          <Text style={st.fStat}>{fStats.emps} employees</Text>
          <Text style={st.fStat}>{fStats.out} checked out</Text>
          <Text style={st.fStat}>{fStats.still} still working</Text>
          <Text style={[st.fStat, { flexBasis: 260, flexGrow: 1, fontWeight: '600' }]}>Employees who checked in away from their allotted sites (outside 500 m) with a reason</Text>
        </View>
      ) : (
        <View style={{ flexDirection: 'row', gap: 12, marginTop: 14 }}>
          {cardsShown.map((c) => (
            <SumCard key={c.label} label={c.label} value={c.value} color={c.color} active={c.rec !== 0 && recIdx === c.rec} onPress={() => setRecIdx(c.rec)} />
          ))}
        </View>
      )}

      <Text style={{ marginTop: 16, marginBottom: 8, fontSize: 14, fontWeight: '800', color: NAVY }}>{foreignMode ? `${shown.length} foreign-location records · A-Z` : listTitle}</Text>
      <Card style={{ paddingVertical: 4 }}>
        {!data ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : shown.length === 0 ? (
          <Empty icon={foreignMode ? 'earth-outline' : 'camera-outline'} text={foreignMode ? 'No foreign location records for these filters.' : 'No selfie attendance records for these filters.'} />
        ) : foreignMode ? (
          <>{foreignHead()}{foreignList.map(foreignRow)}</>
        ) : mode === 'month' && !userId ? (
          <>{monthHead()}{monthRows.map(monthRow)}</>
        ) : (
          <>{dayHead()}{listRows.map(dayRow)}</>
        )}
      </Card>
    </View>
  );

  // old page (opened from one employee's "Selfie Records"): unchanged layout
  const legacy = (
    <>
      <Row style={{ justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.title}>{name ? `${name} - ` : ''}Selfie Attendance</Text>
          <Text style={st.subtitle}>Site selfies with GPS and distance - {fmtDateLong(`${to}T12:00:00+05:30`)}</Text>
        </View>
        <LiveDot live={live} />
      </Row>
      <Card style={{ zIndex: 5 }}>
        <View style={{ flexDirection: wide ? 'row' : 'column', gap: 12, marginBottom: 12, zIndex: 5 }}>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={st.filterLabel}>Show records</Text>
            <Dropdown width="100%" value={recView} onChange={setRecView} options={KINDS.map((k, i) => ({ value: i, label: k.label }))} />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={st.filterLabel}>Place</Text>
            <Dropdown width="100%" value={placeView} onChange={setPlaceView} options={PLACES.map((k, i) => ({ value: i, label: k.label }))} />
          </View>
        </View>
        <Text style={st.filterLabel}>Month</Text>
        <MonthPicker year={Number(from.slice(0, 4))} month={Number(from.slice(5, 7))}
          onChange={(y, m) => {
            const m2 = String(m).padStart(2, '0');
            setFrom(`${y}-${m2}-01`);
            setTo(`${y}-${m2}-${String(new Date(y, m, 0).getDate()).padStart(2, '0')}`);
          }} />
        <Row>
          <PickerField label="From date" mode="date" value={from} onChange={(v) => setFrom(v)} />
          <PickerField label="To date" mode="date" value={to} onChange={(v) => setTo(v)} />
        </Row>
        {isFullAdmin ? (
          <Row style={{ marginTop: 10 }}>
            <Button title={pdfBusy === 'pdf' ? progress || 'Preparing...' : 'Download PDF'} icon="document-outline" variant="secondary" loading={pdfBusy === 'pdf'} disabled={!!pdfBusy} onPress={exportPdf} />
            <Button title={pdfBusy === 'xlsx' ? progress || 'Preparing...' : 'Download Excel'} icon="grid-outline" variant="secondary" loading={pdfBusy === 'xlsx'} disabled={!!pdfBusy} onPress={exportXlsx} />
          </Row>
        ) : null}
      </Card>
      <Row style={{ marginTop: 6 }}>
        <Text style={st.section}>Submitted selfie attendance - {shown.length} record(s)</Text>
      </Row>
      <Card style={{ paddingVertical: 4 }}>
        {!data ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : shown.length === 0 ? (
          <Empty icon="camera-outline" text="No selfie attendance records for these filters. Employees submit selfies from Site Selfie after site access is enabled." />
        ) : shown.map((g) => renderGroup(g))}
      </Card>
    </>
  );

  return (
    <Screen>
      {history ? legacy : modern}

      <Modal visible={!!open} transparent animationType="fade" onRequestClose={() => setOpen(null)}>
        <Pressable style={st.backdrop} onPress={() => setOpen(null)}>
          <Pressable style={st.sheet} onPress={() => {}}>
            {open ? (
              <>
                <Text style={st.sheetTitle}>{open.employee?.full_name}</Text>
                <Text style={st.sheetSub}>{open.kind === 'IN' ? 'Check In' : 'Check Out'} - {fmtDateLong(open.captured_at)} - {fmtTime12(open.captured_at)} IST</Text>
                {open.outside ? (
                  <View style={st.outsideBox}>
                    <Ionicons name="warning-outline" size={30} color={C.red} />
                    <Text style={st.outsideTitle}>
                      {open.kind === 'IN' ? 'Checked in' : 'Checked out'} from another location
                    </Text>
                    <Text style={st.outsideText}>
                      {away(open.distance_m) ? `${away(open.distance_m)} away from ${open.site_name}. ` : ''}
                      The employee was outside the allowed site area, so no selfie was accepted.
                    </Text>
                  </View>
                ) : (
                  <View style={st.photoBox}>
                    {url ? <Image source={{ uri: url }} style={st.photo} resizeMode="contain" /> : <ActivityIndicator color={C.blue} />}
                  </View>
                )}
                <Text style={st.meta}>Site / Project: {open.site_name}</Text>
                <Text style={st.meta}>Work note: {open.note || 'Not provided'}</Text>
                <Text style={st.meta}>Location (lat, lng): {coords(open.lat, open.lng)}</Text>
                <Row style={{ marginTop: 10 }}>
                  {url ? <Button title="Open / Download" icon="download-outline" variant="secondary" style={{ flex: 1 }} onPress={() => Linking.openURL(url)} /> : null}
                  {open.photo_path ? <Button title="Delete Photo" icon="trash-outline" variant="danger" style={{ flex: 1 }} onPress={() => removePhoto(open)} /> : null}
                  <Button title="Close" style={{ flex: 1 }} onPress={() => setOpen(null)} />
                </Row>
              </>
            ) : null}
          </Pressable>
        </Pressable>
      </Modal>
    </Screen>
  );
}

const st = StyleSheet.create({
  title: { fontWeight: '800', color: C.ink, fontSize: 22 },
  subtitle: { color: C.muted, fontSize: 12.5, marginTop: 2 },
  section: { fontWeight: '800', color: C.ink, fontSize: 14 },
  hint: { color: C.muted, fontSize: 11.5 },
  monthTitle: { fontSize: 14, fontWeight: '800', color: '#102A45' },
  monthSub: { fontSize: 12, fontWeight: '700', color: '#3A5068', marginTop: 2 },
  flabel: { fontSize: 10.5, lineHeight: 16, fontWeight: '700', color: '#64748B', letterSpacing: 0.6, marginBottom: 6, textTransform: 'uppercase' },
  tHead: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 6, backgroundColor: '#F6F9FD', borderBottomWidth: 1, borderBottomColor: '#E3ECF6', borderTopLeftRadius: 12, borderTopRightRadius: 12 },
  fStat: { fontSize: 13, fontWeight: '800', color: '#7C2D12' },
  th: { fontSize: 10.5, fontWeight: '700', color: '#64748B', letterSpacing: 0.5, paddingRight: 8 },
  td: { fontSize: 13.5, fontWeight: '600', color: '#0B2A4A', paddingRight: 8 },
  filterLabel: { fontSize: 11.5, lineHeight: 16, fontWeight: '700', color: '#3A5068', marginBottom: 6 },
  field: { flexDirection: 'row', alignItems: 'center', gap: 8, height: 44, borderRadius: 10, borderWidth: 1, borderColor: C.line, backgroundColor: '#F1F6FC', paddingHorizontal: 10 },
  fieldText: { flex: 1, fontSize: 14, fontWeight: '800', color: C.ink },
  pop: { position: 'absolute', top: 44, left: 0, right: 0, zIndex: 20, backgroundColor: C.white, borderRadius: 12, borderWidth: 1, borderColor: C.line, padding: 8, shadowColor: '#0B2B4D', shadowOpacity: 0.18, shadowRadius: 18, shadowOffset: { width: 0, height: 8 }, elevation: 8 },
  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderColor: '#B9D4F6', borderRadius: 10, paddingHorizontal: 10, height: 38, marginBottom: 6 },
  searchInput: { flex: 1, fontSize: 14, color: C.ink },
  opt: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 7, paddingHorizontal: 8, borderRadius: 9 },
  optOn: { backgroundColor: '#E6F1FF' },
  optName: { flex: 1, fontSize: 13.5, fontWeight: '700', color: '#17314D' },
  optMeta: { fontSize: 11.5, color: C.muted },
  allIcon: { width: 28, height: 28, borderRadius: 14, backgroundColor: '#D7F3EE', alignItems: 'center', justifyContent: 'center' },
  allIconText: { fontSize: 10, fontWeight: '800', color: '#0F766E' },
  popFoot: { fontSize: 11.5, color: C.muted, paddingHorizontal: 8, paddingTop: 6 },
  rec: { borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  recHead: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, paddingHorizontal: 6 },
  recName: { fontSize: 14.5, fontWeight: '800', color: '#102A45' },
  metaRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 5, marginTop: 3 },
  recSub: { fontSize: 12, color: C.muted, marginRight: 8 },
  pills: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, justifyContent: 'flex-end', maxWidth: 230 },
  chev: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center', backgroundColor: '#EAF3FF', borderWidth: 1, borderColor: '#CFE2FA', flexShrink: 0 },
  chevOn: { backgroundColor: C.blue, borderColor: C.blue },
  chevM: { position: 'absolute', right: 6, top: 12 },
  recHeadM: { flexWrap: 'wrap', paddingRight: 46, rowGap: 8 },
  pillsM: { flexBasis: '100%', maxWidth: '100%', justifyContent: 'flex-start', marginLeft: 58 },
  recBody: { paddingHorizontal: 6, paddingBottom: 12, gap: 12 },
  tiles: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tile: { flexGrow: 1, flexBasis: 150, backgroundColor: '#F8FBFF', borderRadius: 10, borderWidth: 1, borderColor: '#E3ECF6', paddingVertical: 8, paddingHorizontal: 10 },
  tileHead: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  tileLabel: { fontSize: 10, fontWeight: '800', color: '#8594A6', textTransform: 'uppercase' },
  tileVal: { fontSize: 14.5, fontWeight: '800', color: '#102A45', marginTop: 3 },
  tileNote: { fontSize: 11.5, color: C.muted, marginTop: 2 },
  dCell: { backgroundColor: '#F8FBFF', borderRadius: 8, borderWidth: 1, borderColor: '#EDF2F7', paddingVertical: 6, paddingHorizontal: 9 },
  dLabel: { fontSize: 10.5, fontWeight: '800', color: '#8594A6', textTransform: 'uppercase' },
  dVal: { fontSize: 13, fontWeight: '700', color: '#17314D', marginTop: 1 },
  backdrop: { flex: 1, backgroundColor: 'rgba(6,37,63,0.55)', justifyContent: 'center', padding: 16 },
  sheet: { backgroundColor: C.white, borderRadius: 20, padding: 16 },
  sheetTitle: { fontWeight: '800', fontSize: 17, color: C.ink },
  sheetSub: { color: C.muted, fontSize: 12.5, marginTop: 2 },
  photoBox: { height: 340, marginVertical: 12, backgroundColor: '#EEF2F7', borderRadius: 14, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  photo: { width: '100%', height: '100%' },
  outsideBox: { backgroundColor: C.redSoft, borderRadius: 14, padding: 16, marginVertical: 12, alignItems: 'center', gap: 6 },
  outsideTitle: { fontWeight: '800', color: C.red, fontSize: 15, textAlign: 'center' },
  outsideText: { color: '#203951', textAlign: 'center', lineHeight: 19 },
  meta: { color: '#203951', marginTop: 2 },
  thumb: { backgroundColor: '#EEF2F7', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  thumbImg: { width: '100%', height: '100%' },
});
