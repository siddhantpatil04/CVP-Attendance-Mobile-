import React, { useState } from 'react';
import { Alert } from 'react-native';
import { Dropdown } from '../../components/Pickers';
import { Banner, Button, Card, Field, Label, Screen, SectionTitle } from '../../components/ui';
import { companiesApi, useCompanies } from '../../lib/companies';
import { errorText } from '../../lib/supabase';

/**
 * Settings > Companies (Admin only). One form: the drop-down lists the saved companies.
 * "+ New company" (default) = empty inputs: fill them and Save, the company goes into the drop-down and the inputs are empty again for the next one.
 * Choosing a saved company loads it for editing.
 */
export default function CompaniesAdminScreen() {
  const co = useCompanies();
  const [sel, setSel] = useState(0);        // 0 = a new company
  const [name, setName] = useState('');
  const [pan, setPan] = useState('');
  const [addr, setAddr] = useState('');
  const [busy, setBusy] = useState(false);

  const choose = (id: number) => {
    setSel(id);
    const c = co.companies.find((x) => x.id === id);
    setName(c?.legal_name ?? ''); setPan(c?.pan_or_cin ?? ''); setAddr(c?.address ?? '');
  };
  const save = async () => {
    if (!name.trim()) return Alert.alert('Enter the company name');
    setBusy(true);
    try {
      if (sel) await companiesApi.update(sel, name, addr, pan);
      else await companiesApi.create(name, addr, pan);
      await co.reload();
      Alert.alert('Saved', `${name.trim()} ${sel ? 'updated' : 'added to the company list'}.`);
      choose(0);   // the company is now in the drop-down; the inputs are empty for the next one
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };

  return (
    <Screen>
      <Banner text="These details are printed in the heading of the PDF / Excel reports of each company." />
      {!co.dbOk ? <Banner tone="red" icon="alert-circle" text="The companies table was not found. Run supabase/two_companies.sql in the Supabase SQL Editor and open this screen again." /> : null}
      <SectionTitle title="Companies" />
      <Card>
        <Label>Saved companies</Label>
        <Dropdown width="100%" value={sel} onChange={choose}
          options={[{ value: 0, label: '+ New company' }, ...co.companies.map((c) => ({ value: c.id, label: c.legal_name }))]} />
        <Field label="Legal name" value={name} onChangeText={setName} placeholder="Company legal name" />
        <Field label="PAN / CIN" value={pan} autoCapitalize="characters" onChangeText={(v) => setPan(v.toUpperCase())} />
        <Field label="Address of the Establishment" value={addr} multiline onChangeText={setAddr} />
        <Button title={sel ? 'Update company' : 'Save company'} icon="save-outline" loading={busy} disabled={!co.dbOk} onPress={save} />
      </Card>
    </Screen>
  );
}
