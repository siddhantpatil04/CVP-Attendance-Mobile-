import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Dropdown, PickerField } from '../../components/Pickers';
import { Col,
  Avatar, Banner, Button, Card, Chips, Field, InfoTile, Loading, Pill, Row, Screen, SectionTitle, Toggle,
} from '../../components/ui';
import { PhotoAvatar } from '../../components/PhotoAvatar';
import { SiteAccessCard, SiteAccessState } from '../../components/SiteAccessCard';
import { MenuAccessCard } from '../../components/MenuAccessCard';
import PaidLeavePanel from '../../components/PaidLeavePanel';

const isProjectManager = (d?: string | null) => /project\s*manager/i.test(d ?? '');
import { Collapsible } from '../../components/Collapsible';
import DocumentsPanel from '../../components/DocumentsPanel';
import EmployeeDetailsForm from '../../components/EmployeeDetailsForm';
import EmployeeReportsPanel from '../../components/EmployeeReportsPanel';
import { UsernameCard } from '../../components/UsernameCard';
import { MIN_PASSWORD } from '../../config';
import { api, LeaveBalance, Profile, Role } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { errorText } from '../../lib/supabase';
import { istDateISO, istParts, serviceLength } from '../../lib/time';
import { C } from '../../theme';
import { hasMenuAccess, shownRole } from '../../navigation/menu';

const ordinal = (n: number) => ['', '1st', '2nd', '3rd', '4th', '5th'][n];

export default function EmployeeDetailScreen() {
  const route = useRoute<any>();
  const nav = useNavigation<any>();
  const { profile: me } = useAuth();
  const userId: string = route.params.userId;
  const [p, setP] = useState<Profile | null>(null);
  const [bal, setBal] = useState<LeaveBalance[]>([]);
  const [siteState, setSiteState] = useState<SiteAccessState | null>(null);
  // Access Control: the switches are changed here first and applied together with the Save Access button
  const [acc, setAcc] = useState<{ selfie: boolean; field: boolean; travel: boolean; tour: boolean; documents: boolean } | null>(null);
  const [form, setForm] = useState({ full_name: '', department: '', designation: '', role: 'Employee' as Role, shift_start: '09:00', shift_end: '18:00', site_employee: false, phone: '' });
  const [pw, setPw] = useState('');
  const [photoPath, setPhotoPath] = useState<string | null>(null);
  const [joining, setJoining] = useState('');
  const [salary, setSalary] = useState<number | null>(null);   // current salary (changed only in Salary Management)
  const [qYear, setQYear] = useState(istParts().year);
  const [qRows, setQRows] = useState<LeaveBalance[]>([]);
  const [quota, setQuota] = useState<Record<string, string>>({});

  const loadQuota = useCallback(async () => {
    try {
      const rows = await api.leaveBalance(qYear, userId);
      setQRows(rows);
      setQuota(Object.fromEntries(rows.map((b) => [b.leave_type, String(b.granted)])));
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [qYear, userId]);
  useEffect(() => { loadQuota(); }, [loadQuota]);
  const [sats, setSats] = useState<number[]>([1, 2, 3, 4]);
  const [busy, setBusy] = useState<string | null>(null);
  const [kind, setKind] = useState<string>('Employee');   // Portal role chip: Employee / Project Manager / HR / Admin

  const load = useCallback(async () => {
    try {
      const [prof, b] = await Promise.all([api.profile(userId), api.leaveBalance(undefined, userId)]);
      setP(prof);
      setBal(b);
      // the employee's profile photo (Admin / HR can read it); the initials stay when there is none
      api.employeeDetailFiles(userId).then((fs) => setPhotoPath(fs.find((f) => f.kind === 'photo')?.file_path ?? null)).catch(() => setPhotoPath(null));
      setJoining(prof.joining_date ?? '');
      if (me?.role === 'Admin' || me?.role === 'HR') {
        api.salaryHistory(userId).then((l) => {
          const today = istDateISO();
          setSalary(l.find((h) => h.effective_date <= today)?.salary ?? null);
        }).catch(() => {});
      }
      setKind(hasMenuAccess(prof) || (prof.role === 'Employee' && isProjectManager(prof.designation)) ? 'Project Manager' : prof.role);
      setSats((prof.saturday_off ?? [1, 2, 3, 4]).filter((n) => n <= 4));
      setForm({
        full_name: prof.full_name, department: prof.department ?? '', designation: prof.designation ?? '', role: prof.role,
        shift_start: prof.shift_start.slice(0, 5), shift_end: prof.shift_end.slice(0, 5),
        site_employee: prof.site_employee, phone: prof.phone ?? '',
      });
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [userId]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useEffect(() => { if (p) setAcc({ selfie: !!p.site_employee, field: !!p.wide_site_access, travel: !!p.travel_access, tour: !!p.tour_access, documents: !!p.documents_access }); }, [p]);

  if (!p || !me) return <Loading />;
  const self = p.id === me.id;
  const pm = hasMenuAccess(p);   // Project Manager with admin-menu items: shown and treated as an Employee
  const isFullAdmin = me.role === 'Admin' || me.role === 'HR';
  // HR can manage employees (and themselves); only an Admin can manage HR / Admin accounts and roles
  const canManage = isFullAdmin || p.role === 'Employee' || self;

  const save = async () => {
    setBusy('save');
    try {
      // a Project Manager with menu items keeps his internal permission level; moving him to HR / Admin / Employee first removes the menu items
      if (pm && kind !== 'Project Manager') await api.setMenuAccess(p.id, []);
      await api.updateProfile(p.id, { ...form, role: pm && kind === 'Project Manager' ? p.role : form.role });
      Alert.alert('Saved', 'Access settings updated.');
      await load();
    } catch (e) {
      Alert.alert('Could not save', errorText(e));
    } finally {
      setBusy(null);
    }
  };

  const saveJoining = async () => {
    const v = joining.trim();
    if (v && !/^\d{4}-\d{2}-\d{2}$/.test(v)) return Alert.alert('Use the format YYYY-MM-DD, for example 2021-06-15.');
    setBusy('join');
    try { await api.setJoiningDate(p.id, v || null); await load(); Alert.alert('Saved', 'Joining date updated.'); }
    catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(null); }
  };

  const saveQuota = async () => {
    const out: Record<string, number> = {};
    for (const b of qRows.filter((x) => x.counts_balance)) {
      const n = Number(quota[b.leave_type] ?? '');
      if (!Number.isInteger(n) || n < 0 || n > 366) return Alert.alert(`Enter whole days (0 to 366) for ${b.leave_type}.`);
      out[b.leave_type] = n;
    }
    setBusy('quota');
    try { await api.setLeaveQuota(p.id, qYear, out); await loadQuota(); Alert.alert('Saved', `Leaves for ${qYear} updated. ${p.full_name} sees them in the app.`); }
    catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(null); }
  };

  const toggleSat =(n: number) => setSats((s) => (s.includes(n) ? s.filter((x) => x !== n) : [...s, n].sort()));

  const saveSaturdays = async () => {
    setBusy('sat');
    try { await api.setSaturdays(p.id, sats); await load(); Alert.alert('Saved', 'Saturday holidays updated.'); }
    catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(null); }
  };

  // Access Control: the switches as shown now, and what is saved
  const a = acc ?? { selfie: !!p.site_employee, field: !!p.wide_site_access, travel: !!p.travel_access, tour: !!p.tour_access, documents: !!p.documents_access };
  const accChanged = a.selfie !== !!p.site_employee || a.field !== !!p.wide_site_access || a.travel !== !!p.travel_access || a.tour !== !!p.tour_access || a.documents !== !!p.documents_access;
  const saveAccess = async () => {
    if (!canManage || busy) return;
    setBusy('access');
    try {
      if (a.selfie !== !!p.site_employee) await api.updateProfile(p.id, { site_employee: a.selfie });
      if (a.field !== !!p.wide_site_access) await api.setFeatureAccess(p.id, 'wide_site', a.field);
      if (a.travel !== !!p.travel_access) await api.setTravelAccess(p.id, a.travel);
      if (a.tour !== !!p.tour_access) await api.setFeatureAccess(p.id, 'tour', a.tour);
      if (a.documents !== !!p.documents_access) await api.setFeatureAccess(p.id, 'documents', a.documents);
      if (a.selfie && siteState?.changed) await siteState.save();
      await load();
      Alert.alert('Saved', 'Access updated.');
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(null); }
  };
  // (old) one switch in "Access Control": runs the change, then reloads the person
  const setAccess = async (key: string, change: () => Promise<unknown>) => {
    if (!canManage || busy) return;
    setBusy(key);
    try { await change(); await load(); }
    catch (e) { Alert.alert('Could not update', errorText(e)); }
    finally { setBusy(null); }
  };

  const setActive = (active: boolean) =>
    Alert.alert(active ? 'Activate account?' : 'Delete account?',
      active ? `${p.full_name} will be able to sign in again.` : `${p.full_name} will be treated as having left the company: signed out, blocked from signing in and removed from the employee list. Past attendance records are kept.`, [
        { text: 'Cancel', style: 'cancel' },
        { text: active ? 'Activate' : 'Delete', style: active ? 'default' : 'destructive', onPress: async () => {
          setBusy('active');
          try { await api.adminUsers({ action: 'set_active', user_id: p.id, active }); await load(); }
          catch (e) { Alert.alert('Could not update', errorText(e)); }
          finally { setBusy(null); }
        } },
      ]);

  const resetPw = async () => {
    if (pw.length < MIN_PASSWORD) return Alert.alert(`Use at least ${MIN_PASSWORD} characters.`);
    setBusy('pw');
    try {
      await api.adminUsers({ action: 'reset_password', user_id: p.id, password: pw });
      setPw('');
      Alert.alert('Password reset', `Share the new password with ${p.full_name} securely.`);
    } catch (e) {
      Alert.alert('Could not reset', errorText(e));
    } finally {
      setBusy(null);
    }
  };

  return (
    <Screen>
      <Card>
        <Row>
          <PhotoAvatar name={p.full_name} size={56} path={photoPath} />
          <View style={{ flex: 1 }}>
            <Text style={st.name}>{p.full_name}</Text>
            <Text style={st.sub}>{p.username} - {p.designation || p.department || 'General'}</Text>
            <Row gap={6} style={{ marginTop: 6 }}>
              <Pill text={p.active ? 'Active' : 'Inactive'} tone={p.active ? 'green' : 'red'} />
              <Pill text={shownRole(p)} tone="purple" />
              {p.site_employee ? <Pill text="Site" tone="cyan" /> : null}
            </Row>
          </View>
        </Row>
        <Row style={{ marginTop: 14 }}>
          <Button title="Attendance" icon="calendar-outline" variant="secondary" style={{ flex: 1 }} small
            onPress={() => nav.navigate('EmployeeAttendance', { userId: p.id, name: p.full_name })} />
          {p.site_employee ? (
            <Button title="Selfie Records" icon="images-outline" variant="secondary" style={{ flex: 1 }} small
              onPress={() => nav.navigate('SelfieRecords', { userId: p.id, name: p.full_name, history: true })} />
          ) : null}
        </Row>
      </Card>

      {canManage ? (
        <Collapsible title="Employee Details">
          <EmployeeDetailsForm userId={p.id} admin={!self}
            fallback={{ name: p.full_name, phone: p.phone ?? '', joining: p.joining_date ?? '', department: p.department ?? '', designation: p.designation ?? '', role: p.role, siteEmployee: !!p.site_employee }} />
        </Collapsible>
      ) : null}

      <Collapsible title="Paid leave" note="24 paid leaves a year: eligibility, ledger, adjust balance, EL encashment">
        <PaidLeavePanel userId={p.id} canManage={canManage} />
      </Collapsible>

      <Collapsible title="Yearly leaves" note="Leave days per year">
      <Card>
        <Row style={{ justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <Button title="<" variant="secondary" small onPress={() => setQYear((y) => y - 1)} />
          <Text style={st.qYear}>{qYear}</Text>
          <Button title=">" variant="secondary" small onPress={() => setQYear((y) => y + 1)} />
        </Row>
        {qRows.filter((b) => b.counts_balance).map((b) => (
          <Field key={b.leave_type} label={`${b.leave_type} (days per year)  -  used ${b.used}, balance ${b.balance}`}
            value={quota[b.leave_type] ?? ''} keyboardType="numeric" editable={canManage}
            onChangeText={(v) => setQuota((q) => ({ ...q, [b.leave_type]: v.replace(/[^0-9]/g, '') }))} />
        ))}
        <Button title={`Save ${qYear} Leaves`} icon="save-outline" variant="secondary" small loading={busy === 'quota'}
          disabled={!canManage} onPress={saveQuota} />
      </Card>
      </Collapsible>

      <Collapsible title="Access Control" note="Switch features ON or OFF for this person">
      <Card>
        {!canManage ? <Banner tone="amber" text="Only an Admin can change HR / Admin accounts." /> : null}
        <Toggle label="Selfie Access" note={a.selfie ? 'ON: a selfie and location are required at the project site (site employee).' : 'OFF: no selfie. Check in / out only at the Office Location (Pune CVPATIL).'}
          value={a.selfie}
          onChange={(v) => { if (canManage) setAcc({ ...a, selfie: v }); }} />
        {a.selfie ? (
          <>
            <Collapsible title="Site Access" note="Work sites this employee may use">
              <SiteAccessCard userId={p.id} canManage={canManage} onState={setSiteState} />
            </Collapsible>
          </>
        ) : null}
        {isProjectManager(p.designation ?? form.designation) && (me?.role === 'Admin' || me?.role === 'HR') && p.role !== 'Admin' ? (
          <Collapsible title="Admin Menu Access (Project Manager)" note="Choose which admin-menu items he can use">
            <MenuAccessCard user={p} onSaved={load} />
          </Collapsible>
        ) : null}
        <Text style={st.label}>FIELD WORK</Text>
        <Toggle label="Foreign Location Access" note="Allow this person to check out from a foreign location (any place, with a selfie and a reason)"
          value={a.field}
          onChange={(v) => { if (canManage) setAcc({ ...a, field: v }); }} />
        <Toggle label="Travel Access" note="Check in / out at many stops a day and the distance in km between them"
          value={a.travel}
          onChange={(v) => { if (canManage) setAcc({ ...a, travel: v }); }} />
        <Toggle label="Tour Access" note="Allow this person to apply for a tour outside the city and add tour expenses, documents and tasks"
          value={a.tour}
          onChange={(v) => { if (canManage) setAcc({ ...a, tour: v }); }} />
        <Toggle label="Documents Access" note="Allow this person to upload documents with a remark and to see the documents you send to them"
          value={a.documents}
          onChange={(v) => { if (canManage) setAcc({ ...a, documents: v }); }} />
        <Button title="Save Access" icon="save-outline" loading={busy === 'access'} disabled={!canManage || !(accChanged || (a.selfie && !!siteState?.changed))} onPress={saveAccess} style={{ marginTop: 12 }} />
      </Card>
      </Collapsible>

      <Collapsible title="Profile" note="Name, role, department and joining date">
      <Card>
        <Row style={{ alignItems: 'flex-start' }}>
          <Col><Field label="Full name" value={form.full_name} onChangeText={(v) => setForm({ ...form, full_name: v })} /></Col>
          <Col><Field label="Department" value={form.department} onChangeText={(v) => setForm({ ...form, department: v })} /></Col>
        </Row>
        <Row style={{ alignItems: 'flex-start' }}>
          <Col><Field label="Designation" value={form.designation} onChangeText={(v) => setForm({ ...form, designation: v })} placeholder="e.g. Site Engineer" /></Col>
          <Col><Field label={p.role === 'Employee' || p.role === 'HR' ? 'Mobile number' : 'Phone (optional)'} value={form.phone} keyboardType="phone-pad" onChangeText={(v) => setForm({ ...form, phone: v })} /></Col>
        </Row>
        <Text style={st.label}>Portal role</Text>
        {self ? <Text style={st.sub}>You cannot change your own role.</Text>
          : !isFullAdmin ? <Text style={st.sub}>{shownRole(p)}. Only an Admin can change roles.</Text> : (
            <>
              <Chips<string> options={['Employee', 'Project Manager', 'HR', 'Admin']} value={kind} onChange={(k) => {
                setKind(k);
                const wasPM = isProjectManager(form.designation);
                setForm({ ...form, role: (k === 'Project Manager' ? 'Employee' : k) as Role,
                  designation: k === 'Project Manager' ? 'Project Manager' : wasPM ? '' : form.designation });
              }} />
              {kind === 'Project Manager' ? <Text style={st.sub}>Works as an Employee. Save, then tick his admin-menu items in "Admin Menu Access" above.</Text> : null}
            </>
          )}
        <PickerField label={`Joining date${p.joining_date ? ' - ' + serviceLength(p.joining_date) + ' of service' : ''}`}
          mode="date" value={joining || istDateISO()} maximumDate={new Date()} onChange={setJoining} />
        <Button title="Save Joining Date" icon="calendar-outline" variant="secondary" small loading={busy === 'join'}
          disabled={!canManage} onPress={saveJoining} style={{ marginBottom: 10 }} />
        <Button title="Save Profile Settings" icon="save-outline" loading={busy === 'save'} disabled={!canManage} onPress={save} style={{ marginTop: 8 }} />
      </Card>
      </Collapsible>

      {p.role === 'Employee' || p.role === 'HR' ? (
        <Collapsible title="Documents" note="Documents this person uploaded, and documents you send to them">
          {p.documents_access ? <DocumentsPanel userId={p.id} admin /> : (
            <Card><Banner tone="amber" icon="lock-closed-outline" text="Documents access is OFF for this person. You can still send them a document below, but they see it only after Documents access is switched ON in Access Control." />
              <DocumentsPanel userId={p.id} admin /></Card>
          )}
        </Collapsible>
      ) : null}


      {p.role === 'Employee' || p.role === 'HR' ? (
        <Collapsible title="Reports" note="Detailed Day-wise Report and Leave Register of this person">
          <EmployeeReportsPanel userId={p.id} name={p.full_name} />
        </Collapsible>
      ) : null}

      {isFullAdmin ? (
        <>
          <Collapsible title="Salary">
          <Card>
            <InfoTile label="Current monthly salary" value={salary === null ? 'Not set' : `Rs ${salary.toLocaleString('en-IN')}`} />
            <Button title="Open Salary Management" icon="cash-outline" variant="secondary" small onPress={() => nav.navigate('SalaryManagement')} />
          </Card>
          </Collapsible>
        </>
      ) : null}

      <Collapsible title="Saturday holidays" note="Which Saturdays are a holiday">
      <Card>
        <Row gap={6} style={{ flexWrap: 'wrap', marginBottom: 8 }}>
          {[1, 2, 3, 4].map((n) => {
            const on = sats.includes(n);
            return (
              <Pressable key={n} onPress={() => canManage && toggleSat(n)}
                style={[st.satChip, on && st.satChipOn]}>
                <Text style={[st.satText, on && st.satTextOn]}>{ordinal(n)} Sat - {on ? 'Holiday' : 'Working'}</Text>
              </Pressable>
            );
          })}
        </Row>
        <Button title="Save Saturdays" icon="save-outline" variant="secondary" small loading={busy === 'sat'} disabled={!canManage}
          onPress={saveSaturdays} style={{ marginBottom: 8 }} />
      </Card>
      </Collapsible>
      {canManage ? (
        <Collapsible title="Username" note="Change the name used to sign in">
          <UsernameCard key={p.username} user={p} onChanged={load} />
        </Collapsible>
      ) : null}

      {!self && canManage ? (
        <>
          <Collapsible title="Login account" note="Reset password or delete the account">
          <Card>
            <Field label={`Set a new password (min ${MIN_PASSWORD} characters)`} value={pw} onChangeText={setPw} secureTextEntry />
            <Button title="Reset Password" icon="key-outline" variant="secondary" loading={busy === 'pw'} onPress={resetPw} />
            <View style={{ height: 10 }} />
            {p.active ? (
              <Button title="Delete Account" icon="trash-outline" variant="danger" loading={busy === 'active'} onPress={() => setActive(false)} />
            ) : (
              <Button title="Activate Account" icon="checkmark-circle-outline" variant="success" loading={busy === 'active'} onPress={() => setActive(true)} />
            )}
          </Card>
          </Collapsible>
        </>
      ) : null}
    </Screen>
  );
}

const st = StyleSheet.create({
  name: { fontWeight: '800', fontSize: 18, color: '#102A45' },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 2, marginBottom: 8 },
  label: { fontSize: 12, fontWeight: '700', color: '#3A5068', marginBottom: 8 },
  qYear: { fontSize: 18, fontWeight: '800', color: '#102A45' },
  satChip: { paddingVertical: 9, paddingHorizontal: 12, borderRadius: 999, borderWidth: 1, borderColor: '#DFE8F2', backgroundColor: '#FBFDFF' },
  satChipOn: { backgroundColor: '#E6F4EA', borderColor: '#34A853' },
  satText: { fontSize: 12.5, fontWeight: '700', color: '#5A6B7F' },
  satTextOn: { color: '#1E7A3C' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
});



