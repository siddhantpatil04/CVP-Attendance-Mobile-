import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Dropdown, PickerField } from '../../components/Pickers';
import SalarySlipsTab from './SalarySlipsTab';
import { Banner, Button, Card, Empty, Field, Loading, Pill, Row, Screen, Segmented } from '../../components/ui';
import { api, SalaryHistoryRow, SalaryOverviewRow } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { useIsDesktop } from '../../lib/layout';
import { errorText } from '../../lib/supabase';
import { fmtISODate, istDateISO } from '../../lib/time';
import { shareXlsx } from '../../lib/xlsx';
import SalaryFormulasTab from './SalaryFormulasTab';
import { headingOf, setReportCompany, useCompanies, useCompanyChoice } from '../../lib/companies';
import { C } from '../../theme';

const inr = (n: number) => `Rs ${Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
const inr0 = (n: number) => `₹ ${Math.round(Number(n)).toLocaleString('en-IN')}`;
const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const dash = (n: number | null | undefined) => (n === null || n === undefined ? '-' : inr(n));

/**
 * Salary Management (Admin Dashboard): Basic Salary, Increment 1, Increment 2 and Current Salary of every employee.
 * Only the Admin can set a salary or add an increment; HR can view. People who have left stay in the list.
 */
export default function SalaryManagementScreen() {
  const { profile } = useAuth();
  const nav = useNavigation<any>();
  const desktop = useIsDesktop();
  const isAdmin = profile?.role === 'Admin' || profile?.role === 'HR';   // HR has the same access as Admin
  const [rowsAll, setRows] = useState<SalaryOverviewRow[] | null>(null);
  const co = useCompanies();
  const [coSel, setCoSel] = useCompanyChoice();
  const [coOfEmp, setCoOfEmp] = useState<Map<string, number | null>>(new Map());
  const [admins, setAdmins] = useState<Set<string>>(new Set());   // Admin accounts have no salary
  const [setup, setSetup] = useState(false);   // the database update has not been run yet
  const [q, setQ] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [form, setForm] = useState<{ userId: string } | null>(null);
  const [hist, setHist] = useState<{ row: SalaryOverviewRow; list: SalaryHistoryRow[] | null } | null>(null);

  const [desig, setDesig] = useState<Map<string, string>>(new Map());
  const [finalized, setFinalized] = useState('-');
  const [dept, setDept] = useState(0);
  const [showWho, setShowWho] = useState(0);     // 0 active, 1 everyone, 2 resigned
  const [page, setPage] = useState(0);
  const [tab, setTab] = useState<'salaries' | 'slips' | 'formulas'>('salaries');

  const route = useRoute<any>();
  const load = useCallback(async () => {
    try { const r = await api.salaryOverview(); setRows(r.rows); setSetup(r.setupNeeded); } catch (e) { Alert.alert('Could not load', errorText(e)); }
    // designation of each person and "payroll finalized up to" (the latter needs payroll_months.sql)
    api.allProfiles().then((all) => { setAdmins(new Set(all.filter((p) => p.role === 'Admin').map((p) => p.id))); setDesig(new Map(all.map((p) => [p.id, p.designation ?? '']))); setCoOfEmp(new Map(all.map((p) => [p.id, p.company_id ?? null]))); }, () => {});
    api.payrollMonths().then((ms) => {
      const m = ms.find((x) => x.status === 'Finalized');
      setFinalized(m ? `${MONTHS_SHORT[m.month - 1]} ${m.year}` : 'None yet');
    }, () => setFinalized('-'));
  }, []);
  useFocusEffect(useCallback(() => {
    load();
    // opened with the "Increment Salary" shortcut of the dashboard
    if (route.params?.add && isAdmin) { setForm({ userId: '' }); nav.setParams({ add: undefined }); }
  }, [load, route.params?.add, isAdmin]));

  const rows = useMemo(() => rowsAll?.filter((r) => !admins.has(r.user_id)) ?? null, [rowsAll, admins]);
  const depts = useMemo(() => Array.from(new Set((rows ?? []).map((r) => (r.department ?? '').trim()).filter(Boolean))).sort((a, b) => a.localeCompare(b)), [rows]);
  // All employees are listed; typing a name or choosing a department narrows the list
  const searching = true;
  const shown = useMemo(() => {
    const k = q.trim().toLowerCase();
    return (rows ?? [])
      .filter((r) => !k || `${r.full_name} ${r.department ?? ''} ${desig.get(r.user_id) ?? ''}`.toLowerCase().includes(k))
      .filter((r) => dept === 0 || (r.department ?? '').trim() === depts[dept - 1])
      .filter((r) => (showWho === 0 ? !r.left_on : showWho === 2 ? !!r.left_on : true));
  }, [rows, q, desig, dept, depts, showWho]);

  const exportXlsx = async () => {
    try {
      const today = istDateISO();
      setReportCompany(headingOf(co.companies, coSel));
      await shareXlsx(`cvp_salary_management_${today}.xlsx`, [{
        name: 'Salaries', title: 'Salary Management - employee salaries', subtitle: today,
        rows: shown.map((r) => ({
          'Employee Name': r.full_name, Designation: desig.get(r.user_id) ?? '', Department: r.department ?? '',
          'Basic Salary': r.basic ?? '', 'Increment 1': r.inc1 ?? '', 'Increment 1 from': r.inc1_on ?? '',
          'Increment 2': r.inc2 ?? '', 'Increment 2 from': r.inc2_on ?? '', 'Current Salary': r.current_salary ?? '-',
          Status: r.left_on ? `Resigned ${r.left_on}` : 'Active',
        })),
      }]);
    } catch (e) { Alert.alert('Export failed', errorText(e)); }
  };

  const openHistory = async (row: SalaryOverviewRow) => {
    setHist({ row, list: null });
    try { setHist({ row, list: await api.salaryHistory(row.user_id) }); }
    catch (e) { Alert.alert('Could not load', errorText(e)); setHist(null); }
  };

  if (!rows) return <Loading />;

  const tabBar = (
    <Segmented value={tab} onChange={setTab} options={[{ value: 'salaries', label: 'Salaries & Increments' }, { value: 'slips', label: 'Salary Slips' }, ...(profile?.role === 'Admin' ? [{ value: 'formulas' as const, label: 'Salary Formulas' }] : [])]} />
  );
  if (tab === 'formulas' && profile?.role === 'Admin') {
    return (
      <Screen>
        <Text style={st.title}>Salary Formulas</Text>
        <Text style={st.sub}>Change the salary formulas from a month. Earlier months keep the old formulas.</Text>
        {tabBar}
        <SalaryFormulasTab />
      </Screen>
    );
  }
  if (tab === 'slips') {
    return (
      <Screen>
        <Text style={st.title}>Salary Slips</Text>
        <Text style={st.sub}>Preview or download the salary slip of every employee for a month.</Text>
        {tabBar}
        <SalarySlipsTab />
      </Screen>
    );
  }

  return (
    <Screen refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }}>
      <Row style={{ justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap' }}>
        <View style={{ flex: 1, minWidth: 220 }}>
          <Text style={st.title}>{desktop ? 'Employee salaries' : 'Salary Management'}</Text>
          <Text style={st.sub}>{desktop ? 'Only Admin / HR can change salaries. Every change has an effective date and is kept in history.' : 'Basic salary, increments and current salary of every employee'}</Text>
        </View>
      </Row>
      {tabBar}
      {setup ? <Banner tone="amber" text="Salary increments need a one-time database update. Run supabase/salary_management.sql in the Supabase SQL Editor, then pull down to refresh. Until then you can only enter a Basic salary." /> : null}
      {!isAdmin ? <Banner tone="amber" text="Only the Admin / HR can change salaries. You can view them here." /> : null}

      {desktop ? (
        <>
          <View style={st.kpis}>
            {([
              ['cash-outline', 'Monthly salary bill (current)', inr0(rows.filter((r) => !r.left_on).reduce((a, r) => a + Number(r.current_salary ?? 0), 0)), '#E7F1FF', C.blue],
              ['trending-up-outline', 'Increments this year', `${rows.filter((r) => [r.inc1_on, r.inc2_on].some((d) => d && d.slice(0, 4) === istDateISO().slice(0, 4) && d <= istDateISO())).length} employees`, '#E3F8EE', '#12A05C'],
              ['calendar-outline', 'Scheduled (future date)', String(rows.filter((r) => [r.inc1_on, r.inc2_on].some((d) => d && d > istDateISO())).length), '#F0EAFD', '#7A4BD6'],
              ['lock-closed-outline', 'Payroll finalized up to', finalized, '#FFF3DC', '#D18A00'],
            ] as const).map(([icon, label, value, bg, fg]) => (
              <View key={label} style={st.kpi}>
                <View style={[st.kpiIcon, { backgroundColor: bg }]}><Ionicons name={icon as any} size={20} color={fg} /></View>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={st.kpiLabel} numberOfLines={1}>{label}</Text>
                  <Text style={st.kpiValue} numberOfLines={1}>{value}</Text>
                </View>
              </View>
            ))}
          </View>

          <Card style={{ padding: 0, overflow: 'hidden' }}>
            <Row style={{ padding: 14, alignItems: 'flex-start', flexWrap: 'wrap' }} gap={10}>
              <View style={{ flexGrow: 3, flexBasis: 280, minWidth: 220 }}>
                <Field placeholder="Search employee or designation" value={q} onChangeText={(v) => { setQ(v); setPage(0); }} />
              </View>
              <View style={{ flexGrow: 1, flexBasis: 200, minWidth: 170, marginBottom: 8 }}>
                <Dropdown width="100%" value={dept} onChange={(v) => { setDept(v); setPage(0); }}
                  options={[{ value: 0, label: 'Department: All' }, ...depts.map((d, i) => ({ value: i + 1, label: d }))]} />
              </View>
              <View style={{ flexGrow: 1, flexBasis: 200, minWidth: 170, marginBottom: 8 }}>
                <Dropdown width="100%" value={showWho} onChange={(v) => { setShowWho(v); setPage(0); }}
                  options={[{ value: 0, label: 'Show: Active employees' }, { value: 1, label: 'Show: Everyone' }, { value: 2, label: 'Show: Resigned' }]} />
              </View>
            </Row>
            {searching ? <View style={st.hd}>
              {/* the indent is inside the column: padding on the flex item itself would make this column wider than the rows' */}
              <View style={{ flex: COL.name, minWidth: 0 }}><Text style={[st.hdText, { paddingLeft: 52 }]} numberOfLines={1}>EMPLOYEE NAME</Text></View>
              <Text style={[st.hdText, { flex: COL.basic }]} numberOfLines={1}>BASIC SALARY</Text>
              <Text style={[st.hdText, { flex: COL.inc }]} numberOfLines={1}>INCREMENT 1</Text>
              <Text style={[st.hdText, { flex: COL.inc }]} numberOfLines={1}>INCREMENT 2</Text>
              <Text style={[st.hdText, { flex: COL.cur }]} numberOfLines={1}>CURRENT SALARY</Text>
              <Text style={[st.hdText, { width: ACTIONS_W, textAlign: 'right' }]} numberOfLines={1}>ACTIONS</Text>
            </View> : null}
            {shown.length === 0 ? <Empty text={searching ? 'No employees found.' : 'Search an employee or choose a department to see the salaries.'} icon="search-outline" /> : shown.slice(page * 10, page * 10 + 10).map((r) => (
              <DeskRow key={r.user_id} row={r} designation={desig.get(r.user_id) ?? ''} canEdit={!r.left_on && !setup}
                onHistory={() => openHistory(r)}
                onIncrement={() => (isAdmin ? setForm({ userId: r.user_id }) : Alert.alert('Not allowed', 'Only the Admin / HR can add an increment.'))} />
            ))}
            {searching ? (
              <View style={st.foot2}>
                <Text style={st.sub}>Showing {shown.length === 0 ? 0 : Math.min(page * 10 + 10, shown.length)} of {shown.length} employees - amounts are monthly (₹)</Text>
                <Row gap={6}>
                  <Button title="Previous" variant="secondary" small disabled={page === 0} onPress={() => setPage(page - 1)} />
                  <Button title="Next" variant="secondary" small disabled={(page + 1) * 10 >= shown.length} onPress={() => setPage(page + 1)} />
                </Row>
              </View>
            ) : null}
          </Card>
        </>
      ) : <Field placeholder="Search name or department" value={q} onChangeText={setQ} />}

      {!desktop ? (shown.length === 0 ? <Card><Empty text={searching ? 'No employees found.' : 'Search an employee to see the salary.'} /></Card> : (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12, alignItems: 'flex-start' }}>
          {shown.map((r) => (
            <View key={r.user_id} style={{ flexGrow: 1, flexBasis: desktop ? 360 : '100%', minWidth: 0 }}>
              <SalaryCard row={r} canEdit={!r.left_on && !setup}
                onHistory={() => openHistory(r)}
                onIncrement={() => (isAdmin ? setForm({ userId: r.user_id }) : Alert.alert('Not allowed', 'Only the Admin / HR can add an increment.'))} />
            </View>
          ))}
        </View>
      )) : null}
      {/* the old input table is kept in the code but not shown */}
      <Card style={{ padding: 0, display: 'none' }}>
        <ScrollView horizontal showsHorizontalScrollIndicator>
          <View style={{ minWidth: 1040, flexGrow: 1 }}>
            <View style={[st.tr, st.th]}>
              <Text style={[st.thText, { flex: 2 }]}>Employee Name</Text>
              <Text style={[st.thText, { flex: 1.3 }]}>Basic Salary</Text>
              <Text style={[st.thText, { flex: 1.9 }]}>Increment 1 (amount, from date)</Text>
              <Text style={[st.thText, { flex: 1.9 }]}>Increment 2 (amount, from date)</Text>
              <Text style={[st.thText, { flex: 1.2 }]}>Current Salary</Text>
              <Text style={[st.thText, { flex: 1.5, textAlign: 'right' }]}>Actions</Text>
            </View>
            {shown.length === 0 ? <Empty text="No employees found." /> : shown.map((r) => (
              <SalaryRow key={r.user_id} row={r} canEdit={isAdmin && !r.left_on} setup={setup}
                onSaved={load} onHistory={() => openHistory(r)} onMore={() => setForm({ userId: r.user_id })} />
            ))}
          </View>
        </ScrollView>
      </Card>
      {searching ? (
        <Text style={st.foot}>
          An increment is paid from its effective date. Earlier months keep the salary they had. Employees who have left stay here: their salary is paid up to
          the leaving date and shows "-" from the next month.
        </Text>
      ) : null}

      {form ? (
        <IncrementDialog rows={rows} initialUser={form.userId} onClose={() => setForm(null)} onSaved={() => { setForm(null); load(); }} />
      ) : null}

      <Modal visible={!!hist} transparent animationType="fade" onRequestClose={() => setHist(null)}>
        <Pressable style={st.backdrop} onPress={() => setHist(null)}>
          <Pressable style={st.sheet} onPress={() => {}}>
            {hist ? (
              <>
                <Text style={st.sheetTitle}>{hist.row.full_name}</Text>
                <Text style={st.sub}>Complete salary history (it is never edited or deleted)</Text>
                <ScrollView style={{ maxHeight: 360, marginTop: 10 }}>
                  {!hist.list ? <Loading /> : hist.list.length === 0 ? <Empty text="No salary has been set yet." /> : hist.list.map((h) => (
                    <View key={h.id} style={st.hrow}>
                      <View style={{ flex: 1 }}>
                        <Text style={st.name}>{inr(h.salary)} per month</Text>
                        <Text style={st.meta}>
                          {h.kind === 'Basic' ? 'Basic salary - from joining' : `Increment ${h.increment >= 0 ? '+' : '-'} ${inr(Math.abs(h.increment))} - from ${fmtISODate(h.effective_date)}`}
                        </Text>
                        {h.note ? <Text style={st.meta}>Note: {h.note}</Text> : null}
                        <Text style={st.meta}>Saved {fmtISODate(h.created_at.slice(0, 10))}{h.set_by ? ` by ${h.set_by}` : ''}</Text>
                      </View>
                      <Pill text={h.kind} tone={h.kind === 'Basic' ? 'blue' : 'green'} />
                    </View>
                  ))}
                </ScrollView>
                <Button title="Close" onPress={() => setHist(null)} style={{ marginTop: 12 }} />
              </>
            ) : null}
          </Pressable>
        </Pressable>
      </Modal>
    </Screen>
  );
}

const num = (s: string) => Number(s.replace(/,/g, ''));
// One set of column widths for the table header AND every row, so the headings sit exactly above their values
const COL = { name: 2.4, basic: 1.2, inc: 1.6, cur: 1.7 };
const ACTIONS_W = 270;

/** Desktop table row: name + designation, Basic, Increment 1 / 2 (amount and date, "Scheduled" when it starts later), Current salary, buttons */
function DeskRow({ row, designation, canEdit, onHistory, onIncrement }: {
  row: SalaryOverviewRow; designation: string; canEdit: boolean; onHistory: () => void; onIncrement: () => void;
}) {
  const today = istDateISO();
  const rise = row.basic && row.current_salary ? ((row.current_salary - row.basic) / row.basic) * 100 : null;
  const inc = (amount: number | null, on: string | null) => {
    if (amount === null) return <Text style={st.muted}>-</Text>;
    const future = !!on && on > today;
    return (
      <View>
        <Text style={st.incAmt}>+ {inr0(amount)}</Text>
        <Text style={[st.meta, future && { color: C.blue, fontWeight: '700' }]}>{future ? `Scheduled - from ${fmtISODate(on!)}` : `from ${on ? fmtISODate(on) : ''}`}</Text>
      </View>
    );
  };
  const joined = row.joining_date ? new Date(row.joining_date) : null;
  const isNew = !row.increments && joined && Date.now() - joined.getTime() < 90 * 86400000;
  return (
    <View style={[st.tr2, row.left_on ? { backgroundColor: '#FBF6F6' } : null]}>
      <Row style={{ flex: COL.name, minWidth: 0 }}>
        <View style={st.avatar}><Text style={st.avatarText}>{initials(row.full_name)}</Text></View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.name} numberOfLines={1}>{row.full_name}</Text>
          <Text style={st.meta} numberOfLines={1}>{row.left_on ? `Resigned ${fmtISODate(row.left_on)}` : designation || row.department || 'General'}</Text>
        </View>
      </Row>
      <Text style={[st.basicTxt, { flex: COL.basic, minWidth: 0 }]} numberOfLines={1}>{row.basic === null ? '-' : inr0(row.basic)}</Text>
      <View style={{ flex: COL.inc, minWidth: 0 }}>{inc(row.inc1, row.inc1_on)}</View>
      <View style={{ flex: COL.inc, minWidth: 0 }}>
        {inc(row.inc2, row.inc2_on)}
        {row.increments > 2 ? <Text style={[st.meta, { color: C.blue, fontWeight: '700' }]}>+{row.increments - 2} more - see History</Text> : null}
      </View>
      <View style={{ flex: COL.cur, minWidth: 0 }}>
        <Text style={st.basicTxt}>{row.current_salary === null ? '-' : inr0(row.current_salary)}</Text>
        <Text style={[st.meta, { fontSize: 10.5 }]}>as on {fmtISODate(today)}</Text>
        {rise !== null && rise !== 0 ? <Text style={[st.meta, { color: rise > 0 ? '#0E8A4F' : C.red, fontWeight: '700' }]}>{rise > 0 ? '+' : ''}{rise.toFixed(1)}% since joining</Text>
          : isNew ? <Text style={st.meta}>New - joined {MONTHS_SHORT[joined!.getMonth()]} {joined!.getFullYear()}</Text> : null}
      </View>
      <Row gap={6} style={{ width: ACTIONS_W, justifyContent: 'flex-end', flexWrap: 'nowrap' }}>
        <Button title="History" icon="time-outline" variant="secondary" small onPress={onHistory} />
        {canEdit ? <Button title="Increment Salary" icon="trending-up-outline" small onPress={onIncrement} /> : null}
      </Row>
    </View>
  );
}
const initials = (name: string) => name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();

/** Phone layout: one card per employee with Basic / Increment 1 / Increment 2 tiles and History / Increment buttons */
function SalaryCard({ row, canEdit, onHistory, onIncrement }: { row: SalaryOverviewRow; canEdit: boolean; onHistory: () => void; onIncrement: () => void }) {
  const rise = row.basic && row.current_salary ? ((row.current_salary - row.basic) / row.basic) * 100 : null;
  const tile = (label: string, value: number | null) => (
    <View style={st.tile}>
      <Text style={st.tileLabel}>{label}</Text>
      <Text style={[st.tileVal, value !== null && label !== 'BASIC' && { color: '#0E8A4F' }]}>{value === null ? '-' : label === 'BASIC' ? inr(value) : `+${inr(value)}`}</Text>
    </View>
  );
  return (
    <Card style={row.left_on ? { backgroundColor: '#FBF6F6' } : undefined}>
      <Row style={{ alignItems: 'center' }}>
        <View style={st.avatar}><Text style={st.avatarText}>{initials(row.full_name)}</Text></View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.name} numberOfLines={1}>{row.full_name}</Text>
          <Text style={st.meta} numberOfLines={1}>{row.left_on ? `Resigned ${fmtISODate(row.left_on)}` : row.department || 'General'}</Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={st.cur}>{row.current_salary === null ? '-' : inr(row.current_salary)}</Text>
          {rise !== null && rise !== 0 ? <Text style={[st.meta, { color: rise > 0 ? '#0E8A4F' : C.red, fontWeight: '800' }]}>{rise > 0 ? '+' : ''}{rise.toFixed(1)}%</Text> : null}
        </View>
      </Row>
      <View style={{ flexDirection: 'row', gap: 8, marginVertical: 10 }}>
        {tile('BASIC', row.basic)}{tile('INCR. 1', row.inc1)}{tile('INCR. 2', row.inc2)}
      </View>
      <Row style={{ flexWrap: 'wrap' }}>
        <Button title="History" icon="time-outline" variant="secondary" style={{ flex: 1 }} onPress={onHistory} />
        {canEdit ? <Button title="Increment" icon="trending-up-outline" style={{ flex: 1 }} onPress={onIncrement} /> : null}
      </Row>
    </Card>
  );
}

/**
 * One employee line with input boxes. Empty boxes can be filled in (Basic salary, Increment 1, Increment 2 with its "from" date);
 * a saved value is locked because the salary history is never edited. Current Salary = Basic + Increment 1 + Increment 2.
 */
function SalaryRow({ row, canEdit, setup, onSaved, onHistory, onMore }: {
  row: SalaryOverviewRow; canEdit: boolean; setup: boolean; onSaved: () => void; onHistory: () => void; onMore: () => void;
}) {
  const [basic, setBasic] = useState('');
  const [i1, setI1] = useState('');
  const [d1, setD1] = useState('');
  const [i2, setI2] = useState('');
  const [d2, setD2] = useState('');
  const [busy, setBusy] = useState(false);
  const basicSet = row.basic !== null;
  const inc1Set = row.inc1 !== null;
  const inc2Set = row.inc2 !== null;
  const typed = (s: string) => s.trim() !== '' && Number.isFinite(num(s));
  const basicVal = basicSet ? row.basic! : typed(basic) ? num(basic) : null;
  const inc1Val = inc1Set ? row.inc1! : typed(i1) ? num(i1) : null;
  const inc2Val = inc2Set ? row.inc2! : typed(i2) ? num(i2) : null;
  const dirty = (!basicSet && typed(basic)) || (!inc1Set && typed(i1)) || (!inc2Set && typed(i2));
  // Current Salary follows what is typed; the saved value is shown when nothing new is typed
  const current = dirty && basicVal !== null ? basicVal + (inc1Val ?? 0) + (inc2Val ?? 0) : row.current_salary;
  const can1 = canEdit && !inc1Set && (basicSet || typed(basic)) && !setup;
  const can2 = canEdit && !inc2Set && (inc1Set || typed(i1)) && !setup;

  const save = async () => {
    const today = istDateISO();
    const isoOk = (s: string) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(new Date(s).getTime());
    const newBasic = !basicSet && typed(basic) ? num(basic) : null;
    const new1 = !inc1Set && typed(i1) ? num(i1) : null;
    const new2 = !inc2Set && typed(i2) ? num(i2) : null;
    if (newBasic === null && new1 === null && new2 === null) return Alert.alert('Nothing to save', 'Type a value in an empty box first.');
    if (newBasic !== null && newBasic < 0) return Alert.alert('Enter the basic salary as a number, for example 25000.');
    if ((new1 !== null && new1 <= 0) || (new2 !== null && new2 <= 0)) return Alert.alert('Enter the increment amount as a number above 0, for example 2000.');
    const date1 = d1.trim() || today; const date2 = d2.trim() || today;
    if ((new1 !== null && !isoOk(date1)) || (new2 !== null && !isoOk(date2))) return Alert.alert('Enter the date as YYYY-MM-DD, for example 2026-11-01.');
    setBusy(true);
    try {
      const base = newBasic ?? row.basic ?? 0;
      if (newBasic !== null) {
        if (setup) await api.setBasicLegacy(row.user_id, newBasic);
        else await api.incrementSalary(row.user_id, newBasic, null, 'Basic salary');
      }
      let first = row.inc1 ?? 0;
      if (new1 !== null) { first = new1; await api.incrementSalary(row.user_id, base + new1, date1, 'Increment 1'); }
      if (new2 !== null) await api.incrementSalary(row.user_id, base + first + new2, date2, 'Increment 2');
      setBasic(''); setI1(''); setD1(''); setI2(''); setD2('');
      Alert.alert('Saved', `${row.full_name}: ${inr(base + (new1 ?? row.inc1 ?? 0) + (new2 ?? row.inc2 ?? 0))} per month.`);
      onSaved();
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };

  const money = (set: (v: string) => void) => (v: string) => set(v.replace(/[^0-9.]/g, '').slice(0, 10));
  const date = (set: (v: string) => void) => (v: string) => set(v.replace(/[^0-9-]/g, '').slice(0, 10));

  return (
    <View style={[st.tr, row.left_on ? { backgroundColor: '#FBF6F6' } : null]}>
      <View style={{ flex: 2, minWidth: 0 }}>
        <Text style={st.name} numberOfLines={1}>{row.full_name}</Text>
        <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center', flexWrap: 'wrap', marginTop: 2 }}>
          <Text style={st.meta}>{row.department || 'General'}</Text>
          {row.left_on ? <Pill text={`Resigned ${fmtISODate(row.left_on)}`} tone="red" /> : null}
        </View>
      </View>

      <View style={{ flex: 1.3 }}>
        {basicSet || !canEdit ? <Text style={st.locked}>{dash(row.basic)}</Text>
          : <TextInput style={st.input as any} value={basic} onChangeText={money(setBasic)} keyboardType="numeric" placeholder="Basic salary" placeholderTextColor="#9AA9BA" />}
      </View>

      <View style={{ flex: 1.9, gap: 4 }}>
        {inc1Set || !canEdit ? (
          <>
            <Text style={st.locked}>{row.inc1 === null ? '-' : `+ ${inr(row.inc1)}`}</Text>
            {row.inc1_on ? <Text style={st.meta}>from {fmtISODate(row.inc1_on)}</Text> : null}
          </>
        ) : (
          <View style={{ flexDirection: 'row', gap: 6 }}>
            <TextInput style={[st.input as any, { flex: 1 }, !can1 && st.off]} editable={can1} value={i1} onChangeText={money(setI1)} keyboardType="numeric" placeholder="Increment" placeholderTextColor="#9AA9BA" />
            <TextInput style={[st.input as any, { flex: 1 }, !can1 && st.off]} editable={can1} value={d1} onChangeText={date(setD1)} placeholder="YYYY-MM-DD" placeholderTextColor="#9AA9BA" />
          </View>
        )}
      </View>

      <View style={{ flex: 1.9, gap: 4 }}>
        {inc2Set || !canEdit ? (
          <>
            <Text style={st.locked}>{row.inc2 === null ? '-' : `+ ${inr(row.inc2)}`}</Text>
            {row.inc2_on ? <Text style={st.meta}>from {fmtISODate(row.inc2_on)}</Text> : null}
            {row.increments > 2 ? <Text style={st.meta}>+{row.increments - 2} more in history</Text> : null}
          </>
        ) : (
          <View style={{ flexDirection: 'row', gap: 6 }}>
            <TextInput style={[st.input as any, { flex: 1 }, !can2 && st.off]} editable={can2} value={i2} onChangeText={money(setI2)} keyboardType="numeric" placeholder="Increment" placeholderTextColor="#9AA9BA" />
            <TextInput style={[st.input as any, { flex: 1 }, !can2 && st.off]} editable={can2} value={d2} onChangeText={date(setD2)} placeholder="YYYY-MM-DD" placeholderTextColor="#9AA9BA" />
          </View>
        )}
      </View>

      <View style={{ flex: 1.2 }}>
        <Text style={[st.locked, { color: '#0B2B4D' }]}>{dash(current)}</Text>
        {!dirty && current !== null && row.current_from && row.increments > 0 ? <Text style={st.meta}>from {fmtISODate(row.current_from)}</Text> : null}
        {dirty ? <Text style={[st.meta, { color: C.blue }]}>not saved yet</Text> : null}
      </View>

      <Row gap={6} style={{ flex: 1.5, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
        {canEdit && dirty ? <Button title="Save" icon="checkmark-outline" small loading={busy} onPress={save} /> : null}
        {setup ? null : <Button title="History" icon="time-outline" variant="secondary" small onPress={onHistory} />}
        {canEdit && !setup && inc2Set ? <Button title="Add more" icon="add-outline" variant="secondary" small onPress={onMore} /> : null}
      </Row>
    </View>
  );
}

/** Admin only: choose the employee, the new salary and the effective date */
function IncrementDialog({ rows, initialUser, onClose, onSaved }: {
  rows: SalaryOverviewRow[]; initialUser: string; onClose: () => void; onSaved: () => void;
}) {
  const people = useMemo(() => rows.filter((r) => !r.left_on), [rows]);
  const [userId, setUserId] = useState(initialUser || people[0]?.user_id || '');
  const [salary, setSalary] = useState('');
  const [date, setDate] = useState(istDateISO());
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const row = people.find((r) => r.user_id === userId);
  const first = row?.basic === null || row?.basic === undefined;
  const now = row?.current_salary ?? row?.basic ?? 0;
  const next = Number(salary.replace(/,/g, ''));
  const valid = salary.trim() !== '' && Number.isFinite(next) && next >= 0;

  const save = async () => {
    if (!row) return Alert.alert('Choose an employee.');
    if (!valid) return Alert.alert('Enter the new monthly salary as a number, for example 30000.');
    if (!first && next === now) return Alert.alert('The new salary is the same as the current salary.');
    setBusy(true);
    try {
      await api.incrementSalary(row.user_id, next, first ? null : date, note);
      Alert.alert(first ? 'Basic salary saved' : 'Increment saved', first
        ? `${row.full_name}: ${inr(next)} per month.`
        : `${row.full_name}: ${inr(next)} per month from ${fmtISODate(date)}.`);
      onSaved();
    } catch (e) { Alert.alert('Could not save', errorText(e)); }
    finally { setBusy(false); }
  };

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={st.backdrop} onPress={onClose}>
        <Pressable style={st.sheet} onPress={() => {}}>
          <Text style={st.sheetTitle}>{first ? 'Set Basic Salary' : 'Increment Salary'}</Text>
          <Text style={st.sub}>Only the Admin / HR can do this. It is saved in the salary history and cannot be edited later.</Text>
          <Text style={st.label}>Employee</Text>
          <Dropdown width="100%" value={Math.max(0, people.findIndex((r) => r.user_id === userId))}
            onChange={(i) => setUserId(people[i]?.user_id ?? '')}
            options={people.map((r, i) => ({ value: i, label: r.full_name }))} />
          {row ? <Text style={[st.meta, { marginTop: 6 }]}>{first ? 'No salary is set yet.' : `Current salary: ${inr(now)} per month`}</Text> : null}
          <View style={{ height: 10 }} />
          <Field label={first ? 'Basic monthly salary' : 'New monthly salary'} value={salary} keyboardType="numeric" placeholder="e.g. 30000"
            onChangeText={(v) => setSalary(v.replace(/[^0-9.]/g, '').slice(0, 10))} />
          {!first && valid ? <Text style={[st.meta, { marginBottom: 8, color: next >= now ? C.green : C.red }]}>Increment: {next >= now ? '+' : '-'} {inr(Math.abs(next - now))}</Text> : null}
          {!first ? (
            <PickerField label="Effective from (date)" mode="date" value={date} onChange={(v) => setDate(v)} />
          ) : null}
          <Field label="Note (optional)" value={note} onChangeText={(v) => setNote(v.slice(0, 120))} placeholder="e.g. Yearly appraisal" />
          <Row style={{ marginTop: 6 }}>
            <Button title="Cancel" variant="secondary" style={{ flex: 1 }} onPress={onClose} />
            <Button title={first ? 'Save Salary' : 'Save Increment'} icon="checkmark-outline" style={{ flex: 1 }} loading={busy} onPress={save} />
          </Row>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const st = StyleSheet.create({
  title: { fontWeight: '800', color: C.ink, fontSize: 18 },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 2 },
  tr: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 10, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  th: { backgroundColor: '#FFC000', borderBottomColor: '#3C3C3C' },
  thText: { fontSize: 12, fontWeight: '800', color: '#1F1F1F', flex: 1 },
  input: { height: 38, borderRadius: 9, borderWidth: 1, borderColor: '#B9D4F6', backgroundColor: '#F5F9FF', paddingHorizontal: 9, fontSize: 13.5, fontWeight: '700', color: '#17314D', minWidth: 0 },
  off: { backgroundColor: '#F1F3F6', borderColor: '#E1E6EC', opacity: 0.7 },
  locked: { fontSize: 13.5, fontWeight: '800', color: '#17314D' },
  name: { fontSize: 14, fontWeight: '800', color: '#102A45' },
  cell: { fontSize: 13.5, fontWeight: '700', color: '#17314D', textAlign: 'right' },
  meta: { fontSize: 11.5, color: C.muted },
  foot: { color: C.muted, fontSize: 11.5, lineHeight: 17 },
  backdrop: { flex: 1, backgroundColor: 'rgba(6,37,63,0.55)', justifyContent: 'center', padding: 16 },
  sheet: { backgroundColor: C.white, borderRadius: 20, padding: 16, maxWidth: 520, width: '100%', alignSelf: 'center' },
  sheetTitle: { fontWeight: '800', fontSize: 17, color: C.ink },
  label: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginTop: 12, marginBottom: 6 },
  kpis: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  kpi: { flexGrow: 1, flexBasis: 220, minWidth: 200, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.white, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#E9EFF6' },
  kpiIcon: { width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  kpiLabel: { fontSize: 12, color: C.muted, fontWeight: '600' },
  kpiValue: { fontSize: 20, fontWeight: '800', color: '#102A45', marginTop: 2 },
  hd: { flexDirection: 'row', gap: 8, paddingVertical: 10, paddingHorizontal: 16, backgroundColor: '#F7FAFD', borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#EEF3F8' },
  hdText: { fontSize: 11, fontWeight: '800', color: '#7A8CA0', letterSpacing: 0.6 },
  tr2: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 12, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  basicTxt: { fontSize: 14.5, fontWeight: '800', color: '#102A45' },
  incAmt: { fontSize: 13.5, fontWeight: '800', color: '#0E7A48' },
  muted: { color: '#B5C0CC', fontSize: 14 },
  foot2: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14, flexWrap: 'wrap', gap: 8 },
  tile: { flex: 1, backgroundColor: '#F4F8FC', borderRadius: 10, padding: 8 },
  tileLabel: { fontSize: 10, fontWeight: '800', color: C.muted, letterSpacing: 0.5 },
  tileVal: { fontSize: 13.5, fontWeight: '800', color: '#17314D', marginTop: 3 },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#D8F3F0', alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontWeight: '800', color: '#0B5C66' },
  cur: { fontSize: 16, fontWeight: '800', color: '#102A45' },
  hrow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
});
