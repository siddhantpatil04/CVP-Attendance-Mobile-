import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert, StyleSheet, Text } from 'react-native';
import { Banner, Button, Card, Field, Loading, Screen, SectionTitle } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { fetchRelease, publishUpdate, ReleaseInfo } from '../../lib/release';
import { errorText } from '../../lib/supabase';
import { fmtDateLong, fmtTime12 } from '../../lib/time';
import { C } from '../../theme';

/** Admin: push an update. Everyone signed in (phones and desktops) is signed out, gets the new version and logs in again. */
export default function AppUpdateScreen() {
  const { isFullAdmin } = useAuth();
  const [info, setInfo] = useState<ReleaseInfo | null | undefined>(undefined);
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => { setInfo(await fetchRelease()); }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const publish = () =>
    Alert.alert('Publish update?', 'Everyone who is signed in will be signed out and must log in again to get the new version.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Publish', style: 'destructive', onPress: async () => {
        setBusy(true);
        try { const r = await publishUpdate(note.trim()); setInfo(r); setNote(''); Alert.alert('Update published', `Release ${r.release} is out. Everyone will sign in again.`); }
        catch (e) { Alert.alert('Could not publish', errorText(e)); }
        finally { setBusy(false); }
      } },
    ]);

  if (!isFullAdmin) return <Screen><Banner tone="amber" text="Only the Admin can publish updates." /></Screen>;
  if (info === undefined) return <Loading />;

  return (
    <Screen>
      <Card>
        <Text style={st.label}>Current release</Text>
        <Text style={st.big}>{info ? `#${info.release}` : 'Not set up'}</Text>
        {info ? <Text style={st.sub}>Published {fmtDateLong(info.published_at)} - {fmtTime12(info.published_at)}{info.note ? ` - ${info.note}` : ''}</Text> : null}
        {!info ? <Banner tone="amber" text="Run the latest cvp_attendance_schema.sql in Supabase first (section 22)." /> : null}
      </Card>

      <SectionTitle title="Publish an update" />
      <Card>
        <Field label="What is new (optional)" value={note} onChangeText={setNote} placeholder="e.g. New salary report" />
        <Button title="Publish Update (sign everyone out)" icon="cloud-upload-outline" loading={busy} disabled={!info} onPress={publish} />
      </Card>
    </Screen>
  );
}

const st = StyleSheet.create({
  label: { fontSize: 11, fontWeight: '800', color: '#8594A6', textTransform: 'uppercase' },
  big: { fontSize: 26, fontWeight: '800', color: '#102A45', marginTop: 2 },
  sub: { fontSize: 12.5, color: C.muted, marginTop: 2 },
});
