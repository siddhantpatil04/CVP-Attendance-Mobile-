import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MonthPicker } from '../../components/Pickers';
import { Banner, Button, Card, Empty, Field, Loading, Pill, Row } from '../../components/ui';
import { api, EmployeeDetails, PayrollRow, Profile } from '../../lib/api';
import { useIsDesktop } from '../../lib/layout';
import { PAYROLL_RULES, SlipData, SlipResult, computeSlip, rupeesInWords, shareSalarySlip } from '../../lib/salarySlip';
import { errorText } from '../../lib/supabase';
import { fmtISODate, istDateISO } from '../../lib/time';
import { C } from '../../theme';

const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const inr = (n: number) => `₹ ${Number(n).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
type Line = { p: Pick<Profile, 'id' | 'full_name' | 'username'>; res: SlipResult };

/**
 * "Salary Slips" tab of Salary Management: one line per employee for the chosen month, built from the saved payroll,
 * salary and bank details. A slip is only made when everything is present ("Cannot generate" explains what is missing).
 */
export default function SalarySlipsTab() {
  const nav = useNavigation<any>();
  const desktop = useIsDesktop();
  const today = istDateISO();
  const [ym, setYm] = useState({ year: Number(today.slice(0, 4)), month: Number(today.slice(5, 7)) });
  const [lines, setLines] = useState<Line[] | null>(null);
  const [q, setQ] = useState('');
  const [page, setPage] = useState(0);
  const [view, setView] = useState<SlipData | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLines(null); setError('');
    try {
      const [profiles, pay, details] = await Promise.all([api.allProfiles(), api.payroll(ym.year, ym.month), api.detailsForReports()]);
      const payBy = new Map<string, PayrollRow>(pay.map((p) => [p.user_id, p]));
      const detBy = new Map<string, Partial<EmployeeDetails>>(details.map((d) => [d.user_id, d]));
      const list = profiles.filter((p) => p.role === 'Employee' || p.role === 'HR').map((p) => ({
        p, res: computeSlip(payBy.get(p.id), detBy.get(p.id), { designation: p.designation ?? '', joining: p.joining_date ?? null, department: p.department ?? null }, ym.year, ym.month),
      }));
      setLines(list); setPage(0);
    } catch (e) { setError(errorText(e)); setLines([]); }
  }, [ym.year, ym.month]);
  useEffect(() => { load(); }, [load]);

  const shown = useMemo(() => {
    const k = q.trim().toLowerCase();
    return (lines ?? []).filter((l) => !k || `${l.p.full_name} ${l.p.username}`.toLowerCase().includes(k));
  }, [lines, q]);
  const okCount = (lines ?? []).filter((l) => l.res.ok).length;
  const bad = (lines ?? []).filter((l) => !l.res.ok);

  const pdf = async (s: SlipData) => {
    setBusy(true);
    try { await shareSalarySlip(s); } catch (e) { Alert.alert('Could not create the PDF', errorText(e)); } finally { setBusy(false); }
  };
  const fix = (id: string) => nav.navigate('EmployeeDetail', { userId: id });

  return (
    <View style={{ gap: 12 }}>
      <Row style={{ flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }} gap={10}>
        <MonthPicker year={ym.year} month={ym.month} onChange={(y, m) => setYm({ year: y, month: m })} />
        <Text style={st.sub}>Amounts follow the saved salary, attendance and the payroll rules shown in the preview.</Text>
      </Row>

      <View style={st.kpis}>
        <Kpi icon="create-outline" label="Draft (ready)" value={okCount} bg="#FFF3DC" fg="#D18A00" />
        <Kpi icon="warning-outline" label="Cannot generate" value={bad.length} bg="#FDECEC" fg="#D14343" />
        <Kpi icon="people-outline" label="Employees" value={(lines ?? []).length} bg="#E7F1FF" fg={C.blue} />
      </View>

      {bad.length > 0 ? (
        <Banner tone="red" icon="alert-circle"
          text={`${bad.length} employee${bad.length > 1 ? 's have' : ' has'} no salary slip: a blank slip is never created. ${bad.slice(0, 4).map((b) => `${b.p.full_name} - ${(b.res as any).problems.join(' ')}`).join('  ')}${bad.length > 4 ? '  ...' : ''}`} />
      ) : null}
      {error ? <Banner tone="red" icon="alert-circle" text={error} /> : null}

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <View style={{ padding: 14 }}><Field placeholder="Search employee or code" value={q} onChangeText={(v) => { setQ(v); setPage(0); }} /></View>
        {desktop ? (
          <View style={st.hd}>
            <Text style={[st.hdText, { flex: 2.4 }]}>EMPLOYEE</Text>
            <Text style={[st.hdText, { flex: 1.3 }]}>GROSS EARNINGS</Text>
            <Text style={[st.hdText, { flex: 1.3 }]}>TOTAL DEDUCTIONS</Text>
            <Text style={[st.hdText, { flex: 1.3 }]}>NET PAYABLE</Text>
            <Text style={[st.hdText, { flex: 1.5 }]}>SLIP STATUS</Text>
            <Text style={[st.hdText, { flex: 2, textAlign: 'right' }]}>ACTIONS</Text>
          </View>
        ) : null}
        {!lines ? <Loading /> : shown.length === 0 ? <Empty text="No employees found." icon="search-outline" /> : shown.slice(page * 10, page * 10 + 10).map((l) => {
          const s = l.res.ok ? l.res.slip : null;
          const inits = l.p.full_name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
          const actions = s ? (
            <Row gap={6} style={{ flexWrap: 'wrap', justifyContent: desktop ? 'flex-end' : 'flex-start' }}>
              <Button title="Preview" icon="eye-outline" variant="secondary" small onPress={() => setView(s)} />
              <Button title="PDF" icon="document-text-outline" variant="secondary" small loading={busy} onPress={() => pdf(s)} />
            </Row>
          ) : <Row style={{ justifyContent: desktop ? 'flex-end' : 'flex-start' }}><Button title="Fix data" icon="create-outline" variant="secondary" small onPress={() => fix(l.p.id)} /></Row>;
          const who = (
            <Row style={{ flex: desktop ? 2.4 : undefined, minWidth: 0 }}>
              <View style={st.avatar}><Text style={st.avatarText}>{inits}</Text></View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={st.name} numberOfLines={1}>{l.p.full_name}</Text>
                <Text style={st.meta} numberOfLines={1}>{l.p.username}</Text>
              </View>
            </Row>
          );
          const status = s ? <Pill text="Draft" tone="amber" /> : <Pill text="Cannot generate" tone="red" />;
          return desktop ? (
            <View key={l.p.id} style={[st.tr, !s && { backgroundColor: '#FFF7F7' }]}>
              {who}
              <Text style={[st.num, { flex: 1.3 }]}>{s ? inr(s.gross) : '-'}</Text>
              <Text style={[st.num, { flex: 1.3, color: C.red }]}>{s ? `- ${inr(s.deductions)}` : '-'}</Text>
              <Text style={[st.num, { flex: 1.3 }]}>{s ? inr(s.net) : '-'}</Text>
              <View style={{ flex: 1.5, alignItems: 'flex-start' }}>
                {status}
                {!s ? <Text style={[st.meta, { marginTop: 3 }]} numberOfLines={2}>{(l.res as any).problems.join(' ')}</Text> : null}
              </View>
              <View style={{ flex: 2 }}>{actions}</View>
            </View>
          ) : (
            <View key={l.p.id} style={[st.trM, !s && { backgroundColor: '#FFF7F7' }]}>
              <Row style={{ justifyContent: 'space-between' }}>{who}{status}</Row>
              {s ? <Text style={st.meta}>Gross {inr(s.gross)}  -  Deductions {inr(s.deductions)}  -  Net {inr(s.net)}</Text> : <Text style={st.meta}>{(l.res as any).problems.join(' ')}</Text>}
              {actions}
            </View>
          );
        })}
        <View style={st.foot}>
          <Text style={st.sub}>{MONTH_NAMES[ym.month - 1]} {ym.year} - {Math.min(page * 10 + 10, shown.length)} of {shown.length} employees</Text>
          <Row gap={6}>
            <Button title="Previous" variant="secondary" small disabled={page === 0} onPress={() => setPage(page - 1)} />
            <Button title="Next" variant="secondary" small disabled={(page + 1) * 10 >= shown.length} onPress={() => setPage(page + 1)} />
          </Row>
        </View>
      </Card>

      <Modal visible={!!view} transparent animationType="fade" onRequestClose={() => setView(null)}>
        <Pressable style={st.backdrop} onPress={() => setView(null)}>
          <Pressable style={[st.sheet, desktop && { flexDirection: 'row' }]} onPress={() => {}}>
            {view ? <Preview s={view} desktop={desktop} busy={busy} onPdf={() => pdf(view)} onClose={() => setView(null)} /> : null}
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

function Kpi({ icon, label, value, bg, fg }: { icon: any; label: string; value: number; bg: string; fg: string }) {
  return (
    <View style={st.kpi}>
      <View style={[st.kpiIcon, { backgroundColor: bg }]}><Ionicons name={icon} size={20} color={fg} /></View>
      <View><Text style={st.kpiLabel}>{label}</Text><Text style={st.kpiValue}>{value}</Text></View>
    </View>
  );
}

/** The slip as it prints, and "How it was calculated" beside it */
function Preview({ s, desktop, busy, onPdf, onClose }: { s: SlipData; desktop: boolean; busy: boolean; onPdf: () => void; onClose: () => void }) {
  const cell = (t: string, bold = false, right = false) => <Text style={[st.pc, bold && { fontWeight: '800', color: '#10253F' }, right && { textAlign: 'right' }]}>{t}</Text>;
  const amt = (n: number) => n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const info = (a: string, av: string, b: string, bv: string) => (
    <View style={st.prow}><Text style={[st.pl, { flex: 1 }]}>{a}</Text><Text style={[st.pv, { flex: 1.2 }]}>{av}</Text><Text style={[st.pl, { flex: 1 }]}>{b}</Text><Text style={[st.pv, { flex: 1.2 }]}>{bv}</Text></View>
  );
  const two = (a: string, av: string, b: string, bv: string, tot = false) => (
    <View style={[st.prow, tot && { backgroundColor: '#EBF1F8' }]}><View style={{ flex: 1.1 }}>{cell(a, true)}</View><View style={{ flex: 1 }}>{cell(av, true, true)}</View><View style={{ flex: 1.6 }}>{cell(b, true)}</View><View style={{ flex: 1 }}>{cell(bv, true, true)}</View></View>
  );
  const R = PAYROLL_RULES;
  return (
    <>
      <ScrollView style={{ flex: 1.6, backgroundColor: '#EAF0F8' }} contentContainerStyle={{ padding: 16 }}>
        <View style={st.paper}>
          <Text style={st.co}>C. V. PATIL & ASSOCIATES</Text>
          <View style={st.band}><Text style={st.bandText}>SALARY SLIP FOR THE MONTH OF {MONTH_NAMES[s.month - 1].toUpperCase()} {s.year}</Text></View>
          <View style={st.tbl}>
            {info('Employee Code', s.code, 'Employee Name', s.name)}
            {info('Department', s.department, 'Designation', s.designation)}
            {info('Date of Joining', s.joining === '-' ? '-' : fmtISODate(s.joining), 'Bank Name', s.bank || '-')}
            {info('Account Number', `XXXX ${s.account.slice(-4)}`, 'PAN', s.pan)}
            {info('UAN / PF Number', s.uan, 'Paid Days / Month Days', `${Number(s.paidDays.toFixed(2))} / ${s.monthDays}`)}
          </View>
          <View style={[st.tbl, { marginTop: 10 }]}>
            <View style={[st.prow, { backgroundColor: '#06253F' }]}>
              {['EARNINGS', 'AMOUNT (₹)', 'DEDUCTIONS', 'AMOUNT (₹)'].map((h, i) => <Text key={i} style={[st.ph, { flex: i % 2 ? 1 : i === 0 ? 1.1 : 1.6 }, i % 2 ? { textAlign: 'right' } : null]}>{h}</Text>)}
            </View>
            {two('Basic', amt(s.basic), `Provident Fund (${R.pfPct}% of Basic)`, amt(s.pf))}
            {two('HRA', amt(s.hra), 'Tax (Professional Tax)', amt(s.tax))}
            {two('Allowances', amt(s.allowances), 'Other Deductions', amt(s.other))}
            {two('Bonus', amt(s.bonus), '', '')}
            {two('Gross Earnings', amt(s.gross), 'Total Deductions', amt(s.deductions), true)}
          </View>
          <View style={st.net}><Text style={st.netL}>NET SALARY PAYABLE</Text><Text style={st.netV}>₹ {amt(s.net)}</Text></View>
          <Text style={st.words}>In words: {rupeesInWords(s.net)}</Text>
        </View>
      </ScrollView>
      <View style={[st.side, desktop && { width: 340 }]}>
        <Row style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <View style={{ flex: 1 }}>
            <Text style={st.sideTitle}>Salary Slip - {MONTH_NAMES[s.month - 1]} {s.year}</Text>
            <Text style={st.sub}>{s.name} - {s.code}</Text>
          </View>
          <Pressable onPress={onClose} hitSlop={10}><Ionicons name="close" size={22} color={C.ink} /></Pressable>
        </Row>
        <Text style={st.secHead}>HOW IT WAS CALCULATED</Text>
        <View style={st.box}><Text style={st.boxHead}>SALARY</Text><Text style={st.boxMain}>{inr(s.salary)} / month</Text><Text style={st.sub}>From the salary record (increments applied from their effective date)</Text></View>
        <View style={st.box}><Text style={st.boxHead}>ATTENDANCE</Text><Text style={st.boxMain}>{Number(s.paidDays.toFixed(2))} paid days - {Number(s.unpaidDays.toFixed(2))} unpaid</Text><Text style={st.sub}>Salary for the paid days: {inr(s.basic + s.hra + s.allowances)}</Text></View>
        <View style={st.box}><Text style={st.boxHead}>PAYROLL RULES</Text>
          <Text style={st.boxMain}>Basic {R.basicPct}% - HRA {R.hraPctOfBasic}% of Basic - PF {R.pfPct}% of Basic (max {inr(R.pfMax)})</Text>
          <Text style={st.sub}>{s.pfApplies ? 'PF applies (UAN present).' : 'No UAN, so no PF is deducted.'} Professional Tax by the Maharashtra slab. Bonus = overtime pay.</Text></View>
        <View style={{ flex: 1 }} />
        <Button title="Download PDF" icon="download-outline" variant="secondary" loading={busy} onPress={onPdf} />
      </View>
    </>
  );
}

const st = StyleSheet.create({
  sub: { color: C.muted, fontSize: 12, marginTop: 2 },
  kpis: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  kpi: { flexGrow: 1, flexBasis: 200, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#fff', borderRadius: 14, borderWidth: 1, borderColor: '#E7EEF6', padding: 14 },
  kpiIcon: { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  kpiLabel: { fontSize: 11.5, fontWeight: '700', color: C.muted },
  kpiValue: { fontSize: 22, fontWeight: '800', color: '#102944' },
  hd: { flexDirection: 'row', paddingHorizontal: 14, paddingVertical: 10, borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#EEF3F8', backgroundColor: '#FAFCFE' },
  hdText: { fontSize: 11, fontWeight: '800', color: '#8594A6', letterSpacing: 0.4 },
  tr: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  trM: { gap: 8, paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  avatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#E3F2FB', alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontWeight: '800', fontSize: 12, color: '#0A4F7A' },
  name: { fontWeight: '800', color: '#102944', fontSize: 13.5 },
  meta: { fontSize: 11.5, color: C.muted },
  num: { fontWeight: '800', color: '#17314D', fontSize: 13.5 },
  foot: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8, padding: 14 },
  backdrop: { flex: 1, backgroundColor: 'rgba(8,24,45,0.55)', alignItems: 'center', justifyContent: 'center', padding: 16 },
  sheet: { width: '100%', maxWidth: 1000, height: '90%', backgroundColor: '#fff', borderRadius: 16, overflow: 'hidden' },
  side: { padding: 18, gap: 10 },
  sideTitle: { fontWeight: '800', fontSize: 16, color: '#102944' },
  secHead: { fontSize: 11, fontWeight: '800', color: '#8594A6', letterSpacing: 0.5, marginTop: 6 },
  box: { borderWidth: 1, borderColor: '#E4EDF6', borderRadius: 10, padding: 10 },
  boxHead: { fontSize: 10.5, fontWeight: '800', color: '#8594A6' },
  boxMain: { fontWeight: '800', color: '#102944', fontSize: 13.5, marginTop: 2 },
  paper: { backgroundColor: '#fff', padding: 18, borderRadius: 4 },
  co: { fontWeight: '800', fontSize: 19, color: '#06253F', borderBottomWidth: 2, borderBottomColor: '#06253F', paddingBottom: 8 },
  band: { backgroundColor: '#EBF1F8', borderWidth: 1, borderColor: '#D0DAE6', paddingVertical: 8, marginVertical: 10 },
  bandText: { textAlign: 'center', fontWeight: '800', fontSize: 12.5, letterSpacing: 0.6, color: '#14202F' },
  tbl: { borderWidth: 1, borderColor: '#D0DAE6' },
  prow: { flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#D0DAE6', paddingHorizontal: 8, paddingVertical: 6, gap: 6 },
  pl: { fontSize: 11, fontWeight: '700', color: '#6E7A8A' },
  pv: { fontSize: 11, fontWeight: '800', color: '#14202F' },
  ph: { fontSize: 11, fontWeight: '800', color: '#fff' },
  pc: { fontSize: 11.5, fontWeight: '600', color: '#33465C' },
  net: { flexDirection: 'row', justifyContent: 'space-between', borderWidth: 2, borderColor: '#06253F', padding: 10, marginTop: 14 },
  netL: { fontWeight: '800', fontSize: 13, color: '#14202F' },
  netV: { fontWeight: '800', fontSize: 15, color: '#14202F' },
  words: { fontWeight: '800', fontSize: 11, marginTop: 6, color: '#14202F' },
});
