﻿import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { Dropdown } from '../../components/Pickers';
import { Button, Card, Chips, Field, Row, Screen } from '../../components/ui';
import { MIN_PASSWORD } from '../../config';
import { api, Role } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { errorText } from '../../lib/supabase';

const rowTop = { alignItems: 'flex-start' as const };
const lbl = { fontSize: 12, fontWeight: '700' as const, color: '#3A5068', marginBottom: 8 };
const Col = ({ children }: { children: React.ReactNode }) => <View style={{ flex: 1, minWidth: 0 }}>{children}</View>;
const phoneKey = (p: string | null | undefined) => (p ?? '').replace(/\D/g, '').slice(-10);

/** Add a person (Employee, HR or Admin): Admin / HR set the username and the first password here. */
export default function AddEmployeeScreen() {
  return <Screen><AddEmployeeForm /></Screen>;
}

/** The "add a person" form. `embedded` = shown inside the Employee Forms page (opens the new form without leaving that page's history). */
export function AddEmployeeForm({ embedded, onCreated }: { embedded?: boolean; onCreated?: () => void }) {
  const nav = useNavigation<any>();
  const { profile } = useAuth();
  const [f, setF] = useState({
    full_name: '', mobile: '', username: '', email: '', department: '', designation: '', role: 'Employee' as Role,
    site_employee: false, password: '', uan_no: '',
  });
  const [busy, setBusy] = useState(false);

  // suggest the next Employee ID (emp001, emp002, ...)
  useEffect(() => {
    let alive = true;
    api.allProfiles().then((all) => {
      const max = all.reduce((m, p) => {
        const n = /^emp(\d+)$/i.exec(p.username);
        return n ? Math.max(m, Number(n[1])) : m;
      }, 0);
      if (alive) setF((cur) => (cur.username ? cur : { ...cur, username: `emp${String(max + 1).padStart(3, '0')}` }));
    }).catch(() => {});
    return () => { alive = false; };
  }, []);

  const create = async () => {
    if (!f.full_name.trim()) return Alert.alert('Enter the full name.');
    // working time: office 8:30 AM - 5:30 PM, site 9:00 AM - 6:00 PM
    const shift = f.site_employee ? { shift_start: '09:00', shift_end: '18:00' } : { shift_start: '08:30', shift_end: '17:30' };
    if (!f.username.trim()) return Alert.alert('Enter a username.');
    if (!/^[A-Za-z0-9._-]{2,40}$/.test(f.username.trim())) return Alert.alert('Username may contain letters, numbers, dot, dash and underscore only.');
    if (f.password.length < MIN_PASSWORD) return Alert.alert(`Password must be at least ${MIN_PASSWORD} characters.`);
    setBusy(true);
    try {
      const res = await api.adminUsers({
        action: 'create', full_name: f.full_name.trim(), username: f.username.trim().toLowerCase(), password: f.password,
        email: f.email.trim() || undefined, department: f.department.trim() || undefined, role: f.role, site_employee: f.site_employee, ...shift,
      });
      const extra: { designation?: string; phone?: string } = {};
      if (f.designation.trim()) extra.designation = f.designation.trim();
      if (phoneKey(f.mobile).length === 10) extra.phone = phoneKey(f.mobile);
      if (extra.designation || extra.phone) await api.updateProfile(res.user_id, extra).catch(() => {});
      let uanNote = '';
      if (f.uan_no.trim()) await api.saveEmployeeDetails(res.user_id, { uan_no: f.uan_no.trim() }).catch(() => { uanNote = ' The UAN number could not be saved - add it in the Employee Form.'; });
      Alert.alert('Account created', `${f.full_name.trim()} can now sign in with username "${f.username.trim().toLowerCase()}".${uanNote}`);
      if (embedded) {
        setF((cur) => ({ ...cur, full_name: '', mobile: '', email: '', department: '', designation: '', password: '', username: '', uan_no: '' }));
        onCreated?.();
        if (f.role === 'Employee') nav.navigate('EmployeeForm', { userId: res.user_id, name: f.full_name.trim() });   // fill the Employee Form next
      } else nav.goBack();
    } catch (e) {
      Alert.alert('Could not create', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  // Admin and HR have the same access and can create Employee / HR / Admin accounts
  const roles: Role[] = profile?.role === 'Admin' || profile?.role === 'HR' ? ['Employee', 'HR', 'Admin'] : ['Employee'];

  return (
    <>
      <Card>
        <Row style={rowTop}>
          <Col><Field label="Full name" value={f.full_name} onChangeText={(v) => setF({ ...f, full_name: v })} placeholder="e.g. Rahul Patil" /></Col>
          <Col>
            <Field label="Mobile number (optional)" value={f.mobile} keyboardType="phone-pad" maxLength={14}
              onChangeText={(v) => setF({ ...f, mobile: v })} placeholder="10-digit mobile number" />
          </Col>
        </Row>
        <Row style={rowTop}>
          <Col><Field label="Department (optional)" value={f.department} onChangeText={(v) => setF({ ...f, department: v })} placeholder="e.g. Engineering" /></Col>
          <Col><Field label="Designation (optional)" value={f.designation} onChangeText={(v) => setF({ ...f, designation: v })} placeholder="e.g. Site Engineer" /></Col>
        </Row>
        <Row style={rowTop}>
          <Col>
            <Text style={lbl}>Role</Text>
            <Chips<Role> options={roles} value={f.role} onChange={(r) => setF({ ...f, role: r })} />
          </Col>
          <Col>
            <Text style={lbl}>Employee type</Text>
            <Dropdown width="100%" value={f.site_employee ? 1 : 0} onChange={(v) => setF({ ...f, site_employee: v === 1 })}
              options={[{ value: 0, label: 'Office' }, { value: 1, label: 'Site' }]} />
          </Col>
        </Row>
        <Row style={rowTop}>
          <Col><Field label="Employee ID / Username" value={f.username} onChangeText={(v) => setF({ ...f, username: v })} autoCapitalize="none" placeholder="e.g. emp014" /></Col>
          <Col><Field label={`Initial password (min ${MIN_PASSWORD} characters)`} value={f.password} onChangeText={(v) => setF({ ...f, password: v })} secureTextEntry /></Col>
        </Row>
        <Field label="UAN no. (PF, optional)" value={f.uan_no} keyboardType="number-pad" maxLength={12} placeholder="12 digits"
          onChangeText={(v) => setF({ ...f, uan_no: v.replace(/\D/g, '') })} />
        <Field label="E-mail (optional)" value={f.email} onChangeText={(v) => setF({ ...f, email: v })} autoCapitalize="none" keyboardType="email-address" placeholder="Auto-generated if blank" />
        <Button title="Create Account" icon="person-add-outline" loading={busy} onPress={create} />
      </Card>
    </>
  );
}
