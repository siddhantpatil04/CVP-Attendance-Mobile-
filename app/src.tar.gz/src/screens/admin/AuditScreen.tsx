import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, View } from 'react-native';
import { Dropdown } from '../../components/Pickers';
import { Button, Card, Empty, Field, Kpi, KpiGrid, ListItem, Loading, Screen } from '../../components/ui';
import { api, AuditRow } from '../../lib/api';
import { shareCsv } from '../../lib/csv';
import { errorText } from '../../lib/supabase';
import { fmtDateLong, fmtTime12 } from '../../lib/time';

export default function AuditScreen() {
  const [rows, setRows] = useState<AuditRow[] | null>(null);
  const [q, setQ] = useState('');
  const load = useCallback(async () => {
    try { setRows(await api.audit(1000)); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  // Drop-down of event types with counts: -1 = list hidden, 0 = all events, n = the n-th type
  const [type, setType] = useState(-1); // -1 = list hidden, 0 = all events, n = the n-th type
  const types = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of rows ?? []) m.set(r.action, (m.get(r.action) ?? 0) + 1);
    return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [rows]);

  const shown = useMemo(() => {
    const k = q.trim().toLowerCase();
    let r = rows ?? [];
    if (type > 0) r = r.filter((x) => x.action === types[type - 1]?.[0]);
    return (k ? r.filter((x) => `${x.action} ${x.detail} ${x.actor?.username} ${x.actor?.full_name}`.toLowerCase().includes(k)) : r).slice(0, 300);
  }, [rows, q, type, types]);

  if (!rows) return <Loading />;
  return (
    <Screen>
      <KpiGrid>
        <Kpi label="Recorded Events" value={rows.length} icon="list-outline" tone="blue" note="Latest 1000" />
        <Kpi label="Showing" value={shown.length} icon="filter-outline" tone="cyan" />
      </KpiGrid>
      <Field placeholder="Search action, user or detail" value={q} onChangeText={setQ} autoCapitalize="none" />
      <Button title="Share Audit CSV" icon="share-outline" variant="secondary" style={{ marginBottom: 12 }}
        onPress={() => shareCsv('cvp_audit_trail.csv', rows.map((r) => ({
          id: r.id, user: r.actor?.username ?? '', action: r.action, detail: r.detail ?? '', logged_at: r.logged_at,
        })))} />
      <View style={{ marginBottom: 10 }}>
        <Dropdown width="100%" value={type} onChange={setType}
          options={[{ value: -1, label: 'Select type' }, { value: 0, label: `All (${rows.length})` },
            ...types.map(([a, n], i) => ({ value: i + 1, label: `${a.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase())} (${n})` }))]} />
      </View>
      <Card style={{ paddingVertical: 4, display: type < 0 ? 'none' : 'flex' }}>
        {shown.length === 0 ? <Empty text="No events." /> : shown.map((r) => (
          <ListItem key={r.id} icon="document-text-outline"
            title={`${r.action.replace(/_/g, ' ')}`}
            subtitle={`${r.actor?.full_name ?? 'System'} - ${fmtDateLong(r.logged_at)} ${fmtTime12(r.logged_at)}${r.detail ? '\n' + r.detail : ''}`} />
        ))}
      </Card>
    </Screen>
  );
}

