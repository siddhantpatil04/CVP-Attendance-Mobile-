import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { PickerField } from '../../components/Pickers';
import {
  Avatar, Banner, Button, Card, Empty, Field, Kpi, KpiGrid, Loading, Pill, Screen, SectionTitle, Segmented,
} from '../../components/ui';
import { api, DayHoursStatus, WorkingHoursKpis, WorkingHoursRow, WorkingRule } from '../../lib/api';
import { hm } from '../../lib/hours';
import { useIsDesktop } from '../../lib/layout';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtTime12, istDateISO } from '../../lib/time';
import { C, Tone } from '../../theme';

const TONE: Record<DayHoursStatus, Tone> = {
  'Full day': 'green', 'Short hours': 'amber', Working: 'blue', 'No check-out': 'red', 'Not checked in': 'muted',
};

/** Working time rules (Admin changes them) + "Today - working hours" for every employee */
export default function WorkingHoursScreen() {
  const desktop = useIsDesktop();
  const [date, setDate] = useState(istDateISO());
  const [rows, setRows] = useState<WorkingHoursRow[] | null>(null);
  const [kpi, setKpi] = useState<WorkingHoursKpis | null>(null);
  const [rules, setRules] = useState<WorkingRule[]>([]);
  const [kind, setKind] = useState<'site' | 'office'>('site');
  const [range, setRange] = useState('500');
  const [hours, setHours] = useState('8');
  const [before, setBefore] = useState<'reason' | 'block'>('reason');
  const [saving, setSaving] = useState(false);

  const fillForm = (r: WorkingRule | undefined) => {
    if (!r) return;
    setRange(String(r.range_m));
    setHours(String(r.required_minutes / 60));
    setBefore(r.before_required);
  };

  const load = useCallback(async () => {
    try {
      const [r, k, rl] = await Promise.all([api.workingHoursToday(date), api.workingHoursKpis(date), api.workingRules()]);
      setRows(r);
      setKpi(k);
      setRules(rl);
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
      setRows((x) => x ?? []);
    }
  }, [date]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('working-hours', [{ table: 'attendance' }], () => load(), true);

  // the form shows the rule of the selected tab (Site / Office employees)
  // (only when the tab changes or the rules first arrive - a live refresh must not overwrite what the Admin is typing)
  const haveRules = rules.length > 0;
  React.useEffect(() => {
    if (haveRules) fillForm(rules.find((r) => r.kind === kind));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, haveRules]);

  const save = async () => {
    const r = Number(range);
    const h = Number(hours);
    if (!Number.isFinite(r) || r < 50 || r > 5000) return Alert.alert('Place range', 'Enter a range between 50 m and 5000 m.');
    if (!Number.isFinite(h) || h < 1 || h > 24) return Alert.alert('Required hours', 'Enter the required hours per day (1 to 24, for example 8 or 7.5).');
    setSaving(true);
    try {
      await api.saveWorkingRules({ kind, range_m: Math.round(r), required_minutes: Math.round(h * 60), before_required: before });
      Alert.alert('Saved', `${kind === 'site' ? 'Site' : 'Office'} employees: range ${Math.round(r)} m, ${hm(Math.round(h * 60))} per day. The app follows the new values the next time it is opened.`);
      await load();
    } catch (e) {
      Alert.alert('Could not save', errorText(e));
    } finally {
      setSaving(false);
    }
  };

  if (!rows || !kpi) return <Loading />;

  const statusText = (r: WorkingHoursRow) => r.status === 'Short hours' && r.short_minutes != null ? `Short ${hm(r.short_minutes)}` : r.status;

  const table = (
    <Card>
      <Text style={st.cardTitle}>Today - working hours</Text>
      <PickerField label="Date" mode="date" value={date} onChange={setDate} maximumDate={new Date()} />
      {rows.length === 0 ? <Empty text="No employees." icon="people-outline" /> : rows.map((r) => (
        <View key={r.user_id} style={st.row}>
          <Avatar name={r.full_name} size={36} />
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={st.name} numberOfLines={1}>{r.full_name}</Text>
            <Text style={st.sub} numberOfLines={1}>{r.username}{r.place ? ` - ${r.place}` : ''}</Text>
            <Text style={st.sub}>
              In {r.check_in_at ? fmtTime12(r.check_in_at) : '-'}  Out {r.check_out_at ? fmtTime12(r.check_out_at) : '-'}
              {r.worked_minutes != null ? `  Worked ${hm(r.worked_minutes)}${r.status === 'Working' ? ' (live)' : ''}` : ''}
            </Text>
            {r.short_reason ? <Text style={[st.sub, { color: '#C98400' }]}>Reason: {r.short_reason}</Text> : null}
          </View>
          <Pill text={statusText(r)} tone={TONE[r.status]} />
        </View>
      ))}
    </Card>
  );

  const rulesCard = (
    <Card>
      <Text style={st.cardTitle}>Working time rules</Text>
      <Text style={st.sub}>Admin can change these values</Text>
      <View style={{ marginVertical: 10 }}>
        <Segmented value={kind} onChange={setKind} options={[{ value: 'site', label: 'Site employees' }, { value: 'office', label: 'Office employees' }]} />
      </View>
      <Field label="Place range (metres)" value={range} onChangeText={setRange} keyboardType="numeric" />
      <Field label="Required hours / day" value={hours} onChangeText={setHours} keyboardType="numeric" />
      <View style={{ marginBottom: 10 }}>
        <Text style={st.label}>Before the required hours</Text>
        <Segmented value={before} onChange={setBefore}
          options={[{ value: 'reason', label: 'Allowed with reason' }, { value: 'block', label: 'Not allowed' }]} />
      </View>
      <Banner tone="blue" icon="information-circle-outline"
        text="Check-in and check-out are allowed at any time. Hours are counted from check-in to check-out. If someone forgets to check out, the day shows 'No check-out' for Admin to fix." />
      <Button title="Save rules" icon="save-outline" loading={saving} onPress={save} />
    </Card>
  );

  return (
    <Screen onRefresh={load}>
      <KpiGrid>
        <Kpi label="Checked in today" value={`${kpi.checked_in} of ${kpi.total}`} icon="people-outline" tone="blue" />
        <Kpi label="Full day (8h+)" value={kpi.full_day} icon="time-outline" tone="green" />
        <Kpi label="Short hours" value={kpi.short_hours} icon="warning-outline" tone="amber" />
        <Kpi label="No check-out yesterday" value={kpi.no_checkout_yesterday} icon="ban-outline" tone="red" />
      </KpiGrid>
      <SectionTitle title="Working time rules and hours" />
      {/* the employee-by-employee hours list is hidden: only the KPI cards and the rules are shown */}
      {rulesCard}
    </Screen>
  );
}

const st = StyleSheet.create({
  cardTitle: { fontSize: 16, fontWeight: '800', color: C.ink, marginBottom: 6 },
  label: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderTopWidth: 1, borderTopColor: '#EEF3F8' },
  name: { fontSize: 14.5, fontWeight: '800', color: C.ink },
  sub: { fontSize: 12, color: C.muted, marginTop: 2 },
});
