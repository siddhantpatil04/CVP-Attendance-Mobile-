import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Dropdown, PickerField } from '../../components/Pickers';
import LocationMap from '../../components/LocationMap';
import { Button, Card, Empty, Kpi, Pill, Row, Screen } from '../../components/ui';
import { api, FieldSiteJourney, JourneyPlanChange, MapDot, MapLine, Profile, Site } from '../../lib/api';
import { rh } from '../../lib/companies';
import { errorText } from '../../lib/supabase';
import { fmtDateLong, fmtMinutes, fmtTime12, istDateISO } from '../../lib/time';
import { shareXlsx } from '../../lib/xlsx';
import { styledTablePdf } from '../../lib/wagesRegisterPdf';
import { C } from '../../theme';

const km1 = (n: number | null | undefined) => `${Number(n ?? 0).toFixed(1)} km`;
const dmy = (iso: string) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`;
const gps = (la: number | null, ln: number | null) => (la != null && ln != null ? `${la.toFixed(4)}, ${ln.toFixed(4)}` : '-');

interface Day {
  key: string; user_id: string; name: string; code: string; date: string; list: FieldSiteJourney[];
  journeys: number; visits: number; mins: number; km: number; travelling: boolean;
  changed: number; changes: number; cancelled: number;   // journeys with a plan change, total plan changes, cancelled visits
}

/** Plan change of a journey (journey_change_plan.sql): "Plan changed 2x", "Cancelled" or "No change" */
const changesOf = (j: FieldSiteJourney) => j.plan_change_count ?? 0;
const planText = (j: FieldSiteJourney) => (j.status === 'cancelled' ? 'Cancelled' : changesOf(j) > 0 ? `Plan changed ${changesOf(j)}x` : 'No change');
const wasChanged = (j: FieldSiteJourney) => changesOf(j) > 0 || j.status === 'cancelled';

/** Admin / HR: view only (no approve / reject / edit / delete) */
export default function FieldJourneyReportScreen() {
  const today = istDateISO();
  const [from, setFrom] = useState(today);
  const [to, setTo] = useState(today);
  const [team, setTeam] = useState<Profile[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [userId, setUserId] = useState('');
  const [siteId] = useState(0);                 // no Site filter any more: every site is shown
  const [rows, setRows] = useState<FieldSiteJourney[] | null>(null);
  const [detail, setDetail] = useState<string | null>(null);
  const [planFilter] = useState<'all' | 'changed' | 'same'>('all');   // no Plan change filter any more: every journey is shown
  const [changes, setChanges] = useState<JourneyPlanChange[]>([]);
  const teamF = team;

  useEffect(() => {
    api.team().then((l) => setTeam(l.filter((p) => p.site_employee))).catch(() => {});
    api.sites(false).then(setSites).catch(() => {});
  }, []);

  const load = useCallback(async () => {
    if (to < from) return Alert.alert('To date must be on or after From date.');
    try { setRows(await api.fieldSiteJourneys(from, to, userId || undefined)); }
    catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [from, to, userId]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  // every plan change of the shown journeys (view only), loaded in small groups
  useEffect(() => {
    const ids = (rows ?? []).filter(wasChanged).map((j) => j.id);
    if (ids.length === 0) { setChanges([]); return; }
    let off = false;
    (async () => {
      const out: JourneyPlanChange[] = [];
      for (let i = 0; i < ids.length; i += 100) out.push(...await api.journeyPlanChanges(ids.slice(i, i + 100)));
      if (!off) setChanges(out);
    })();
    return () => { off = true; };
  }, [rows]);
  const siteName = (id: number | null | undefined) => (id ? sites.find((s) => s.id === id)?.name : undefined) ?? '-';
  const changesByJourney = useMemo(() => {
    const m = new Map<number, JourneyPlanChange[]>();
    for (const c of changes) m.set(c.journey_id, [...(m.get(c.journey_id) ?? []), c]);
    return m;
  }, [changes]);
  /** "10:15 AM Site B > Site C (Emergency)" for the export, one line per change */
  const changeText = (j: FieldSiteJourney) => (changesByJourney.get(j.id) ?? []).map((c) =>
    `${fmtTime12(c.changed_at)} ${siteName(c.old_destination_site_id)} > ${c.change_type === 'cancel' ? 'Cancelled' : siteName(c.new_destination_site_id)} (${c.reason}${c.remarks ? ': ' + c.remarks : ''}${!c.gps_available ? '; GPS not available' : ''})`).join(' | ');

  const filtered = useMemo(() => (rows ?? [])
    .filter((j) => !siteId || j.from_site_id === siteId || j.to_site_id === siteId)
    .filter((j) => planFilter === 'all' || (planFilter === 'changed' ? wasChanged(j) : !wasChanged(j))), [rows, siteId, planFilter]);

  const days: Day[] = useMemo(() => {
    const m = new Map<string, Day>();
    for (const j of filtered) {
      const key = `${j.user_id}|${j.journey_date}`;
      const d = m.get(key) ?? { key, user_id: j.user_id, name: j.full_name ?? 'Employee', code: j.emp_code ?? '', date: j.journey_date, list: [], journeys: 0, visits: 0, mins: 0, km: 0, travelling: false, changed: 0, changes: 0, cancelled: 0 };
      d.list.push(j);
      m.set(key, d);
    }
    return [...m.values()].map((d) => {
      d.list.sort((a, b) => a.seq_no - b.seq_no);
      const done = d.list.filter((j) => j.status === 'reached');
      d.journeys = d.list.length;
      d.visits = d.list.length ? 1 + done.length : 0;   // the starting site plus every site reached
      d.mins = done.reduce((a, j) => a + (j.duration_minutes ?? 0), 0);
      d.km = d.list.filter((j) => j.status !== 'travelling').reduce((a, j) => a + Number(j.distance_km ?? 0), 0);   // reached + cancelled (distance kept)
      d.travelling = d.list.some((j) => j.status === 'travelling');
      d.changed = d.list.filter(wasChanged).length;
      d.changes = d.list.reduce((a, j) => a + changesOf(j), 0);
      d.cancelled = d.list.filter((j) => j.status === 'cancelled').length;
      return d;
    }).sort((a, b) => b.date.localeCompare(a.date) || a.name.localeCompare(b.name));
  }, [filtered]);

  const statusOf = (j: FieldSiteJourney) => (j.status === 'reached' ? '' : j.status === 'cancelled' ? 'Cancelled' : j.journey_date === today ? 'Travelling' : 'Not reached');
  const flat = useMemo(() => [...filtered].sort((a, b) => a.journey_date.localeCompare(b.journey_date) || a.start_time.localeCompare(b.start_time)), [filtered]);

  const period = from === to ? fmtDateLong(`${from}T12:00:00+05:30`) : `${dmy(from)} to ${dmy(to)}`;
  const tableHead = ['#', 'Employee', 'Date', 'Starting site', 'Destination site', 'Start', 'Reached', 'Duration', 'Distance', 'Start GPS', 'Arrival GPS', 'Plan change', 'Plan change details'];
  const tableRows = (list: FieldSiteJourney[]) => list.map((j, i) => [
    i + 1, `${j.full_name ?? ''} (${j.emp_code ?? ''})`, dmy(j.journey_date), j.from_site_name ?? '', j.to_site_name ?? '',
    fmtTime12(j.start_time), j.reached_time ? fmtTime12(j.reached_time) : statusOf(j),
    j.duration_minutes != null ? fmtMinutes(j.duration_minutes) : '-', j.distance_km != null ? km1(j.distance_km) : '-',
    gps(j.start_lat, j.start_lng), j.status === 'cancelled' ? gps(j.cancelled_lat ?? null, j.cancelled_lng ?? null) : gps(j.reached_lat, j.reached_lng),
    planText(j), changeText(j),
  ]);
  const scope = detail ? flat.filter((j) => `${j.user_id}|${j.journey_date}` === detail) : flat;

  // PDF and Excel follow the same rules: exactly what is on screen. One employee (picked in the filter or opened in Details):
  // the name once in a green row and no Employee column. All employees: the Employee column stays.
  const exportSetup = () => {
    const oneId = userId || (detail ? scope[0]?.user_id : '');
    const single = !!oneId && scope.length > 0 && scope.every((j) => j.user_id === oneId);
    const first = scope[0];
    const prof = team.find((p) => p.id === oneId);
    const name = first?.full_name ?? prof?.full_name ?? 'Employee';
    const keep = tableHead.map((h) => !(single && h === 'Employee'));
    const head = tableHead.filter((_, i) => keep[i]);
    const body = tableRows(scope).map((r) => r.filter((_, i) => keep[i]));
    const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][Number(from.slice(5, 7)) - 1];
    const month = `${mon} ${from.slice(0, 4)}`;
    const emp = single ? { name: `${name}${first?.emp_code ? ` (${first.emp_code})` : ''}`, department: prof?.department || 'SITE' } : undefined;
    const file = `cvp_field_site_journey_${single ? name.trim().replace(/\s+/g, '_') + '_' : ''}${from}_to_${to}`;
    return { head, body, month, emp, file };
  };
  const exportPdf = async () => {
    if (scope.length === 0) return Alert.alert('Nothing to export', 'No journeys for these filters.');
    try {
      const x = exportSetup();
      await styledTablePdf(`${x.file}.pdf`, 'Field Site Report', period, x.head, x.body as (string | number)[][], {
        info: [`Name of the Establishment - ${rh().name}        For the Month of - ${x.month}`, `Address of the Establishment - ${rh().address}`],
        employee: x.emp ? `Name of the Employee - ${x.emp.name}        Department - ${x.emp.department}` : undefined,
      });
    } catch (e) { Alert.alert('Export failed', errorText(e)); }
  };
  const exportXlsx = async () => {
    if (scope.length === 0) return Alert.alert('Nothing to export', 'No journeys for these filters.');
    try {
      const x = exportSetup();
      await shareXlsx(`${x.file}.xlsx`, [{
        name: 'Field Site', title: 'Field Site Report', subtitle: period, compact: true, month: x.month, employee: x.emp,
        rows: x.body.map((r) => Object.fromEntries(x.head.map((h, i) => [h, r[i]]))),
      }]);
    } catch (e) { Alert.alert('Export failed', errorText(e)); }
  };
  const shown = detail ? days.find((d) => d.key === detail) : undefined;

  return (
    <Screen>
      {shown ? (
        <DetailView day={shown} today={today} onBack={() => setDetail(null)} onPdf={exportPdf} sites={sites}
          changes={changes.filter((c) => shown.list.some((j) => j.id === c.journey_id))} />
      ) : (
        <>
          <Card style={{ zIndex: 5 }}>
            <View style={st.filters}>
              <View style={st.f}><Text style={st.lbl}>Employee</Text>
                <Dropdown width="100%" value={teamF.findIndex((p) => p.id === userId)} onChange={(i) => setUserId(i >= 0 ? teamF[i].id : '')}
                  options={[{ value: -1, label: 'All employees' }, ...teamF.map((p, i) => ({ value: i, label: p.full_name }))]} /></View>
              {/* only two filters: the employee and one date (the Site and Plan change filters are removed) */}
              {/* one date: the report shows that day (from and to are both set to it) */}
              <View style={st.f}>
                <PickerField flat label="Select date" mode="date" value={from} onChange={(v) => { setFrom(v); setTo(v); }} />
              </View>
            </View>
            <Row style={{ marginTop: 10 }}>
              <Button title="PDF" icon="document-outline" variant="secondary" onPress={exportPdf} />
              <Button title="Excel" icon="download-outline" onPress={exportXlsx} />
            </Row>
          </Card>

          {rows === null ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : (
            days.length === 0 ? <Card><Empty icon="navigate-outline" text={`No field site journeys on ${dmy(from)}`} /></Card> : days.map((d) => (
              <Card key={d.key}>
                <View style={st.head}>
                  <View style={{ flex: 1, minWidth: 0 }}>
                    <Text style={st.name}>{d.name} {d.travelling && d.date === today ? <Pill text="Travelling now" tone="amber" /> : null}</Text>
                    <Text style={st.sub}>{d.code} - {fmtDateLong(`${d.date}T12:00:00+05:30`)}</Text>
                  </View>
                  <Button title="Details" icon="document-text-outline" variant="secondary" small onPress={() => setDetail(d.key)} />
                </View>
                <View style={st.chips}>
                  <Pill text={`${d.journeys} journey${d.journeys === 1 ? '' : 's'}`} tone="muted" />
                  <Pill text={`${d.visits} site visit${d.visits === 1 ? '' : 's'}`} tone="blue" />
                  <Pill text={d.mins ? fmtMinutes(d.mins) : '-'} tone="muted" />
                  <Pill text={d.km ? km1(d.km) : '-'} tone="muted" />
                  <Pill text={d.changes > 0 ? `Plan changed ${d.changes}x` : d.cancelled > 0 ? 'Plan changed' : 'No change'} tone={d.changed > 0 ? 'amber' : 'muted'} />
                  {d.cancelled > 0 ? <Pill text={`${d.cancelled} cancelled`} tone="red" /> : null}
                </View>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  <Chain list={d.list} today={today} />
                </ScrollView>
              </Card>
            ))
          )}
          <Text style={st.note}>Monitor only - no approve / reject. Distance and duration come from GPS points and timestamps.</Text>
        </>
      )}
    </Screen>
  );
}

/** Site A -> Site B -> Site C, each leg with its time, duration and km */
function Chain({ list, today }: { list: FieldSiteJourney[]; today: string }) {
  return (
    <View style={st.chain}>
      <Text style={st.node}>{list[0].from_site_name}</Text>
      {list.map((j) => (
        <React.Fragment key={j.id}>
          <View style={st.link}>
            <Text style={st.linkTime}>{fmtTime12(j.start_time)}{j.reached_time ? ` - ${fmtTime12(j.reached_time)}` : ''}</Text>
            <View style={st.line} />
            <Text style={st.linkKm}>{j.reached_time ? `${fmtMinutes(j.duration_minutes ?? 0)} - ${km1(j.distance_km)}` : j.status === 'cancelled' ? 'cancelled' : j.journey_date === today ? 'on the way' : 'not reached'}</Text>
          </View>
          <Text style={st.node}>{j.to_site_name}</Text>
        </React.Fragment>
      ))}
    </View>
  );
}

function Table({ head, body, widths }: { head: string[]; body: string[][]; widths: number[] }) {
  return (
    <View>
      <View style={st.tr}>{head.map((h, i) => <Text key={i} style={[st.th, { width: widths[i] }]}>{h}</Text>)}</View>
      {body.map((r, ri) => <View key={ri} style={st.tr}>{r.map((c, i) => <Text key={i} style={[st.td, { width: widths[i] }]}>{c}</Text>)}</View>)}
    </View>
  );
}

function DetailView({ day, today, onBack, onPdf, sites, changes }: {
  day: Day; today: string; onBack: () => void; onPdf: () => void; sites: Site[]; changes: JourneyPlanChange[];
}) {
  const first = day.list[0];
  const site = (id: number | null | undefined) => (id ? sites.find((s) => s.id === id) : undefined);
  const live = day.list.filter((j) => j.status !== 'cancelled');   // a cancelled visit is not a stop of the sequence
  const stops = [
    { name: first.from_site_name ?? '-', sub: `Left ${fmtTime12(first.start_time)}`, lat: first.start_lat, lng: first.start_lng },
    ...live.map((j, i) => ({
      name: j.to_site_name ?? '-', lat: j.reached_lat ?? j.start_lat, lng: j.reached_lng ?? j.start_lng,
      sub: j.reached_time ? `${fmtTime12(j.reached_time)}${live[i + 1] ? ` - ${fmtTime12(live[i + 1].start_time)}` : ''}` : (day.date === today ? 'On the way' : 'Not reached'),
      leg: j.reached_time ? `${fmtMinutes(j.duration_minutes ?? 0)} - ${km1(j.distance_km)}` : undefined,
    })),
  ] as { name: string; sub: string; lat: number; lng: number; leg?: string }[];
  const dots: MapDot[] = stops.map((s, i) => ({ key: `s${i}`, lat: s.lat, lng: s.lng, color: i === 0 ? '#16A34A' : '#1677FF', label: `${i + 1}. ${s.name}` }));
  // travelled route per journey: start -> change point(s) -> arrival (or the cancel point); the base line is the plain site-to-site route
  const lines: MapLine[] = [];
  day.list.forEach((j) => {
    const cs = changes.filter((c) => c.journey_id === j.id && c.lat != null && c.lng != null);
    const pts: [number, number][] = [[j.start_lat, j.start_lng], ...cs.map((c) => [c.lat as number, c.lng as number] as [number, number])];
    if (j.status === 'reached' && j.reached_lat != null && j.reached_lng != null) pts.push([j.reached_lat, j.reached_lng]);
    if (pts.length >= 2) lines.push({ key: `route${j.id}`, color: '#1677FF', label: `Journey ${j.seq_no}`, points: pts });
  });
  if (lines.length === 0) lines.push({ key: 'route', color: '#1677FF', label: '', points: stops.map((s) => [s.lat, s.lng] as [number, number]) });
  // change points (orange), and the destination that was dropped: grey dot with a dashed grey line from the change point
  changes.forEach((c, i) => {
    if (c.lat != null && c.lng != null) {
      dots.push({ key: `c${c.id}`, lat: c.lat, lng: c.lng, color: '#F59E0B', label: `Change point ${i + 1}: ${c.change_type === 'cancel' ? 'visit cancelled' : 'plan changed'} (${fmtTime12(c.changed_at)})` });
      const old = site(c.old_destination_site_id);
      if (old) {
        lines.push({ key: `x${c.id}`, color: '#9AA6B5', label: `Cancelled destination: ${old.name}`, dashed: true, points: [[c.lat, c.lng], [old.lat, old.lng]] });
        dots.push({ key: `o${c.id}`, lat: old.lat, lng: old.lng, color: '#9AA6B5', label: `Cancelled destination: ${old.name}` });
      }
      const nw = site(c.new_destination_site_id);
      if (nw) lines.push({ key: `n${c.id}`, color: '#16A34A', label: `New destination: ${nw.name}`, points: [[c.lat, c.lng], [nw.lat, nw.lng]] });
    }
  });
  return (
    <>
      <Row style={{ justifyContent: 'space-between' }}>
        <Button title="Back to report" icon="arrow-back" variant="secondary" small onPress={onBack} />
        <Button title="PDF" icon="document-outline" variant="secondary" small onPress={onPdf} />
      </Row>
      <Text style={st.name}>{day.name}</Text>
      <Text style={st.sub}>{day.code} - {fmtDateLong(`${day.date}T12:00:00+05:30`)}</Text>
      <View style={st.kpis}>
        <Kpi label="Journeys" value={day.journeys} icon="navigate-outline" />
        <Kpi label="Site visits" value={day.visits} icon="location-outline" tone="green" />
        <Kpi label="Travel time" value={day.mins ? fmtMinutes(day.mins) : '-'} icon="time-outline" tone="amber" />
        <Kpi label="Distance" value={km1(day.km)} icon="speedometer-outline" tone="purple" />
        <Kpi label="Plan changes" value={day.changes} icon="swap-horizontal-outline" tone="amber" />
        <Kpi label="Visits cancelled" value={day.cancelled} icon="close-circle-outline" tone="red" />
      </View>
      <Card>
        <Text style={st.name}>Sequence of visited sites</Text>
        {stops.map((s, i) => (
          <View key={i}>
            {s.leg ? <Text style={st.legTxt}>{s.leg}</Text> : null}
            <Text style={st.stopTxt}>{i + 1}. {s.name}</Text>
            <Text style={st.sub}>{s.sub}</Text>
          </View>
        ))}
        <View style={{ marginTop: 10 }}><LocationMap height={300} dots={dots} lines={lines} /></View>
      </Card>
      {changes.length > 0 ? (
        <Card>
          <Text style={st.name}>Plan change timeline</Text>
          <Text style={st.sub}>View only. Orange = change point, grey dashed = the destination that was dropped.</Text>
          {[...changes].sort((a, b) => a.changed_at.localeCompare(b.changed_at)).map((c, i) => {
            const j = day.list.find((x) => x.id === c.journey_id);
            const oldN = site(c.old_destination_site_id)?.name ?? '-';
            return (
              <View key={c.id} style={st.chg}>
                <Text style={st.stopTxt}>{i + 1}. {fmtTime12(c.changed_at)} - Journey {j?.seq_no ?? ''}: {oldN} to {c.change_type === 'cancel' ? 'CANCELLED' : (site(c.new_destination_site_id)?.name ?? '-')}
                  {c.change_type === 'back_to_start' ? ' (back to start)' : ''}</Text>
                <Text style={st.sub}>Reason: {c.reason}{c.remarks ? ` - ${c.remarks}` : ''}</Text>
                <Text style={st.sub}>
                  Change point: {c.gps_available && c.lat != null && c.lng != null ? `${gps(c.lat, c.lng)}${c.accuracy_m != null ? ` (+/-${c.accuracy_m} m)` : ''}` : 'GPS not available'}
                  {c.distance_at_change_km != null ? ` - ${km1(c.distance_at_change_km)} travelled so far` : ''}
                </Text>
              </View>
            );
          })}
        </Card>
      ) : null}
      <Card>
        <ScrollView horizontal><View>
          <Table head={['#', 'Starting site', 'Destination site', 'Start', 'Reached', 'Duration', 'Distance', 'Start GPS', 'Arrival GPS', 'Plan change']}
            widths={[34, 190, 190, 80, 100, 80, 80, 150, 150, 120]}
            body={day.list.map((j) => [String(j.seq_no), j.from_site_name ?? '', j.to_site_name ?? '', fmtTime12(j.start_time),
              j.reached_time ? fmtTime12(j.reached_time) : j.status === 'cancelled' ? 'Cancelled' : (day.date === today ? 'Travelling' : 'Not reached'),
              j.duration_minutes != null ? fmtMinutes(j.duration_minutes) : '-', j.distance_km != null ? km1(j.distance_km) : '-',
              gps(j.start_lat, j.start_lng), j.status === 'cancelled' ? gps(j.cancelled_lat ?? null, j.cancelled_lng ?? null) : gps(j.reached_lat, j.reached_lng),
              planText(j)])} />
        </View></ScrollView>
      </Card>
    </>
  );
}

const st = StyleSheet.create({
  filters: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 10 },
  // 4 cells in one line on a wide screen; 2 x 2 on a phone (each cell at least 140 wide, so two fit side by side)
  f: { flexGrow: 1, flexShrink: 1, flexBasis: 140, minWidth: 140 },
  lbl: { fontSize: 12, fontWeight: '800', color: '#4A5A6E', marginBottom: 4 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  name: { fontSize: 16, fontWeight: '800', color: C.ink },
  sub: { fontSize: 12.5, color: C.muted, marginTop: 2 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginVertical: 10 },
  kpis: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginVertical: 8 },
  note: { fontSize: 12, color: C.muted, marginTop: 6 },
  chain: { flexDirection: 'row', alignItems: 'center', paddingVertical: 4 },
  node: { borderWidth: 1.5, borderColor: '#1677FF', borderRadius: 14, paddingHorizontal: 12, paddingVertical: 6, fontSize: 13, fontWeight: '800', color: C.ink, backgroundColor: '#fff' },
  link: { alignItems: 'center', marginHorizontal: 6 },
  linkTime: { fontSize: 10.5, fontWeight: '700', color: C.muted },
  line: { width: 70, borderTopWidth: 2, borderStyle: 'dashed', borderColor: '#1677FF', marginVertical: 2 },
  linkKm: { fontSize: 10.5, fontWeight: '800', color: '#1677FF' },
  tr: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#EEF3F8', paddingVertical: 8 },
  th: { fontSize: 11, fontWeight: '800', color: '#8594A6', textTransform: 'uppercase', paddingHorizontal: 6 },
  td: { fontSize: 13, fontWeight: '700', color: C.ink, paddingHorizontal: 6 },
  stopTxt: { fontSize: 14.5, fontWeight: '800', color: C.ink, marginTop: 4 },
  legTxt: { fontSize: 12, fontWeight: '800', color: '#1677FF', marginLeft: 12 },
  chg: { borderTopWidth: 1, borderTopColor: '#EEF3F8', paddingVertical: 8, marginTop: 4 },
});
