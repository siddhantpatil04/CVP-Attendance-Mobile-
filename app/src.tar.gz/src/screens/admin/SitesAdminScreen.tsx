import { useFocusEffect } from '@react-navigation/native';
import * as Location from 'expo-location';
import React, { useCallback, useState } from 'react';
import { Alert, Linking, Text, View } from 'react-native';
import { Dropdown } from '../../components/Pickers';
import { citySites, SiteDropdown } from '../../components/SiteDropdown';
import { Banner, Button, Card, Chips, Col, Empty, Field, ListItem, Pill, Row, Screen, SectionTitle, Segmented } from '../../components/ui';
import { api, Site } from '../../lib/api';
import { fmtDistance, isForeignSiteName } from '../../lib/geo';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { C } from '../../theme';

type Tab = 'list' | 'edit';

/** Accepts "18.5485, 73.7740" (as copied from Google Maps) */
function parseCoords(v: string): { lat: number; lng: number } | null {
  const m = v.replace(/[()]/g, '').split(/[,\s]+/).filter(Boolean).map(Number);
  if (m.length !== 2 || m.some((n) => !Number.isFinite(n))) return null;
  const [lat, lng] = m;
  if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  return { lat, lng };
}

export default function SitesAdminScreen() {
  const [tab, setTab] = useState<Tab>('list');
  const [rows, setRows] = useState<Site[]>([]);
  const [editId, setEditId] = useState<number | null>(null);
  const [name, setName] = useState('');
  const [coords, setCoords] = useState('');
  const [radius, setRadius] = useState('500');
  const [unit, setUnit] = useState<'Metres' | 'Kilometres'>('Metres');
  const [active, setActive] = useState(true);
  const [busy, setBusy] = useState<'save' | 'del' | 'gps' | null>(null);

  const load = useCallback(async () => {
    try { setRows(await api.sites(false)); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('sites-admin', [{ table: 'sites' }], () => load());

  const [isOffice, setIsOffice] = useState(false); // office location: office employees check in / out only here (no selfie)
  const reset = () => { setEditId(null); setName(''); setCoords(''); setRadius('500'); setUnit('Metres'); setActive(true); setIsOffice(false); };

  const edit = (s: Site) => {
    setEditId(s.id); setName(s.name); setCoords(`${s.lat}, ${s.lng}`); setActive(s.active); setIsOffice(!!s.is_office);
    // Big areas are easier to read in kilometres
    if (s.radius_m >= 1000) { setUnit('Kilometres'); setRadius(String(s.radius_m / 1000)); }
    else { setUnit('Metres'); setRadius(String(s.radius_m)); }
    setTab('edit');
  };

  // Switching the unit keeps the same real distance (200 m <-> 0.2 km)
  const changeUnit = (u: 'Metres' | 'Kilometres') => {
    const n = Number(radius);
    if (Number.isFinite(n) && n > 0 && u !== unit) setRadius(String(u === 'Kilometres' ? n / 1000 : Math.round(n * 1000)));
    setUnit(u);
  };

  // Drop-down "Location source": 0 = paste coordinates, 1 = fill from this device's current position
  const [source, setSource] = useState(0);
  const [listFilter, setListFilter] = useState(-1); // -1 = hidden, 0 = all sites, otherwise one site id // Work Sites list: -1 = hidden, 0 = all sites, otherwise one site id
  const useMyLocation = async () => {
    setBusy('gps');
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (perm.status !== 'granted') {
        setSource(0);
        return Alert.alert('Location permission needed', 'Allow location access to use your current position.');
      }
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setCoords(`${pos.coords.latitude.toFixed(6)}, ${pos.coords.longitude.toFixed(6)}`);
    } catch (e) {
      setSource(0);
      Alert.alert('Could not get location', errorText(e));
    } finally {
      setBusy(null);
    }
  };
  const pickSource = (v: number) => {
    setSource(v);
    if (v === 1) useMyLocation();
  };

  const save = async () => {
    const c = parseCoords(coords);
    const r = Math.round(Number(radius) * (unit === 'Kilometres' ? 1000 : 1));
    if (!name.trim()) return Alert.alert('Enter the site name.');
    if (!c) return Alert.alert('Enter valid coordinates', 'Use the format: 18.5485, 73.7740 (latitude, longitude).');
    // the Foreign location site has no radius limit: the stored radius is not used\n    if (!isForeignSiteName(name) && (!Number.isFinite(r) || r < 20 || r > 100000)) return Alert.alert('Radius must be between 20 metres and 100 km.');
    setBusy('save');
    try {
      await api.saveSite({ id: editId ?? undefined, name: name.trim(), lat: c.lat, lng: c.lng, radius_m: isForeignSiteName(name) ? 500 : r, active, is_office: isOffice || editId != null ? isOffice : undefined });
      Alert.alert(editId ? 'Site updated' : 'Location added', editId ? undefined : `${name.trim()} is now ${isOffice ? 'the office location' : 'a work site'}. You can add another location.`);
      const wasEdit = editId != null;
      reset();
      setSource(0);
      // Editing returns to the list; adding stays here, ready for the next location
      if (wasEdit) setTab('list');
      await load();
    } catch (e) {
      Alert.alert('Could not save', errorText(e));
    } finally {
      setBusy(null);
    }
  };

  const remove = () => {
    if (editId == null) return;
    const lastActive = active && rows.filter((s) => s.active).length <= 1;
    Alert.alert(
      `Delete "${name}"?`,
      'The site is removed for good. Past attendance and selfie records keep the site name.'
        + (lastActive ? '\n\nThis is your last active site: until you add another, site employees will not be restricted to a site area.' : ''),
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: async () => {
          setBusy('del');
          try {
            await api.deleteSite(editId);
            reset();
            setTab('list');
            await load();
          } catch (e) {
            Alert.alert('Could not delete', errorText(e));
          } finally {
            setBusy(null);
          }
        } },
      ],
    );
  };

  const preview = parseCoords(coords);

  return (
    <Screen>
      <Segmented<Tab> value={tab} onChange={(t) => { if (t === 'edit' && tab === 'list') reset(); setTab(t); }}
        options={[{ value: 'list', label: 'Work Sites' }, { value: 'edit', label: editId ? 'Edit Site' : 'Add Site' }]} />

      {tab === 'edit' ? (
        <Card>
          <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
            <Button title="Site location" icon="construct-outline" variant={isOffice ? 'secondary' : 'primary'} style={{ flex: 1 }} onPress={() => setIsOffice(false)} />
            <Button title="Office location" icon="business-outline" variant={isOffice ? 'primary' : 'secondary'} style={{ flex: 1 }} onPress={() => setIsOffice(true)} />
          </View>
          <Row style={{ alignItems: 'flex-start' }}>
            <Col><Field label="Site / project name" value={name} onChangeText={setName} placeholder="e.g. STP Project Site" /></Col>
            <Col><Field label="Location (latitude, longitude)" value={coords} onChangeText={setCoords}
              placeholder="18.548640, 73.773280" autoCapitalize="none" autoCorrect={false} /></Col>
          </Row>
          <Row style={{ alignItems: 'flex-start' }}>
            <Col>
              <Text style={{ fontWeight: '700', color: C.ink, marginBottom: 6, fontSize: 12 }}>Location source</Text>
              <Dropdown value={source} onChange={pickSource} width="100%"
                options={[{ value: 0, label: 'Paste coordinates' }, { value: 1, label: busy === 'gps' ? 'Getting location...' : 'My location' }]} />
            </Col>
            <Col>
              {isForeignSiteName(name) ? (
                <>
                  <Text style={{ fontWeight: '700', color: C.ink, marginBottom: 6, fontSize: 12 }}>Allowed radius</Text>
                  <Text style={{ fontSize: 13, color: C.muted, lineHeight: 18 }}>No radius limit for the Foreign location. The employee can punch from any place (selfie, GPS and reason are required); the distance is recorded from the nearest work site.</Text>
                </>
              ) : (
                <>
                  <Text style={{ fontWeight: '700', color: C.ink, marginBottom: 6, fontSize: 12 }}>Allowed radius ({unit === 'Metres' ? 'm' : 'km'})</Text>
                  <Field value={radius} onChangeText={setRadius} keyboardType="decimal-pad" placeholder={unit === 'Metres' ? '500' : '15'} />
                </>
              )}
            </Col>
          </Row>
          {isForeignSiteName(name) ? null : <Chips<'Metres' | 'Kilometres'> options={['Metres', 'Kilometres']} value={unit} onChange={changeUnit} />}
          {preview ? (
            <Button title="Preview on map" icon="map-outline" variant="ghost" small
              onPress={() => Linking.openURL(`https://maps.google.com/?q=${preview.lat},${preview.lng}`)} />
          ) : null}
          {editId ? (
            <Button title={active ? 'Site is Active (tap to deactivate)' : 'Site is Inactive (tap to activate)'}
              icon={active ? 'checkmark-circle-outline' : 'pause-circle-outline'} variant="secondary"
              onPress={() => setActive(!active)} style={{ marginBottom: 10 }} />
          ) : null}
          <Button title={editId ? 'Save Changes' : 'Add this location to work sites'} icon={editId ? 'save-outline' : 'add-circle-outline'}
            loading={busy === 'save'} onPress={save} />
          {editId ? (
            <Button title="Delete Site" icon="trash-outline" variant="danger" loading={busy === 'del'} onPress={remove} style={{ marginTop: 10 }} />
          ) : null}
        </Card>
      ) : (
        <>
          {rows.some((s) => s.is_office) ? (
            <>
              <SectionTitle title="Office location" note="Office employees check in and out here, no selfie. Tap to edit" />
              <Card>
                {rows.filter((s) => s.is_office).map((s) => (
                  <ListItem key={s.id} icon="business-outline" title={s.name}
                    subtitle={`${s.lat.toFixed(5)}, ${s.lng.toFixed(5)} - within ${fmtDistance(s.radius_m)} - all office employees`}
                    right={<Pill text={s.active ? 'Active' : 'Inactive'} tone={s.active ? 'green' : 'muted'} />}
                    onPress={() => edit(s)} />
                ))}
              </Card>
            </>
          ) : null}
          <SectionTitle title={`${rows.filter((s) => !s.is_office).length} work site(s)`} note="Project sites for site employees (selfie). Tap a site to edit it" />
          <Card>
            {rows.some((s) => !s.is_office) ? (
              <View style={{ paddingVertical: 8 }}>
                <SiteDropdown sites={rows.filter((s) => !s.is_office)} value={listFilter} onChange={setListFilter}
                  allLabel={`All sites (${rows.filter((s) => !s.is_office).length})`} />
              </View>
            ) : null}
            {rows.length === 0 ? (
              <Empty icon="location-outline" text="No work sites yet. Add a site so employees can only check in and out at the site location." />
            ) : rows.filter((s) => !s.is_office && (listFilter === 0 || s.id === listFilter || citySites(rows.filter((x) => !x.is_office), listFilter).some((c) => c.id === s.id))).map((s) => (
              <ListItem key={s.id} icon="location-outline" title={s.name}
                subtitle={`${s.is_office ? 'Office - ' : ''}${s.lat.toFixed(5)}, ${s.lng.toFixed(5)} - ${isForeignSiteName(s.name) ? 'no radius limit' : `within ${fmtDistance(s.radius_m)}`}`}
                right={<Pill text={s.active ? 'Active' : 'Inactive'} tone={s.active ? 'green' : 'muted'} />}
                onPress={() => edit(s)} />
            ))}
          </Card>
        </>
      )}
    </Screen>
  );
}


