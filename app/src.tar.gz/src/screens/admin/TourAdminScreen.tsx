﻿import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Dropdown, MonthPicker } from '../../components/Pickers';
import TourDetail from '../../components/TourDetail';
import { Card, Empty, Row, Screen } from '../../components/ui';
import { api, Profile, Tour } from '../../lib/api';
import { errorText } from '../../lib/supabase';
import { fmtISODate, istDateISO } from '../../lib/time';
import { C } from '../../theme';

const money = (n: number) => `Rs ${n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

/** Admin / HR: every approved tour with its total expense; open one to see the tasks, expenses and documents */
export default function TourAdminScreen() {
  const today = istDateISO();
  const [year, setYear] = useState(Number(today.slice(0, 4)));
  const [month, setMonth] = useState(Number(today.slice(5, 7)));
  const [team, setTeam] = useState<Profile[]>([]);
  const [userId, setUserId] = useState<string | undefined>();
  const [tours, setTours] = useState<Tour[] | null>(null);
  const [totals, setTotals] = useState<Record<number, number>>({});
  const [openId, setOpenId] = useState<number | null>(null);

  useEffect(() => { api.team().then(setTeam).catch(() => {}); }, []);

  const load = useCallback(async () => {
    const mm = String(month).padStart(2, '0');
    const from = `${year}-${mm}-01`;
    const to = `${year}-${mm}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}`;
    try {
      const list = await api.approvedTours(from, to, userId);
      setTours(list);
      setTotals(await api.tourExpenseTotals(list.map((t) => t.id)));
    } catch (e) {
      Alert.alert('Could not load', errorText(e));
    }
  }, [year, month, userId]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const [picked, setPicked] = useState(false);

  return (
    <Screen>
      <Card>
        <Text style={st.lbl}>Employee</Text>
        <View style={{ marginBottom: 10 }}>
          <Dropdown width="100%" value={userId ? team.findIndex((e) => e.id === userId) + 1 : 0}
            onChange={(i) => setUserId(i > 0 ? team[i - 1]?.id : undefined)}
            options={[{ value: 0, label: 'All employees' }, ...team.map((e, i) => ({ value: i + 1, label: e.full_name }))]} />
        </View>
        <Text style={st.lbl}>Month</Text>
        <MonthPicker year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); setOpenId(null); }} />
      </Card>

      {!picked ? null : !tours ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : tours.length === 0 ? (
        <Card><Empty icon="bus-outline" text="No approved tours in this month." /></Card>
      ) : tours.map((t) => {
        const isOpen = openId === t.id;
        return (
          <View key={t.id} style={{ marginBottom: 8 }}>
            <Pressable onPress={() => setOpenId(isOpen ? null : t.id)}>
              <Card>
                <Row style={{ justifyContent: 'space-between' }}>
                  <Text style={st.name}>{t.employee?.full_name ?? 'Employee'}</Text>
                  <Text style={st.amount}>{money(totals[t.id] ?? 0)}</Text>
                </Row>
                <Text style={st.sub}>{t.city} - {fmtISODate(t.from_day)} to {fmtISODate(t.to_day)}</Text>
                <Text style={st.link}>{isOpen ? 'Hide report' : 'View tasks, expenses and documents'}</Text>
              </Card>
            </Pressable>
            {isOpen ? <TourDetail tour={t} editable={false} /> : null}
          </View>
        );
      })}
    </Screen>
  );
}

const st = StyleSheet.create({
  lbl: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  name: { fontWeight: '800', color: '#102A45', fontSize: 15, flexShrink: 1 },
  amount: { fontWeight: '800', color: C.ink },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  link: { color: C.blue, fontWeight: '700', fontSize: 12.5, marginTop: 6 },
});

