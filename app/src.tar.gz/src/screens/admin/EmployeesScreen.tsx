import { useFocusEffect, useNavigation } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { Dropdown } from '../../components/Pickers';
import { Avatar, Button, Card, Empty, Field, Kpi, KpiGrid, ListItem, Loading, Pill, Screen, SectionTitle } from '../../components/ui';
import { api, Profile, Site } from '../../lib/api';
import { useCompanies } from '../../lib/companies';
import { companyTone } from '../../components/CompanyFilter';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { shareCsv } from '../../lib/csv';
import { fmtISODate, istDateISO } from '../../lib/time';
import { C } from '../../theme';
import { shownRole } from '../../navigation/menu';

type F = 'Office' | 'Site';

export default function EmployeesScreen() {
  const nav = useNavigation<any>();
  const [rows, setRows] = useState<Profile[] | null>(null);
  const [q, setQ] = useState('');
  const [pick, setPick] = useState(-1); // drop-down: -1 = nothing shown yet, 0 = office employees, 1 = site employees
  const f: F = pick === 1 ? 'Site' : 'Office';
  const [who, setWho] = useState(-1); // second drop-down: -1 = nothing shown yet, 0 = all names, otherwise the n-th employee
  const [sites, setSites] = useState<Site[]>([]);
  const [siteSel, setSiteSel] = useState(0);
  const co = useCompanies();
  const coOf = (x: Profile) => co.byId(x.company_id ?? 0);
  useFocusEffect(useCallback(() => { api.sites().then((l) => setSites(l.filter((s) => !s.is_office))).catch(() => undefined); }, []));

  const load = useCallback(async () => {
    try { setRows(await api.allProfiles()); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('employees', [{ table: 'profiles' }], () => load());

  const matches = (x: Profile) => !q.trim() || `${x.full_name} ${x.username}`.toLowerCase().includes(q.trim().toLowerCase());
  // One list of names, A to Z: Office employees (no selfie, office location only) or Site employees (selfie)
  const shown = useMemo(() => {
    // a deleted employee (account switched off = left the company) is not listed
    // "All employees" (pick 2): everyone, so the Admin can open anybody and give any access
    const r = (rows ?? []).filter((x) => x.active && matches(x) && (pick === 2 || (shownRole(x) === 'Employee' && (f === 'Site' ? x.site_employee : !x.site_employee))));
    return r.sort((a, b) => a.full_name.localeCompare(b.full_name));
  }, [rows, q, f, pick]);

  // Site employees who can be moved to the office list (no selfie, office location only)
  const makeOffice = (name: string, list: Profile[]) => {
    const targets = list.filter((x) => shownRole(x) === 'Employee' && x.site_employee);
    Alert.alert(
      `Make ${name} office employee(s)?`,
      'Selfie attendance is switched off and work-site access is removed. They check in and out only at the Office Location (Pune CVPATIL).',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Make office employees', onPress: async () => {
          try {
            for (const x of targets) {
              await api.updateProfile(x.id, { site_employee: false });
              await api.setEmployeeSites(x.id, []).catch(() => undefined);
            }
            await load();
            Alert.alert('Done', `${targets.length} employee(s) are now office employees.`);
          } catch (e) { Alert.alert('Could not update', errorText(e)); }
        } },
      ],
    );
  };

  const addToSite = async (x: Profile) => {
    const site = sites.find((s) => s.id === siteSel);
    if (!site) return;
    try {
      await api.updateProfile(x.id, { site_employee: true });
      await api.setEmployeeSites(x.id, [site.id]);
      await load();
      Alert.alert('Done', `${x.full_name} is now a site employee at ${site.name} (selfie required).`);
    } catch (e) { Alert.alert('Could not update', errorText(e)); }
  };

  if (!rows) return <Loading />;
  const officeStaff = rows.filter((x) => x.active && shownRole(x) === 'Employee' && !x.site_employee && matches(x));
  const staff = rows.filter((r) => r.active && shownRole(r) === 'Employee');
  const movable = rows.filter((x) => x.active && shownRole(x) === 'Employee' && x.site_employee && matches(x));
  return (
    <Screen>
      <KpiGrid>
        <Kpi label="Employees" value={staff.length} icon="people-outline" tone="blue" />
        <Kpi label="Office Employees" value={staff.filter((r) => !r.site_employee).length} icon="business-outline" tone="green" />
        <Kpi label="Site Employees" value={staff.filter((r) => r.site_employee).length} icon="camera-outline" tone="cyan" />
      </KpiGrid>
      <SectionTitle title="Quick actions" />
      <Card>
        <Button title="Add a new employee" icon="person-add-outline" onPress={() => nav.navigate('AddEmployee')} style={{ marginBottom: 8 }} />
      </Card>

      <SectionTitle title="Find an employee" />
      <Card>
        <Text style={st.label}>Group</Text>
        <View style={{ marginBottom: 6 }}>
          <Dropdown width="100%" value={pick} onChange={(v) => { setPick(v); setWho(v >= 0 ? 0 : -1); }}
            options={[
              { value: -1, label: 'Select group' },
              { value: 2, label: `Everyone (${(rows ?? []).filter((r) => r.active).length})` },
              { value: 0, label: `Office (${staff.filter((r) => !r.site_employee).length})` },
              { value: 1, label: `Site (${staff.filter((r) => r.site_employee).length})` },
            ]} />
        </View>

        {pick < 0 || shown.length === 0 ? null : (
          <>
            <Text style={st.label}>Employee</Text>
            <Dropdown width="100%" value={who} onChange={setWho}
              options={[{ value: 0, label: `All names (${shown.length})` }, ...shown.map((r, i) => ({ value: i + 1, label: `${r.full_name} (${r.username})` }))]} />
          </>
        )}
      </Card>

      {pick < 0 || who <= 0 ? null : shown.length === 0 ? <Card><Empty text="No employees here." /></Card> : (
        <Card style={{ paddingVertical: 4 }}>
          <View style={st.head}>
            <Ionicons name={pick === 2 ? 'people-outline' : f === 'Office' ? 'business-outline' : 'camera-outline'} size={18} color={C.blue} />
            <Text style={st.title}>{pick === 2 ? 'All employees' : f === 'Office' ? 'Office employees' : 'Site employees'} - A to Z</Text>
            <Pill text={`${shown.length}`} tone="blue" />
          </View>
          {(who > 0 ? shown.filter((_, i) => i === who - 1) : shown).map((r) => (
            <ListItem key={r.id} left={<Avatar name={r.full_name} size={40} />} title={r.full_name}
              subtitle={`${r.username}${r.designation ? ' - ' + r.designation : ''}${r.joining_date ? ' - Joined ' + fmtISODate(r.joining_date) : ''}`}
              right={<View style={{ alignItems: 'flex-end', gap: 4 }}>
                {coOf(r) ? <Pill text={coOf(r)!.short_code === 'CVPCE' ? 'Pvt. Ltd.' : coOf(r)!.short_code === 'CVPA' ? 'C.V. Patil & Associates' : coOf(r)!.legal_name} tone={companyTone(coOf(r))} /> : null}
                {pick === 2 ? <Pill text={shownRole(r) === 'Employee' ? (r.site_employee ? 'Site' : 'Office') : r.role} tone={shownRole(r) === 'Employee' ? 'blue' : 'purple'} /> : null}
              </View>}
              onPress={() => nav.navigate('EmployeeDetail', { userId: r.id })} />
          ))}
        </Card>
      )}
    </Screen>
  );
}

const st = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12, paddingHorizontal: 4 },
  title: { flex: 1, fontSize: 15, fontWeight: '800', color: '#102A45' },
  label: { fontSize: 12.5, fontWeight: '800', color: '#3A5068', marginBottom: 6, marginTop: 4 },
  hint: { color: C.muted, fontSize: 12.5, lineHeight: 18, marginBottom: 10 },
});
