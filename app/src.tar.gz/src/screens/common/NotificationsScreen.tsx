import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { openNotificationLink } from '../../components/NotificationsHost';
import { Banner, Button, Card, Empty, Loading, Screen } from '../../components/ui';
import { useAuth } from '../../lib/auth';
import { ago, AppNotification, useNotificationList } from '../../lib/notifications';
import { C } from '../../theme';

const GOOD = (k: AppNotification['kind']) => k === 'LEAVE_APPROVED' || k === 'REG_APPROVED';
const BAD = (k: AppNotification['kind']) => k === 'LEAVE_REJECTED' || k === 'REG_REJECTED';

/** Bell list: newest first, unread in bold; tap = mark read + open the screen; Mark all as read. Live through Realtime. */
export default function NotificationsScreen() {
  const { isAdmin } = useAuth();
  const { rows, unread, missing, markRead } = useNotificationList();
  if (!rows) return <Loading />;
  return (
    <Screen>
      {missing ? <Banner tone="amber" text="Notifications are not set up in the database yet (run supabase/notifications.sql)." /> : null}
      <View style={st.head}>
        <Text style={st.sub}>{unread ? `${unread} unread` : 'All read'}</Text>
        <Button title="Mark all as read" icon="checkmark-done-outline" variant="secondary" small disabled={!unread} onPress={() => markRead(null)} />
      </View>
      <Card style={{ paddingVertical: 4 }}>
        {rows.length === 0 ? <Empty icon="notifications-outline" text="No notifications yet." /> : rows.map((n) => {
          const good = GOOD(n.kind); const bad = BAD(n.kind);
          return (
            <Pressable key={n.id} style={[st.row, !n.read_at && { backgroundColor: '#F3F8FF' }]}
              onPress={() => { if (!n.read_at) void markRead([n.id]); openNotificationLink(n.link, isAdmin); }} accessibilityRole="button">
              <View style={[st.icon, { backgroundColor: good ? '#E3F8EE' : bad ? '#FDECEC' : '#EAF3FF' }]}>
                <Ionicons name={good ? 'checkmark-circle' : bad ? 'close-circle' : 'notifications'} size={22} color={good ? '#12A05C' : bad ? '#D14343' : C.blue} />
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={[st.title, !n.read_at && { fontWeight: '800' }]}>{n.title}</Text>
                <Text style={[st.body, !n.read_at && { color: '#17314D', fontWeight: '700' }]}>{n.body}</Text>
              </View>
              <Text style={st.time}>{ago(n.created_at)}</Text>
              {!n.read_at ? <View style={st.dot} /> : null}
            </Pressable>
          );
        })}
      </Card>
    </Screen>
  );
}

const st = StyleSheet.create({
  head: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  sub: { color: C.muted, fontWeight: '700', fontSize: 13 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, paddingHorizontal: 8, borderBottomWidth: 1, borderBottomColor: '#EEF3F8', borderRadius: 8 },
  icon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 14.5, color: '#102A45', fontWeight: '600' },
  body: { fontSize: 13, color: '#4B6078', marginTop: 2, lineHeight: 18 },
  time: { fontSize: 11.5, color: C.muted, fontWeight: '700' },
  dot: { width: 9, height: 9, borderRadius: 5, backgroundColor: C.blue },
});
