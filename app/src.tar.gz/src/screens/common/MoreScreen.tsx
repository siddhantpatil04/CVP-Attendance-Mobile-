﻿import { useFocusEffect, useNavigation } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { Alert, Pressable, Text, View } from 'react-native';
import { PhotoAvatar } from '../../components/PhotoAvatar';
import { Card, IconName, ListItem, Pill, Row, Screen, SectionTitle } from '../../components/ui';
import { api } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { menuAllowed } from '../../navigation/menu';
import { C } from '../../theme';
import { shownRole } from '../../navigation/menu';

type Item = { title: string; subtitle: string; icon: IconName; route: string };

export default function MoreScreen() {
  const nav = useNavigation<any>();
  const { profile, isAdmin, isFullAdmin, signOut } = useAuth();
  // my profile photo (the photo of the Employee Form): initials until it is there or when there is none.
  // Reloaded every time this screen is shown, so a photo just added in My Profile appears when the person comes back.
  const [photoPath, setPhotoPath] = useState<string | null>(null);
  useFocusEffect(useCallback(() => {
    if (!profile) return;
    api.employeeDetailFiles(profile.id).then((fs) => setPhotoPath(fs.find((f) => f.kind === 'photo')?.file_path ?? null)).catch(() => setPhotoPath(null));
  }, [profile?.id]));
  if (!profile) return null;

  const profileItem: Item = { title: 'My Profile', subtitle: 'Account details & password', icon: 'person-circle-outline', route: 'Profile' };
  // The Admin is the owner, not an employee: only My Profile (password). HR keeps the employee items.
  const mine: Item[] = profile.role === 'Admin' ? [profileItem] : [
    { title: "My Salary", subtitle: 'Current salary and increment history (view only)', icon: 'cash-outline', route: 'MySalary' },
    ...(isAdmin ? [
      { title: "My Attendance", subtitle: 'Monthly timesheet & calendar', icon: 'calendar-outline', route: 'MyAttendance' } as Item,
      { title: "My Leave", subtitle: 'Balances and requests', icon: 'airplane-outline', route: 'MyLeave' } as Item,
    ] : []),
    // Site access = Field Site too (automatic; the bottom tab shows it for employees, this entry covers HR and any other layout)
    ...(profile.site_employee ? [{ title: "Field Site", subtitle: 'Record your travel between work sites', icon: 'navigate-outline', route: 'FieldJourney' } as Item] : []),
    ...(profile.site_employee && isAdmin ? [{ title: "Site Selfie", subtitle: 'Camera check-in from project site', icon: 'camera-outline', route: 'SiteSelfie' } as Item] : []),
    ...(profile.role === 'Employee' ? [{ title: "My Map", subtitle: profile.site_employee ? 'Your live position and your work sites' : 'Your live position and the office location', icon: 'map-outline', route: 'MyMap' } as Item] : []),
    ...(profile.tour_access ? [{ title: "Tour", subtitle: 'Apply for a tour, add expenses, documents and tasks', icon: 'bus-outline', route: 'Tour' } as Item] : []),
    ...(profile.documents_access ? [{ title: "Documents", subtitle: 'Upload documents with a remark; see documents sent to you', icon: 'document-text-outline', route: 'Documents' } as Item] : []),
    ...(profile.documents_access ? [{ title: "Documents Report", subtitle: 'All documents sent and received, with download', icon: 'folder-open-outline', route: 'DocsReport' } as Item] : []),
    ...(profile.site_employee ? [{ title: "Daily Report", subtitle: 'Fill today\'s report before you check out', icon: 'create-outline', route: 'DailyReport' } as Item] : []),   // automatic for site employees
    { title: "Regularization", subtitle: 'Correct a missed or wrong punch', icon: 'git-pull-request-outline', route: 'Regularization' },
    { title: "Holiday Calendar", subtitle: 'Company holidays', icon: 'sunny-outline', route: 'Holidays' },
    ...(isAdmin ? [{ title: "Team", subtitle: 'Company directory', icon: 'people-outline', route: 'Team' } as Item] : []),   // employees do not see the Team directory
    { title: "My Profile", subtitle: 'Account details & password', icon: 'person-circle-outline', route: 'Profile' },
  ];
  const admin: Item[] = [
    { title: 'Employees', subtitle: 'Add, view and manage employees, forms and documents', icon: 'people-outline', route: 'EmployeeForms' },
    ...(isFullAdmin ? [{ title: 'Salary Management', subtitle: 'Basic salary, increments and current salary', icon: 'cash-outline', route: 'SalaryManagement' } as Item] : []),
    { title: "Today's Team Attendance", subtitle: 'Who is working, on leave or not in', icon: 'people-circle-outline', route: 'TeamAttendance' },
    { title: 'Live Map', subtitle: 'Where employees checked in and out', icon: 'map-outline', route: 'LiveMap' },
    { title: 'Field Site', subtitle: 'Employee journeys between sites (view only)', icon: 'navigate-outline', route: 'FieldJourneyReport' },
    { title: 'Selfie Attendance', subtitle: 'Review site selfies', icon: 'images-outline', route: 'SelfieRecords' },
    { title: 'Working Hours', subtitle: "Place range, required hours and today's hours", icon: 'time-outline', route: 'WorkingHours' },
    { title: 'Tour Reports', subtitle: 'Tour expenses, documents and tasks', icon: 'bus-outline', route: 'TourAdmin' },
    { title: 'Documents Report', subtitle: 'Documents of all employees, with download', icon: 'folder-open-outline', route: 'DocsReport' },
    ...(isFullAdmin ? [{ title: 'Work Sites', subtitle: 'Site locations & allowed radius', icon: 'location-outline', route: 'SitesAdmin' } as Item] : []),
    { title: 'Holidays Setup', subtitle: 'Publish company holidays', icon: 'create-outline', route: 'HolidaysAdmin' },
    { title: 'Saturday Holidays', subtitle: 'Choose which employees get which Saturday off', icon: 'calendar-outline', route: 'SaturdaysAdmin' },
    ...(isFullAdmin ? [{ title: 'Audit Trail', subtitle: 'Every user & HR action', icon: 'list-outline', route: 'Audit' } as Item] : []),
    ...(isFullAdmin ? [{ title: 'App Updates', subtitle: 'Publish an update: everyone signs in again', icon: 'cloud-upload-outline', route: 'AppUpdate' } as Item] : []),
  ];

  return (
    <Screen>
      <Pressable onPress={() => nav.navigate('Profile')} accessibilityRole="button" accessibilityLabel="Open my profile">
        <Card>
          <Row>
            <PhotoAvatar name={profile.full_name} size={48} path={photoPath} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '800', fontSize: 16, color: C.ink }}>{profile.full_name}</Text>
              <Text style={{ fontSize: 12.5, color: C.blue, fontWeight: '700', marginTop: 2 }}>{"View my profile"}</Text>
            </View>
            <Pill text={shownRole(profile)} tone={isAdmin ? 'purple' : 'blue'} />
            <Ionicons name="chevron-forward" size={18} color={C.muted} />
          </Row>
        </Card>
      </Pressable>
      <SectionTitle title={"My Account"} />
      <Card>{mine.map((i) => <ListItem key={i.route} title={i.title} icon={i.icon} onPress={() => nav.navigate(i.route)} />)}</Card>
      {isAdmin ? (
        <>
          <SectionTitle title={isFullAdmin ? 'Admin' : 'HR'} />
          <Card>{admin.filter((i) => menuAllowed(profile, i.route)).map((i) => <ListItem key={i.route} title={i.title} icon={i.icon} onPress={() => nav.navigate(i.route)} />)}</Card>
        </>
      ) : null}
      <Card>
        <ListItem title={"Sign out"} icon="log-out-outline" onPress={() =>
          Alert.alert('Sign out?', '', [{ text: 'Cancel', style: 'cancel' }, { text: 'Sign out', style: 'destructive', onPress: signOut }])} />
      </Card>
    </Screen>
  );
}

