﻿import React, { useCallback, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { PhotoAvatar, photoUrl } from '../../components/PhotoAvatar';
import { pickFile } from '../../lib/pickFile';
import { ActivityIndicator, Alert, Image, Modal, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Card, Field, InfoTile, Pill, Row, Screen, SectionTitle } from '../../components/ui';
import { UsernameCard } from '../../components/UsernameCard';
import { COMPANY_ADDRESS, COMPANY_NAME, MIN_PASSWORD } from '../../config';
import { api, MySalaryRow } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { errorText, supabase } from '../../lib/supabase';
import { fmtISODate, serviceLength } from '../../lib/time';
import { C } from '../../theme';
import { shownRole } from '../../navigation/menu';
import NotificationSettings from '../../components/NotificationSettings';

export default function ProfileScreen() {
  const { profile, session, signOut, isAdmin, refreshProfile } = useAuth();
  const [oldPw, setOldPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  // Profile photo = the photo of the Employee Form
  const [photoPath, setPhotoPath] = useState<string | null>(null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [menu, setMenu] = useState(false);          // "Add profile photo" / "Profile photo" sheet
  const [viewer, setViewer] = useState(false);      // full-size photo page
  const [viewUrl, setViewUrl] = useState<string | null>(null);
  const [toast, setToast] = useState('');
  const [photoAt, setPhotoAt] = useState<string | null>(null);
  const [photoErr, setPhotoErr] = useState('');     // why a saved photo cannot be shown
  const loadPhoto = useCallback(async () => {
    if (!profile) return;
    try {
      const files = await api.employeeDetailFiles(profile.id);
      const ph = files.find((f) => f.kind === 'photo');
      setPhotoPath(ph?.file_path ?? null);
      setPhotoAt(ph?.created_at ?? null);
      // the photo is saved: make sure it can also be opened, otherwise say why
      if (ph?.file_path) photoUrl(ph.file_path).then(() => setPhotoErr('')).catch((e) => setPhotoErr(errorText(e)));
      else setPhotoErr('');
    } catch { /* no photo yet */ }
  }, [profile?.id]);
  // My salary: the current salary and every increment that has started
  const [pay, setPay] = useState<MySalaryRow[]>([]);
  useFocusEffect(useCallback(() => {
    loadPhoto();
    api.mySalary().then(setPay).catch(() => {});
  }, [loadPhoto]));
  if (!profile) return null;

  const hadPhoto = !!photoPath;
  const uploadPhoto = async (camera: boolean) => {
    setMenu(false);
    try {
      const f = await pickFile(camera, true);   // phone: the picker opens a square crop ("Adjust photo")
      if (!f) return;
      if (!f.mime.startsWith('image/')) return Alert.alert('Choose a photo', 'The profile photo must be a picture (JPG, PNG or WEBP).');
      setPhotoBusy(true);
      await api.uploadDetailFile(profile.id, false, 'photo', f.bytes, f.name, f.mime);
      await loadPhoto();
      setToast(hadPhoto ? "Profile photo changed. Admin can see it." : "Profile photo added. Admin can see it.");
    } catch (e) { Alert.alert('Could not upload', errorText(e)); }
    finally { setPhotoBusy(false); }
  };
  const removePhoto = () => {
    setMenu(false);
    Alert.alert('Remove profile photo?', 'Your initials will be shown instead.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: async () => {
        try { setPhotoBusy(true); await api.deleteDetailFile(profile.id, false, 'photo'); await loadPhoto(); setToast("Profile photo removed."); }
        catch (e) { Alert.alert('Could not remove', errorText(e)); }
        finally { setPhotoBusy(false); }
      } },
    ]);
  };
  const viewPhoto = async () => {
    setMenu(false);
    if (!photoPath) return;
    try { setViewUrl(await photoUrl(photoPath)); setViewer(true); } catch (e) { Alert.alert('Photo unavailable', errorText(e)); }
  };

  const change = async () => {
    if (newPw.length < MIN_PASSWORD) return Alert.alert(`Use at least ${MIN_PASSWORD} characters.`);
    if (newPw !== confirm) return Alert.alert('New passwords do not match.');
    setBusy(true);
    try {
      // verify the current password first (same as the web app)
      const email = session?.user.email;
      if (!email) throw new Error('Session expired. Please sign in again.');
      const check = await supabase.auth.signInWithPassword({ email, password: oldPw });
      if (check.error) throw new Error('Current password incorrect.');
      const { error } = await supabase.auth.updateUser({ password: newPw });
      if (error) throw error;
      await api.logPasswordChange();
      setOldPw(''); setNewPw(''); setConfirm('');
      Alert.alert('Password updated');
    } catch (e) {
      Alert.alert('Could not update', errorText(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <Card style={{ backgroundColor: '#F2F8FF' }}>
        <Row>
          <Image source={require('../../../assets/cvp_logo.png')} style={st.logo} />
          <View style={{ flex: 1 }}>
            <Text style={st.company}>{COMPANY_NAME}</Text>
            <Text style={st.address}>{COMPANY_ADDRESS}</Text>
          </View>
        </Row>
      </Card>

      {toast ? <Banner tone="green" icon="checkmark" text={toast} /> : null}
      {photoErr ? <Banner tone="amber" icon="warning-outline" text={`The photo is saved but cannot be shown: ${photoErr}`} /> : null}
      <Card>
        <View style={{ alignItems: 'center', marginBottom: 12 }}>
          {/* tap the photo: Add photo (no photo) or View / Change / Remove (has photo) */}
          <Pressable onPress={() => setMenu(true)} accessibilityRole="button" accessibilityLabel={photoPath ? 'Change profile photo' : 'Add profile photo'}
            style={[st.ring, !photoPath && st.ringEmpty]}>
            <PhotoAvatar name={profile.full_name} size={104} path={photoPath} />
            <View style={st.badge}>
              {photoBusy ? <ActivityIndicator size="small" color="#FFFFFF" /> : <Ionicons name={photoPath ? 'camera' : 'add'} size={16} color="#FFFFFF" />}
            </View>
          </Pressable>
          <Text style={[st.name, { marginTop: 10 }]}>{profile.full_name}</Text>
          <Text style={st.sub}>{shownRole(profile)} - {profile.department || 'General'}</Text>
          <View style={{ flexDirection: 'row', gap: 6, marginTop: 6 }}>
            <Pill text={"Active"} tone="green" />
            <Pill text={profile.site_employee ? "Site Employee" : "Office Employee"} tone="cyan" />
          </View>
        </View>
        <View style={st.grid}>
          <InfoTile label={"Username"} value={profile.username} />
          <InfoTile label={"Department"} value={profile.department} />
          <InfoTile label={"Joined"} value={fmtISODate(profile.joining_date)} />
          <InfoTile label={"Service"} value={serviceLength(profile.joining_date)} />
          <InfoTile label={"Standard Day"} value={"8 hours"} />
        </View>
      </Card>

      {pay.length ? (
        <>
          <SectionTitle title={"My salary"} note={"Updated by the Admin; an increment applies from its effective date"} />
          <Card>
            <View style={st.grid}>
              <InfoTile label={"Current monthly salary"} value={`Rs ${pay[0].salary.toLocaleString('en-IN')}`} />
              <InfoTile label={"Effective from"} value={pay[0].kind === 'Basic' ? "Joining" : fmtISODate(pay[0].effective_date)} />
            </View>
          </Card>
        </>
      ) : null}

      {isAdmin ? (
        <>
          <SectionTitle title="Change username" note="For Admin and HR accounts" />
          <UsernameCard user={profile} onChanged={refreshProfile} />
        </>
      ) : null}

      {isAdmin ? (
        <>
          <SectionTitle title="Change password" note={`Use a strong password with at least ${MIN_PASSWORD} characters.`} />
          <Card>
            <Field label="Current password" secureTextEntry value={oldPw} onChangeText={setOldPw} />
            <Field label="New password" secureTextEntry value={newPw} onChangeText={setNewPw} />
            <Field label="Confirm new password" secureTextEntry value={confirm} onChangeText={setConfirm} />
            <Button title="Update Password" icon="key-outline" loading={busy} onPress={change} />
          </Card>
        </>
      ) : null}

      <SectionTitle title="Notifications" note="Approved / rejected leave and attendance corrections" />
      <NotificationSettings />

      <Button title={"Sign out"} icon="log-out-outline" variant="danger" onPress={() =>
        Alert.alert(`${"Sign out"}?`, '', [{ text: "Cancel", style: 'cancel' }, { text: "Sign out", style: 'destructive', onPress: signOut }])} />


      <Modal visible={menu} transparent animationType="slide" onRequestClose={() => setMenu(false)}>
        <Pressable style={st.backdrop} onPress={() => setMenu(false)}>
          <Pressable style={st.sheet} onPress={() => {}}>
            <Text style={st.sheetTitle}>{photoPath ? "Profile photo" : "Add profile photo"}</Text>
            {photoPath ? null : <Text style={st.sub}>{"Clear face, plain background."}</Text>}
            <View style={{ gap: 8, marginTop: 12 }}>
              {photoPath ? <SheetBtn icon="eye-outline" label={"View photo"} onPress={viewPhoto} /> : null}
              {Platform.OS === 'web' ? null : <SheetBtn icon="camera-outline" label={photoPath ? "Take new photo" : "Take photo"} onPress={() => uploadPhoto(true)} />}
              <SheetBtn icon="image-outline" label={"Choose from gallery"} onPress={() => uploadPhoto(false)} />
              {photoPath ? <SheetBtn icon="close" label={"Remove photo"} danger onPress={removePhoto} /> : null}
              <SheetBtn label={"Cancel"} center onPress={() => setMenu(false)} />
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      <Modal visible={viewer} animationType="slide" onRequestClose={() => setViewer(false)}>
        <View style={st.viewPage}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <Pressable onPress={() => setViewer(false)} hitSlop={10}><Ionicons name="arrow-back" size={24} color={C.blue} /></Pressable>
            <Text style={st.sheetTitle}>{"Profile photo"}</Text>
          </View>
          <View style={st.viewBox}>
            {viewUrl ? <Image source={{ uri: viewUrl }} style={st.viewImg} resizeMode="contain" /> : <ActivityIndicator color="#FFFFFF" />}
          </View>
          {photoAt ? <Text style={[st.sub, { textAlign: 'center', marginTop: 10 }]}>{"Updated"} {fmtISODate(photoAt.slice(0, 10))}</Text> : null}
          <Button title={"Change photo"} icon="camera-outline" style={{ marginTop: 12 }} onPress={() => { setViewer(false); setMenu(true); }} />
        </View>
      </Modal>
    </Screen>
  );
}

function SheetBtn({ icon, label, onPress, danger, center }: { icon?: keyof typeof Ionicons.glyphMap; label: string; onPress: () => void; danger?: boolean; center?: boolean }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={[st.sheetBtn, center && { justifyContent: 'center' }]}>
      {icon ? <Ionicons name={icon} size={18} color={danger ? C.red : C.blue} /> : null}
      <Text style={[st.sheetBtnText, danger && { color: C.red }]}>{label}</Text>
    </Pressable>
  );
}

const st = StyleSheet.create({
  ring: { width: 116, height: 116, borderRadius: 58, alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: '#B9D4F6' },
  ringEmpty: { borderStyle: 'dashed' },
  badge: { position: 'absolute', right: 2, bottom: 2, width: 30, height: 30, borderRadius: 15, backgroundColor: C.blue, borderWidth: 2, borderColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  backdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(6,37,63,0.4)' },
  sheet: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 18, paddingBottom: 26, width: '100%', maxWidth: 640, alignSelf: 'center' },
  sheetTitle: { fontSize: 18, fontWeight: '800', color: '#102A45' },
  sheetBtn: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderColor: '#DCE7F3', borderRadius: 12, paddingVertical: 14, paddingHorizontal: 14, backgroundColor: '#FBFDFF' },
  sheetBtnText: { fontSize: 15, fontWeight: '800', color: '#102A45' },
  viewPage: { flex: 1, backgroundColor: '#FFFFFF', padding: 16, paddingTop: 40, width: '100%', maxWidth: 640, alignSelf: 'center' },
  viewBox: { flex: 1, backgroundColor: '#0B0F14', borderRadius: 18, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  viewImg: { width: '100%', height: '100%' },
  logo: { width: 52, height: 52, borderRadius: 14, backgroundColor: C.white },
  company: { fontWeight: '800', color: '#0B2B4D', fontSize: 14 },
  address: { color: '#6F8196', fontSize: 11.5, marginTop: 3, lineHeight: 16 },
  name: { fontWeight: '800', fontSize: 17, color: '#102A45' },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 2 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
});
