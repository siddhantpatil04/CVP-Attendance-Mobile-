import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Linking, StyleSheet, Text, View } from 'react-native';
import { Dropdown, MonthPicker } from '../../components/Pickers';
import { DocStatusLine, DocumentReview } from '../../components/DocumentReview';
import { DailyReportsPanel } from '../../components/DailyReportsPanel';
import { getAttendanceKind, isOfficeEmployee, officeNameSet } from '../../lib/attendanceKind';
import { useRealtime } from '../../lib/realtime';
import { applyDailyFilters, DAILY_FILTERS_DEFAULT, DailyFilters, DailyFilterState, DownloadKind } from '../../components/DailyFilters';
import { ShareDocumentPanel, SharedLogPanel } from '../../components/SharedDocuments';
import { Button, Card, Chips, Empty, Pill, Row, Screen, Segmented } from '../../components/ui';
import { downloadOrOpen } from '../../lib/saveDownload';
import { api, DailyReport, DocumentReportRow, Profile } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { shareCsv } from '../../lib/csv';
import { dailyReportDatePdf, dailyReportDateXlsx, dailyReportMonthlyPdf, dailyReportMonthlyXlsx } from '../../lib/dailyReportPdf';
import { sharePdf } from '../../lib/pdf';
import { errorText } from '../../lib/supabase';
import { fmtISODate, istDateISO, MONTHS } from '../../lib/time';
import { C } from '../../theme';

/**
 * Documents report: every document sent or received in a month, with a Download button for each file.
 * Admin / HR see all employees (and can pick one); an employee sees his own documents.
 */
export default function DocumentsReportScreen() {
  const { isAdmin, profile } = useAuth();
  const [sharedKey, setSharedKey] = useState(0);
  const today = istDateISO();
  const [year, setYear] = useState(Number(today.slice(0, 4)));
  const [month, setMonth] = useState(Number(today.slice(5, 7)));
  const [team, setTeam] = useState<Profile[]>([]);
  const [userId, setUserId] = useState<string | undefined>();
  const [rows, setRows] = useState<DocumentReportRow[] | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [statusF, setStatusF] = useState<string>('All');
  // Daily Reports tab (Admin / HR): the same Employee filter and month, plus a Site filter and status chips
  const [tab, setTab] = useState<'docs' | 'daily'>(isAdmin ? 'daily' : 'docs');   // Admin / HR open on Daily Reports first
  // Inside Documents (Admin / HR / Project Manager): My documents | Received | Share (From CV Patil) | Shared & view log
  const [sub, setSub] = useState<'mine' | 'received' | 'share' | 'shared'>('mine');
  const [daily, setDaily] = useState<DailyReport[] | null>(null);
  const [df, setDf] = useState<DailyFilterState>(DAILY_FILTERS_DEFAULT);
  const dailyCity = df.city; const dailySite = df.site;
  const [dlBusy, setDlBusy] = useState<DownloadKind | null>(null);

  useEffect(() => { if (isAdmin) api.team().then(setTeam).catch(() => {}); }, [isAdmin]);

  const range = () => {
    if (month === 0) return { from: `${year}-01-01`, to: `${year}-12-31` };   // All months: the whole year
    const mm = String(month).padStart(2, '0');
    return { from: `${year}-${mm}-01`, to: `${year}-${mm}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}` };
  };

  const load = useCallback(async () => {
    const { from, to } = range();
    const dm = month === 0 ? Number(today.slice(5, 7)) : month; const dmm = String(dm).padStart(2, '0');
    const dFrom = `${year}-${dmm}-01`; const dTo = `${year}-${dmm}-${String(new Date(year, dm, 0).getDate()).padStart(2, '0')}`;
    try { setRows(await api.documentsReport(from, to, userId)); }
    catch (e) { Alert.alert('Could not load', errorText(e)); }
    // Daily reports load on their own: a problem here never affects the Documents tab
    if (isAdmin) api.dailyReportsAdmin(dFrom, dTo, tab === 'daily' ? undefined : userId).then(setDaily).catch(() => setDaily([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, month, userId, isAdmin, tab === 'daily']);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const download = async (d: DocumentReportRow) => {
    try { await downloadOrOpen(await api.employeeFileUrl(d.file_path, d.file_name || d.title), d.file_name || d.title, true); }
    catch (e) { Alert.alert('File unavailable', errorText(e)); }
  };

  const statusOf = (d: DocumentReportRow) => d.status ?? (d.direction === 'from_admin' ? 'Sent' : 'Submitted');
  const shown = (rows ?? []).filter((d) => (statusF === 'All' || statusOf(d) === statusF) && (sub !== 'received' || d.direction !== 'from_admin'));
  // the Company choice only applies to the downloaded report
  const reportRows = () => shown.map((d) => ({
    Date: fmtISODate(d.created_at.slice(0, 10)),
    Employee: d.employee?.full_name ?? '',
    'Employee ID': d.employee?.username ?? '',
    Direction: d.direction === 'from_admin' ? 'Sent by Admin / HR' : 'Uploaded by employee',
    'Sent by': d.sender?.full_name ?? '',
    Document: d.title,
    Type: d.category ?? '',
    Status: statusOf(d),
    File: d.file_name ?? '',
    Remark: d.remark ?? '',
    'Review note': d.review_note ?? '',
  }));
  const dailyC = daily;
  const dailyShown = applyDailyFilters(dailyC ?? [], df);
  // the day on screen: new reports appear live; the site employees who checked in that day (office-day check-ins are not counted)
  useRealtime('daily-reports-live', [{ table: 'daily_reports' }, { table: 'daily_report_sites' }, { table: 'attendance' }], () => { if (tab === 'daily') { load(); loadDay(); } });
  const [allTeamP, setAllTeamP] = useState<Profile[]>([]);
  const [officeNames, setOfficeNames] = useState<Set<string>>(new Set());
  const [photoPaths, setPhotoPaths] = useState<Map<string, string>>(new Map());
  const [dayRows, setDayRows] = useState<{ user_id: string; site_name: string | null; source: string | null }[]>([]);
  useEffect(() => {
    if (!isAdmin) return;
    api.team().then(setAllTeamP).catch(() => {});
    api.sites().then((l) => setOfficeNames(officeNameSet(l))).catch(() => {});
    api.profilePhotoPaths().then(setPhotoPaths).catch(() => {});
  }, [isAdmin]);
  const dayISO = df.dateMode === 'day' && df.dateFrom ? df.dateFrom : '';
  const loadDay = useCallback(async () => {
    if (!isAdmin || !dayISO) { setDayRows([]); return; }
    try { setDayRows(await api.officeAttendanceRows(dayISO, dayISO)); } catch { setDayRows([]); }
  }, [isAdmin, dayISO]);
  useEffect(() => { if (tab === 'daily') loadDay(); }, [tab, loadDay]);
  const dayCheckins = useMemo(() => dayRows.filter((r) => {
    const p = allTeamP.find((x) => x.id === r.user_id);
    return !!p && getAttendanceKind({ site_name: r.site_name, source: r.source }, officeNames, isOfficeEmployee(p)) === 'site';
  }), [dayRows, allTeamP, officeNames]);
  const notSubmitted = useMemo(() => {
    const done = new Set((dailyC ?? []).filter((r) => r.report_date === dayISO && (r.status === 'Submitted' || r.status === 'Reviewed')).map((r) => r.user_id));
    return dayCheckins.filter((r) => !done.has(r.user_id)).map((r) => {
      const p = allTeamP.find((x) => x.id === r.user_id);
      return { name: p?.full_name ?? 'Employee', id: p?.username ?? '', site: r.site_name ?? '' };
    }).sort((a, b) => a.name.localeCompare(b.name));
  }, [dayCheckins, dailyC, dayISO, allTeamP]);
  const dailyEmployee = () => (df.empId ? (dailyC ?? []).find((r) => r.user_id === df.empId)?.employee?.full_name ?? team.find((e) => e.id === df.empId)?.full_name : undefined);
  const mm = String(month).padStart(2, '0');
  const [dlText, setDlText] = useState('');
  // ONE Download PDF / Download Excel, exactly as the dropdowns say:
  //   Whole month, running month  -> 1st .. today      file daily_report_2026-11-01_to_2026-11-20
  //   Whole month, completed month -> 1st .. last day   file daily_report_2026-10
  //   Particular date             -> that day only     file daily_report_2026-11-18
  // City / Site / Employee are added to the heading and to the file name (e.g. daily_report_2026-11-18_Pune_Koregaon_MBR_Mul)
  const dailyDownload = async (kind: DownloadKind) => {
    if (dlBusy) return;
    const day = df.dateMode === 'day' && df.dateFrom ? df.dateFrom : '';
    const reps = applyDailyFilters(daily ?? [], day ? df : { ...df, dateMode: 'all' });
    if (reps.length === 0) return Alert.alert('Nothing to export', 'No daily reports for these filters.');
    setDlBusy(kind); setDlText('Preparing report...');
    try {
      const part = (v?: string) => (v ? `_${v.trim().replace(/[^A-Za-z0-9]+/g, '_').replace(/^_+|_+$/g, '')}` : '');
      const tail = `${part(df.city)}${part(df.site)}${part(dailyEmployee())}`;
      const ext = kind === 'pdf' ? 'pdf' : 'xlsx';
      const filt = { site: df.site || undefined, city: df.city || undefined, employee: dailyEmployee() };
      if (day) {
        const o = { date: day, reports: reps, ...filt, team };
        const name = `daily_report_${day}${tail}.${ext}`;
        if (kind === 'pdf') await dailyReportDatePdf(name, o); else await dailyReportDateXlsx(name, o);
      } else {
        const today = istDateISO();
        const lastISO = `${year}-${mm}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}`;
        const running = today >= `${year}-${mm}-01` && today < lastISO;
        const name = `daily_report_${running ? `${year}-${mm}-01_to_${today}` : `${year}-${mm}`}${tail}.${ext}`;
        const o = { year, month, reports: reps, ...filt, ...(running ? { from: `${year}-${mm}-01`, to: today } : {}), onProgress: (x: number, n: number) => setDlText(`Preparing report... ${x} / ${n} employees`) };
        if (kind === 'pdf') await dailyReportMonthlyPdf(name, o); else await dailyReportMonthlyXlsx(name, o);
      }
    } catch (e) { Alert.alert(`Could not create the ${kind === 'pdf' ? 'PDF' : 'Excel file'}`, errorText(e)); }
    finally { setDlBusy(null); setDlText(''); }
  };
  const exportCsv = () => {
    if (!rows || rows.length === 0) return Alert.alert('Nothing to export', 'No documents in this month.');
    shareCsv(`documents_report_${year}_${month === 0 ? 'all_months' : String(month).padStart(2, '0')}.csv`, reportRows());
  };
  const exportPdf = async () => {
    if (!rows || rows.length === 0) return Alert.alert('Nothing to export', 'No documents in this month.');
    setPdfBusy(true);
    try {
      const who = userId ? team.find((e) => e.id === userId)?.full_name : isAdmin ? 'All employees' : 'My documents';
      await sharePdf(`documents_report_${year}_${month === 0 ? 'all_months' : String(month).padStart(2, '0')}.pdf`, {
        title: 'Documents Report',
        subtitle: `${who ?? ''} - ${month === 0 ? 'All months' : MONTHS[month - 1]} ${year}  |  ${rows.length} document(s): ${fromAdmin} sent by Admin / HR, ${fromEmp} by employees`,
        rows: reportRows(),
      });
    } catch (e) { Alert.alert('Could not create the PDF', errorText(e)); }
    finally { setPdfBusy(false); }
  };

  const fromAdmin = rows?.filter((d) => d.direction === 'from_admin').length ?? 0;
  const fromEmp = (rows?.length ?? 0) - fromAdmin;

  return (
    <Screen>
      {isAdmin ? (
        <Segmented<'docs' | 'daily'> value={tab} onChange={(t) => { if (t !== tab) { setDaily(null); if (t === 'daily' && month === 0) setMonth(Number(today.slice(5, 7))); setTab(t); } }} options={[
          { value: 'daily', label: `Daily Reports (${tab === 'daily' ? dailyShown.length : daily?.length ?? 0})` },
          { value: 'docs', label: `Documents (${rows?.length ?? 0})` },
        ]} />
      ) : null}
      {tab === 'docs' ? (
        <View>
          <Text style={st.ftitle}>Documents Report</Text>
          <Card>
            <View style={st.frow}>
              <View style={st.ffld}>
                <View style={st.flbl}><View style={st.fbadge}><Text style={st.fbadgeTx}>1</Text></View><Text style={st.flbTx}>YEAR</Text></View>
                <Dropdown width="100%" value={year} onChange={(y) => { setYear(y); if (y === Number(today.slice(0, 4)) && month > Number(today.slice(5, 7))) setMonth(Number(today.slice(5, 7))); setRows(null); setDaily(null); setDf(DAILY_FILTERS_DEFAULT); }}
                  options={Array.from({ length: Math.max(Number(today.slice(0, 4)), year) - 2024 + 1 }, (_, i) => ({ value: 2024 + i, label: String(2024 + i) }))} />
              </View>
              <View style={st.ffld}>
                <View style={st.flbl}><View style={st.fbadge}><Text style={st.fbadgeTx}>2</Text></View><Text style={st.flbTx}>MONTH</Text></View>
                <Dropdown width="100%" value={month} onChange={(m) => { setMonth(m); setRows(null); setDaily(null); setDf(DAILY_FILTERS_DEFAULT); }}
                  options={[{ value: 0, label: 'All months' }, ...MONTHS.map((n, i) => ({ value: i + 1, label: n, disabled: year > Number(today.slice(0, 4)) || (year === Number(today.slice(0, 4)) && i + 1 > Number(today.slice(5, 7))) }))]} />
              </View>
              {isAdmin ? (
                <View style={st.ffld}>
                  <View style={st.flbl}><View style={st.fbadge}><Text style={st.fbadgeTx}>3</Text></View><Text style={st.flbTx}>EMPLOYEE</Text></View>
                  <Dropdown width="100%" value={userId ? team.findIndex((e) => e.id === userId) + 1 : 0}
                    onChange={(i) => setUserId(i > 0 ? team[i - 1]?.id : undefined)}
                    options={[{ value: 0, label: 'All employees' }, ...team.map((e, i) => ({ value: i + 1, label: e.full_name }))]} />
                </View>
              ) : null}
            </View>
          </Card>
        </View>
      ) : null}

      {isAdmin && tab === 'docs' ? (
        <Segmented<'mine' | 'received' | 'share' | 'shared'> value={sub} onChange={setSub} options={[
          { value: 'mine', label: `My documents (${rows?.length ?? 0})` },
          { value: 'received', label: 'Received' },
          { value: 'share', label: 'Share (From CV Patil)' },
          { value: 'shared', label: 'Shared & view log' },
        ]} />
      ) : null}

      {tab === 'daily' ? (
        <DailyFilters year={year} month={month} rows={dailyC}
          f={df} shown={dailyShown} busy={dlBusy} busyText={dlText} onDownload={dailyDownload}
          onYearMonth={(y, m) => { setYear(y); setMonth(m); setRows(null); setDaily(null); setDf((p) => ({ ...p, dateMode: 'day', dateFrom: '', dateTo: '' })); }}
          set={(patch) => setDf((p) => ({ ...p, ...patch }))} onReset={() => { const t = istDateISO(); setYear(Number(t.slice(0, 4))); setMonth(Number(t.slice(5, 7))); setDf(DAILY_FILTERS_DEFAULT); }} />
      ) : tab === 'docs' && isAdmin && (sub === 'share' || sub === 'shared') ? null : <Row style={{ justifyContent: 'space-between', marginBottom: 10 }}>
        <Text style={st.count}>{`${rows?.length ?? 0} document(s) - ${fromAdmin} sent by Admin / HR, ${fromEmp} by employees`}</Text>
        <Row>
          <Button title="PDF report" icon="document-text-outline" small loading={pdfBusy} onPress={exportPdf} />
          <Button title="CSV" icon="download-outline" variant="secondary" small onPress={exportCsv} />
        </Row>
      </Row>}
      {tab === 'docs' && sub === 'share' && isAdmin ? (
        <ShareDocumentPanel onShared={() => { setSharedKey((k) => k + 1); setSub('shared'); }} />
      ) : tab === 'docs' && sub === 'shared' && isAdmin ? (
        <SharedLogPanel refreshKey={sharedKey} myId={profile?.id ?? ''} />
      ) : tab === 'daily' && isAdmin ? (
        <DailyReportsPanel rows={dailyC} shown={dailyShown} city={dailyCity} site={dailySite} onChanged={load}
          day={df.dateMode === 'day' && df.dateFrom ? df.dateFrom : null} checkedIn={dayCheckins.length} notSubmitted={notSubmitted} photos={photoPaths} />
      ) : (
      <>
      <Chips<string> options={['All', 'Submitted', 'Approved', 'Rejected', 'Sent']} value={statusF} onChange={setStatusF} />

      <Card style={{ paddingVertical: 4 }}>
        {!rows ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : shown.length === 0 ? (
          <Empty icon="document-outline" text="No documents here." />
        ) : shown.map((d) => {
          const admin = d.direction === 'from_admin';
          return (
            <View key={d.id} style={st.item}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Text style={st.title} numberOfLines={1}>{d.title}</Text>
                <Pill text={admin ? 'Admin / HR' : 'Employee'} tone={admin ? 'purple' : 'blue'} />
              </Row>
              <Text style={st.sub}>
                {fmtISODate(d.created_at.slice(0, 10))} - {d.employee?.full_name ?? 'Employee'}
                {d.sender?.full_name ? ` - sent by ${d.sender.full_name}` : ''}
              </Text>
              {d.remark ? <Text style={st.remark}>Remark: {d.remark}</Text> : null}
              <DocStatusLine d={d} />
              <Row style={{ marginTop: 6 }}>
                <Button title="Download" icon="download-outline" small onPress={() => download(d)} />
              </Row>
              {isAdmin ? <DocumentReview d={d} onChanged={load} /> : null}
            </View>
          );
        })}
      </Card>
      </>
      )}
    </Screen>
  );
}

const st = StyleSheet.create({
  ftitle: { fontSize: 14, fontWeight: '800', color: '#102A45', marginBottom: 8, marginTop: 4 },
  frow: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  ffld: { flexGrow: 1, flexBasis: 180, minWidth: 150 },
  flbl: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  fbadge: { width: 18, height: 18, borderRadius: 9, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center' },
  fbadgeTx: { color: '#fff', fontSize: 10.5, fontWeight: '800' },
  flbTx: { fontSize: 11.5, fontWeight: '800', color: '#5A6F86', letterSpacing: 0.4 },
  lbl: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  count: { flex: 1, fontSize: 12.5, fontWeight: '700', color: C.muted, marginRight: 8 },
  item: { paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  title: { fontWeight: '800', color: '#102A45', fontSize: 14, flexShrink: 1 },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  remark: { color: '#203951', marginTop: 4, lineHeight: 19 },
});

