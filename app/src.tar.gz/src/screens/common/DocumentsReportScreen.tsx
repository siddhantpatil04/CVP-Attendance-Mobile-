import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Linking, StyleSheet, Text, View } from 'react-native';
import { Dropdown, MonthPicker } from '../../components/Pickers';
import { DocStatusLine, DocumentReview } from '../../components/DocumentReview';
import { DailyReportsPanel, DailyStatusFilter, filterDaily } from '../../components/DailyReportsPanel';
import { SiteWorkMonthPanel, siteWorkRows } from '../../components/SiteWorkMonthPanel';
import { ShareDocumentPanel, SharedLogPanel } from '../../components/SharedDocuments';
import { Button, Card, Chips, Empty, Pill, Row, Screen, Segmented } from '../../components/ui';
import { downloadOrOpen } from '../../lib/saveDownload';
import { api, DailyReport, DocumentReportRow, Profile } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { shareCsv } from '../../lib/csv';
import { dailyReportSiteWisePdf, dailyReportSiteWiseCsv } from '../../lib/dailyReportPdf';
import { sharePdf } from '../../lib/pdf';
import { errorText } from '../../lib/supabase';
import { fmtISODate, istDateISO, MONTHS } from '../../lib/time';
import { C } from '../../theme';

/**
 * Documents report: every document sent or received in a month, with a Download button for each file.
 * Admin / HR see all employees (and can pick one); an employee sees his own documents.
 */
export default function DocumentsReportScreen() {
  const { isAdmin, profile } = useAuth();
  const [sharedKey, setSharedKey] = useState(0);
  const today = istDateISO();
  const [year, setYear] = useState(Number(today.slice(0, 4)));
  const [month, setMonth] = useState(Number(today.slice(5, 7)));
  const [team, setTeam] = useState<Profile[]>([]);
  const [userId, setUserId] = useState<string | undefined>();
  const [rows, setRows] = useState<DocumentReportRow[] | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [statusF, setStatusF] = useState<string>('All');
  // Daily Reports tab (Admin / HR): the same Employee filter and month, plus a Site filter and status chips
  const [tab, setTab] = useState<'docs' | 'daily' | 'sitework'>('docs');
  // Inside Documents (Admin / HR / Project Manager): My documents | Received | Share (From CV Patil) | Shared & view log
  const [sub, setSub] = useState<'mine' | 'received' | 'share' | 'shared'>('mine');
  const [daily, setDaily] = useState<DailyReport[] | null>(null);
  const [dailyCity, setDailyCity] = useState('');
  const [dailySite, setDailySite] = useState('');
  const [dailyStatus, setDailyStatus] = useState<DailyStatusFilter>('All');

  useEffect(() => { if (isAdmin) api.team().then(setTeam).catch(() => {}); }, [isAdmin]);

  const range = () => {
    const mm = String(month).padStart(2, '0');
    return { from: `${year}-${mm}-01`, to: `${year}-${mm}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}` };
  };

  const load = useCallback(async () => {
    const { from, to } = range();
    try { setRows(await api.documentsReport(from, to, userId)); }
    catch (e) { Alert.alert('Could not load', errorText(e)); }
    // Daily reports load on their own: a problem here never affects the Documents tab
    if (isAdmin) api.dailyReportsAdmin(from, to, userId).then(setDaily).catch(() => setDaily([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, month, userId, isAdmin]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const download = async (d: DocumentReportRow) => {
    try { await downloadOrOpen(await api.employeeFileUrl(d.file_path, d.file_name || d.title), d.file_name || d.title, true); }
    catch (e) { Alert.alert('File unavailable', errorText(e)); }
  };

  const statusOf = (d: DocumentReportRow) => d.status ?? (d.direction === 'from_admin' ? 'Sent' : 'Submitted');
  const shown = (rows ?? []).filter((d) => (statusF === 'All' || statusOf(d) === statusF) && (sub !== 'received' || d.direction !== 'from_admin'));
  const reportRows = () => shown.map((d) => ({
    Date: fmtISODate(d.created_at.slice(0, 10)),
    Employee: d.employee?.full_name ?? '',
    'Employee ID': d.employee?.username ?? '',
    Direction: d.direction === 'from_admin' ? 'Sent by Admin / HR' : 'Uploaded by employee',
    'Sent by': d.sender?.full_name ?? '',
    Document: d.title,
    Type: d.category ?? '',
    Status: statusOf(d),
    File: d.file_name ?? '',
    Remark: d.remark ?? '',
    'Review note': d.review_note ?? '',
  }));
  // daily_report_city_site_<city>_<site>_<employee>_<from>_to_<to>
  const dailyFileName = () => {
    const { from, to } = range();
    const part = (v?: string) => (v ? `${v.trim().replace(/[^A-Za-z0-9]+/g, '_')}_` : '');
    return `daily_report_city_site_${part(dailyCity)}${part(dailySite)}${part(userId ? team.find((e) => e.id === userId)?.full_name : '')}${from}_to_${to}`;
  };
  const dailyShown = filterDaily(daily ?? [], dailySite, dailyStatus, dailyCity);
  const exportCsv = () => {
    if (tab === 'sitework') {
      const sw = siteWorkRows(daily ?? []);
      if (sw.length === 0) return Alert.alert('Nothing to export', 'No site work in this month.');
      return shareCsv(`site_work_report_${year}_${String(month).padStart(2, '0')}.csv`, sw);
    }
    if (tab === 'daily') {
      if (dailyShown.length === 0) return Alert.alert('Nothing to export', 'No daily reports match the filters.');
      // the same site-wise structure as the PDF: blocks by site and employee, Remarks + Comments in one column
      return dailyReportSiteWiseCsv(`${dailyFileName()}.csv`, { reports: dailyShown, site: dailySite || undefined, city: dailyCity || undefined }).catch((e) => Alert.alert('Could not create the CSV', errorText(e)));
    }
    if (!rows || rows.length === 0) return Alert.alert('Nothing to export', 'No documents in this month.');
    shareCsv(`documents_report_${year}_${String(month).padStart(2, '0')}.csv`, reportRows());
  };
  const exportPdf = async () => {
    if (tab === 'sitework') {
      const sw = siteWorkRows(daily ?? []);
      if (sw.length === 0) return Alert.alert('Nothing to export', 'No site work in this month.');
      setPdfBusy(true);
      try {
        const who = userId ? team.find((e) => e.id === userId)?.full_name : 'All employees';
        await sharePdf(`site_work_report_${year}_${String(month).padStart(2, '0')}.pdf`, { title: 'Monthly Site Work Report', subtitle: `${who ?? ''} - ${MONTHS[month - 1]} ${year}`, rows: sw });
      } catch (e) { Alert.alert('Could not create the PDF', errorText(e)); }
      finally { setPdfBusy(false); }
      return;
    }
    if (tab === 'daily') {
      if (dailyShown.length === 0) return Alert.alert('Nothing to export', 'No daily reports match the filters.');
      setPdfBusy(true);
      try {
        const who = userId ? team.find((e) => e.id === userId)?.full_name : 'All employees';
        // site-wise layout: blocks by site and employee, Remarks + Comments in one column, the photos of the reports
        const filters = `City: ${dailyCity || 'All cities'}  |  Site: ${dailySite || 'All sites'}  |  Employee: ${who ?? 'All employees'}  |  Status: ${dailyStatus}`;
        await dailyReportSiteWisePdf(`${dailyFileName()}.pdf`,
          { period: `${MONTHS[month - 1]} ${year}`, reports: dailyShown, site: dailySite || undefined, city: dailyCity || undefined, filters });
      } catch (e) { Alert.alert('Could not create the PDF', errorText(e)); }
      finally { setPdfBusy(false); }
      return;
    }
    if (!rows || rows.length === 0) return Alert.alert('Nothing to export', 'No documents in this month.');
    setPdfBusy(true);
    try {
      const who = userId ? team.find((e) => e.id === userId)?.full_name : isAdmin ? 'All employees' : 'My documents';
      await sharePdf(`documents_report_${year}_${String(month).padStart(2, '0')}.pdf`, {
        title: 'Documents Report',
        subtitle: `${who ?? ''} - ${MONTHS[month - 1]} ${year}  |  ${rows.length} document(s): ${fromAdmin} sent by Admin / HR, ${fromEmp} by employees`,
        rows: reportRows(),
      });
    } catch (e) { Alert.alert('Could not create the PDF', errorText(e)); }
    finally { setPdfBusy(false); }
  };

  const fromAdmin = rows?.filter((d) => d.direction === 'from_admin').length ?? 0;
  const fromEmp = (rows?.length ?? 0) - fromAdmin;

  return (
    <Screen>
      {isAdmin ? (
        <Card>
          <Text style={st.lbl}>Employee</Text>
          <Dropdown width="100%" value={userId ? team.findIndex((e) => e.id === userId) + 1 : 0}
            onChange={(i) => setUserId(i > 0 ? team[i - 1]?.id : undefined)}
            options={[{ value: 0, label: 'All employees' }, ...team.map((e, i) => ({ value: i + 1, label: e.full_name }))]} />
        </Card>
      ) : null}
      <MonthPicker year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); setRows(null); setDaily(null); }} />

      {isAdmin ? (
        <Segmented<'docs' | 'daily' | 'sitework'> value={tab} onChange={setTab} options={[
          { value: 'docs', label: `Documents (${rows?.length ?? 0})` },
          { value: 'daily', label: `Daily Reports (${daily?.length ?? 0})` },
          { value: 'sitework', label: 'Site Work (monthly)' },
        ]} />
      ) : null}
      {isAdmin && tab === 'docs' ? (
        <Segmented<'mine' | 'received' | 'share' | 'shared'> value={sub} onChange={setSub} options={[
          { value: 'mine', label: `My documents (${rows?.length ?? 0})` },
          { value: 'received', label: 'Received' },
          { value: 'share', label: 'Share (From CV Patil)' },
          { value: 'shared', label: 'Shared & view log' },
        ]} />
      ) : null}

      {tab === 'docs' && isAdmin && (sub === 'share' || sub === 'shared') ? null : <Row style={{ justifyContent: 'space-between', marginBottom: 10 }}>
        <Text style={st.count}>{tab === 'sitework' ? `${siteWorkRows(daily ?? []).length} site visit line(s) this month` : tab === 'daily'
          ? `${dailyShown.length} daily report(s)`
          : `${rows?.length ?? 0} document(s) - ${fromAdmin} sent by Admin / HR, ${fromEmp} by employees`}</Text>
        <Row>
          <Button title="PDF report" icon="document-text-outline" small loading={pdfBusy} onPress={exportPdf} />
          <Button title="CSV" icon="download-outline" variant="secondary" small onPress={exportCsv} />
        </Row>
      </Row>}
      {tab === 'docs' && sub === 'share' && isAdmin ? (
        <ShareDocumentPanel onShared={() => { setSharedKey((k) => k + 1); setSub('shared'); }} />
      ) : tab === 'docs' && sub === 'shared' && isAdmin ? (
        <SharedLogPanel refreshKey={sharedKey} myId={profile?.id ?? ''} />
      ) : tab === 'sitework' && isAdmin ? (
        <SiteWorkMonthPanel rows={daily} />
      ) : tab === 'daily' && isAdmin ? (
        <DailyReportsPanel rows={daily} shown={dailyShown} city={dailyCity} setCity={setDailyCity} site={dailySite} setSite={setDailySite}
          status={dailyStatus} setStatus={setDailyStatus} onChanged={load} />
      ) : (
      <>
      <Chips<string> options={['All', 'Submitted', 'Approved', 'Rejected', 'Sent']} value={statusF} onChange={setStatusF} />

      <Card style={{ paddingVertical: 4 }}>
        {!rows ? <ActivityIndicator style={{ margin: 20 }} color={C.blue} /> : shown.length === 0 ? (
          <Empty icon="document-outline" text="No documents here." />
        ) : shown.map((d) => {
          const admin = d.direction === 'from_admin';
          return (
            <View key={d.id} style={st.item}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Text style={st.title} numberOfLines={1}>{d.title}</Text>
                <Pill text={admin ? 'Admin / HR' : 'Employee'} tone={admin ? 'purple' : 'blue'} />
              </Row>
              <Text style={st.sub}>
                {fmtISODate(d.created_at.slice(0, 10))} - {d.employee?.full_name ?? 'Employee'}
                {d.sender?.full_name ? ` - sent by ${d.sender.full_name}` : ''}
              </Text>
              {d.remark ? <Text style={st.remark}>Remark: {d.remark}</Text> : null}
              <DocStatusLine d={d} />
              <Row style={{ marginTop: 6 }}>
                <Button title="Download" icon="download-outline" small onPress={() => download(d)} />
              </Row>
              {isAdmin ? <DocumentReview d={d} onChanged={load} /> : null}
            </View>
          );
        })}
      </Card>
      </>
      )}
    </Screen>
  );
}

const st = StyleSheet.create({
  lbl: { fontSize: 12, fontWeight: '800', color: '#3A5068', marginBottom: 6 },
  count: { flex: 1, fontSize: 12.5, fontWeight: '700', color: C.muted, marginRight: 8 },
  item: { paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#EEF3F8' },
  title: { fontWeight: '800', color: '#102A45', fontSize: 14, flexShrink: 1 },
  sub: { color: C.muted, fontSize: 12.5, marginTop: 3 },
  remark: { color: '#203951', marginTop: 4, lineHeight: 19 },
});

