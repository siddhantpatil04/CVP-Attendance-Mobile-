import React, { useMemo } from 'react';
import EmployeeDetailsForm from '../../components/EmployeeDetailsForm';
import { Screen } from '../../components/ui';
import { useAuth } from '../../lib/auth';

/** My Details: the employee fills the company Employee Form and uploads photo, Aadhar, PAN, bank, graduation and CV */
export default function MyDetailsScreen() {
  const { profile } = useAuth();
  const fallback = useMemo(() => ({
    name: profile?.full_name ?? '', phone: profile?.phone ?? '', joining: profile?.joining_date ?? '',
    department: profile?.department ?? '', designation: profile?.designation ?? '', role: profile?.role ?? '', siteEmployee: !!profile?.site_employee,
  }), [profile?.full_name, profile?.phone, profile?.joining_date, profile?.department, profile?.designation, profile?.role, profile?.site_employee]);
  if (!profile) return null;
  return <Screen><EmployeeDetailsForm userId={profile.id} admin={false} fallback={fallback} /></Screen>;
}
