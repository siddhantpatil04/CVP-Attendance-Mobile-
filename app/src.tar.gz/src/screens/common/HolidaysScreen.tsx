import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Dropdown } from '../../components/Pickers';
import { holidayMonths } from '../../lib/holidayMonths';
import { Card, Empty, Kpi, KpiGrid, ListItem, Pill, Screen } from '../../components/ui';
import { api, EmployeeHoliday, Holiday } from '../../lib/api';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtISODate, istDateISO, istParts } from '../../lib/time';
import { C } from '../../theme';

export default function HolidaysScreen() {
  const [year, setYearState] = useState(istParts().year);
  const setYear = (y: number) => { setYearState(y); setMonth(-1); };
  const [company, setCompany] = useState<Holiday[]>([]);
  const [mine, setMine] = useState<EmployeeHoliday[]>([]);   // holidays made for this person's category / for him (Holiday Setup)
  const load = useCallback(async () => {
    try {
      const [c, m] = await Promise.all([api.holidays(year), api.employeeHolidays(year)]);
      setCompany(c); setMine(m);
    } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, [year]);
  // one list: company holidays (paid) + the holidays that apply to this employee (paid or unpaid)
  const rows = [
    ...company.map((h) => ({ day: h.day, name: h.name, kind: h.kind as string, unpaid: false })),
    ...mine.map((h) => ({ day: h.day, name: h.name, kind: h.holiday_type === 'Unpaid' ? 'Unpaid' : 'Paid', unpaid: h.holiday_type === 'Unpaid' })),
  ].sort((a, b) => a.day.localeCompare(b.day));
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('holidays', [{ table: 'holidays' }, { table: 'employee_holidays' }], () => load());
  const today = istDateISO();
  // Month drop-down: -1 = list hidden, 0 = the whole year, n = the n-th month
  const [month, setMonth] = useState(-1); // -1 = list hidden, 0 = the whole year, n = the n-th month
  const months = holidayMonths(rows);
  const shownRows = month > 0 ? rows.filter((h) => h.day.startsWith(months[month - 1]?.key ?? '')) : rows;
  const upcoming = rows.filter((h) => h.day >= today).length;

  return (
    <Screen>
      <View style={st.yearRow}>
        <Pressable onPress={() => setYear(year - 1)} hitSlop={10}><Ionicons name="chevron-back" size={22} color={C.ink} /></Pressable>
        <Text style={st.year}>{year}</Text>
        <Pressable onPress={() => setYear(year + 1)} hitSlop={10}><Ionicons name="chevron-forward" size={22} color={C.ink} /></Pressable>
      </View>
      <KpiGrid>
        <Kpi label="Published Holidays" value={rows.length} icon="calendar-outline" tone="blue" />
        <Kpi label="Upcoming" value={upcoming} icon="sunny-outline" tone="amber" />
      </KpiGrid>
      {rows.length > 0 ? (
        <View style={{ marginBottom: 10 }}>
          <Dropdown width="100%" value={month} onChange={setMonth}
            options={[{ value: -1, label: 'Select month' }, { value: 0, label: `All (${rows.length})` },
              ...months.map((m, i) => ({ value: i + 1, label: m.label }))]} />
        </View>
      ) : null}
      <Card style={{ display: month < 0 && rows.length > 0 ? 'none' : 'flex' }}>
        {rows.length === 0 ? <Empty text="HR has not published holidays for this year yet." icon="calendar-outline" /> : shownRows.map((h) => (
          <ListItem key={`-`} icon={h.day < today ? 'checkmark-done-outline' : 'calendar-outline'} title={h.name}
            subtitle={h.unpaid ? ` - unpaid holiday (salary of this day is deducted)` : fmtISODate(h.day)}
            right={<Pill text={h.kind} tone={h.kind === 'General' ? 'blue' : h.kind === 'Paid' ? 'green' : h.kind === 'Unpaid' ? 'amber' : 'purple'} />} />
        ))}
      </Card>
    </Screen>
  );
}

const st = StyleSheet.create({
  yearRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 24, marginBottom: 12 },
  year: { fontSize: 20, fontWeight: '800', color: C.ink },
});

