import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert } from 'react-native';
import { Avatar, Card, Empty, Field, Kpi, KpiGrid, ListItem, Pill, Screen } from '../../components/ui';
import { api, Profile } from '../../lib/api';
import { useRealtime } from '../../lib/realtime';
import { errorText } from '../../lib/supabase';
import { fmtISODate } from '../../lib/time';
import { shownRole } from '../../navigation/menu';

export default function TeamScreen() {
  const [rows, setRows] = useState<Profile[]>([]);
  const [q, setQ] = useState('');
  const load = useCallback(async () => {
    try { setRows(await api.team()); } catch (e) { Alert.alert('Could not load', errorText(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  useRealtime('team', [{ table: 'profiles' }], () => load());

  const shown = useMemo(() => {
    const k = q.trim().toLowerCase();
    return k ? rows.filter((r) => `${r.full_name} ${r.department} ${r.role}`.toLowerCase().includes(k)) : rows;
  }, [rows, q]);

  return (
    <Screen>
      <KpiGrid>
        <Kpi label="Active Members" value={rows.length} icon="people-outline" tone="blue" />
        <Kpi label="Departments" value={new Set(rows.map((r) => r.department || 'General')).size} icon="business-outline" tone="cyan" />
      </KpiGrid>
      <Field placeholder="Search name or department" value={q} onChangeText={setQ} />
      <Card>
        {shown.length === 0 ? <Empty text="No team members found." /> : shown.map((r) => (
          <ListItem key={r.id} left={<Avatar name={r.full_name} size={38} />} title={r.full_name}
            subtitle={`${r.department || 'General'}${r.joining_date ? ' - Joined ' + fmtISODate(r.joining_date) : ''}`}
            right={shownRole(r) !== 'Employee' ? <Pill text={shownRole(r)} tone="purple" /> : undefined} />
        ))}
      </Card>
    </Screen>
  );
}
