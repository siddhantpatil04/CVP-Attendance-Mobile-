import AsyncStorage from '@react-native-async-storage/async-storage';

// ------------------------------------------------------------------
// App configuration.
// Server address, in this order:
//   1. a server chosen inside the app (Login screen -> Server settings), saved on this device
//   2. the ".env" file (EXPO_PUBLIC_SUPABASE_URL / EXPO_PUBLIC_SUPABASE_ANON_KEY), read at build time
// ------------------------------------------------------------------
const envUrl = process.env.EXPO_PUBLIC_SUPABASE_URL ?? '';
const envKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';
const SERVER_KEY = 'cvp_server';

export let SUPABASE_URL = envUrl;
export let SUPABASE_ANON_KEY = envKey;
/** True when the address comes from "Server settings" (e.g. the office server) instead of the built-in one */
export let SERVER_IS_CUSTOM = false;

const valid = (u: string, k: string) => /^https?:\/\/\S+$/.test(u) && k.length > 20;
export let isConfigured = valid(SUPABASE_URL, SUPABASE_ANON_KEY);

const listeners = new Set<() => void>();
/** Called after the server address changed, so the app can reconnect without a restart */
export function onServerChange(fn: () => void) { listeners.add(fn); return () => { listeners.delete(fn); }; }

function apply(u: string, k: string, custom: boolean) {
  SUPABASE_URL = u;
  SUPABASE_ANON_KEY = k;
  SERVER_IS_CUSTOM = custom;
  isConfigured = valid(u, k);
}

/** Reads the server chosen in the app (if any). Called once before the app starts. */
export async function loadServerConfig() {
  try {
    const raw = await AsyncStorage.getItem(SERVER_KEY);
    if (raw) {
      const { u, k } = JSON.parse(raw);
      if (valid(u, k)) apply(u, k, true);
    }
  } catch { /* use the built-in address */ }
}

/** "Connection code" = base64 of {"u": address, "k": anon key}. The office server script prints it. */
export function decodeConnectionCode(code: string): { u: string; k: string } | null {
  try {
    const o = JSON.parse(atob(code.replace(/\s+/g, '')));
    return valid(o.u, o.k) ? { u: String(o.u).replace(/\/+$/, ''), k: String(o.k) } : null;
  } catch { return null; }
}

export async function saveServerCode(code: string): Promise<boolean> {
  const o = decodeConnectionCode(code);
  if (!o) return false;
  await AsyncStorage.setItem(SERVER_KEY, JSON.stringify(o));
  apply(o.u, o.k, true);
  listeners.forEach((f) => f());
  return true;
}

/** Back to the built-in (internet) server */
export async function resetServer() {
  await AsyncStorage.removeItem(SERVER_KEY).catch(() => {});
  apply(envUrl, envKey, false);
  listeners.forEach((f) => f());
}

export const COMPANY_NAME = 'C. V. PATIL & ASSOCIATES';
/**
 * Employees who are counted as OFFICE employees in the attendance screens and reports (Office Attendance) on EVERY day, wherever they check in
 * (own office, other office, work site, other city, Foreign Location) - even when their "Site employee" switch is on.
 * Only where the attendance is SHOWN changes; check-in / check-out, salary and leave are not touched. Add more employee IDs here.
 */
export const OFFICE_ATTENDANCE_EMPLOYEES: string[] = ['emp009'];
export const COMPANY_ADDRESS =
  '1002, Trident Business Centre, Oppo. Audi Showroom, Mumbai-Pune Highway, Baner, Pune-411045';
export const APP_NAME = 'CVP Attendance';
/** Printed on the Muster Roll cum Wages Register (Form II) */
export const COMPANY_PAN = 'AKDPP4541Q';

/** Minimum password length (same rule as the Streamlit app) */
export const MIN_PASSWORD = 12;

/**
 * Registration codes by SMS. Keep false until an SMS provider is set up in Supabase
 * (Authentication -> Providers -> Phone); then change to true to show the "Mobile" choice again.
 */
export const MOBILE_CODES_ENABLED = true;
