﻿import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNavigationContainerRef, DefaultTheme, NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { menuAllowed } from './menu';
import { View } from 'react-native';
import { Loading } from '../components/ui';
import { useAuth } from '../lib/auth';
import { useIsDesktop } from '../lib/layout';
import { Sidebar } from './Sidebar';
import { C } from '../theme';

import LoginScreen from '../screens/LoginScreen';
import HomeScreen from '../screens/employee/HomeScreen';
import AttendanceScreen from '../screens/employee/AttendanceScreen';
import DailyReportHubScreen from '../screens/employee/DailyReportHubScreen';
import SiteSelfieScreen from '../screens/employee/SiteSelfieScreen';
import LeaveScreen from '../screens/employee/LeaveScreen';
import RegularizationScreen from '../screens/employee/RegularizationScreen';
import HolidaysScreen from '../screens/common/HolidaysScreen';
import TeamScreen from '../screens/common/TeamScreen';
import TourHubScreen from '../screens/employee/TourHubScreen';
import DocumentsScreen from '../screens/employee/DocumentsScreen';
import DocumentsReportScreen from '../screens/common/DocumentsReportScreen';
import TourAdminScreen from '../screens/admin/TourAdminScreen';
import ProfileScreen from '../screens/common/ProfileScreen';
import MyDetailsScreen from '../screens/common/MyDetailsScreen';
import MoreScreen from '../screens/common/MoreScreen';
import LiveDashboardScreen from '../screens/admin/LiveDashboardScreen';
import ApprovalsScreen from '../screens/admin/ApprovalsScreen';
import EmployeesScreen from '../screens/admin/EmployeesScreen';
import EmployeeDetailScreen from '../screens/admin/EmployeeDetailScreen';
import EmployeeFormsScreen from '../screens/admin/EmployeeFormsScreen';
import EmployeeFormScreen from '../screens/admin/EmployeeFormScreen';
import AddEmployeeScreen from '../screens/admin/AddEmployeeScreen';
import AppUpdateScreen from '../screens/admin/AppUpdateScreen';
import ReportsScreen from '../screens/admin/ReportsScreen';
import SaturdaysAdminScreen from '../screens/admin/SaturdaysAdminScreen';
import TravelReportScreen from '../screens/admin/TravelReportScreen';
import TeamAttendanceScreen from '../screens/admin/TeamAttendanceScreen';
import LiveMapScreen from '../screens/admin/LiveMapScreen';
import SelfieRecordsScreen from '../screens/admin/SelfieRecordsScreen';
import WorkingHoursScreen from '../screens/admin/WorkingHoursScreen';
import SalaryManagementScreen from '../screens/admin/SalaryManagementScreen';
import MySalaryScreen from '../screens/employee/MySalaryScreen';
import HolidaysAdminScreen from '../screens/admin/HolidaysAdminScreen';
import SitesAdminScreen from '../screens/admin/SitesAdminScreen';
import AuditScreen from '../screens/admin/AuditScreen';
import MyMapScreen from '../screens/employee/MyMapScreen';
import FieldJourneyScreen from '../screens/employee/FieldJourneyScreen';
import FieldJourneyReportScreen from '../screens/admin/FieldJourneyReportScreen';
const Stack = createNativeStackNavigator();
export const navigationRef = createNavigationContainerRef<any>();
const Tab = createBottomTabNavigator();

const headerOpts = {
  headerStyle: { backgroundColor: C.white },
  headerTitleStyle: { fontWeight: '800' as const, color: C.ink },
  headerTintColor: C.blue,
  headerShadowVisible: false,
};

const tabOpts = (icons: Record<string, [keyof typeof Ionicons.glyphMap, keyof typeof Ionicons.glyphMap]>, desktop: boolean) =>
  ({ route }: { route: { name: string } }) => ({
    ...headerOpts,
    tabBarActiveTintColor: C.blue,
    tabBarInactiveTintColor: '#8090A2',
    // On desktop the left Sidebar replaces the bottom tab bar
    tabBarStyle: desktop ? { display: 'none' as const } : { borderTopColor: C.line },
    tabBarLabelStyle: { fontWeight: '700' as const, fontSize: 11 },
    tabBarIcon: ({ focused, color, size }: { focused: boolean; color: string; size: number }) => {
      const [on, off] = icons[route.name] ?? ['ellipse', 'ellipse-outline'];
      return <Ionicons name={focused ? on : off} size={size} color={color} />;
    },
  });

function EmployeeTabs() {
  const { profile } = useAuth();
  const desktop = useIsDesktop();
  return (
    <Tab.Navigator screenOptions={tabOpts({
      Home: ['home', 'home-outline'],
      Attendance: ['calendar', 'calendar-outline'],
      Selfie: ['camera', 'camera-outline'],
      Journey: ['navigate', 'navigate-outline'],
      Leave: ['airplane', 'airplane-outline'],
      More: ['grid', 'grid-outline'],
    }, desktop)}>
      <Tab.Screen name="Home" component={HomeScreen} options={{ title: 'Dashboard', tabBarLabel: "Home" }} />
      <Tab.Screen name="Attendance" component={AttendanceScreen} options={{ title: 'My Attendance', tabBarLabel: "Attendance" }} />
      {profile?.site_employee ? (
        <Tab.Screen name="Selfie" component={SiteSelfieScreen} options={{ title: 'Site Selfie', tabBarLabel: "Selfie" }} />
      ) : null}
      {profile?.site_employee ? (
        <Tab.Screen name="Journey" component={FieldJourneyScreen} options={{ title: 'Field Site', tabBarLabel: "Field Site" }} />
      ) : null}
      <Tab.Screen name="Leave" component={LeaveScreen} options={{ title: 'Leave Management', tabBarLabel: "Leave" }} />
      <Tab.Screen name="More" component={MoreScreen} options={{ tabBarLabel: "More" }} />
    </Tab.Navigator>
  );
}

function AdminTabs() {
  const desktop = useIsDesktop();
  const { isFullAdmin, profile } = useAuth(); // Reports and downloads: Admin and HR
  const isOwner = profile?.role === 'Admin'; // the owner does not punch in; HR does
  return (
    <Tab.Navigator screenOptions={tabOpts({
      Live: ['pulse', 'pulse-outline'],
      CheckIn: ['finger-print', 'finger-print-outline'],
      Approvals: ['checkmark-done-circle', 'checkmark-done-circle-outline'],
      Reports: ['bar-chart', 'bar-chart-outline'],
      More: ['grid', 'grid-outline'],
    }, desktop)}>
      {menuAllowed(profile, 'Live') ? <Tab.Screen name="Live" component={LiveDashboardScreen} options={{ title: 'Live Dashboard', tabBarLabel: 'Live' }} /> : null}
      {isOwner ? null : <Tab.Screen name="CheckIn" component={HomeScreen} options={{ title: 'My Check-In', tabBarLabel: 'Check-In' }} />}
      {menuAllowed(profile, 'Approvals') ? <Tab.Screen name="Approvals" component={ApprovalsScreen} /> : null}
      {isFullAdmin && menuAllowed(profile, 'Reports') ? <Tab.Screen name="Reports" component={ReportsScreen} options={{ title: 'Company Reports', tabBarLabel: 'Reports' }} /> : null}
      <Tab.Screen name="More" component={MoreScreen} />
    </Tab.Navigator>
  );
}

export default function RootNavigator() {
  const { session, profile, loading, isAdmin, isFullAdmin } = useAuth();
  const desktop = useIsDesktop();
  const [current, setCurrent] = useState<string | undefined>();
  if (loading) return <Loading />;
  const signedIn = !!session && !!profile;
  const track = () => setCurrent(navigationRef.getCurrentRoute()?.name);

  const stack = (
      <Stack.Navigator screenOptions={headerOpts}>
        {!signedIn ? (
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        ) : (
          <>
            <Stack.Screen name="Tabs" component={isAdmin ? AdminTabs : EmployeeTabs} options={{ headerShown: false }} />
            {/* shared pages opened from "More" and from other screens */}
            <Stack.Screen name="SiteSelfie" component={SiteSelfieScreen} options={{ title: 'Site Selfie' }} />
            <Stack.Screen name="Regularization" component={RegularizationScreen} options={{ title: 'Attendance Regularization' }} />
            <Stack.Screen name="Tour" component={TourHubScreen} options={{ title: 'Tour' }} />
            <Stack.Screen name="Documents" component={DocumentsScreen} options={{ title: 'Documents' }} />
            <Stack.Screen name="DocsReport" component={DocumentsReportScreen} options={{ title: 'Documents Report' }} />
            <Stack.Screen name="MyMap" component={MyMapScreen} options={{ title: 'My Map' }} />
            <Stack.Screen name="Holidays" component={HolidaysScreen} options={{ title: 'Holiday Calendar' }} />
            <Stack.Screen name="Team" component={TeamScreen} options={{ title: 'Team Directory' }} />
            <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: 'My Profile' }} />
            <Stack.Screen name="MyDetails" component={MyDetailsScreen} options={{ title: 'Employee Details' }} />
            <Stack.Screen name="MySalary" component={MySalaryScreen} options={{ title: 'My Salary' }} />
            <Stack.Screen name="DailyReport" component={DailyReportHubScreen} options={{ title: 'Daily Report' }} />
            {isAdmin ? (
              <>
                <Stack.Screen name="MyHome" component={HomeScreen} options={{ title: 'My Check-In' }} />
                <Stack.Screen name="MyAttendance" component={AttendanceScreen} options={{ title: 'My Attendance' }} />
                <Stack.Screen name="MyLeave" component={LeaveScreen} options={{ title: 'My Leave' }} />
                <Stack.Screen name="EmployeeDetail" component={EmployeeDetailScreen} options={{ title: 'Employee' }} />
                <Stack.Screen name="EmployeeAttendance" component={AttendanceScreen} options={{ title: 'Attendance Report' }} />
                <Stack.Screen name="EmployeeForms" component={EmployeeFormsScreen} options={{ title: 'Employees' }} />
                <Stack.Screen name="EmployeeForm" component={EmployeeFormScreen} options={({ route }: any) => ({ title: route.params?.name ?? 'Employee Form' })} />
                <Stack.Screen name="AddEmployee"component={AddEmployeeScreen} options={{ title: 'Add Employee' }} />
                <Stack.Screen name="FieldJourneyReport" component={FieldJourneyReportScreen} options={{ title: 'Field Site Report' }} />
                <Stack.Screen name="FieldJourney" component={FieldJourneyScreen} options={{ title: 'Field Site' }} />
                <Stack.Screen name="TravelReport" component={TravelReportScreen} options={{ title: 'Travel Report' }} />
                <Stack.Screen name="TeamAttendance" component={TeamAttendanceScreen} options={{ title: "Today's Team Attendance" }} />
                <Stack.Screen name="LiveMap" component={LiveMapScreen} options={{ title: 'Live Map' }} />
                <Stack.Screen name="SelfieRecords" component={SelfieRecordsScreen} options={{ title: 'Selfie Attendance' }} />
                <Stack.Screen name="WorkingHours" component={WorkingHoursScreen} options={{ title: 'Working Time Rules' }} />
                <Stack.Screen name="SalaryManagement" component={SalaryManagementScreen} options={{ title: 'Salary Management' }} />
                <Stack.Screen name="TourAdmin" component={TourAdminScreen} options={{ title: 'Tour Reports' }} />
                <Stack.Screen name="HolidaysAdmin"component={HolidaysAdminScreen} options={{ title: 'Holidays Setup' }} />
                <Stack.Screen name="SaturdaysAdmin" component={SaturdaysAdminScreen} options={{ title: 'Saturday Holidays' }} />
              </>
            ) : null}
            {/* Admin only (HR does not get these) */}
            {isFullAdmin ? (
              <>
                <Stack.Screen name="SitesAdmin" component={SitesAdminScreen} options={{ title: 'Work Sites' }} />
                <Stack.Screen name="Audit" component={AuditScreen} options={{ title: 'Audit Trail' }} />
                <Stack.Screen name="AppUpdate" component={AppUpdateScreen} options={{ title: 'App Updates' }} />
              </>
            ) : null}
          </>
        )}
      </Stack.Navigator>
  );

  return (
    <NavigationContainer
      ref={navigationRef}
      onReady={track}
      onStateChange={track}
      documentTitle={{ formatter: (_o, route) => `${route?.name && route.name !== 'Tabs' ? route.name + ' - ' : ''}CVP Attendance` }}
      theme={{ ...DefaultTheme, colors: { ...DefaultTheme.colors, background: C.bg, primary: C.blue } }}
    >
      {/* Desktop: fixed left menu + page area. Phone: page area only (bottom tabs).
          The page area stays in the same place so resizing the window keeps your page. */}
      <View style={{ flex: 1, flexDirection: 'row', backgroundColor: C.bg }}>
        {signedIn && desktop ? <Sidebar nav={navigationRef} current={current} /> : null}
        <View style={{ flex: 1, minWidth: 0 }}>{stack}</View>
      </View>
    </NavigationContainer>
  );
}

