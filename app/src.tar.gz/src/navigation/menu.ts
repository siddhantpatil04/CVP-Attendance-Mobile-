﻿import type { IconName } from '../components/ui';
import type { Profile } from '../lib/api';

/**
 * One entry of the desktop left menu.
 * `tab` = a screen inside the bottom tabs (opened as Tabs to tab); otherwise `route` is a full page.
 * `also` = other pages that keep this entry highlighted (e.g. Employee detail to Employees).
 */
export interface MenuItem {
  key: string;
  label: string;
  icon: IconName;
  tab?: string;
  route?: string;
  also?: string[];
}
export interface MenuSection { title: string; items: MenuItem[] }

/** The admin-menu items an Admin / HR can give to a Project Manager (key = menu key = route / tab name) */
export const MENU_ACCESS_ITEMS: { key: string; label: string }[] = [
  { key: 'Live', label: 'Live Dashboard' }, { key: 'Approvals', label: 'Approvals' }, { key: 'Reports', label: 'Company Reports' },
  { key: 'EmployeeForms', label: 'Employees' }, { key: 'SalaryManagement', label: 'Salary Management' }, { key: 'TeamAttendance', label: "Today's Team" },
  { key: 'LiveMap', label: 'Live Map' }, { key: 'FieldJourneyReport', label: 'Field Site' }, { key: 'SelfieRecords', label: 'Attendance' },
  { key: 'WorkingHours', label: 'Working Hours' },
  { key: 'TourAdmin', label: 'Tour Reports' }, { key: 'DocsReport', label: 'Daily Reports / Documents' }, { key: 'SitesAdmin', label: 'Work Sites' },
  { key: 'HolidaysAdmin', label: 'Holidays Setup' }, { key: 'SaturdaysAdmin', label: 'Saturday Holidays' }, { key: 'Audit', label: 'Audit Trail' },
  { key: 'AppUpdate', label: 'App Updates' },
];
/** A Project Manager (HR-level with a menu_access list) sees only the ticked admin items; everybody else sees everything their role has */
export const menuAllowed = (profile: { role: string; menu_access?: string[] | null } | null | undefined, key: string) =>
  !profile || profile.role !== 'HR' || !Array.isArray(profile.menu_access) || profile.menu_access.includes(key);

/** A Project Manager with admin-menu items is still an EMPLOYEE for everybody (the database keeps an internal HR permission level only so the ticked items work) */
export const hasMenuAccess = (p: { role: string; menu_access?: string[] | null } | null | undefined) =>
  !!p && p.role === 'HR' && Array.isArray(p.menu_access) && p.menu_access.length > 0;
export const shownRole = (p: { role: string; menu_access?: string[] | null } | null | undefined): string =>
  hasMenuAccess(p) ? 'Employee' : (p?.role ?? '');

export function buildMenu(profile: Profile, isAdmin: boolean, isFullAdmin: boolean): MenuSection[] {
  const site = !!profile.site_employee;
  const tour = !!profile.tour_access;
  const docs = !!profile.documents_access;

  if (!isAdmin) {
    return [
      {
        title: 'Main',
        items: [
          { key: 'Home', label: 'Dashboard', icon: 'home-outline', tab: 'Home' },
          { key: 'Attendance', label: 'My Attendance', icon: 'calendar-outline', tab: 'Attendance' },
          ...(site ? [{ key: 'Selfie', label: 'Site Selfie', icon: 'camera-outline', tab: 'Selfie', also: ['SiteSelfie'] } as MenuItem] : []),
          ...(site ? [{ key: 'Journey', label: 'Field Site', icon: 'navigate-outline', tab: 'Journey' } as MenuItem] : []),
          { key: 'Leave', label: 'Leave', icon: 'airplane-outline', tab: 'Leave' },
        ],
      },
      {
        title: 'My Account',
        items: [
          ...(profile.role === 'Employee' ? [{ key: 'MyMap', label: 'My Map', icon: 'map-outline', route: 'MyMap' } as MenuItem] : []),
          ...(tour ? [{ key: 'Tour', label: 'Tour', icon: 'bus-outline', route: 'Tour' } as MenuItem] : []),
          ...(docs ? [{ key: 'Documents', label: 'Documents', icon: 'document-text-outline', route: 'Documents' } as MenuItem] : []),
          ...(docs ? [{ key: 'DocsReport', label: 'Daily Reports / Documents', icon: 'folder-open-outline', route: 'DocsReport' } as MenuItem] : []),
          ...(site ? [{ key: 'DailyReport', label: 'Daily Report', icon: 'create-outline', route: 'DailyReport' } as MenuItem] : []),   // automatic for site employees
          { key: 'Regularization', label: 'Regularization', icon: 'git-pull-request-outline', route: 'Regularization' },
          { key: 'Holidays', label: 'Holiday Calendar', icon: 'sunny-outline', route: 'Holidays' },
          { key: 'MySalary', label: 'My Salary', icon: 'cash-outline', route: 'MySalary' },
          { key: 'Profile', label: 'My Profile', icon: 'person-circle-outline', route: 'Profile' },
        ],
      },
    ];
  }

  const sections: MenuSection[] = [
    {
      title: 'Main',
      items: [
        { key: 'Live', label: 'Live Dashboard', icon: 'pulse-outline', tab: 'Live' },
        ...(profile.role === 'Admin' ? [] : [{ key: 'CheckIn', label: 'My Check-In', icon: 'finger-print-outline', tab: 'CheckIn' } as MenuItem]),
        { key: 'Approvals', label: 'Approvals', icon: 'checkmark-done-circle-outline', tab: 'Approvals' },
        ...(isFullAdmin ? [{ key: 'Reports', label: 'Company Reports', icon: 'bar-chart-outline', tab: 'Reports' } as MenuItem] : []),
      ],
    },
    {
      title: isFullAdmin ? 'Admin' : 'HR',
      items: [
        { key: 'EmployeeForms', label: 'Employees', icon: 'people-outline', route: 'EmployeeForms', also: ['EmployeeForm', 'EmployeeDetail', 'EmployeeAttendance', 'AddEmployee'] },
        ...(isFullAdmin ? [{ key: 'SalaryManagement', label: 'Salary Management', icon: 'cash-outline', route: 'SalaryManagement' } as MenuItem] : []),
        { key: 'TeamAttendance', label: "Today's Team", icon: 'people-circle-outline', route: 'TeamAttendance' },
        { key: 'LiveMap', label: 'Live Map', icon: 'map-outline', route: 'LiveMap' },
        { key: 'FieldJourneyReport', label: 'Field Site', icon: 'navigate-outline', route: 'FieldJourneyReport' },
        { key: 'SelfieRecords', label: 'Attendance', icon: 'images-outline', route: 'SelfieRecords' },
        { key: 'WorkingHours', label: 'Working Hours', icon: 'time-outline', route: 'WorkingHours' },
        { key: 'TourAdmin', label: 'Tour Reports', icon: 'bus-outline', route: 'TourAdmin' },
        { key: 'DocsReport', label: 'Daily Reports / Documents', icon: 'folder-open-outline', route: 'DocsReport' },
        ...(isFullAdmin ? [{ key: 'SitesAdmin', label: 'Work Sites', icon: 'location-outline', route: 'SitesAdmin' } as MenuItem] : []),
        { key: 'HolidaysAdmin', label: 'Holidays Setup', icon: 'create-outline', route: 'HolidaysAdmin' },
        { key: 'SaturdaysAdmin', label: 'Saturday Holidays', icon: 'calendar-outline', route: 'SaturdaysAdmin' },
        ...(isFullAdmin ? [{ key: 'Audit', label: 'Audit Trail', icon: 'list-outline', route: 'Audit' } as MenuItem] : []),
        ...(isFullAdmin ? [{ key: 'Companies', label: 'Companies', icon: 'business-outline', route: 'Companies' } as MenuItem] : []),
        ...(isFullAdmin ? [{ key: 'AppUpdate', label: 'App Updates', icon: 'cloud-upload-outline', route: 'AppUpdate' } as MenuItem] : []),
      ],
    },
    {
      title: 'My Account',
      // The Admin is the owner, not an employee: only My Profile. HR keeps the employee items.
      items: profile.role === 'Admin' ? [{ key: 'Profile', label: 'My Profile', icon: 'person-circle-outline', route: 'Profile' }] : [
        { key: 'MyAttendance', label: 'My Attendance', icon: 'calendar-outline', route: 'MyAttendance' },
        { key: 'MyLeave', label: 'My Leave', icon: 'airplane-outline', route: 'MyLeave' },
        ...(site ? [{ key: 'SiteSelfie', label: 'Site Selfie', icon: 'camera-outline', route: 'SiteSelfie' } as MenuItem] : []),
        ...(tour ? [{ key: 'Tour', label: 'Tour', icon: 'bus-outline', route: 'Tour' } as MenuItem] : []),
          ...(docs ? [{ key: 'Documents', label: 'Documents', icon: 'document-text-outline', route: 'Documents' } as MenuItem] : []),
        ...(docs ? [{ key: 'DocsReport', label: 'Daily Reports / Documents', icon: 'folder-open-outline', route: 'DocsReport' } as MenuItem] : []),
        ...(site ? [{ key: 'DailyReport', label: 'Daily Report', icon: 'create-outline', route: 'DailyReport' } as MenuItem] : []),   // automatic for site employees
        { key: 'Regularization', label: 'Regularization', icon: 'git-pull-request-outline', route: 'Regularization' },
        { key: 'Holidays', label: 'Holiday Calendar', icon: 'sunny-outline', route: 'Holidays' },
        { key: 'Team', label: 'Team', icon: 'people-outline', route: 'Team' },
        { key: 'MySalary', label: 'My Salary', icon: 'cash-outline', route: 'MySalary' },
        { key: 'Profile', label: 'My Profile', icon: 'person-circle-outline', route: 'Profile' },
      ],
    },
  ];
  // Project Manager: only the admin items Admin / HR ticked (the "My Check-In" entry and My Account stay)
  return sections.map((s, i) => (i < 2 ? { ...s, items: s.items.filter((it) => it.key === 'CheckIn' || menuAllowed(profile, it.key)) } : s));
}

