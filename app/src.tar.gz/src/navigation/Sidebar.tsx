import { Ionicons } from '@expo/vector-icons';
import { NavigationContainerRefWithCurrent, StackActions } from '@react-navigation/native';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { PhotoAvatar } from '../components/PhotoAvatar';
import { COMPANY_NAME } from '../config';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { SIDEBAR_WIDTH } from '../lib/layout';
import { useRealtime, useTicker } from '../lib/realtime';
import { supabase } from '../lib/supabase';
import { fmtDateLong, fmtTime12 } from '../lib/time';
import { C } from '../theme';
import { buildMenu, MenuItem } from './menu';
import { shownRole } from './menu';

/** Desktop left menu: replaces the phone's bottom tabs + "More" page. */
export function Sidebar({ nav, current }: {
  nav: NavigationContainerRefWithCurrent<any>;
  current: string | undefined;
}) {
  const { profile, isAdmin, isFullAdmin, signOut } = useAuth();
  const now = useTicker(15000);
  // my own profile photo (the photo of the Employee Form): the circle shows initials until it is there or when there is none
  const [photoPath, setPhotoPath] = useState<string | null>(null);
  const loadPhoto = useCallback(() => {
    if (!profile) return;
    api.employeeDetailFiles(profile.id).then((fs) => setPhotoPath(fs.find((f) => f.kind === 'photo')?.file_path ?? null)).catch(() => setPhotoPath(null));
  }, [profile?.id]);
  useEffect(() => { loadPhoto(); }, [loadPhoto]);
  useRealtime(`sidebar-photo-${profile?.id}`, [{ table: 'employee_detail_files', filter: `user_id=eq.${profile?.id}` }], () => loadPhoto(), !!profile);
  if (!profile) return null;
  const sections = buildMenu(profile, isAdmin, isFullAdmin);
  const connected = supabase.realtime.isConnected();

  const go = (item: MenuItem) => {
    if (!nav.isReady()) return;
    // Close any open page first so the stack never grows from menu clicks
    const state = nav.getRootState();
    if (state && state.index > 0) nav.dispatch(StackActions.popToTop());
    if (item.tab) nav.navigate('Tabs', { screen: item.tab });
    else if (item.route) nav.navigate(item.route);
  };

  const isActive = (i: MenuItem) => !!current && (current === i.key || current === i.tab || current === i.route || !!i.also?.includes(current));

  return (
    <View style={st.wrap}>
      <View style={st.brand}>
        <Image source={require('../../assets/cvp_logo.png')} style={st.logo} />
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.app} numberOfLines={1}>CVP Attendance</Text>
          <Text style={st.company} numberOfLines={2}>{COMPANY_NAME}</Text>
        </View>
      </View>

      <View style={st.clock}>
        <Text style={st.clockTime}>{fmtTime12(now)}</Text>
        <Text style={st.clockDate}>{fmtDateLong(now)}</Text>
        <View style={st.syncRow}>
          <View style={[st.dot, { backgroundColor: connected ? C.green : '#7C8DA0' }]} />
          <Text style={st.syncText}>{connected ? 'Live sync on' : 'Sync connecting...'}</Text>
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 12 }}>
        {sections.map((sec) => (
          <View key={sec.title} style={{ marginTop: 12 }}>
            <Text style={st.section}>{sec.title.toUpperCase()}</Text>
            {sec.items.map((i) => {
              const on = isActive(i);
              return (
                <Pressable
                  key={i.key}
                  onPress={() => go(i)}
                  style={({ hovered, pressed }: any) => [st.item, on && st.itemOn, !on && (hovered || pressed) && st.itemHover]}
                  accessibilityRole="link"
                >
                  <Ionicons name={(on ? String(i.icon).replace('-outline', '') : i.icon) as any} size={18} color={on ? C.white : '#A9C1D6'} />
                  <Text style={[st.itemText, on && { color: C.white }]} numberOfLines={1}>{i.label}</Text>
                </Pressable>
              );
            })}
          </View>
        ))}
      </ScrollView>

      <View style={st.user}>
        <PhotoAvatar name={profile.full_name} size={38} path={photoPath} />
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={st.userName} numberOfLines={1}>{profile.full_name}</Text>
          <Text style={st.userRole} numberOfLines={1}>{shownRole(profile)} - {profile.username}</Text>
        </View>
        <Pressable
          onPress={() => Alert.alert('Sign out?', '', [{ text: 'Cancel', style: 'cancel' }, { text: 'Sign out', style: 'destructive', onPress: signOut }])}
          hitSlop={8}
          style={st.out}
          accessibilityLabel="Sign out"
        >
          <Ionicons name="log-out-outline" size={20} color="#FFB4BB" />
        </Pressable>
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  wrap: { width: SIDEBAR_WIDTH, backgroundColor: C.navy, paddingHorizontal: 14, paddingTop: 18, paddingBottom: 12 },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 4 },
  logo: { width: 42, height: 42, borderRadius: 12, backgroundColor: C.white },
  app: { color: C.white, fontWeight: '800', fontSize: 14, lineHeight: 19 },
  company: { color: '#8FB3CC', fontSize: 10.5, marginTop: 2, lineHeight: 14 },
  clock: { marginTop: 16, backgroundColor: C.navy2, borderRadius: 14, padding: 12 },
  clockTime: { color: C.white, fontSize: 19, lineHeight: 25, fontWeight: '800', letterSpacing: -0.3 },
  clockDate: { color: '#A8C6DA', fontSize: 11, lineHeight: 15, marginTop: 2 },
  syncRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  syncText: { color: '#CFE2EE', fontSize: 11, fontWeight: '700' },
  section: { color: '#6F93AE', fontSize: 10.5, fontWeight: '800', letterSpacing: 1.2, marginBottom: 6, paddingHorizontal: 8 },
  item: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 40, paddingVertical: 8, paddingHorizontal: 12, borderRadius: 10, marginBottom: 2 },
  itemOn: { backgroundColor: C.blue },
  itemHover: { backgroundColor: 'rgba(255,255,255,0.07)' },
  itemText: { color: '#CFE0EC', fontSize: 12.5, lineHeight: 17, fontWeight: '700', flex: 1, minWidth: 0 },
  user: { flexDirection: 'row', alignItems: 'center', gap: 10, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.08)', paddingTop: 12 },
  userName: { color: C.white, fontWeight: '800', fontSize: 12.5, lineHeight: 17 },
  userRole: { color: '#8FB3CC', fontSize: 10.5, lineHeight: 14, marginTop: 1 },
  out: { padding: 6, borderRadius: 8 },
});
