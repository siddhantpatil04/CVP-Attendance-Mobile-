-- =====================================================================
-- PF ON / OFF per employee + PF rules.
--
--   pf_control    one row: switch_from = first month in which the PF buttons are used.
--                 EMPTY (the default) = every month is calculated exactly as today.
--                 From switch_from on, an employee without a PF row is PF OFF.
--   employee_pf   PF history of an employee: from a month -> ON / OFF, Auto or Fixed amount.
--   pf_rules      rates and ceiling, from a month. Seeded with TODAY's values (12 %, 12 %, ceiling 25,000).
--
-- New tables and functions only. No existing table, row or function is changed.
-- Needs salary_management.sql and payroll_months.sql first.
-- BACK UP FIRST.  Supabase -> SQL Editor -> paste the WHOLE file -> Run.  Safe to run again.
-- Undo: see the ROLLBACK block at the end.
-- =====================================================================

create table if not exists public.pf_control (
  id          int primary key default 1 check (id = 1),
  switch_from date check (switch_from is null or extract(day from switch_from) = 1),
  updated_by  uuid references public.profiles(id) on delete set null,
  updated_at  timestamptz not null default now()
);
insert into public.pf_control (id) values (1) on conflict do nothing;

create table if not exists public.employee_pf (
  user_id      uuid not null references public.profiles(id) on delete cascade,
  from_date    date not null check (extract(day from from_date) = 1),
  applicable   boolean not null default false,
  amount_mode  text not null default 'auto' check (amount_mode in ('auto', 'fixed')),
  fixed_amount numeric(10,2),
  created_by   uuid references public.profiles(id) on delete set null,
  created_at   timestamptz not null default now(),
  primary key (user_id, from_date),
  check (amount_mode <> 'fixed' or (fixed_amount is not null and fixed_amount > 0))
);

create table if not exists public.pf_rules (
  effective_from date primary key check (extract(day from effective_from) = 1),
  employee_rate  numeric(5,2) not null check (employee_rate between 0 and 100),
  employer_rate  numeric(5,2) not null check (employer_rate between 0 and 100),
  eps_rate       numeric(5,2) not null check (eps_rate between 0 and 100),
  wage_ceiling   numeric(10,2) not null check (wage_ceiling > 0),
  apply_ceiling  boolean not null default true,
  created_by     uuid references public.profiles(id) on delete set null,
  created_at     timestamptz not null default now(),
  check (eps_rate <= employer_rate)
);
insert into public.pf_rules (effective_from, employee_rate, employer_rate, eps_rate, wage_ceiling, apply_ceiling)
values (date '2000-01-01', 12, 12, 8.33, 25000, true)
on conflict do nothing;

-- Read: Admin / HR everything, an employee only their own PF row. Writes only through the functions below.
alter table public.pf_control  enable row level security;
alter table public.employee_pf enable row level security;
alter table public.pf_rules    enable row level security;
drop policy if exists pf_control_read on public.pf_control;
create policy pf_control_read on public.pf_control for select to authenticated using (true);
drop policy if exists employee_pf_read on public.employee_pf;
create policy employee_pf_read on public.employee_pf for select to authenticated
  using (user_id = auth.uid() or private.is_staff_admin());
drop policy if exists pf_rules_read on public.pf_rules;
create policy pf_rules_read on public.pf_rules for select to authenticated using (private.is_staff_admin());
revoke all on public.pf_control, public.employee_pf, public.pf_rules from anon, authenticated;
grant select on public.pf_control, public.employee_pf, public.pf_rules to authenticated;

-- a PF change can never start inside a finalized month
create or replace function public._pf_check_month(p_from date) returns void
language plpgsql security definer set search_path = public as $$
declare last_fin date;
begin
  if p_from is null or extract(day from p_from) <> 1 then raise exception 'The date must be the 1st of a month'; end if;
  select max(make_date(year, month, 1)) into last_fin from public.payroll_months;
  if last_fin is not null and p_from <= last_fin then
    raise exception '% is finalized - choose % or later', to_char(last_fin, 'FMMonth YYYY'), to_char(last_fin + interval '1 month', 'FMMonth YYYY');
  end if;
end $$;

-- Admin / HR (HR only for plain Employees): PF ON / OFF, Auto / Fixed amount and UAN
create or replace function public.set_employee_pf(p_user uuid, p_from date, p_applicable boolean, p_mode text, p_fixed numeric, p_uan text)
returns void
language plpgsql security definer set search_path = public as $$
declare
  me    public.profiles := public._require_active();
  t     public.profiles;
  old   public.employee_pf;
  v_uan text := nullif(regexp_replace(coalesce(p_uan, ''), '\s', '', 'g'), '');
begin
  if me.role not in ('Admin', 'HR') then raise exception 'Only Admin / HR can change PF' using errcode = '42501'; end if;
  select * into t from public.profiles where id = p_user;
  if t.id is null then raise exception 'User not found'; end if;
  if me.role <> 'Admin' and t.role <> 'Employee' then raise exception 'Only an Admin can change HR / Admin accounts' using errcode = '42501'; end if;
  perform public._pf_check_month(p_from);
  if p_applicable is null then raise exception 'Choose PF ON or OFF'; end if;
  if coalesce(p_mode, '') not in ('auto', 'fixed') then raise exception 'PF amount must be Auto or Fixed'; end if;
  if p_applicable and p_mode = 'fixed' and coalesce(p_fixed, 0) <= 0 then raise exception 'Enter the fixed employee PF amount'; end if;
  if v_uan is not null and v_uan !~ '^[0-9]{12}$' then raise exception 'UAN number must be 12 digits'; end if;
  if p_applicable and v_uan is null then raise exception 'Enter the UAN number'; end if;

  select * into old from public.employee_pf where user_id = p_user and from_date <= p_from order by from_date desc limit 1;

  insert into public.employee_pf (user_id, from_date, applicable, amount_mode, fixed_amount, created_by)
  values (p_user, p_from, p_applicable, p_mode, case when p_mode = 'fixed' then p_fixed end, me.id)
  on conflict (user_id, from_date) do update set applicable = excluded.applicable, amount_mode = excluded.amount_mode,
    fixed_amount = excluded.fixed_amount, created_by = excluded.created_by, created_at = now();

  -- the same UAN as the Joining form (one field)
  if v_uan is not null then
    insert into public.employee_details (user_id, uan_no, updated_by) values (p_user, v_uan, me.id)
    on conflict (user_id) do update set uan_no = excluded.uan_no, updated_at = now(), updated_by = me.id;
  end if;

  perform public._audit('EMPLOYEE_PF', t.username || ' from ' || to_char(p_from, 'DD-MM-YYYY') || ': '
    || case when old.user_id is null then 'not set'
            else (case when old.applicable then 'ON ' || old.amount_mode || coalesce(' ' || old.fixed_amount, '') else 'OFF' end) end
    || ' -> ' || case when p_applicable then 'ON ' || p_mode || case when p_mode = 'fixed' then ' ' || p_fixed else '' end else 'OFF' end);
end $$;

-- Admin only: PF rules from a month
create or replace function public.save_pf_rules(p_from date, p_employee numeric, p_employer numeric, p_eps numeric, p_ceiling numeric, p_apply_ceiling boolean)
returns void
language plpgsql security definer set search_path = public as $$
declare me public.profiles := public._require_active();
begin
  if me.role <> 'Admin' then raise exception 'Only an Admin can change the PF rules' using errcode = '42501'; end if;
  perform public._pf_check_month(p_from);
  insert into public.pf_rules (effective_from, employee_rate, employer_rate, eps_rate, wage_ceiling, apply_ceiling, created_by)
  values (p_from, p_employee, p_employer, p_eps, p_ceiling, coalesce(p_apply_ceiling, true), me.id)
  on conflict (effective_from) do update set employee_rate = excluded.employee_rate, employer_rate = excluded.employer_rate,
    eps_rate = excluded.eps_rate, wage_ceiling = excluded.wage_ceiling, apply_ceiling = excluded.apply_ceiling,
    created_by = excluded.created_by, created_at = now();
  perform public._audit('PF_RULES_SAVE', 'From ' || to_char(p_from, 'FMMonth YYYY') || ': employee ' || p_employee || '%, employer ' || p_employer
    || '%, EPS ' || p_eps || '%, ceiling ' || p_ceiling || case when p_apply_ceiling then ' (applied)' else ' (not applied)' end);
end $$;

-- Admin only: the first month in which the PF buttons are used (null = not started)
create or replace function public.set_pf_switch_month(p_from date) returns void
language plpgsql security definer set search_path = public as $$
declare me public.profiles := public._require_active(); v_old date;
begin
  if me.role <> 'Admin' then raise exception 'Only an Admin can change this' using errcode = '42501'; end if;
  select switch_from into v_old from public.pf_control where id = 1;
  if p_from is not null then perform public._pf_check_month(p_from); end if;
  if v_old is not null then perform public._pf_check_month(v_old); end if;   -- cannot move once that month is finalized
  update public.pf_control set switch_from = p_from, updated_by = me.id, updated_at = now() where id = 1;
  perform public._audit('PF_SWITCH_MONTH', coalesce(to_char(v_old, 'FMMonth YYYY'), 'not set') || ' -> ' || coalesce(to_char(p_from, 'FMMonth YYYY'), 'not set'));
end $$;

revoke all on function public._pf_check_month(date) from public, anon, authenticated;
revoke all on function public.set_employee_pf(uuid, date, boolean, text, numeric, text) from public, anon;
revoke all on function public.save_pf_rules(date, numeric, numeric, numeric, numeric, boolean) from public, anon;
revoke all on function public.set_pf_switch_month(date) from public, anon;
grant execute on function public.set_employee_pf(uuid, date, boolean, text, numeric, text) to authenticated;
grant execute on function public.save_pf_rules(date, numeric, numeric, numeric, numeric, boolean) to authenticated;
grant execute on function public.set_pf_switch_month(date) to authenticated;

notify pgrst, 'reload schema';

-- CHECK after running:
--   select switch_from from public.pf_control;                  -- empty
--   select * from public.pf_rules;                              -- 2000-01-01, 12, 12, 8.33, 25000, true
--   select count(*) from public.employee_pf;                    -- 0

-- =====================================================================
-- ROLLBACK: commented out so it does NOT run with the file. Select the lines below (without the leading "-- "),
-- paste them in the SQL Editor on their own and Run. All saved PF switches and PF rules are lost.
-- UAN numbers, salaries, attendance, leave and Audit Trail lines are NOT touched.
-- =====================================================================
-- drop function if exists public.set_pf_switch_month(date);
-- drop function if exists public.save_pf_rules(date, numeric, numeric, numeric, numeric, boolean);
-- drop function if exists public.set_employee_pf(uuid, date, boolean, text, numeric, text);
-- drop function if exists public._pf_check_month(date);
-- drop table if exists public.employee_pf;
-- drop table if exists public.pf_rules;
-- drop table if exists public.pf_control;
-- notify pgrst, 'reload schema';
